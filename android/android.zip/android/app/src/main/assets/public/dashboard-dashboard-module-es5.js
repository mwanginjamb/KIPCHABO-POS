function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["dashboard-dashboard-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/dashboard/dashboard.page.html":
  /*!*************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/dashboard/dashboard.page.html ***!
    \*************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppDashboardDashboardPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <ion-title class=\"ion-text-center\">Dashboard</ion-title>\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button slot=\"icon-only\" fill=\"clear\" (click)=\"logout()\">\r\n        <ion-icon name=\"exit-outline\" title=\"Logout\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <section class=\"ion-text-center\">\r\n    <ion-icon name=\"Person\"></ion-icon>\r\n    <h4>Welcome, <br>\r\n      {{ username }} \r\n    </h4>\r\n  </section>\r\n\r\n  <ion-grid>\r\n\r\n\r\n     <!----<ion-row>\r\n      <ion-col col-6 col-sm-12 [routerLink]=\"['../farmer']\">\r\n        <ion-card ion-text-center padding color=\"warning\">\r\n            <ion-icon name=\"people\"></ion-icon>\r\n            <h2>Farmers</h2>\r\n        </ion-card>\r\n      </ion-col>\r\n\r\n      <ion-col col-6 col-sm-12 [routerLink]=\"['../collection']\">\r\n        <ion-card ion-text-center padding color=\"success\">\r\n          <ion-icon name=\"leaf\"></ion-icon>\r\n          <h2>Leaf Collection</h2>\r\n      </ion-card>\r\n      </ion-col>\r\n    </ion-row> --->\r\n\r\n\r\n    <ion-row>\r\n      <ion-col col-6 col-sm-12 [routerLink]=\"['../postedsales']\">\r\n        <ion-card ion-text-center padding color=\"warning\">\r\n            <ion-icon name=\"cart\"></ion-icon>\r\n            <h2>Posted Sales</h2>\r\n        </ion-card>\r\n      </ion-col>\r\n\r\n      <ion-col col-6 col-sm-12 [routerLink]=\"['../payments']\">\r\n        <ion-card ion-text-center padding color=\"warning\">\r\n            <ion-icon name=\"card\"></ion-icon>\r\n            <h2>Sales</h2>\r\n        </ion-card>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <ion-row>\r\n      <ion-col col-6 col-sm-12 [routerLink]=\"['../requisitions/released-requisitions']\">\r\n        <ion-card ion-text-center padding color=\"warning\">\r\n            <ion-icon name=\"pricetag\"></ion-icon>\r\n            <h2>Shipped Requisitions</h2>\r\n        </ion-card>\r\n      </ion-col>\r\n\r\n      <ion-col col-6 col-sm-12 [routerLink]=\"['../requisitions']\">\r\n        <ion-card ion-text-center padding color=\"warning\">\r\n            <ion-icon name=\"basket\"></ion-icon>\r\n            <h2>Requisitions</h2>\r\n        </ion-card>\r\n      </ion-col>\r\n\r\n    </ion-row>\r\n\r\n  \r\n\r\n    \r\n<ion-card>\r\n  <ion-card-header>\r\n    <ion-card-title>Reports</ion-card-title>\r\n  </ion-card-header>\r\n</ion-card>\r\n\r\n    <ion-row>\r\n      <ion-col col-6 col-sm-12 (click)=\"showDaily()\">\r\n        <ion-card ion-text-center padding color=\"success\">\r\n            <ion-icon name=\"document\"></ion-icon>\r\n            <h2>Daily Sales</h2>\r\n        </ion-card>\r\n      </ion-col>\r\n\r\n      <ion-col col-6 col-sm-12 (click)=\"showMonthly()\">\r\n        <ion-card ion-text-center padding color=\"success\">\r\n            <ion-icon name=\"document\"></ion-icon>\r\n            <h2>Monthly Sales</h2>\r\n        </ion-card>\r\n      </ion-col>\r\n\r\n     \r\n    </ion-row>\r\n\r\n    <ion-row>\r\n      <ion-col col-6 col-sm-12 (click)=\"showDailyPayments()\">\r\n        <ion-card ion-text-center padding color=\"success\">\r\n            <ion-icon name=\"document\"></ion-icon>\r\n            <h2>D.Payments</h2>\r\n        </ion-card>\r\n      </ion-col>\r\n\r\n      <ion-col col-6 col-sm-12 (click)=\"showMonthlyPayments()\">\r\n        <ion-card ion-text-center padding color=\"success\">\r\n            <ion-icon name=\"document\"></ion-icon>\r\n            <h2>M.Payments</h2>\r\n        </ion-card>\r\n      </ion-col> \r\n    </ion-row>\r\n\r\n    <ion-row>\r\n      <ion-col col-6 col-sm-12 (click)=\"showAvailability()\">\r\n        <ion-card ion-text-center padding color=\"success\">\r\n            <ion-icon name=\"document\"></ion-icon>\r\n            <h2>Stock Availability</h2>\r\n        </ion-card>\r\n      </ion-col> \r\n\r\n      <ion-col col-6 col-sm-12 (click)=\"showMpesa()\">\r\n        <ion-card ion-text-center padding color=\"success\">\r\n          <ion-icon name=\"document\"></ion-icon>\r\n          <h2>Mpesa</h2>\r\n        </ion-card>\r\n      </ion-col>\r\n\r\n    </ion-row>\r\n   \r\n\r\n    \r\n\r\n\r\n  </ion-grid>\r\n\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./src/app/dashboard/dashboard-routing.module.ts":
  /*!*******************************************************!*\
    !*** ./src/app/dashboard/dashboard-routing.module.ts ***!
    \*******************************************************/

  /*! exports provided: DashboardPageRoutingModule */

  /***/
  function srcAppDashboardDashboardRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DashboardPageRoutingModule", function () {
      return DashboardPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _dashboard_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./dashboard.page */
    "./src/app/dashboard/dashboard.page.ts");

    var routes = [{
      path: '',
      component: _dashboard_page__WEBPACK_IMPORTED_MODULE_3__["DashboardPage"]
    }];

    var DashboardPageRoutingModule = function DashboardPageRoutingModule() {
      _classCallCheck(this, DashboardPageRoutingModule);
    };

    DashboardPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], DashboardPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/dashboard/dashboard.module.ts":
  /*!***********************************************!*\
    !*** ./src/app/dashboard/dashboard.module.ts ***!
    \***********************************************/

  /*! exports provided: DashboardPageModule */

  /***/
  function srcAppDashboardDashboardModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DashboardPageModule", function () {
      return DashboardPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _dashboard_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./dashboard-routing.module */
    "./src/app/dashboard/dashboard-routing.module.ts");
    /* harmony import */


    var _dashboard_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./dashboard.page */
    "./src/app/dashboard/dashboard.page.ts");

    var DashboardPageModule = function DashboardPageModule() {
      _classCallCheck(this, DashboardPageModule);
    };

    DashboardPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _dashboard_routing_module__WEBPACK_IMPORTED_MODULE_5__["DashboardPageRoutingModule"]],
      declarations: [_dashboard_page__WEBPACK_IMPORTED_MODULE_6__["DashboardPage"]]
    })], DashboardPageModule);
    /***/
  },

  /***/
  "./src/app/dashboard/dashboard.page.scss":
  /*!***********************************************!*\
    !*** ./src/app/dashboard/dashboard.page.scss ***!
    \***********************************************/

  /*! exports provided: default */

  /***/
  function srcAppDashboardDashboardPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-card {\n  align-content: center;\n  text-align: center;\n}\nion-card ion-icon {\n  font-size: 4em;\n  padding-top: 15px;\n}\nsection > ion-icon {\n  font-size: 4em;\n  padding-top: 15px;\n}\nh2 {\n  font-weight: bold;\n  font-size: 0.9em;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvZGFzaGJvYXJkL0M6XFxVc2Vyc1xcSFAgRUxJVEVCT09LIDg0MCBHNVxcRGVza3RvcFxcS2lwY2hhYm9fcmVtYWtlXFxLSVBDSEFCTy1QT1Mvc3JjXFxhcHBcXGRhc2hib2FyZFxcZGFzaGJvYXJkLnBhZ2Uuc2NzcyIsInNyYy9hcHAvZGFzaGJvYXJkL2Rhc2hib2FyZC5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDRSxxQkFBQTtFQUNBLGtCQUFBO0FDQ0Y7QURDRTtFQUNFLGNBQUE7RUFDQSxpQkFBQTtBQ0NKO0FES0E7RUFDRSxjQUFBO0VBQ0EsaUJBQUE7QUNGRjtBRElBO0VBQ0UsaUJBQUE7RUFDQSxnQkFBQTtBQ0RGIiwiZmlsZSI6InNyYy9hcHAvZGFzaGJvYXJkL2Rhc2hib2FyZC5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24tY2FyZCB7XHJcbiAgYWxpZ24tY29udGVudDogY2VudGVyO1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuXHJcbiAgaW9uLWljb24ge1xyXG4gICAgZm9udC1zaXplOiA0ZW07XHJcbiAgICBwYWRkaW5nLXRvcDogMTVweDtcclxuICB9XHJcbiAgXHJcblxyXG59XHJcblxyXG5zZWN0aW9uID4gaW9uLWljb24ge1xyXG4gIGZvbnQtc2l6ZTogNGVtO1xyXG4gIHBhZGRpbmctdG9wOiAxNXB4O1xyXG59XHJcbmgyIHtcclxuICBmb250LXdlaWdodDogYm9sZDtcclxuICBmb250LXNpemU6IDAuOWVtO1xyXG59XHJcbiIsImlvbi1jYXJkIHtcbiAgYWxpZ24tY29udGVudDogY2VudGVyO1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG5pb24tY2FyZCBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogNGVtO1xuICBwYWRkaW5nLXRvcDogMTVweDtcbn1cblxuc2VjdGlvbiA+IGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiA0ZW07XG4gIHBhZGRpbmctdG9wOiAxNXB4O1xufVxuXG5oMiB7XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICBmb250LXNpemU6IDAuOWVtO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/dashboard/dashboard.page.ts":
  /*!*********************************************!*\
    !*** ./src/app/dashboard/dashboard.page.ts ***!
    \*********************************************/

  /*! exports provided: DashboardPage */

  /***/
  function srcAppDashboardDashboardPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DashboardPage", function () {
      return DashboardPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _auth_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../auth/auth-service */
    "./src/app/auth/auth-service.ts");

    var DashboardPage = /*#__PURE__*/function () {
      function DashboardPage(router, auth) {
        _classCallCheck(this, DashboardPage);

        this.router = router;
        this.auth = auth;
        this.username = '';
      }

      _createClass(DashboardPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.fetchUsername();
        }
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.fetchUsername();
        }
      }, {
        key: "ionViewDidEnter",
        value: function ionViewDidEnter() {
          this.fetchUsername();
        }
      }, {
        key: "fetchUsername",
        value: function fetchUsername() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var employee;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.auth.getEmployee();

                  case 2:
                    employee = _context.sent;

                    if (typeof employee === 'object' && employee.First_Name && employee.Last_Name) {
                      this.username = "".concat(employee.First_Name, " ").concat(employee.Last_Name);
                    }

                  case 4:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "showDaily",
        value: function showDaily() {
          return this.router.navigate(['./postedsales/dailyreport']);
        }
      }, {
        key: "showMonthly",
        value: function showMonthly() {
          return this.router.navigate(['./postedsales/monthlyreport']);
        }
      }, {
        key: "showDailyPayments",
        value: function showDailyPayments() {
          return this.router.navigate(['./payments/daily-report']);
        }
      }, {
        key: "showMonthlyPayments",
        value: function showMonthlyPayments() {
          return this.router.navigate(['./payments/monthly-report']);
        }
      }, {
        key: "showAvailability",
        value: function showAvailability() {
          return this.router.navigate(['./items/availability']);
        }
      }, {
        key: "showMpesa",
        value: function showMpesa() {
          return this.router.navigate(['./payments/mpesa']);
        }
      }, {
        key: "logout",
        value: function logout() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.auth.logout();

                  case 2:
                    this.router.navigate(['./auth']);

                  case 3:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }]);

      return DashboardPage;
    }();

    DashboardPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]
      }];
    };

    DashboardPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-dashboard',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./dashboard.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/dashboard/dashboard.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./dashboard.page.scss */
      "./src/app/dashboard/dashboard.page.scss"))["default"]]
    })], DashboardPage);
    /***/
  }
}]);
//# sourceMappingURL=dashboard-dashboard-module-es5.js.map