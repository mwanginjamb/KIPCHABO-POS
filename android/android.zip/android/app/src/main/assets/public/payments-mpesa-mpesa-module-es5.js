function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["payments-mpesa-mpesa-module"], {
  /***/
  "./src/app/orders/order.service.ts":
  /*!*****************************************!*\
    !*** ./src/app/orders/order.service.ts ***!
    \*****************************************/

  /*! exports provided: OrderService */

  /***/
  function srcAppOrdersOrderServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "OrderService", function () {
      return OrderService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");

    var OrderService = /*#__PURE__*/function () {
      // private items  = new BehaviorSubject<[]>([]) ;
      function OrderService(http) {
        _classCallCheck(this, OrderService);

        this.http = http;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
      }

      _createClass(OrderService, [{
        key: "orders",
        get: function get() {
          return this.http.get("".concat(this.url, "site/saleinvoices")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        } // Create New Sales Invoice

      }, {
        key: "createInvoice",
        value: function createInvoice() {
          return this.http.get("".concat(this.url, "site/create-invoice"));
        } // Retrieve Sales Invoice Card / Details

      }, {
        key: "ordercard",
        value: function ordercard(id) {
          return this.http.get("".concat(this.url, "site/saleinvoice/?id=").concat(id));
        } // Post Lines Data

      }, {
        key: "postLine",
        value: function postLine(line) {
          return this.http.post("".concat(this.url, "site/addsalesinvoiceline"), JSON.stringify(line));
        } // Update Line

      }, {
        key: "updateInvoiceLine",
        value: function updateInvoiceLine(line) {
          return this.http.post("".concat(this.url, "site/updatesalesinvoiceline"), JSON.stringify(line));
        } // Fetch Line to Update

      }, {
        key: "getLine",
        value: function getLine(docId, LineNo) {
          return this.http.get("".concat(this.url, "site/getsalesinvoiceline?Document_No=").concat(docId, "&Line_No=").concat(LineNo));
        } // Post Invoice Header

      }, {
        key: "postInvoice",
        value: function postInvoice(invoice) {
          invoice.Posting_Date = this.formatDate(invoice.Posting_Date);
          invoice.Due_Date = this.formatDate(invoice.Due_Date);
          return this.http.post("".concat(this.url, "site/update-invoice"), JSON.stringify(invoice));
        } // Get Customers

      }, {
        key: "Customers",
        get: function get() {
          return this.http.get("".concat(this.url, "site/receipting-customers")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "postSalesInvoice",
        value: function postSalesInvoice(No) {
          return this.http.get("".concat(this.url, "site/postsaleinvoice?No=").concat(No));
        } // Format date utility

      }, {
        key: "formatDate",
        value: function formatDate(datestring) {
          // Format Date to YYYY-MM-DD
          var recDate = new Date(datestring);
          var month = recDate.getMonth() + 1 > 9 ? recDate.getMonth() + 1 : "0" + (recDate.getMonth() + 1);
          var day = recDate.getDate() > 9 ? recDate.getDate() : "0" + recDate.getDate();
          return "".concat(recDate.getFullYear(), "-").concat(month, "-").concat(day);
        }
      }]);

      return OrderService;
    }();

    OrderService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }];
    };

    OrderService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], OrderService);
    /***/
  },

  /***/
  "./src/app/payments/payments.service.ts":
  /*!**********************************************!*\
    !*** ./src/app/payments/payments.service.ts ***!
    \**********************************************/

  /*! exports provided: PaymentsService */

  /***/
  function srcAppPaymentsPaymentsServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PaymentsService", function () {
      return PaymentsService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _orders_order_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../orders/order.service */
    "./src/app/orders/order.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");

    var PaymentsService = /*#__PURE__*/function () {
      function PaymentsService(http, orderService, toastCtrl) {
        _classCallCheck(this, PaymentsService);

        this.http = http;
        this.orderService = orderService;
        this.toastCtrl = toastCtrl;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].url;
        this._refresh$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__["Subject"]();
      } // Define a synthetic getter for the subject


      _createClass(PaymentsService, [{
        key: "refresh$",
        get: function get() {
          return this._refresh$;
        }
      }, {
        key: "newPayment",
        value: function newPayment(receipt) {
          return this.http.post("".concat(this.url, "site/cash-sale"), JSON.stringify(receipt));
        }
      }, {
        key: "updateReceipt",
        value: function updateReceipt(receipt) {
          return this.http.post("".concat(this.url, "site/cash-sale"), JSON.stringify(receipt));
        }
      }, {
        key: "getPayments",
        value: function getPayments(userID) {
          return this.http.get("".concat(this.url, "site/get?service=POSReceiptList&userid=").concat(userID)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "getPayment",
        value: function getPayment(id) {
          return this.http.get("".concat(this.url, "site/receipt/?id=").concat(id)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "Banks",
        get: function get() {
          return this.http.get("".concat(this.url, "site/get?service=BankAccounts")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "getLine",
        value: function getLine(Key) {
          return this.http.get("".concat(this.url, "site/cash-sale-line?Key=").concat(Key));
        }
      }, {
        key: "suggestlines",
        value: function suggestlines(receiptNo, customerNo) {
          return this.http.get("".concat(this.url, "site/suggestlines?receiptNo=").concat(receiptNo, "&customerNo=").concat(customerNo)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        } // Post Lines Data

      }, {
        key: "postLine",
        value: function postLine(line) {
          var _this = this;

          return this.http.post("".concat(this.url, "site/cash-sale-line"), JSON.stringify(line)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function () {
            _this._refresh$.next();
          }));
        } // Update Line

      }, {
        key: "updateLine",
        value: function updateLine(line) {
          var _this2 = this;

          return this.http.post("".concat(this.url, "site/cash-sale-line"), JSON.stringify(line)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function () {
            _this2._refresh$.next();
          }));
        }
      }, {
        key: "Customers",
        get: function get() {
          return this.http.get("".concat(this.url, "site/receipting-customers")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
        /*
         * Get Customer By Search Name
         */

      }, {
        key: "Customer",
        value: function Customer(searchName) {
          return this.http.get("".concat(this.url, "site/receipting-customers?searchName=").concat(searchName)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
        /*
         * Get Customer By Sales Person Code
         */

      }, {
        key: "CustomerBySalesPerson",
        value: function CustomerBySalesPerson(salesPersonCode) {
          return this.http.get("".concat(this.url, "site/receipting-customers?Salesperson_Code=").concat(salesPersonCode)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        } // Get CustomerPriceGroups

      }, {
        key: "CustomerPriceGroups",
        value: function CustomerPriceGroups() {
          return this.http.get("".concat(this.url, "site/get?service=CustomerPriceGroups")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "Mpesa",
        value: function Mpesa() {
          return this.http.get("".concat(this.url, "site/get?service=MPESATransactions")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "selectLine",
        value: function selectLine(CustomerNo, Line, ReceiptNo) {
          var payload = {
            Customer_No: CustomerNo,
            Line_No: Line,
            Receipt_No: ReceiptNo
          };
          return this.http.post("".concat(this.url, "site/updatecashreceiptline"), JSON.stringify(payload));
        }
      }, {
        key: "setAmountToReceipt",
        value: function setAmountToReceipt(CustomerNo, Line, ReceiptNo, AmountToReceipt) {
          var payload = {
            Customer_No: CustomerNo,
            Line_No: Line,
            Receipt_No: ReceiptNo,
            Amount_To_Receipt: AmountToReceipt
          }; // console.log(payload); return;

          return this.http.post("".concat(this.url, "site/updateamounttoreceipt"), JSON.stringify(payload));
        }
      }, {
        key: "postReceipt",
        value: function postReceipt(No) {
          return this.http.get("".concat(this.url, "site/postreceipt?No=").concat(No));
        }
      }, {
        key: "getTotals",
        value: function getTotals(elements, subjectColumn) {
          var sum = 0;
          elements.forEach(function (obj) {
            // console.log(obj);
            for (var property in obj) {
              if (property === subjectColumn && !isNaN(+obj[property])) {
                // console.log(+obj[property]);
                sum += +obj[property];
              }
            }
          });
          return sum;
        }
      }, {
        key: "showToast",
        value: function showToast(text) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.toastCtrl.create({
                      message: text,
                      duration: 4000,
                      position: 'top'
                    }).then(function (toastEl) {
                      toastEl.present();
                    });

                  case 2:
                    return _context.abrupt("return", _context.sent);

                  case 3:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "formatDate",
        value: function formatDate(date) {
          return this.orderService.formatDate(date);
        }
      }, {
        key: "FilterReceipts",
        value: function FilterReceipts(startDate, userID) {
          return this.http.get("".concat(this.url, "site/filterpayments?startdate=").concat(startDate, "&userid=").concat(userID)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "FilterReceiptsbyRange",
        value: function FilterReceiptsbyRange(startDate, endDate, userID) {
          return this.http.get("".concat(this.url, "site/filterpayments?startdate=").concat(startDate, "&enddate=").concat(endDate, "&userid=").concat(userID)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }]);

      return PaymentsService;
    }();

    PaymentsService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]
      }, {
        type: _orders_order_service__WEBPACK_IMPORTED_MODULE_5__["OrderService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"]
      }];
    };

    PaymentsService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], PaymentsService);
    /***/
  },

  /***/
  "./src/app/utility.service.ts":
  /*!************************************!*\
    !*** ./src/app/utility.service.ts ***!
    \************************************/

  /*! exports provided: UtilityService */

  /***/
  function srcAppUtilityServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "UtilityService", function () {
      return UtilityService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var UtilityService = /*#__PURE__*/function () {
      function UtilityService(toastCtrl, alertCtrl, loadingCtrl) {
        _classCallCheck(this, UtilityService);

        this.toastCtrl = toastCtrl;
        this.alertCtrl = alertCtrl;
        this.loadingCtrl = loadingCtrl;
      }

      _createClass(UtilityService, [{
        key: "formatDate",
        value: function formatDate(datestring) {
          // Format Date to YYYY-MM-DD
          var recDate = new Date(datestring);
          var month = recDate.getMonth() + 1 > 9 ? recDate.getMonth() + 1 : "0" + (recDate.getMonth() + 1);
          var day = recDate.getDate() > 9 ? recDate.getDate() : "0" + recDate.getDate();
          return "".concat(recDate.getFullYear(), "-").concat(month, "-").concat(day);
        }
      }, {
        key: "showToast",
        value: function showToast(text) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var toastEl;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    toastEl = this.toastCtrl.create({
                      message: text,
                      duration: 4000,
                      position: 'top'
                    });
                    _context2.next = 3;
                    return toastEl;

                  case 3:
                    _context2.sent.present();

                  case 4:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "showAlert",
        value: function showAlert(text) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var alertEl;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.alertCtrl.create({
                      header: 'Operation Error',
                      message: 'Message : ' + text,
                      buttons: [{
                        text: 'Okay'
                      }]
                    });

                  case 2:
                    alertEl = _context3.sent;
                    _context3.next = 5;
                    return alertEl.present();

                  case 5:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "presentLoading",
        value: function presentLoading(message) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            var loading;
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    _context4.next = 2;
                    return this.loadingCtrl.create({
                      spinner: 'dots',
                      animated: true,
                      message: message ? message : 'Loading Data...'
                    });

                  case 2:
                    loading = _context4.sent;
                    _context4.next = 5;
                    return loading.present();

                  case 5:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this);
          }));
        }
      }]);

      return UtilityService;
    }();

    UtilityService.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]
      }];
    };

    UtilityService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], UtilityService);
    /***/
  }
}]);
//# sourceMappingURL=payments-mpesa-mpesa-module-es5.js.map