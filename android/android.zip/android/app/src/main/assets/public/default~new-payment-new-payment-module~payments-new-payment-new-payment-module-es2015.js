(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~new-payment-new-payment-module~payments-new-payment-new-payment-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/payments/new-payment/new-payment.page.html":
/*!**************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/payments/new-payment/new-payment.page.html ***!
  \**************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button defaultHref=\"payments\"></ion-back-button>\r\n     </ion-buttons>\r\n    <ion-title> New Cash Receipt Card -  {{ card?.POS_Receipt_No}} </ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n\r\n<ion-content>\r\n\r\n  \r\n  <ion-row>\r\n    <ion-col >\r\n      <ion-item>\r\n        <ion-label position=\"floating\">Receipt No.</ion-label>\r\n        <ion-input [(ngModel)]=\"card.POS_Receipt_No\" readonly></ion-input>\r\n      </ion-item>\r\n    </ion-col>\r\n\r\n    <ion-col >\r\n      \r\n        <ion-item>\r\n          <ion-label position=\"floating\">Balance Amount</ion-label>\r\n          <ion-input [(ngModel)]=\"card.Balance_Amount\" readonly></ion-input>\r\n          </ion-item>\r\n      \r\n    </ion-col>\r\n  </ion-row>\r\n\r\n  <ion-row>\r\n\r\n    <ion-col >\r\n      <ion-item>\r\n        <ion-label position=\"floating\">Customer.</ion-label>                \r\n        <ion-select [(ngModel)]=\"card.Customer_No\" (ionChange)=\"updateReceipt(card)\" name=\"Customer_No\"\r\n          [selectedText]=\"card.Customer_Name\"\r\n          placeholder=\"Select ...\">\r\n          <ion-select-option *ngFor=\"let cust of customers\" [value]=\"cust.No\">{{cust.Name}}</ion-select-option>\r\n        </ion-select>\r\n      </ion-item>\r\n    </ion-col>\r\n\r\n    <ion-col>\r\n      <ion-item>\r\n        <ion-label position=\"floating\">Type of Sale</ion-label>\r\n        <ion-select [(ngModel)]=\"card.Type_Of_Sale\" (ionChange)=\"updateReceipt(card)\" name=\"Type_Of_Sale\"\r\n          [selectedText]=\"card.Type_Of_Sale\" placeholder=\"Select ...\">\r\n          <ion-select-option *ngFor=\"let st of saleType\" [value]=\"st.Code\">{{st.Code}}</ion-select-option>\r\n        </ion-select>\r\n      </ion-item>\r\n    </ion-col>\r\n\r\n    \r\n  </ion-row>\r\n\r\n\r\n  <ion-row>\r\n    <ion-col >\r\n      <ion-item>\r\n        <ion-label position=\"floating\">Receipt Date: </ion-label>\r\n        <ion-datetime type=\"date\" name=\"Receipt_Date\" [(ngModel)]=\"card.Receipt_Date\" (ionChange)=\"updateReceipt(card)\" readonly></ion-datetime>\r\n      </ion-item>\r\n    </ion-col>\r\n\r\n    <ion-col>\r\n      <ion-item>\r\n        <ion-label position=\"floating\">Reference No</ion-label>\r\n        <ion-input [(ngModel)]=\"card.Reference_No\" (ionBlur)=\"updateReceipt(card)\"></ion-input>\r\n      </ion-item>\r\n    </ion-col>\r\n\r\n    \r\n  </ion-row>\r\n\r\n  \r\n  <!--<ion-row>\r\n    <ion-col>\r\n      <ion-item>\r\n        <ion-label position=\"floating\">Key </ion-label>\r\n        <ion-input type=\"text\" name=\"Key\" [(ngModel)]=\"card.Key\" readonly></ion-input>\r\n      </ion-item>\r\n    </ion-col>\r\n  \r\n    <ion-col>\r\n      <ion-item>\r\n        <ion-label position=\"floating\">Price Group</ion-label>\r\n  \r\n        <ion-select [(ngModel)]=\"card.Price_Group\" (ionChange)=\"updateReceipt(card)\" name=\"Price_Group\"\r\n          [selectedText]=\"card.Price_Group\" placeholder=\"Select ...\">\r\n          <ion-select-option *ngFor=\"let pg of priceGroups\" [value]=\"pg.Code\">{{pg.Description}}</ion-select-option>\r\n        </ion-select>\r\n  \r\n      </ion-item>\r\n    </ion-col>\r\n  \r\n  \r\n  </ion-row>-->\r\n  <ion-row>\r\n    <ion-col>\r\n      <ion-list>\r\n        <ion-item>\r\n          <ion-button type=\"button\" outline color=\"primary\" (click)=\"toView()\">Add Receipt Lines</ion-button>\r\n        </ion-item>\r\n      </ion-list>\r\n    </ion-col>\r\n  </ion-row>\r\n\r\n\r\n</ion-content>\r\n");

/***/ }),

/***/ "./src/app/models/receipt.model.ts":
/*!*****************************************!*\
  !*** ./src/app/models/receipt.model.ts ***!
  \*****************************************/
/*! exports provided: Receipt */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Receipt", function() { return Receipt; });
class Receipt {
    constructor(Key, POS_Receipt_No, Receipt_Date, Type_Of_Sale, Customer_No, Customer_Name, Bank_Account_No, Bank_Account_Name, Global_Dimension_1_Code, Reference_No, Price_Group, Total_Amount, Created_By, Balance_Amount, VAT_Amount, Amount_Inc_VAT, POS_Receipt_Lines) {
        this.Key = Key;
        this.POS_Receipt_No = POS_Receipt_No;
        this.Receipt_Date = Receipt_Date;
        this.Type_Of_Sale = Type_Of_Sale;
        this.Customer_No = Customer_No;
        this.Customer_Name = Customer_Name;
        this.Bank_Account_No = Bank_Account_No;
        this.Bank_Account_Name = Bank_Account_Name;
        this.Global_Dimension_1_Code = Global_Dimension_1_Code;
        this.Reference_No = Reference_No;
        this.Price_Group = Price_Group;
        this.Total_Amount = Total_Amount;
        this.Created_By = Created_By;
        this.Balance_Amount = Balance_Amount;
        this.VAT_Amount = VAT_Amount;
        this.Amount_Inc_VAT = Amount_Inc_VAT;
        this.POS_Receipt_Lines = POS_Receipt_Lines;
    }
}


/***/ }),

/***/ "./src/app/payments/new-payment/new-payment-routing.module.ts":
/*!********************************************************************!*\
  !*** ./src/app/payments/new-payment/new-payment-routing.module.ts ***!
  \********************************************************************/
/*! exports provided: NewPaymentPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewPaymentPageRoutingModule", function() { return NewPaymentPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _new_payment_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./new-payment.page */ "./src/app/payments/new-payment/new-payment.page.ts");




const routes = [
    {
        path: '',
        component: _new_payment_page__WEBPACK_IMPORTED_MODULE_3__["NewPaymentPage"]
    }
];
let NewPaymentPageRoutingModule = class NewPaymentPageRoutingModule {
};
NewPaymentPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], NewPaymentPageRoutingModule);



/***/ }),

/***/ "./src/app/payments/new-payment/new-payment.module.ts":
/*!************************************************************!*\
  !*** ./src/app/payments/new-payment/new-payment.module.ts ***!
  \************************************************************/
/*! exports provided: NewPaymentPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewPaymentPageModule", function() { return NewPaymentPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _new_payment_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./new-payment-routing.module */ "./src/app/payments/new-payment/new-payment-routing.module.ts");
/* harmony import */ var _new_payment_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./new-payment.page */ "./src/app/payments/new-payment/new-payment.page.ts");
/* harmony import */ var _new_cash_line_new_cash_line_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../new-cash-line/new-cash-line.component */ "./src/app/payments/new-cash-line/new-cash-line.component.ts");








let NewPaymentPageModule = class NewPaymentPageModule {
};
NewPaymentPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _new_payment_routing_module__WEBPACK_IMPORTED_MODULE_5__["NewPaymentPageRoutingModule"]
        ],
        entryComponents: [_new_cash_line_new_cash_line_component__WEBPACK_IMPORTED_MODULE_7__["NewCashLineComponent"]],
        declarations: [_new_payment_page__WEBPACK_IMPORTED_MODULE_6__["NewPaymentPage"], _new_cash_line_new_cash_line_component__WEBPACK_IMPORTED_MODULE_7__["NewCashLineComponent"]]
    })
], NewPaymentPageModule);



/***/ }),

/***/ "./src/app/payments/new-payment/new-payment.page.scss":
/*!************************************************************!*\
  !*** ./src/app/payments/new-payment/new-payment.page.scss ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BheW1lbnRzL25ldy1wYXltZW50L25ldy1wYXltZW50LnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/payments/new-payment/new-payment.page.ts":
/*!**********************************************************!*\
  !*** ./src/app/payments/new-payment/new-payment.page.ts ***!
  \**********************************************************/
/*! exports provided: NewPaymentPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewPaymentPage", function() { return NewPaymentPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _payments_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../payments.service */ "./src/app/payments/payments.service.ts");
/* harmony import */ var src_app_models_receipt_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/models/receipt.model */ "./src/app/models/receipt.model.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _new_cash_line_new_cash_line_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../new-cash-line/new-cash-line.component */ "./src/app/payments/new-cash-line/new-cash-line.component.ts");
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/auth/auth-service */ "./src/app/auth/auth-service.ts");
/* harmony import */ var src_app_utility_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/utility.service */ "./src/app/utility.service.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");










let NewPaymentPage = class NewPaymentPage {
    constructor(paymentService, authService, router, toastCtrl, alertCtrl, popover, modalCtrl, utilitySvc) {
        this.paymentService = paymentService;
        this.authService = authService;
        this.router = router;
        this.toastCtrl = toastCtrl;
        this.alertCtrl = alertCtrl;
        this.popover = popover;
        this.modalCtrl = modalCtrl;
        this.utilitySvc = utilitySvc;
        this.saleType = [
            { 'type': 'Cash', 'Code': 'Cash' },
            { 'type': 'Credit', 'Code': 'Credit' }
        ];
        this.card = new src_app_models_receipt_model__WEBPACK_IMPORTED_MODULE_3__["Receipt"]();
    }
    ngOnInit() {
        this.setUser();
        this.DismissPopover();
        this.FetchBanks();
        this.FetchPriceGroups();
        this.newPayment();
    }
    ionViewWillEnter() {
        this.setUser();
    }
    ionViewDidEnter() {
        if (this.userID) {
            this.FetchCustomers();
        }
    }
    setUser() {
        var _a;
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.user = yield this.authService.getUser();
            this.Store_Code = this.user.Store_Code;
            this.userID = (_a = this.user) === null || _a === void 0 ? void 0 : _a.User_ID;
            console.log(this.userID);
        });
    }
    newPayment() {
        var _a;
        this.card.Created_By = (_a = this.user) === null || _a === void 0 ? void 0 : _a.User_ID;
        this.paymentSub = this.paymentService.newPayment(this.card).subscribe(receipt => {
            this.card = receipt;
            const curr = new Date();
            const formattedDate = this.paymentService.formatDate(curr);
            // this.card.Posting_Date = formattedDate;
        });
    }
    updateReceipt($event) {
        var _a;
        this.card.Created_By = (_a = this.user) === null || _a === void 0 ? void 0 : _a.User_ID;
        this.updateSub = this.paymentService.updateReceipt(this.card).subscribe(res => {
            if (typeof res === 'string') {
                // this.utilitySvc.showAlert(res);
                return false;
            }
            if (typeof res === 'object') {
                Object.assign(this.card, res);
                this.toastCtrl.create({
                    message: `Receipt Updated Successfully.`,
                    duration: 2000,
                    position: 'top'
                }).then((toastData) => {
                    toastData.present();
                });
            }
        }, error => {
            this.alertCtrl.create({
                header: 'New Payment Error!',
                message: 'Connection problem: ' + error,
                buttons: [{ text: 'Okay' }]
            })
                .then(alertEl => {
                alertEl.present();
            });
        });
    }
    FetchBanks() {
        this.bankSub = this.paymentService.Banks.subscribe(result => {
            this.banks = result;
        });
    }
    Suggestlines(receiptNo, customerNo) {
        this.suggestLinesSub = this.paymentService.suggestlines(receiptNo, customerNo).subscribe(res => {
            if (res.return_value > 0) {
                // Show a Toast Notification
                this.toastCtrl.create({
                    message: `Invoice Lines Suggested Successfully.`,
                    duration: 2000,
                    position: 'top'
                }).then((toastData) => {
                    toastData.present();
                    this.router.navigate(['/', 'payments', receiptNo]);
                });
            }
            else {
                console.log(res);
                this.alertCtrl.create({
                    header: 'Operation Error',
                    message: 'Message : ' + res,
                    buttons: [{ text: 'Okay' }]
                }).then(alertEl => {
                    alertEl.present();
                });
            }
        }, error => {
            console.log(error.error);
            this.alertCtrl.create({
                header: 'Service Error!',
                message: 'Connection problem: ' + error,
                buttons: [{ text: 'Okay' }]
            })
                .then(alertEl => {
                alertEl.present();
            });
        });
    }
    onAddLine(POS_Receipt_No) {
        this, this.modalCtrl.create({
            component: _new_cash_line_new_cash_line_component__WEBPACK_IMPORTED_MODULE_6__["NewCashLineComponent"],
            componentProps: { receiptNo: POS_Receipt_No }
        })
            .then(modalEl => {
            modalEl.present();
        });
    }
    FetchCustomers() {
        console.log(`User Found....`);
        console.table(this.user);
        this.utilitySvc.presentLoading('Loading Customers ....');
        this.customerListSub = this.paymentService.CustomerBySalesPerson(this === null || this === void 0 ? void 0 : this.userID)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["finalize"])(() => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.utilitySvc.loadingCtrl.dismiss();
        })))
            .subscribe(cust => {
            this.customers = cust;
        });
    }
    FetchPriceGroups() {
        this.priceGroupsSub = this.paymentService.CustomerPriceGroups().subscribe(grps => {
            this.priceGroups = grps;
        });
    }
    DismissPopover() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.popover.dismiss();
        });
    }
    toView() {
        return this.router.navigate(['/', 'payments', this.card.POS_Receipt_No]);
    }
    ngOnDestroy() {
        if (this.paymentSub) {
            this.paymentSub.unsubscribe();
        }
        else if (this.bankSub) {
            this.bankSub.unsubscribe();
        }
        else if (this.customerListSub) {
            this.customerListSub.unsubscribe();
        }
        else if (this.suggestLinesSub) {
            this.suggestLinesSub.unsubscribe();
        }
        else if (this.updateSub) {
            this.updateSub.unsubscribe();
        }
        else if (this.priceGroupsSub) {
            this.priceGroupsSub.unsubscribe();
        }
    }
};
NewPaymentPage.ctorParameters = () => [
    { type: _payments_service__WEBPACK_IMPORTED_MODULE_2__["PaymentsService"] },
    { type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_7__["AuthService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["PopoverController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"] },
    { type: src_app_utility_service__WEBPACK_IMPORTED_MODULE_8__["UtilityService"] }
];
NewPaymentPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-new-payment',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./new-payment.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/payments/new-payment/new-payment.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./new-payment.page.scss */ "./src/app/payments/new-payment/new-payment.page.scss")).default]
    })
], NewPaymentPage);



/***/ })

}]);
//# sourceMappingURL=default~new-payment-new-payment-module~payments-new-payment-new-payment-module-es2015.js.map