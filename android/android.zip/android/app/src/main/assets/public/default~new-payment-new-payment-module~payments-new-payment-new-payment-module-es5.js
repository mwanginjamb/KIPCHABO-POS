function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~new-payment-new-payment-module~payments-new-payment-new-payment-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/payments/new-payment/new-payment.page.html":
  /*!**************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/payments/new-payment/new-payment.page.html ***!
    \**************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPaymentsNewPaymentNewPaymentPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button defaultHref=\"payments\"></ion-back-button>\r\n     </ion-buttons>\r\n    <ion-title> New Cash Receipt Card -  {{ card?.POS_Receipt_No}} </ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n\r\n<ion-content>\r\n\r\n  \r\n  <ion-row>\r\n    <ion-col >\r\n      <ion-item>\r\n        <ion-label position=\"floating\">Receipt No.</ion-label>\r\n        <ion-input [(ngModel)]=\"card.POS_Receipt_No\" readonly></ion-input>\r\n      </ion-item>\r\n    </ion-col>\r\n\r\n    <ion-col >\r\n      \r\n        <ion-item>\r\n          <ion-label position=\"floating\">Balance Amount</ion-label>\r\n          <ion-input [(ngModel)]=\"card.Balance_Amount\" readonly></ion-input>\r\n          </ion-item>\r\n      \r\n    </ion-col>\r\n  </ion-row>\r\n\r\n  <ion-row>\r\n\r\n    <ion-col >\r\n      <ion-item>\r\n        <ion-label position=\"floating\">Customer.</ion-label>                \r\n        <ion-select [(ngModel)]=\"card.Customer_No\" (ionChange)=\"updateReceipt(card)\" name=\"Customer_No\"\r\n          [selectedText]=\"card.Customer_Name\"\r\n          placeholder=\"Select ...\">\r\n          <ion-select-option *ngFor=\"let cust of customers\" [value]=\"cust.No\">{{cust.Name}}</ion-select-option>\r\n        </ion-select>\r\n      </ion-item>\r\n    </ion-col>\r\n\r\n    <ion-col>\r\n      <ion-item>\r\n        <ion-label position=\"floating\">Type of Sale</ion-label>\r\n        <ion-select [(ngModel)]=\"card.Type_Of_Sale\" (ionChange)=\"updateReceipt(card)\" name=\"Type_Of_Sale\"\r\n          [selectedText]=\"card.Type_Of_Sale\" placeholder=\"Select ...\">\r\n          <ion-select-option *ngFor=\"let st of saleType\" [value]=\"st.Code\">{{st.Code}}</ion-select-option>\r\n        </ion-select>\r\n      </ion-item>\r\n    </ion-col>\r\n\r\n    \r\n  </ion-row>\r\n\r\n\r\n  <ion-row>\r\n    <ion-col >\r\n      <ion-item>\r\n        <ion-label position=\"floating\">Receipt Date: </ion-label>\r\n        <ion-datetime type=\"date\" name=\"Receipt_Date\" [(ngModel)]=\"card.Receipt_Date\" (ionChange)=\"updateReceipt(card)\" readonly></ion-datetime>\r\n      </ion-item>\r\n    </ion-col>\r\n\r\n    <ion-col>\r\n      <ion-item>\r\n        <ion-label position=\"floating\">Reference No</ion-label>\r\n        <ion-input [(ngModel)]=\"card.Reference_No\" (ionBlur)=\"updateReceipt(card)\"></ion-input>\r\n      </ion-item>\r\n    </ion-col>\r\n\r\n    \r\n  </ion-row>\r\n\r\n  \r\n  <!--<ion-row>\r\n    <ion-col>\r\n      <ion-item>\r\n        <ion-label position=\"floating\">Key </ion-label>\r\n        <ion-input type=\"text\" name=\"Key\" [(ngModel)]=\"card.Key\" readonly></ion-input>\r\n      </ion-item>\r\n    </ion-col>\r\n  \r\n    <ion-col>\r\n      <ion-item>\r\n        <ion-label position=\"floating\">Price Group</ion-label>\r\n  \r\n        <ion-select [(ngModel)]=\"card.Price_Group\" (ionChange)=\"updateReceipt(card)\" name=\"Price_Group\"\r\n          [selectedText]=\"card.Price_Group\" placeholder=\"Select ...\">\r\n          <ion-select-option *ngFor=\"let pg of priceGroups\" [value]=\"pg.Code\">{{pg.Description}}</ion-select-option>\r\n        </ion-select>\r\n  \r\n      </ion-item>\r\n    </ion-col>\r\n  \r\n  \r\n  </ion-row>-->\r\n  <ion-row>\r\n    <ion-col>\r\n      <ion-list>\r\n        <ion-item>\r\n          <ion-button type=\"button\" outline color=\"primary\" (click)=\"toView()\">Add Receipt Lines</ion-button>\r\n        </ion-item>\r\n      </ion-list>\r\n    </ion-col>\r\n  </ion-row>\r\n\r\n\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./src/app/models/receipt.model.ts":
  /*!*****************************************!*\
    !*** ./src/app/models/receipt.model.ts ***!
    \*****************************************/

  /*! exports provided: Receipt */

  /***/
  function srcAppModelsReceiptModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Receipt", function () {
      return Receipt;
    });

    var Receipt = function Receipt(Key, POS_Receipt_No, Receipt_Date, Type_Of_Sale, Customer_No, Customer_Name, Bank_Account_No, Bank_Account_Name, Global_Dimension_1_Code, Reference_No, Price_Group, Total_Amount, Created_By, Balance_Amount, VAT_Amount, Amount_Inc_VAT, POS_Receipt_Lines) {
      _classCallCheck(this, Receipt);

      this.Key = Key;
      this.POS_Receipt_No = POS_Receipt_No;
      this.Receipt_Date = Receipt_Date;
      this.Type_Of_Sale = Type_Of_Sale;
      this.Customer_No = Customer_No;
      this.Customer_Name = Customer_Name;
      this.Bank_Account_No = Bank_Account_No;
      this.Bank_Account_Name = Bank_Account_Name;
      this.Global_Dimension_1_Code = Global_Dimension_1_Code;
      this.Reference_No = Reference_No;
      this.Price_Group = Price_Group;
      this.Total_Amount = Total_Amount;
      this.Created_By = Created_By;
      this.Balance_Amount = Balance_Amount;
      this.VAT_Amount = VAT_Amount;
      this.Amount_Inc_VAT = Amount_Inc_VAT;
      this.POS_Receipt_Lines = POS_Receipt_Lines;
    };
    /***/

  },

  /***/
  "./src/app/payments/new-payment/new-payment-routing.module.ts":
  /*!********************************************************************!*\
    !*** ./src/app/payments/new-payment/new-payment-routing.module.ts ***!
    \********************************************************************/

  /*! exports provided: NewPaymentPageRoutingModule */

  /***/
  function srcAppPaymentsNewPaymentNewPaymentRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NewPaymentPageRoutingModule", function () {
      return NewPaymentPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _new_payment_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./new-payment.page */
    "./src/app/payments/new-payment/new-payment.page.ts");

    var routes = [{
      path: '',
      component: _new_payment_page__WEBPACK_IMPORTED_MODULE_3__["NewPaymentPage"]
    }];

    var NewPaymentPageRoutingModule = function NewPaymentPageRoutingModule() {
      _classCallCheck(this, NewPaymentPageRoutingModule);
    };

    NewPaymentPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], NewPaymentPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/payments/new-payment/new-payment.module.ts":
  /*!************************************************************!*\
    !*** ./src/app/payments/new-payment/new-payment.module.ts ***!
    \************************************************************/

  /*! exports provided: NewPaymentPageModule */

  /***/
  function srcAppPaymentsNewPaymentNewPaymentModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NewPaymentPageModule", function () {
      return NewPaymentPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _new_payment_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./new-payment-routing.module */
    "./src/app/payments/new-payment/new-payment-routing.module.ts");
    /* harmony import */


    var _new_payment_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./new-payment.page */
    "./src/app/payments/new-payment/new-payment.page.ts");
    /* harmony import */


    var _new_cash_line_new_cash_line_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../new-cash-line/new-cash-line.component */
    "./src/app/payments/new-cash-line/new-cash-line.component.ts");

    var NewPaymentPageModule = function NewPaymentPageModule() {
      _classCallCheck(this, NewPaymentPageModule);
    };

    NewPaymentPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _new_payment_routing_module__WEBPACK_IMPORTED_MODULE_5__["NewPaymentPageRoutingModule"]],
      entryComponents: [_new_cash_line_new_cash_line_component__WEBPACK_IMPORTED_MODULE_7__["NewCashLineComponent"]],
      declarations: [_new_payment_page__WEBPACK_IMPORTED_MODULE_6__["NewPaymentPage"], _new_cash_line_new_cash_line_component__WEBPACK_IMPORTED_MODULE_7__["NewCashLineComponent"]]
    })], NewPaymentPageModule);
    /***/
  },

  /***/
  "./src/app/payments/new-payment/new-payment.page.scss":
  /*!************************************************************!*\
    !*** ./src/app/payments/new-payment/new-payment.page.scss ***!
    \************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPaymentsNewPaymentNewPaymentPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BheW1lbnRzL25ldy1wYXltZW50L25ldy1wYXltZW50LnBhZ2Uuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/payments/new-payment/new-payment.page.ts":
  /*!**********************************************************!*\
    !*** ./src/app/payments/new-payment/new-payment.page.ts ***!
    \**********************************************************/

  /*! exports provided: NewPaymentPage */

  /***/
  function srcAppPaymentsNewPaymentNewPaymentPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NewPaymentPage", function () {
      return NewPaymentPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _payments_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ../payments.service */
    "./src/app/payments/payments.service.ts");
    /* harmony import */


    var src_app_models_receipt_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/models/receipt.model */
    "./src/app/models/receipt.model.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _new_cash_line_new_cash_line_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../new-cash-line/new-cash-line.component */
    "./src/app/payments/new-cash-line/new-cash-line.component.ts");
    /* harmony import */


    var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! src/app/auth/auth-service */
    "./src/app/auth/auth-service.ts");
    /* harmony import */


    var src_app_utility_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! src/app/utility.service */
    "./src/app/utility.service.ts");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");

    var NewPaymentPage = /*#__PURE__*/function () {
      function NewPaymentPage(paymentService, authService, router, toastCtrl, alertCtrl, popover, modalCtrl, utilitySvc) {
        _classCallCheck(this, NewPaymentPage);

        this.paymentService = paymentService;
        this.authService = authService;
        this.router = router;
        this.toastCtrl = toastCtrl;
        this.alertCtrl = alertCtrl;
        this.popover = popover;
        this.modalCtrl = modalCtrl;
        this.utilitySvc = utilitySvc;
        this.saleType = [{
          'type': 'Cash',
          'Code': 'Cash'
        }, {
          'type': 'Credit',
          'Code': 'Credit'
        }];
        this.card = new src_app_models_receipt_model__WEBPACK_IMPORTED_MODULE_3__["Receipt"]();
      }

      _createClass(NewPaymentPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.setUser();
          this.DismissPopover();
          this.FetchBanks();
          this.FetchPriceGroups();
          this.newPayment();
        }
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.setUser();
        }
      }, {
        key: "ionViewDidEnter",
        value: function ionViewDidEnter() {
          if (this.userID) {
            this.FetchCustomers();
          }
        }
      }, {
        key: "setUser",
        value: function setUser() {
          var _a;

          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.authService.getUser();

                  case 2:
                    this.user = _context.sent;
                    this.Store_Code = this.user.Store_Code;
                    this.userID = (_a = this.user) === null || _a === void 0 ? void 0 : _a.User_ID;
                    console.log(this.userID);

                  case 6:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "newPayment",
        value: function newPayment() {
          var _this = this;

          var _a;

          this.card.Created_By = (_a = this.user) === null || _a === void 0 ? void 0 : _a.User_ID;
          this.paymentSub = this.paymentService.newPayment(this.card).subscribe(function (receipt) {
            _this.card = receipt;
            var curr = new Date();

            var formattedDate = _this.paymentService.formatDate(curr); // this.card.Posting_Date = formattedDate;

          });
        }
      }, {
        key: "updateReceipt",
        value: function updateReceipt($event) {
          var _this2 = this;

          var _a;

          this.card.Created_By = (_a = this.user) === null || _a === void 0 ? void 0 : _a.User_ID;
          this.updateSub = this.paymentService.updateReceipt(this.card).subscribe(function (res) {
            if (typeof res === 'string') {
              // this.utilitySvc.showAlert(res);
              return false;
            }

            if (typeof res === 'object') {
              Object.assign(_this2.card, res);

              _this2.toastCtrl.create({
                message: "Receipt Updated Successfully.",
                duration: 2000,
                position: 'top'
              }).then(function (toastData) {
                toastData.present();
              });
            }
          }, function (error) {
            _this2.alertCtrl.create({
              header: 'New Payment Error!',
              message: 'Connection problem: ' + error,
              buttons: [{
                text: 'Okay'
              }]
            }).then(function (alertEl) {
              alertEl.present();
            });
          });
        }
      }, {
        key: "FetchBanks",
        value: function FetchBanks() {
          var _this3 = this;

          this.bankSub = this.paymentService.Banks.subscribe(function (result) {
            _this3.banks = result;
          });
        }
      }, {
        key: "Suggestlines",
        value: function Suggestlines(receiptNo, customerNo) {
          var _this4 = this;

          this.suggestLinesSub = this.paymentService.suggestlines(receiptNo, customerNo).subscribe(function (res) {
            if (res.return_value > 0) {
              // Show a Toast Notification
              _this4.toastCtrl.create({
                message: "Invoice Lines Suggested Successfully.",
                duration: 2000,
                position: 'top'
              }).then(function (toastData) {
                toastData.present();

                _this4.router.navigate(['/', 'payments', receiptNo]);
              });
            } else {
              console.log(res);

              _this4.alertCtrl.create({
                header: 'Operation Error',
                message: 'Message : ' + res,
                buttons: [{
                  text: 'Okay'
                }]
              }).then(function (alertEl) {
                alertEl.present();
              });
            }
          }, function (error) {
            console.log(error.error);

            _this4.alertCtrl.create({
              header: 'Service Error!',
              message: 'Connection problem: ' + error,
              buttons: [{
                text: 'Okay'
              }]
            }).then(function (alertEl) {
              alertEl.present();
            });
          });
        }
      }, {
        key: "onAddLine",
        value: function onAddLine(POS_Receipt_No) {
          this, this.modalCtrl.create({
            component: _new_cash_line_new_cash_line_component__WEBPACK_IMPORTED_MODULE_6__["NewCashLineComponent"],
            componentProps: {
              receiptNo: POS_Receipt_No
            }
          }).then(function (modalEl) {
            modalEl.present();
          });
        }
      }, {
        key: "FetchCustomers",
        value: function FetchCustomers() {
          var _this5 = this;

          console.log("User Found....");
          console.table(this.user);
          this.utilitySvc.presentLoading('Loading Customers ....');
          this.customerListSub = this.paymentService.CustomerBySalesPerson(this === null || this === void 0 ? void 0 : this.userID).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["finalize"])(function () {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this5, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      this.utilitySvc.loadingCtrl.dismiss();

                    case 1:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          })).subscribe(function (cust) {
            _this5.customers = cust;
          });
        }
      }, {
        key: "FetchPriceGroups",
        value: function FetchPriceGroups() {
          var _this6 = this;

          this.priceGroupsSub = this.paymentService.CustomerPriceGroups().subscribe(function (grps) {
            _this6.priceGroups = grps;
          });
        }
      }, {
        key: "DismissPopover",
        value: function DismissPopover() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.popover.dismiss();

                  case 2:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "toView",
        value: function toView() {
          return this.router.navigate(['/', 'payments', this.card.POS_Receipt_No]);
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          if (this.paymentSub) {
            this.paymentSub.unsubscribe();
          } else if (this.bankSub) {
            this.bankSub.unsubscribe();
          } else if (this.customerListSub) {
            this.customerListSub.unsubscribe();
          } else if (this.suggestLinesSub) {
            this.suggestLinesSub.unsubscribe();
          } else if (this.updateSub) {
            this.updateSub.unsubscribe();
          } else if (this.priceGroupsSub) {
            this.priceGroupsSub.unsubscribe();
          }
        }
      }]);

      return NewPaymentPage;
    }();

    NewPaymentPage.ctorParameters = function () {
      return [{
        type: _payments_service__WEBPACK_IMPORTED_MODULE_2__["PaymentsService"]
      }, {
        type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_7__["AuthService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["AlertController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["PopoverController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"]
      }, {
        type: src_app_utility_service__WEBPACK_IMPORTED_MODULE_8__["UtilityService"]
      }];
    };

    NewPaymentPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-new-payment',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./new-payment.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/payments/new-payment/new-payment.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./new-payment.page.scss */
      "./src/app/payments/new-payment/new-payment.page.scss"))["default"]]
    })], NewPaymentPage);
    /***/
  }
}]);
//# sourceMappingURL=default~new-payment-new-payment-module~payments-new-payment-new-payment-module-es5.js.map