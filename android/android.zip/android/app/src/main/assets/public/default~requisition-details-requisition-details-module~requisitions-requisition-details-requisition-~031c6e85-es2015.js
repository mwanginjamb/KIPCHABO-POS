(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~requisition-details-requisition-details-module~requisitions-requisition-details-requisition-~031c6e85"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/requisitions/requisition-details/requisition-details.page.html":
/*!**********************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/requisitions/requisition-details/requisition-details.page.html ***!
  \**********************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button defaultHref=\"requisitions\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>{{ card?.Req_No }} Requisition Card</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <ion-fab vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\">\r\n    <ion-fab-button color=\"warning\" (click)=\"post(card.Req_No)\">\r\n      <ion-icon name=\"send\"></ion-icon>\r\n    </ion-fab-button>\r\n  </ion-fab>\r\n\r\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"refresh($event)\" pullMin=\"100\" pullMax=\"200\">\r\n      <ion-refresher-content\r\n        pullingIcon=\"arrow-down-outline\"\r\n        pullingText=\"Pull to Refresh\"\r\n        refreshingSpinner=\"crescent\"\r\n        refreshingText=\"Refreshing...\"\r\n        >\r\n      </ion-refresher-content>\r\n  </ion-refresher>\r\n\r\n  <ion-grid>\r\n     <ion-row>\r\n       <ion-col >\r\n          <ion-card>\r\n            <ion-card-header>\r\n              <ion-card-title>\r\n                General Card Details\r\n              </ion-card-title>\r\n            </ion-card-header>\r\n\r\n            <ion-card-content>\r\n\r\n              <ion-row>\r\n                <ion-col >\r\n                  <ion-item>\r\n                    <ion-label position=\"fixed\">Req. No</ion-label>\r\n                    <ion-text>{{ card?.Req_No }}</ion-text>\r\n                  </ion-item>\r\n                </ion-col>\r\n\r\n                <ion-col >\r\n                  <ion-item>\r\n                    <ion-label position=\"fixed\">Store Code.</ion-label>\r\n                    <ion-text>{{ card?.Store_Code }}</ion-text>\r\n                  </ion-item>\r\n                </ion-col>\r\n              </ion-row>\r\n\r\n              <ion-row>\r\n                <ion-col >\r\n                  <ion-item>\r\n                    <ion-label position=\"fixed\">Requisition Date</ion-label>\r\n                    <ion-text>{{ card?.Requisition_Date }}</ion-text>\r\n                  </ion-item>\r\n                </ion-col>\r\n\r\n                <ion-col >\r\n                  <ion-item>\r\n                    <ion-label position=\"fixed\">Store Name</ion-label>\r\n                    <ion-text>{{ card?.Store_Name }}</ion-text>\r\n                  </ion-item>\r\n                </ion-col>\r\n              </ion-row>\r\n\r\n              <ion-row>\r\n                <ion-col >\r\n                  <ion-item>\r\n                    <ion-label position=\"fixed\">Requested On</ion-label>\r\n                    <ion-text>{{ card?.Requested_On }}</ion-text>\r\n                  </ion-item>\r\n                </ion-col>\r\n\r\n                <ion-col >\r\n                  <ion-item>\r\n                    <ion-label position=\"fixed\">Approval Status</ion-label>\r\n                    <ion-text>{{ card?.Approval_Status }}</ion-text>\r\n                  </ion-item>\r\n                </ion-col>\r\n              </ion-row>\r\n\r\n              \r\n\r\n             \r\n            </ion-card-content>\r\n\r\n          </ion-card> \r\n\r\n          <!--Start Lines Card-->\r\n          <ion-card>\r\n            <ion-card-header>\r\n              <ion-card-title>Lines</ion-card-title>\r\n            </ion-card-header>\r\n            <ion-card-content>\r\n              <ion-grid>\r\n                <ion-row *ngIf=\"card?.Approval_Status === 'New' \">\r\n                  <ion-col>\r\n                    <ion-list>\r\n                      <ion-item>\r\n                        <ion-button type=\"button\" outline color=\"primary\" (click)=\"onAddLine(card?.Req_No)\">New</ion-button>\r\n                      </ion-item>\r\n                    </ion-list>\r\n                    \r\n                  </ion-col>\r\n                </ion-row>\r\n\r\n                <ion-row scrollX=\"true\">\r\n                  <ion-col>\r\n                    <ion-label>Description</ion-label>\r\n                  </ion-col>\r\n\r\n                  \r\n                  <ion-col>\r\n                    <ion-label>Unit Pieces</ion-label>\r\n                  </ion-col>\r\n\r\n                  \r\n                  <ion-col>\r\n                    <ion-label>U.O.M</ion-label>\r\n                  </ion-col>\r\n\r\n                 \r\n\r\n                </ion-row>\r\n              \r\n                 \r\n               \r\n                <ion-list *ngFor=\"let item of card ?.Point_Of_Sale_Request_Lines ?.Point_Of_Sale_Request_Lines\">\r\n                    <ion-row >\r\n                      <ion-col> \r\n                        <ion-item (click)=\"onUpdateLine(item?.Key)\" color=\"primary\">\r\n                            <ion-label>{{item.Description}}</ion-label>\r\n                        </ion-item>\r\n                      </ion-col>\r\n  \r\n                     \r\n  \r\n                      \r\n  \r\n                      <ion-col> \r\n                        <ion-item>                         \r\n                            <ion-label>{{item.Pieces_To_Request}}</ion-label>\r\n                        </ion-item>\r\n                      </ion-col>\r\n  \r\n                      \r\n  \r\n                      <ion-col> \r\n                        <ion-item>                         \r\n                            <ion-label>{{item.U_O_M}}</ion-label>\r\n                        </ion-item>\r\n                      </ion-col>\r\n  \r\n                      \r\n  \r\n                    </ion-row>   \r\n                </ion-list>\r\n                 \r\n                \r\n              </ion-grid>\r\n            </ion-card-content>\r\n          </ion-card>\r\n          <!--End Lines Card-->\r\n       </ion-col>\r\n     </ion-row>\r\n  </ion-grid>\r\n\r\n</ion-content>\r\n");

/***/ }),

/***/ "./src/app/requisitions/requisition-details/requisition-details-routing.module.ts":
/*!****************************************************************************************!*\
  !*** ./src/app/requisitions/requisition-details/requisition-details-routing.module.ts ***!
  \****************************************************************************************/
/*! exports provided: RequisitionDetailsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RequisitionDetailsPageRoutingModule", function() { return RequisitionDetailsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _requisition_details_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./requisition-details.page */ "./src/app/requisitions/requisition-details/requisition-details.page.ts");




const routes = [
    {
        path: '',
        component: _requisition_details_page__WEBPACK_IMPORTED_MODULE_3__["RequisitionDetailsPage"]
    }
];
let RequisitionDetailsPageRoutingModule = class RequisitionDetailsPageRoutingModule {
};
RequisitionDetailsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], RequisitionDetailsPageRoutingModule);



/***/ }),

/***/ "./src/app/requisitions/requisition-details/requisition-details.module.ts":
/*!********************************************************************************!*\
  !*** ./src/app/requisitions/requisition-details/requisition-details.module.ts ***!
  \********************************************************************************/
/*! exports provided: RequisitionDetailsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RequisitionDetailsPageModule", function() { return RequisitionDetailsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _requisition_details_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./requisition-details-routing.module */ "./src/app/requisitions/requisition-details/requisition-details-routing.module.ts");
/* harmony import */ var _requisition_details_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./requisition-details.page */ "./src/app/requisitions/requisition-details/requisition-details.page.ts");
/* harmony import */ var _lines_lines_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../lines/lines.component */ "./src/app/requisitions/lines/lines.component.ts");








let RequisitionDetailsPageModule = class RequisitionDetailsPageModule {
};
RequisitionDetailsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _requisition_details_routing_module__WEBPACK_IMPORTED_MODULE_5__["RequisitionDetailsPageRoutingModule"],
        ],
        declarations: [_requisition_details_page__WEBPACK_IMPORTED_MODULE_6__["RequisitionDetailsPage"], _lines_lines_component__WEBPACK_IMPORTED_MODULE_7__["LinesComponent"]],
        entryComponents: [_lines_lines_component__WEBPACK_IMPORTED_MODULE_7__["LinesComponent"]],
    })
], RequisitionDetailsPageModule);



/***/ }),

/***/ "./src/app/requisitions/requisition-details/requisition-details.page.scss":
/*!********************************************************************************!*\
  !*** ./src/app/requisitions/requisition-details/requisition-details.page.scss ***!
  \********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3JlcXVpc2l0aW9ucy9yZXF1aXNpdGlvbi1kZXRhaWxzL3JlcXVpc2l0aW9uLWRldGFpbHMucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/requisitions/requisition-details/requisition-details.page.ts":
/*!******************************************************************************!*\
  !*** ./src/app/requisitions/requisition-details/requisition-details.page.ts ***!
  \******************************************************************************/
/*! exports provided: RequisitionDetailsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RequisitionDetailsPage", function() { return RequisitionDetailsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _requisition_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../requisition.service */ "./src/app/requisitions/requisition.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _lines_lines_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../lines/lines.component */ "./src/app/requisitions/lines/lines.component.ts");
/* harmony import */ var src_app_items_item_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/items/item.service */ "./src/app/items/item.service.ts");
/* harmony import */ var src_app_models_requisitionline_model__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/models/requisitionline.model */ "./src/app/models/requisitionline.model.ts");
/* harmony import */ var src_app_stock_details_stockdetail_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/stock-details/stockdetail.service */ "./src/app/stock-details/stockdetail.service.ts");









let RequisitionDetailsPage = class RequisitionDetailsPage {
    constructor(requisitionService, itemService, activatedRoute, modalCtrl, stockService, alertCtrl, router) {
        this.requisitionService = requisitionService;
        this.itemService = itemService;
        this.activatedRoute = activatedRoute;
        this.modalCtrl = modalCtrl;
        this.stockService = stockService;
        this.alertCtrl = alertCtrl;
        this.router = router;
        this.items = [];
        this.units = [];
        this.id = null;
        this.line = new src_app_models_requisitionline_model__WEBPACK_IMPORTED_MODULE_7__["Requisitionline"]();
        this.model = {};
    }
    ngOnInit() {
        this.id = this.activatedRoute.snapshot.paramMap.get('id');
        // get card details
        this.fetchCard();
        //Auto refresh upon line activitie
        this.requisitionService.refresh$.subscribe(() => {
            this.fetchCard();
        });
    }
    fetchCard() {
        this.cardSub = this.requisitionService.requisitioncard(this.id).subscribe(cardInfo => {
            this.card = [...cardInfo][0];
            console.log(this.card);
        });
    }
    ionViewDidEnter() {
        this.id = this.activatedRoute.snapshot.paramMap.get('id');
        // get card details
        this.cardSub = this.requisitionService.requisitioncard(this.id).subscribe(cardInfo => {
            this.card = [...cardInfo][0];
        });
    }
    // Show Line modal form
    onAddLine(Req_No) {
        this.modalCtrl.create({
            component: _lines_lines_component__WEBPACK_IMPORTED_MODULE_5__["LinesComponent"],
            componentProps: { docId: Req_No }
        }).then(modalEl => {
            modalEl.present();
        });
    }
    onUpdateLine(Key) {
        this.modalCtrl.create({
            component: _lines_lines_component__WEBPACK_IMPORTED_MODULE_5__["LinesComponent"],
            componentProps: { Key }
        })
            .then(modalEl => {
            modalEl.present();
        });
    }
    // Get Units of Measure
    getUnit() {
        this.unitSub = this.requisitionService.getunits(this.line.Item_No).subscribe(units => {
            this.units = units;
            console.log(this.units);
        });
    }
    /* addLine() {
      this.requisitionService.postLine(this.line).subscribe( line => {
        console.log(line.Line_No);
      });
     }*/
    refresh(event) {
        this.cardSub = this.requisitionService.requisitioncard(this.id).subscribe(cardInfo => {
            this.card = [...cardInfo][0];
            if (event) {
                event.target.complete();
            }
        });
    }
    post(ReceiptNo) {
        // Should send for requisition for approval but we fake it now since work flows are not degined
        this.stockService.showToast(`Requisition Sent for Approval Successfully.`);
        setTimeout(() => {
            this.router.navigate(['../', 'requisitions']);
        }, 3000);
        return;
        console.log(ReceiptNo);
        this.stockService.postDocument(ReceiptNo).subscribe(res => {
            if (typeof res === 'string') { // a string response represents a Nav Error, so we display it.
                this.alertCtrl.create({
                    header: 'Service Warning!',
                    message: res,
                    buttons: [{ text: 'Okay' }]
                }).then(alertEl => {
                    alertEl.present();
                });
            }
            else {
                this.stockService.showToast(`Document Posted Successfully.`);
            }
        }, error => {
            alert(error);
        });
    }
    ngOnDestroy() {
        if (this.itemSub) {
            this.itemSub.unsubscribe();
        }
        if (this.unitSub) {
            this.unitSub.unsubscribe();
        }
        if (this.cardSub) {
            this.cardSub.unsubscribe();
        }
    }
};
RequisitionDetailsPage.ctorParameters = () => [
    { type: _requisition_service__WEBPACK_IMPORTED_MODULE_2__["RequisitionService"] },
    { type: src_app_items_item_service__WEBPACK_IMPORTED_MODULE_6__["ItemService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
    { type: src_app_stock_details_stockdetail_service__WEBPACK_IMPORTED_MODULE_8__["StockdetailService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] }
];
RequisitionDetailsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-requisition-details',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./requisition-details.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/requisitions/requisition-details/requisition-details.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./requisition-details.page.scss */ "./src/app/requisitions/requisition-details/requisition-details.page.scss")).default]
    })
], RequisitionDetailsPage);



/***/ }),

/***/ "./src/app/stock-details/stockdetail.service.ts":
/*!******************************************************!*\
  !*** ./src/app/stock-details/stockdetail.service.ts ***!
  \******************************************************/
/*! exports provided: StockdetailService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StockdetailService", function() { return StockdetailService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");






let StockdetailService = class StockdetailService {
    constructor(http, toastCtrl) {
        this.http = http;
        this.toastCtrl = toastCtrl;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].url;
    }
    get releasedrequisitions() {
        return this.http.get(`${this.url}site/releasedrequisitions`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    // Retrieve Stock Issue Card / Details
    requisitioncard(id) {
        return this.http.get(`${this.url}site/stockissue/?id=${id}`);
    }
    // Create New Requisition
    createRequisition() {
        return this.http.get(`${this.url}site/create-requisition`);
    }
    //Update Stock Issue
    updateStockIssue(Card) {
        return this.http.post(`${this.url}site/stock-issue-card`, JSON.stringify(Card));
    }
    // get Units of Measure
    getunits(itemNo) {
        return this.http.get(`${this.url}site/unitmeasure?itemNo=${itemNo}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    // Get Locations List
    getLocations() {
        return this.http.get(`${this.url}site/locationlist`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    // Get any items from generic service getter function
    get Dimensions() {
        return this.http.get(`${this.url}site/get?service=Dimensions`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    get Departments() {
        return this.http.get(`${this.url}site/departments`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    get Projects() {
        return this.http.get(`${this.url}site/projects`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    // Post Lines Data
    postLine(line) {
        return this.http.post(`${this.url}site/addline`, JSON.stringify(line));
    }
    // Update Line
    updateRequisitionLine(line) {
        return this.http.post(`${this.url}site/updateissueline`, JSON.stringify(line));
    }
    // Fetch Line to Update
    getLine(Key) {
        return this.http.get(`${this.url}site/stock-issue-line?Key=${Key}`);
    }
    // Post Requisition Header
    postRequisition(requisition) {
        return this.http.post(`${this.url}site/update-requisition`, JSON.stringify(requisition));
    }
    // Format date utility
    formatDate(datestring) {
        // Format Date to YYYY-MM-DD
        const recDate = new Date(datestring);
        const month = (recDate.getMonth() + 1) > 9 ? recDate.getMonth() + 1 : `0` + (recDate.getMonth() + 1);
        const day = (recDate.getDate()) > 9 ? recDate.getDate() : `0` + recDate.getDate();
        return `${recDate.getFullYear()}-${month}-${day}`;
    }
    acknowledgeStockIssue(No) {
        return this.http.get(`${this.url}site/acknowledge-stock-issue?No=${No}`);
    }
    postDocument(No) {
        return this.http.get(`${this.url}site/acknowledge-stock-issue?No=${No}`);
    }
    showToast(text) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return yield this.toastCtrl.create({
                message: text,
                duration: 4000,
                position: 'top'
            }).then(toastEl => {
                toastEl.present();
            });
        });
    }
};
StockdetailService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"] }
];
StockdetailService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
        providedIn: 'root'
    })
], StockdetailService);



/***/ })

}]);
//# sourceMappingURL=default~requisition-details-requisition-details-module~requisitions-requisition-details-requisition-~031c6e85-es2015.js.map