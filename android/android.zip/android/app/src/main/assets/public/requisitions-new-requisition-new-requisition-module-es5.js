function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["requisitions-new-requisition-new-requisition-module"], {
  /***/
  "./src/app/requisitions/requisition.service.ts":
  /*!*****************************************************!*\
    !*** ./src/app/requisitions/requisition.service.ts ***!
    \*****************************************************/

  /*! exports provided: RequisitionService */

  /***/
  function srcAppRequisitionsRequisitionServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RequisitionService", function () {
      return RequisitionService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");

    var RequisitionService = /*#__PURE__*/function () {
      function RequisitionService(http) {
        _classCallCheck(this, RequisitionService);

        this.http = http;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
        this._refresh$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__["Subject"]();
      } // Synthetic Getter for our refresh observerble


      _createClass(RequisitionService, [{
        key: "refresh$",
        get: function get() {
          return this._refresh$;
        }
      }, {
        key: "getRequisitions",
        value: function getRequisitions(userID) {
          return this.http.get("".concat(this.url, "site/requisitions?userid=").concat(userID)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "releasedrequisitions",
        get: function get() {
          return this.http.get("".concat(this.url, "site/releasedrequisitions")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        } // Retrieve Requisition Card / Details

      }, {
        key: "requisitioncard",
        value: function requisitioncard(id) {
          return this.http.get("".concat(this.url, "site/requisitioncard/?id=").concat(id));
        } // Create New Requisition

      }, {
        key: "createRequisition",
        value: function createRequisition(userID) {
          console.log('creator is:' + userID);
          return this.http.get("".concat(this.url, "site/create-requisition?userid=").concat(userID));
        } // get Units of Measure

      }, {
        key: "getunits",
        value: function getunits(itemNo) {
          return this.http.get("".concat(this.url, "site/unitmeasure?itemNo=").concat(itemNo)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        } // Get Locations List

      }, {
        key: "getLocations",
        value: function getLocations() {
          return this.http.get("".concat(this.url, "site/locationlist")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        } // Get any items from generic service getter function

      }, {
        key: "Dimensions",
        get: function get() {
          return this.http.get("".concat(this.url, "site/get?service=Dimensions")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "Departments",
        get: function get() {
          return this.http.get("".concat(this.url, "site/departments")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "Projects",
        get: function get() {
          return this.http.get("".concat(this.url, "site/projects")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        } // Post Lines Data

      }, {
        key: "postLine",
        value: function postLine(line) {
          var _this = this;

          return this.http.post("".concat(this.url, "site/requisition-lines"), JSON.stringify(line)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function () {
            _this._refresh$.next();
          }));
        } // Update Line

      }, {
        key: "updateRequisitionLine",
        value: function updateRequisitionLine(line) {
          var _this2 = this;

          return this.http.post("".concat(this.url, "site/updaterequisitionline"), JSON.stringify(line)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function () {
            _this2._refresh$.next();
          }));
        } // Fetch Line to Update

      }, {
        key: "getLine",
        value: function getLine(Key) {
          return this.http.get("".concat(this.url, "site/requisition-lines?Key=").concat(Key));
        } // Post Requisition Header

      }, {
        key: "postRequisition",
        value: function postRequisition(requisition) {
          return this.http.post("".concat(this.url, "site/update-requisition"), JSON.stringify(requisition));
        } // Format date utility

      }, {
        key: "formatDate",
        value: function formatDate(datestring) {
          // Format Date to YYYY-MM-DD
          var recDate = new Date(datestring);
          var month = recDate.getMonth() + 1 > 9 ? recDate.getMonth() + 1 : "0" + (recDate.getMonth() + 1);
          var day = recDate.getDate() > 9 ? recDate.getDate() : "0" + recDate.getDate();
          return "".concat(recDate.getFullYear(), "-").concat(month, "-").concat(day);
        }
      }]);

      return RequisitionService;
    }();

    RequisitionService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }];
    };

    RequisitionService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], RequisitionService);
    /***/
  }
}]);
//# sourceMappingURL=requisitions-new-requisition-new-requisition-module-es5.js.map