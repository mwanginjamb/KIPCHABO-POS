function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["items-availability-by-location-availability-by-location-module"], {
  /***/
  "./src/app/items/item.service.ts":
  /*!***************************************!*\
    !*** ./src/app/items/item.service.ts ***!
    \***************************************/

  /*! exports provided: ItemService */

  /***/
  function srcAppItemsItemServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ItemService", function () {
      return ItemService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var ItemService = /*#__PURE__*/function () {
      function ItemService(http, toastCtrl) {
        _classCallCheck(this, ItemService);

        this.http = http;
        this.toastCtrl = toastCtrl;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
      }

      _createClass(ItemService, [{
        key: "items",
        get: function get() {
          return this.http.get("".concat(this.url, "site/items")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "itemcard",
        value: function itemcard(id) {
          return this.http.get("".concat(this.url, "site/itemcard/?id=").concat(id));
        }
      }, {
        key: "itemBalance",
        value: function itemBalance(No) {
          return this.http.get("".concat(this.url, "site/itemavailabilitybylocation/?No=").concat(No));
        }
      }, {
        key: "itemBalanceByLocation",
        value: function itemBalanceByLocation(No, LocationCode) {
          return this.http.get("".concat(this.url, "site/itemavailabilitybylocation/?No=").concat(No, "&Location=").concat(LocationCode)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "getTotals",
        value: function getTotals(elements, subjectColumn) {
          var sum = 0;
          elements.forEach(function (obj) {
            // console.log(obj);
            for (var property in obj) {
              if (property === subjectColumn && !isNaN(+obj[property])) {
                // console.log(+obj[property]);
                sum += +obj[property];
              }
            }
          });
          return sum;
        } // Get Locations List

      }, {
        key: "getLocations",
        value: function getLocations() {
          return this.http.get("".concat(this.url, "site/locationlist")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "showToast",
        value: function showToast(text) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.toastCtrl.create({
                      message: text,
                      duration: 4000,
                      position: 'top'
                    }).then(function (toastEl) {
                      toastEl.present();
                    });

                  case 2:
                    return _context.abrupt("return", _context.sent);

                  case 3:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }]);

      return ItemService;
    }();

    ItemService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"]
      }];
    };

    ItemService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], ItemService);
    /***/
  }
}]);
//# sourceMappingURL=items-availability-by-location-availability-by-location-module-es5.js.map