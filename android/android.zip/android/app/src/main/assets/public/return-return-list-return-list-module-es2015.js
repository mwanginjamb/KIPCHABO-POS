(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["return-return-list-return-list-module"],{

/***/ "./src/app/return/return.service.ts":
/*!******************************************!*\
  !*** ./src/app/return/return.service.ts ***!
  \******************************************/
/*! exports provided: ReturnService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReturnService", function() { return ReturnService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _utility_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../utility.service */ "./src/app/utility.service.ts");






let ReturnService = class ReturnService {
    constructor(http, utilitySvc) {
        this.http = http;
        this.utilitySvc = utilitySvc;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
    }
    formatDate(date) {
        return this.utilitySvc.formatDate(date);
    }
    // Can create or Update
    ReturnTransaction(returnData) {
        return this.http.post(`${this.url}site/return`, JSON.stringify(returnData)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    // Read a single Return
    getReturnTransaction(Key) {
        return this.http.get(`${this.url}site/view-return/?Key=${Key}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    // Get a list of returns for a particular user
    getReturnTransactions(userID) {
        return this.http.get(`${this.url}site/get?service=POSReturnList&userid=${userID}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    // Add Update Return Line
    returnLine(lineData) {
        return this.http.post(`${this.url}site/return-line`, JSON.stringify(lineData));
    }
    // Fetch return Line By Key
    fetchLine(Key) {
        return this.http.get(`${this.url}site/fetch-return-line?Key=${Key}`);
    }
};
ReturnService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] },
    { type: _utility_service__WEBPACK_IMPORTED_MODULE_5__["UtilityService"] }
];
ReturnService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
        providedIn: 'root'
    })
], ReturnService);



/***/ }),

/***/ "./src/app/utility.service.ts":
/*!************************************!*\
  !*** ./src/app/utility.service.ts ***!
  \************************************/
/*! exports provided: UtilityService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UtilityService", function() { return UtilityService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");



let UtilityService = class UtilityService {
    constructor(toastCtrl, alertCtrl, loadingCtrl) {
        this.toastCtrl = toastCtrl;
        this.alertCtrl = alertCtrl;
        this.loadingCtrl = loadingCtrl;
    }
    formatDate(datestring) {
        // Format Date to YYYY-MM-DD
        const recDate = new Date(datestring);
        const month = (recDate.getMonth() + 1) > 9 ? recDate.getMonth() + 1 : `0` + (recDate.getMonth() + 1);
        const day = (recDate.getDate()) > 9 ? recDate.getDate() : `0` + recDate.getDate();
        return `${recDate.getFullYear()}-${month}-${day}`;
    }
    showToast(text) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            let toastEl = this.toastCtrl.create({
                message: text,
                duration: 4000,
                position: 'top'
            });
            (yield toastEl).present();
        });
    }
    showAlert(text) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alertEl = yield this.alertCtrl.create({
                header: 'Operation Error',
                message: 'Message : ' + text,
                buttons: [{ text: 'Okay' }]
            });
            yield alertEl.present();
        });
    }
    presentLoading(message) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingCtrl.create({
                spinner: 'dots',
                animated: true,
                message: (message) ? message : 'Loading Data...'
            });
            yield loading.present();
        });
    }
};
UtilityService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] }
];
UtilityService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], UtilityService);



/***/ })

}]);
//# sourceMappingURL=return-return-list-return-list-module-es2015.js.map