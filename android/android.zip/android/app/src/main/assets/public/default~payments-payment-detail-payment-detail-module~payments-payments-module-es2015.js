(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~payments-payment-detail-payment-detail-module~payments-payments-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/payments/bluetooth/bluetooth.component.html":
/*!***************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/payments/bluetooth/bluetooth.component.html ***!
  \***************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-title>Select Bluetooth Printer</ion-title>\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button  (click)=\"closeModal()\">\r\n        <ion-icon slot=\"icon-only\" name=\"close\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n<ion-button color=\"primary\" expand=\"block\" (click)=\"listPrinters()\">Scan\r\n\r\n</ion-button>\r\n\r\n  <ion-list>\r\n    <ion-list-header *ngIf=\"!scanning\">Available Devices</ion-list-header>\r\n\r\n    <ion-item *ngFor=\"let dev of  btDevices\" (click)=\"selectPrinter(dev.id)\">{{dev.name}}</ion-item>\r\n    \r\n  </ion-list>\r\n\r\n  <ion-spinner name=\"crescent\" *ngIf=\"scanning\"></ion-spinner>\r\n\r\n</ion-content>\r\n    \r\n\r\n");

/***/ }),

/***/ "./src/app/orders/order.service.ts":
/*!*****************************************!*\
  !*** ./src/app/orders/order.service.ts ***!
  \*****************************************/
/*! exports provided: OrderService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrderService", function() { return OrderService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");





let OrderService = class OrderService {
    // private items  = new BehaviorSubject<[]>([]) ;
    constructor(http) {
        this.http = http;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
    }
    get orders() {
        return this.http.get(`${this.url}site/saleinvoices`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    // Create New Sales Invoice
    createInvoice() {
        return this.http.get(`${this.url}site/create-invoice`);
    }
    // Retrieve Sales Invoice Card / Details
    ordercard(id) {
        return this.http.get(`${this.url}site/saleinvoice/?id=${id}`);
    }
    // Post Lines Data
    postLine(line) {
        return this.http.post(`${this.url}site/addsalesinvoiceline`, JSON.stringify(line));
    }
    // Update Line
    updateInvoiceLine(line) {
        return this.http.post(`${this.url}site/updatesalesinvoiceline`, JSON.stringify(line));
    }
    // Fetch Line to Update
    getLine(docId, LineNo) {
        return this.http.get(`${this.url}site/getsalesinvoiceline?Document_No=${docId}&Line_No=${LineNo}`);
    }
    // Post Invoice Header
    postInvoice(invoice) {
        invoice.Posting_Date = this.formatDate(invoice.Posting_Date);
        invoice.Due_Date = this.formatDate(invoice.Due_Date);
        return this.http.post(`${this.url}site/update-invoice`, JSON.stringify(invoice));
    }
    // Get Customers
    get Customers() {
        return this.http.get(`${this.url}site/receipting-customers`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    postSalesInvoice(No) {
        return this.http.get(`${this.url}site/postsaleinvoice?No=${No}`);
    }
    // Format date utility
    formatDate(datestring) {
        // Format Date to YYYY-MM-DD
        const recDate = new Date(datestring);
        const month = (recDate.getMonth() + 1) > 9 ? recDate.getMonth() + 1 : `0` + (recDate.getMonth() + 1);
        const day = (recDate.getDate()) > 9 ? recDate.getDate() : `0` + recDate.getDate();
        return `${recDate.getFullYear()}-${month}-${day}`;
    }
};
OrderService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
OrderService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], OrderService);



/***/ }),

/***/ "./src/app/payments/bluetooth/bluetooth.component.scss":
/*!*************************************************************!*\
  !*** ./src/app/payments/bluetooth/bluetooth.component.scss ***!
  \*************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BheW1lbnRzL2JsdWV0b290aC9ibHVldG9vdGguY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/payments/bluetooth/bluetooth.component.ts":
/*!***********************************************************!*\
  !*** ./src/app/payments/bluetooth/bluetooth.component.ts ***!
  \***********************************************************/
/*! exports provided: BluetoothComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "BluetoothComponent", function() { return BluetoothComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _print_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../print.service */ "./src/app/payments/print.service.ts");
/* harmony import */ var _ionic_native_bluetooth_serial_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/bluetooth-serial/ngx */ "./node_modules/@ionic-native/bluetooth-serial/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _payments_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../payments.service */ "./src/app/payments/payments.service.ts");






let BluetoothComponent = class BluetoothComponent {
    constructor(modalCtrl, printService, bluetoothSerial, alertCtrl, toastCtrl, popOverCtrl, paymentService) {
        this.modalCtrl = modalCtrl;
        this.printService = printService;
        this.bluetoothSerial = bluetoothSerial;
        this.alertCtrl = alertCtrl;
        this.toastCtrl = toastCtrl;
        this.popOverCtrl = popOverCtrl;
        this.paymentService = paymentService;
        this.btDevices = [];
        this.pairedDevices = null;
        this.unpairedDevices = null;
        this.myString = null;
        this.success = (data) => {
            this.deviceConnected();
            if (this.Printable === 'Invoice') {
                this.generatePostedSalesInvoicePrintable();
            }
            else if (this.Printable === 'Receipt') {
                this.generateReceiptPrintable();
            }
            this.print(this.myString);
        };
        this.fail = (error) => {
            alert(error);
        };
        this.bluetoothSerial.enable();
    }
    ngOnInit() {
        this.popOverCtrl.dismiss();
    }
    closeModal() {
        this.modalCtrl.dismiss();
    }
    listPrinters() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.scanning = true;
            return yield this.printService.searchBluetoothPrinter().then(res => {
                this.btDevices = res;
                this.scanning = false;
            }, error => {
                console.log(error);
            });
        });
    }
    selectPrinter(macAddress) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alert = yield this.alertCtrl.create({
                header: 'Connect',
                message: 'Do you want to connect with selected device ?',
                buttons: [
                    {
                        text: 'Cancel',
                        role: 'cancel',
                        handler: () => {
                            this.showToast('Connection Intent Cancelled.');
                        }
                    },
                    {
                        text: 'Connect',
                        handler: () => {
                            this.selectPrinter = macAddress;
                            this.bluetoothSerial.connect(macAddress).subscribe(this.success, this.fail);
                        }
                    }
                ]
            });
            yield alert.present();
        });
    }
    deviceConnected() {
        this.bluetoothSerial.isConnected()
            .then(success => {
            alert(`Connected Successfully. `);
        }, error => {
            alert('error' + JSON.stringify('error'));
        });
    }
    print(stringtoPrint) {
        this.printService.sendToBluetoothPrinter(stringtoPrint);
    }
    showToast(text) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return yield this.toastCtrl.create({
                message: text,
                duration: 3000,
                position: 'top'
            }).then(toastEl => {
                toastEl.present();
            });
        });
    }
    generatePostedSalesInvoicePrintable() {
        var _a, _b, _c;
        this.myString = `
    Kipchabo Tea Factory Ltd - Invoice.

    Customer: ${(_a = this.Card) === null || _a === void 0 ? void 0 : _a.Customer_Name}

    Sale Date: ${this.Card.Posting_Date}

    Invoice No: ${this.Card.No}

    Item | Quantity  | Unit Price (Ksh) | Total  (Incl. VAT)

    `;
        /* this.Card.SalesInvLines.Posted_Sales_Invoice_Line.forEach(line => {
          this.myString += `
        ${line.Description}  | ${line.Quantity} | ${line.Unit_Price} | ${line.Line_Amount } \r\n` ;
        });*/
        // Filter Lines to print
        const LinestoPrint = this.Card.SalesInvLines.Posted_Sales_Invoice_Line.filter(ln => ln.Line_Amount > 0);
        LinestoPrint.forEach(line => {
            this.myString += `
    ${line.Description}  | ${line.Quantity} | ${line.Unit_Price} | ${line.Line_Amount} \r\n`;
        });
        const VAT = ((_b = this.Card) === null || _b === void 0 ? void 0 : _b.Amount) * 0.16;
        this.myString += `

     Total Amount: ${(_c = this.Card) === null || _c === void 0 ? void 0 : _c.Amount}

     VAT: ${VAT}
     `;
    }
    generateReceiptPrintable() {
        var _a;
        this.myString = `
    Kipchabo Tea Factory Receipt.

    Customer: ${(_a = this.receiptCard) === null || _a === void 0 ? void 0 : _a.Customer_Name}


    Invoice No | Amount  | Amount to receipt 

    `;
        // Filter Lines to Print
        const LinestoPrint = this.receiptCard.POS_Receipt_Lines.POS_Receipt_Lines.filter(ln => ln.Total_Amount > 0);
        LinestoPrint.forEach(line => {
            this.myString += `

    ${line.Description}  | ${line.Price} | ${line.Total_Amount}  \r\n`;
        });
        const Total = this.paymentService.getTotals(this.receiptCard.POS_Receipt_Lines.POS_Receipt_Lines, 'Amount_To_Receipt');
        this.myString += `

          Total Amount: ${Total}

                   `;
    }
};
BluetoothComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
    { type: _print_service__WEBPACK_IMPORTED_MODULE_3__["PrintService"] },
    { type: _ionic_native_bluetooth_serial_ngx__WEBPACK_IMPORTED_MODULE_4__["BluetoothSerial"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PopoverController"] },
    { type: _payments_service__WEBPACK_IMPORTED_MODULE_5__["PaymentsService"] }
];
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], BluetoothComponent.prototype, "No", void 0);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], BluetoothComponent.prototype, "Card", void 0);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], BluetoothComponent.prototype, "receiptCard", void 0);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], BluetoothComponent.prototype, "Printable", void 0);
BluetoothComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-bluetooth',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./bluetooth.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/payments/bluetooth/bluetooth.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./bluetooth.component.scss */ "./src/app/payments/bluetooth/bluetooth.component.scss")).default]
    })
], BluetoothComponent);



/***/ }),

/***/ "./src/app/payments/payments.service.ts":
/*!**********************************************!*\
  !*** ./src/app/payments/payments.service.ts ***!
  \**********************************************/
/*! exports provided: PaymentsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PaymentsService", function() { return PaymentsService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _orders_order_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../orders/order.service */ "./src/app/orders/order.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");








let PaymentsService = class PaymentsService {
    constructor(http, orderService, toastCtrl) {
        this.http = http;
        this.orderService = orderService;
        this.toastCtrl = toastCtrl;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].url;
        this._refresh$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__["Subject"]();
    }
    // Define a synthetic getter for the subject
    get refresh$() {
        return this._refresh$;
    }
    newPayment(receipt) {
        return this.http.post(`${this.url}site/cash-sale`, JSON.stringify(receipt));
    }
    updateReceipt(receipt) {
        return this.http.post(`${this.url}site/cash-sale`, JSON.stringify(receipt));
    }
    getPayments(userID) {
        return this.http.get(`${this.url}site/get?service=POSReceiptList&userid=${userID}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    getPayment(id) {
        return this.http.get(`${this.url}site/receipt/?id=${id}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    get Banks() {
        return this.http.get(`${this.url}site/get?service=BankAccounts`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    getLine(Key) {
        return this.http.get(`${this.url}site/cash-sale-line?Key=${Key}`);
    }
    suggestlines(receiptNo, customerNo) {
        return this.http.get(`${this.url}site/suggestlines?receiptNo=${receiptNo}&customerNo=${customerNo}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    // Post Lines Data
    postLine(line) {
        return this.http.post(`${this.url}site/cash-sale-line`, JSON.stringify(line))
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(() => {
            this._refresh$.next();
        }));
    }
    // Update Line
    updateLine(line) {
        return this.http.post(`${this.url}site/cash-sale-line`, JSON.stringify(line))
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(() => {
            this._refresh$.next();
        }));
    }
    get Customers() {
        return this.http.get(`${this.url}site/receipting-customers`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    /*
     * Get Customer By Search Name
     */
    Customer(searchName) {
        return this.http.get(`${this.url}site/receipting-customers?searchName=${searchName}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    /*
     * Get Customer By Sales Person Code
     */
    CustomerBySalesPerson(salesPersonCode) {
        return this.http.get(`${this.url}site/receipting-customers?Salesperson_Code=${salesPersonCode}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    // Get CustomerPriceGroups
    CustomerPriceGroups() {
        return this.http.get(`${this.url}site/get?service=CustomerPriceGroups`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    Mpesa() {
        return this.http.get(`${this.url}site/get?service=MPESATransactions`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    selectLine(CustomerNo, Line, ReceiptNo) {
        const payload = { Customer_No: CustomerNo, Line_No: Line, Receipt_No: ReceiptNo };
        return this.http.post(`${this.url}site/updatecashreceiptline`, JSON.stringify(payload));
    }
    setAmountToReceipt(CustomerNo, Line, ReceiptNo, AmountToReceipt) {
        const payload = { Customer_No: CustomerNo, Line_No: Line, Receipt_No: ReceiptNo, Amount_To_Receipt: AmountToReceipt };
        // console.log(payload); return;
        return this.http.post(`${this.url}site/updateamounttoreceipt`, JSON.stringify(payload));
    }
    postReceipt(No) {
        return this.http.get(`${this.url}site/postreceipt?No=${No}`);
    }
    getTotals(elements, subjectColumn) {
        let sum = 0;
        elements.forEach(obj => {
            // console.log(obj);
            for (const property in obj) {
                if (property === subjectColumn && !isNaN(+obj[property])) {
                    // console.log(+obj[property]);
                    sum += +obj[property];
                }
            }
        });
        return sum;
    }
    showToast(text) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return yield this.toastCtrl.create({
                message: text,
                duration: 4000,
                position: 'top'
            }).then(toastEl => {
                toastEl.present();
            });
        });
    }
    formatDate(date) {
        return this.orderService.formatDate(date);
    }
    FilterReceipts(startDate, userID) {
        return this.http.get(`${this.url}site/filterpayments?startdate=${startDate}&userid=${userID}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    FilterReceiptsbyRange(startDate, endDate, userID) {
        return this.http.get(`${this.url}site/filterpayments?startdate=${startDate}&enddate=${endDate}&userid=${userID}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
};
PaymentsService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
    { type: _orders_order_service__WEBPACK_IMPORTED_MODULE_5__["OrderService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] }
];
PaymentsService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], PaymentsService);



/***/ }),

/***/ "./src/app/payments/print.service.ts":
/*!*******************************************!*\
  !*** ./src/app/payments/print.service.ts ***!
  \*******************************************/
/*! exports provided: PrintService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PrintService", function() { return PrintService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_native_bluetooth_serial_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/bluetooth-serial/ngx */ "./node_modules/@ionic-native/bluetooth-serial/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");




let PrintService = class PrintService {
    constructor(btSerial, toastCtrl) {
        this.btSerial = btSerial;
        this.toastCtrl = toastCtrl;
        this.success = (data) => {
            this.showToast(`Printing Successfull !`);
        };
        this.fail = (error) => {
            alert(error);
        };
        btSerial.enable();
    }
    searchBluetoothPrinter() {
        return this.btSerial.list();
    }
    connectToBluetoothPrinter(macAddress) {
        return this.btSerial.connect(macAddress);
    }
    disconnectBluetoothPrinter() {
        return this.btSerial.disconnect();
    }
    sendToBluetoothPrinter(dataString) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            // Write to bt printer
            yield this.btSerial.write(dataString).then(this.success, this.fail);
            // Disconnect the Printer.
            this.disconnectBluetoothPrinter();
        });
    }
    showToast(text) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return yield this.toastCtrl.create({
                message: text,
                duration: 4000,
                position: 'top'
            }).then(toastEl => {
                toastEl.present();
            });
        });
    }
};
PrintService.ctorParameters = () => [
    { type: _ionic_native_bluetooth_serial_ngx__WEBPACK_IMPORTED_MODULE_2__["BluetoothSerial"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"] }
];
PrintService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], PrintService);



/***/ })

}]);
//# sourceMappingURL=default~payments-payment-detail-payment-detail-module~payments-payments-module-es2015.js.map