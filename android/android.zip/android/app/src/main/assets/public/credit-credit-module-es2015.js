(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["credit-credit-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/credit/credit-popover/credit-popover.component.html":
/*!***********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/credit/credit-popover/credit-popover.component.html ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<p>\r\n  credit-popover works!\r\n</p>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/credit/credit.page.html":
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/credit/credit.page.html ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <ion-title>Credit Sales</ion-title>\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button slot=\"icon-only\" fill=\"clear\" (click)=\"presentPopover($event)\">\r\n        <ion-icon name=\"ellipsis-vertical-outline\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <div *ngIf=\"isLoading\" class=\"ion-text-center\">\r\n    <ion-spinner name=\"crescent\"></ion-spinner>\r\n  </div>\r\n  \r\n  <ion-searchbar [(ngModel)]=\"searchTerm\" debounce=\"2000\" (ionChange)=\"searchPayment($event)\"></ion-searchbar>\r\n  <ion-grid fixed>\r\n    <ion-row>\r\n      <ion-col col-4 col-sm>Invoice No.</ion-col>\r\n      <ion-col col-4 col-sm>Customer Name </ion-col>\r\n      <!-- <ion-col col-4 col-sm>Receipt Date</ion-col>-->\r\n    </ion-row>\r\n  </ion-grid>\r\n  \r\n  <ion-virtual-scroll [items]=\"list\" approxItemHeight=\"47.2px\">\r\n  \r\n    <ion-item [routerLink]=\"['/','credit', item.No ]\" detail *virtualItem=\"let item\">\r\n  \r\n      <ion-grid>\r\n        <ion-row>\r\n  \r\n          <ion-col col-6 col-sm>\r\n            <ion-label>\r\n              <h3>{{ item?.No }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n  \r\n          <ion-col col-6 col-sm>\r\n            <ion-label>\r\n              <h3>{{ item?.Customer_Name }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n  \r\n          <!--<ion-col col-4 col-sm>\r\n                <ion-label>\r\n                  <h3>{{ item.Sale_Date}}</h3>\r\n                </ion-label>\r\n              </ion-col>-->\r\n  \r\n        </ion-row>\r\n      </ion-grid>\r\n  \r\n    </ion-item>\r\n  \r\n  </ion-virtual-scroll>\r\n\r\n</ion-content>\r\n");

/***/ }),

/***/ "./src/app/credit/credit-popover/credit-popover.component.scss":
/*!*********************************************************************!*\
  !*** ./src/app/credit/credit-popover/credit-popover.component.scss ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NyZWRpdC9jcmVkaXQtcG9wb3Zlci9jcmVkaXQtcG9wb3Zlci5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/credit/credit-popover/credit-popover.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/credit/credit-popover/credit-popover.component.ts ***!
  \*******************************************************************/
/*! exports provided: CreditPopoverComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreditPopoverComponent", function() { return CreditPopoverComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


let CreditPopoverComponent = class CreditPopoverComponent {
    constructor() { }
    ngOnInit() { }
};
CreditPopoverComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-credit-popover',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./credit-popover.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/credit/credit-popover/credit-popover.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./credit-popover.component.scss */ "./src/app/credit/credit-popover/credit-popover.component.scss")).default]
    })
], CreditPopoverComponent);



/***/ }),

/***/ "./src/app/credit/credit-routing.module.ts":
/*!*************************************************!*\
  !*** ./src/app/credit/credit-routing.module.ts ***!
  \*************************************************/
/*! exports provided: CreditPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreditPageRoutingModule", function() { return CreditPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _credit_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./credit.page */ "./src/app/credit/credit.page.ts");




const routes = [
    {
        path: '',
        component: _credit_page__WEBPACK_IMPORTED_MODULE_3__["CreditPage"]
    },
    {
        path: 'credit-detail',
        loadChildren: () => __webpack_require__.e(/*! import() | credit-detail-credit-detail-module */ "credit-detail-credit-detail-module").then(__webpack_require__.bind(null, /*! ./credit-detail/credit-detail.module */ "./src/app/credit/credit-detail/credit-detail.module.ts")).then(m => m.CreditDetailPageModule)
    }
];
let CreditPageRoutingModule = class CreditPageRoutingModule {
};
CreditPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CreditPageRoutingModule);



/***/ }),

/***/ "./src/app/credit/credit.module.ts":
/*!*****************************************!*\
  !*** ./src/app/credit/credit.module.ts ***!
  \*****************************************/
/*! exports provided: CreditPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreditPageModule", function() { return CreditPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _credit_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./credit-routing.module */ "./src/app/credit/credit-routing.module.ts");
/* harmony import */ var _credit_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./credit.page */ "./src/app/credit/credit.page.ts");
/* harmony import */ var _credit_popover_credit_popover_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./credit-popover/credit-popover.component */ "./src/app/credit/credit-popover/credit-popover.component.ts");








let CreditPageModule = class CreditPageModule {
};
CreditPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _credit_routing_module__WEBPACK_IMPORTED_MODULE_5__["CreditPageRoutingModule"]
        ],
        entryComponents: [_credit_popover_credit_popover_component__WEBPACK_IMPORTED_MODULE_7__["CreditPopoverComponent"]],
        declarations: [_credit_page__WEBPACK_IMPORTED_MODULE_6__["CreditPage"]]
    })
], CreditPageModule);



/***/ }),

/***/ "./src/app/credit/credit.page.scss":
/*!*****************************************!*\
  !*** ./src/app/credit/credit.page.scss ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2NyZWRpdC9jcmVkaXQucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/credit/credit.page.ts":
/*!***************************************!*\
  !*** ./src/app/credit/credit.page.ts ***!
  \***************************************/
/*! exports provided: CreditPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreditPage", function() { return CreditPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _credit_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./credit.service */ "./src/app/credit/credit.service.ts");




let CreditPage = class CreditPage {
    constructor(creditService, alertCtrl) {
        this.creditService = creditService;
        this.alertCtrl = alertCtrl;
        this.isLoading = true;
        this.searchTerm = null;
    }
    ngOnInit() {
        this.fetchCreditSales();
    }
    fetchCreditSales() {
        this.listSub = this.creditService.creditList.subscribe(result => {
            this.list = this.sort([...result]);
            this.isLoading = false;
        }, error => {
            console.log(error.error);
            this.alertCtrl.create({
                header: 'Service Error!',
                message: 'Connection problem: ' + error.error.message,
                buttons: [{ text: 'Okay' }]
            }).then(alertEl => {
                alertEl.present();
            });
        });
    }
    searchPayment($event) {
        const searchItems = [...this.list];
        // Begin search only if searchTerm is provided
        if (this.searchTerm.trim().length && this.searchTerm !== '') {
            this.list = searchItems.filter((item) => {
                if (item.Customer_Name && item.Customer_Name.length > 1) {
                    return (item.Customer_Name.toLowerCase().indexOf(this.searchTerm.toLowerCase()) > -1);
                }
            });
            return;
        }
        else { // Search Term not provide display all items
            this.fetchCreditSales();
        }
    }
    sort(dataArray) {
        return dataArray.sort((a, b) => (b.No > a.No) ? 1 : -1);
    }
    presentPopover($event) {
        return;
    }
};
CreditPage.ctorParameters = () => [
    { type: _credit_service__WEBPACK_IMPORTED_MODULE_3__["CreditService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] }
];
CreditPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-credit',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./credit.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/credit/credit.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./credit.page.scss */ "./src/app/credit/credit.page.scss")).default]
    })
], CreditPage);



/***/ }),

/***/ "./src/app/credit/credit.service.ts":
/*!******************************************!*\
  !*** ./src/app/credit/credit.service.ts ***!
  \******************************************/
/*! exports provided: CreditService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CreditService", function() { return CreditService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");





let CreditService = class CreditService {
    constructor(http) {
        this.http = http;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
    }
    get creditList() {
        return this.http.get(`${this.url}site/get?service=POSCreditList`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
};
CreditService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] }
];
CreditService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
        providedIn: 'root'
    })
], CreditService);



/***/ })

}]);
//# sourceMappingURL=credit-credit-module-es2015.js.map