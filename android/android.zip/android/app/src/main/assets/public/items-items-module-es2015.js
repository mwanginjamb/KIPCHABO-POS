(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["items-items-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/items/items.page.html":
/*!*****************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/items/items.page.html ***!
  \*****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button menu=\"m1\"></ion-menu-button>\r\n    </ion-buttons>\r\n\r\n    <ion-title>Items</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <div *ngIf=\"isLoading\" class=\"ion-text-center\">\r\n    <ion-spinner  name=\"crescent\"></ion-spinner>\r\n  </div>\r\n\r\n  <ion-searchbar [(ngModel)]=\"searchTerm\" debounce=\"2000\" (ionChange)=\"searchItem($event)\"></ion-searchbar>\r\n\r\n  <ion-grid fixed>\r\n    <ion-row>\r\n      <ion-col >Description</ion-col>\r\n      <ion-col >Inventory</ion-col>\r\n      <ion-col > Replenishment Sys.</ion-col>\r\n      <ion-col >Costing Method</ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n  \r\n  \r\n  \r\n    <ion-virtual-scroll [items]=\"Items\" approxItemHeight=\"47.2px\">\r\n               \r\n              <ion-item \r\n                [routerLink] = \"['/','items',item.No]\"\r\n               detail\r\n               *virtualItem=\"let item\" > \r\n  \r\n               <ion-grid fixed>\r\n                  <ion-row>\r\n  \r\n                    <ion-col>\r\n                      <ion-label>\r\n                        <h3>{{ item.Description }}</h3>\r\n                      </ion-label>\r\n                    </ion-col>\r\n  \r\n                    <ion-col>\r\n                      <ion-label>\r\n                        <h3>{{ item.Inventory }}</h3>\r\n                      </ion-label>\r\n                    </ion-col>\r\n  \r\n                    <ion-col>\r\n                      <ion-label>\r\n                        <h3>{{ item.Replenishment_System }}</h3>\r\n                      </ion-label>\r\n                    </ion-col>\r\n  \r\n                    <ion-col>\r\n                      <ion-label>\r\n                        <h3>{{ item.Costing_Method}}</h3>\r\n                      </ion-label>\r\n                    </ion-col>\r\n  \r\n                  </ion-row>\r\n                </ion-grid>\r\n                      \r\n          </ion-item>\r\n        \r\n    </ion-virtual-scroll>\r\n  \r\n\r\n</ion-content>\r\n");

/***/ }),

/***/ "./src/app/items/item.service.ts":
/*!***************************************!*\
  !*** ./src/app/items/item.service.ts ***!
  \***************************************/
/*! exports provided: ItemService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ItemService", function() { return ItemService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");






let ItemService = class ItemService {
    constructor(http, toastCtrl) {
        this.http = http;
        this.toastCtrl = toastCtrl;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
    }
    get items() {
        return this.http.get(`${this.url}site/items`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    itemcard(id) {
        return this.http.get(`${this.url}site/itemcard/?id=${id}`);
    }
    itemBalance(No) {
        return this.http.get(`${this.url}site/itemavailabilitybylocation/?No=${No}`);
    }
    itemBalanceByLocation(No, LocationCode) {
        return this.http.get(`${this.url}site/itemavailabilitybylocation/?No=${No}&Location=${LocationCode}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    getTotals(elements, subjectColumn) {
        let sum = 0;
        elements.forEach(obj => {
            // console.log(obj);
            for (const property in obj) {
                if (property === subjectColumn && !isNaN(+obj[property])) {
                    // console.log(+obj[property]);
                    sum += +obj[property];
                }
            }
        });
        return sum;
    }
    // Get Locations List
    getLocations() {
        return this.http.get(`${this.url}site/locationlist`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    showToast(text) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return yield this.toastCtrl.create({
                message: text,
                duration: 4000,
                position: 'top'
            }).then(toastEl => {
                toastEl.present();
            });
        });
    }
};
ItemService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"] }
];
ItemService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], ItemService);



/***/ }),

/***/ "./src/app/items/items-routing.module.ts":
/*!***********************************************!*\
  !*** ./src/app/items/items-routing.module.ts ***!
  \***********************************************/
/*! exports provided: ItemsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ItemsPageRoutingModule", function() { return ItemsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _items_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./items.page */ "./src/app/items/items.page.ts");




const routes = [
    {
        path: '',
        component: _items_page__WEBPACK_IMPORTED_MODULE_3__["ItemsPage"]
    },
    {
        path: 'item-detail',
        loadChildren: () => __webpack_require__.e(/*! import() | item-detail-item-detail-module */ "common").then(__webpack_require__.bind(null, /*! ./item-detail/item-detail.module */ "./src/app/items/item-detail/item-detail.module.ts")).then(m => m.ItemDetailPageModule)
    },
    {
        path: 'availability',
        loadChildren: () => __webpack_require__.e(/*! import() | availability-by-location-availability-by-location-module */ "common").then(__webpack_require__.bind(null, /*! ./availability-by-location/availability-by-location.module */ "./src/app/items/availability-by-location/availability-by-location.module.ts")).then(m => m.AvailabilityByLocationPageModule)
    },
    {
        path: 'availability-card',
        loadChildren: () => __webpack_require__.e(/*! import() | availability-card-availability-card-module */ "common").then(__webpack_require__.bind(null, /*! ./availability-card/availability-card.module */ "./src/app/items/availability-card/availability-card.module.ts")).then(m => m.AvailabilityCardPageModule)
    },
];
let ItemsPageRoutingModule = class ItemsPageRoutingModule {
};
ItemsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ItemsPageRoutingModule);



/***/ }),

/***/ "./src/app/items/items.module.ts":
/*!***************************************!*\
  !*** ./src/app/items/items.module.ts ***!
  \***************************************/
/*! exports provided: ItemsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ItemsPageModule", function() { return ItemsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _items_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./items-routing.module */ "./src/app/items/items-routing.module.ts");
/* harmony import */ var _items_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./items.page */ "./src/app/items/items.page.ts");







let ItemsPageModule = class ItemsPageModule {
};
ItemsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _items_routing_module__WEBPACK_IMPORTED_MODULE_5__["ItemsPageRoutingModule"]
        ],
        declarations: [_items_page__WEBPACK_IMPORTED_MODULE_6__["ItemsPage"]]
    })
], ItemsPageModule);



/***/ }),

/***/ "./src/app/items/items.page.scss":
/*!***************************************!*\
  !*** ./src/app/items/items.page.scss ***!
  \***************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2l0ZW1zL2l0ZW1zLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/items/items.page.ts":
/*!*************************************!*\
  !*** ./src/app/items/items.page.ts ***!
  \*************************************/
/*! exports provided: ItemsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ItemsPage", function() { return ItemsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _item_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./item.service */ "./src/app/items/item.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");




let ItemsPage = class ItemsPage {
    constructor(itemService, platform, alertCtrl) {
        /* this.appSub = this.platform.backButton.subscribeWithPriority(666666, () => {
          if ( this.constructor.name === 'ItemsPage' ) {
              if (window.confirm(`Do you want to exit the app?`)) {
                navigator['app'].exitApp();
              }
          }
        });*/
        this.itemService = itemService;
        this.platform = platform;
        this.alertCtrl = alertCtrl;
        this.isLoading = true;
        this.searchTerm = null;
        this.searched = null;
        const routerEl = document.querySelector('ion-router');
        document.addEventListener('ionBackButton', (ev) => {
            ev.detail.register(-1, () => {
                const path = window.location.pathname;
                if (path === routerEl.root) {
                    if (window.confirm(`Do you want to exit the app?`)) {
                        navigator['app'].exitApp();
                    }
                }
            });
        });
    }
    ngOnInit() {
        this.isLoading = true;
        this.itemSub = this.itemService.items.subscribe(result => {
            console.log(result);
            this.Items = [...result];
            this.isLoading = false;
        }, error => {
            this.isLoading = false;
            console.log(error.error);
            this.alertCtrl.create({
                header: 'Service Error!',
                message: 'Connection problem: ' + error.error.message,
                buttons: [{ text: 'Okay' }]
            })
                .then(alertEl => {
                alertEl.present();
            });
        });
    }
    searchItem($event) {
        const searchItems = [...this.Items];
        // Begin search only if searchTerm is provided
        if (this.searchTerm.trim().length && this.searchTerm !== '') {
            this.Items = searchItems.filter((prod) => {
                if (prod.Description && prod.Description.length > 1) {
                    return (prod.Description.toLowerCase().indexOf(this.searchTerm.toLowerCase()) > -1);
                }
            });
            return;
        }
        else { // Search Term not provide display all items
            this.initializeItems();
        }
    }
    initializeItems() {
        this.itemSub = this.itemService.items
            .subscribe(result => {
            console.log(result);
            this.Items = [...result];
        });
    }
    ngOnDestroy() {
        if (this.itemSub) {
            this.itemSub.unsubscribe();
        }
        if (this.appSub) {
            this.appSub.unsubscribe();
        }
    }
};
ItemsPage.ctorParameters = () => [
    { type: _item_service__WEBPACK_IMPORTED_MODULE_2__["ItemService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] }
];
ItemsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-items',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./items.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/items/items.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./items.page.scss */ "./src/app/items/items.page.scss")).default]
    })
], ItemsPage);



/***/ })

}]);
//# sourceMappingURL=items-items-module-es2015.js.map