(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["customers-customers-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/customers/customers.page.html":
/*!*************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/customers/customers.page.html ***!
  \*************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n\r\n    <ion-title>My Customers</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content *ngIf=\"customers\">\r\n\r\n  <ion-searchbar [(ngModel)]=\"searchTerm\" debounce=\"2000\" (ionChange)=\"search($event)\" placeholder=\"Search Requisition\">\r\n  </ion-searchbar>\r\n\r\n  <ion-grid>\r\n    <ion-row>\r\n      <ion-col size=\"3\">Name</ion-col>\r\n      <ion-col size=\"3\">Region</ion-col>\r\n      <ion-col size=\"3\">Location</ion-col>\r\n      <ion-col size=\"3\">Phone No.</ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n\r\n  <ion-virtual-scroll [items]=\"customers\" approxItemHeight=\"47.2px\">\r\n\r\n    <ion-item *virtualItem=\"let cust\">\r\n\r\n      <ion-grid>\r\n        <ion-row>\r\n\r\n          <ion-col size=\"3\">\r\n            <ion-label>\r\n              <h3>{{ cust?.Name }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n\r\n          <ion-col size=\"3\">\r\n            <ion-label>\r\n              <h3>{{ cust.Country_Region_Code }}</h3>\r\n              </ion-label>\r\n          </ion-col>\r\n          <ion-col size=\"3\">\r\n            <ion-label>\r\n              <h3>{{ cust.Location_Market }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n              \r\n          <ion-col size=\"3\">\r\n                <ion-label>\r\n                  <h3>{{ cust.Phone_No }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n\r\n        </ion-row>\r\n      </ion-grid>\r\n\r\n    </ion-item>\r\n\r\n  </ion-virtual-scroll>\r\n\r\n\r\n\r\n</ion-content>");

/***/ }),

/***/ "./src/app/customers/customers-routing.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/customers/customers-routing.module.ts ***!
  \*******************************************************/
/*! exports provided: CustomersPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomersPageRoutingModule", function() { return CustomersPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _customers_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./customers.page */ "./src/app/customers/customers.page.ts");




const routes = [
    {
        path: '',
        component: _customers_page__WEBPACK_IMPORTED_MODULE_3__["CustomersPage"]
    },
    {
        path: 'customer-detail',
        loadChildren: () => __webpack_require__.e(/*! import() | customer-detail-customer-detail-module */ "customer-detail-customer-detail-module").then(__webpack_require__.bind(null, /*! ./customer-detail/customer-detail.module */ "./src/app/customers/customer-detail/customer-detail.module.ts")).then(m => m.CustomerDetailPageModule)
    }
];
let CustomersPageRoutingModule = class CustomersPageRoutingModule {
};
CustomersPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CustomersPageRoutingModule);



/***/ }),

/***/ "./src/app/customers/customers.module.ts":
/*!***********************************************!*\
  !*** ./src/app/customers/customers.module.ts ***!
  \***********************************************/
/*! exports provided: CustomersPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomersPageModule", function() { return CustomersPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _customers_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./customers-routing.module */ "./src/app/customers/customers-routing.module.ts");
/* harmony import */ var _customers_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./customers.page */ "./src/app/customers/customers.page.ts");







let CustomersPageModule = class CustomersPageModule {
};
CustomersPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _customers_routing_module__WEBPACK_IMPORTED_MODULE_5__["CustomersPageRoutingModule"]
        ],
        declarations: [_customers_page__WEBPACK_IMPORTED_MODULE_6__["CustomersPage"]]
    })
], CustomersPageModule);



/***/ }),

/***/ "./src/app/customers/customers.page.scss":
/*!***********************************************!*\
  !*** ./src/app/customers/customers.page.scss ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2N1c3RvbWVycy9jdXN0b21lcnMucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/customers/customers.page.ts":
/*!*********************************************!*\
  !*** ./src/app/customers/customers.page.ts ***!
  \*********************************************/
/*! exports provided: CustomersPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CustomersPage", function() { return CustomersPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _auth_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../auth/auth-service */ "./src/app/auth/auth-service.ts");
/* harmony import */ var _payments_payments_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../payments/payments.service */ "./src/app/payments/payments.service.ts");
/* harmony import */ var _utility_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../utility.service */ "./src/app/utility.service.ts");






let CustomersPage = class CustomersPage {
    constructor(utilitySvc, paymentService, authSvc) {
        this.utilitySvc = utilitySvc;
        this.paymentService = paymentService;
        this.authSvc = authSvc;
        this.customers = null;
        this.searchTerm = null;
    }
    ngOnInit() {
        this.setUser();
    }
    ionViewWillEnter() {
        this.setUser();
    }
    ionViewDidEnter() {
        this.FetchCustomers();
    }
    FetchCustomers() {
        this.utilitySvc.presentLoading('Loading Customers ....');
        this.customerListSub = this.paymentService.CustomerBySalesPerson(this.userID)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["finalize"])(() => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.utilitySvc.loadingCtrl.dismiss();
        })))
            .subscribe(cust => {
            console.log(cust);
            this.customers = cust;
        });
    }
    setUser() {
        var _a;
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.user = yield this.authSvc.getUser();
            this.userID = (_a = this.user) === null || _a === void 0 ? void 0 : _a.User_ID;
        });
    }
    search($event) {
        // get a copy of requisitions
        const searchItems = [...this.customers];
        // Begin search, only if searchTerm is provided
        if (this.searchTerm.trim().length && this.searchTerm !== '') {
            this.customers = searchItems.filter((req) => {
                if (req.Name && req.Name.length > 1) {
                    return (req.Name.toLowerCase().indexOf(this.searchTerm.toLowerCase()) > -1);
                }
            });
            return;
        }
        else { // Search Term not provided display all requisitions
            this.initializeItems();
        }
    }
    initializeItems() {
        this.FetchCustomers();
    }
    ngOnDestroy() {
        if (this.customerListSub) {
            this.customerListSub.unsubscribe();
        }
    }
};
CustomersPage.ctorParameters = () => [
    { type: _utility_service__WEBPACK_IMPORTED_MODULE_5__["UtilityService"] },
    { type: _payments_payments_service__WEBPACK_IMPORTED_MODULE_4__["PaymentsService"] },
    { type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"] }
];
CustomersPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-customers',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./customers.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/customers/customers.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./customers.page.scss */ "./src/app/customers/customers.page.scss")).default]
    })
], CustomersPage);



/***/ }),

/***/ "./src/app/orders/order.service.ts":
/*!*****************************************!*\
  !*** ./src/app/orders/order.service.ts ***!
  \*****************************************/
/*! exports provided: OrderService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrderService", function() { return OrderService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");





let OrderService = class OrderService {
    // private items  = new BehaviorSubject<[]>([]) ;
    constructor(http) {
        this.http = http;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
    }
    get orders() {
        return this.http.get(`${this.url}site/saleinvoices`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    // Create New Sales Invoice
    createInvoice() {
        return this.http.get(`${this.url}site/create-invoice`);
    }
    // Retrieve Sales Invoice Card / Details
    ordercard(id) {
        return this.http.get(`${this.url}site/saleinvoice/?id=${id}`);
    }
    // Post Lines Data
    postLine(line) {
        return this.http.post(`${this.url}site/addsalesinvoiceline`, JSON.stringify(line));
    }
    // Update Line
    updateInvoiceLine(line) {
        return this.http.post(`${this.url}site/updatesalesinvoiceline`, JSON.stringify(line));
    }
    // Fetch Line to Update
    getLine(docId, LineNo) {
        return this.http.get(`${this.url}site/getsalesinvoiceline?Document_No=${docId}&Line_No=${LineNo}`);
    }
    // Post Invoice Header
    postInvoice(invoice) {
        invoice.Posting_Date = this.formatDate(invoice.Posting_Date);
        invoice.Due_Date = this.formatDate(invoice.Due_Date);
        return this.http.post(`${this.url}site/update-invoice`, JSON.stringify(invoice));
    }
    // Get Customers
    get Customers() {
        return this.http.get(`${this.url}site/receipting-customers`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    postSalesInvoice(No) {
        return this.http.get(`${this.url}site/postsaleinvoice?No=${No}`);
    }
    // Format date utility
    formatDate(datestring) {
        // Format Date to YYYY-MM-DD
        const recDate = new Date(datestring);
        const month = (recDate.getMonth() + 1) > 9 ? recDate.getMonth() + 1 : `0` + (recDate.getMonth() + 1);
        const day = (recDate.getDate()) > 9 ? recDate.getDate() : `0` + recDate.getDate();
        return `${recDate.getFullYear()}-${month}-${day}`;
    }
};
OrderService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
OrderService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], OrderService);



/***/ }),

/***/ "./src/app/payments/payments.service.ts":
/*!**********************************************!*\
  !*** ./src/app/payments/payments.service.ts ***!
  \**********************************************/
/*! exports provided: PaymentsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PaymentsService", function() { return PaymentsService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _orders_order_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../orders/order.service */ "./src/app/orders/order.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");








let PaymentsService = class PaymentsService {
    constructor(http, orderService, toastCtrl) {
        this.http = http;
        this.orderService = orderService;
        this.toastCtrl = toastCtrl;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].url;
        this._refresh$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__["Subject"]();
    }
    // Define a synthetic getter for the subject
    get refresh$() {
        return this._refresh$;
    }
    newPayment(receipt) {
        return this.http.post(`${this.url}site/cash-sale`, JSON.stringify(receipt));
    }
    updateReceipt(receipt) {
        return this.http.post(`${this.url}site/cash-sale`, JSON.stringify(receipt));
    }
    getPayments(userID) {
        return this.http.get(`${this.url}site/get?service=POSReceiptList&userid=${userID}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    getPayment(id) {
        return this.http.get(`${this.url}site/receipt/?id=${id}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    get Banks() {
        return this.http.get(`${this.url}site/get?service=BankAccounts`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    getLine(Key) {
        return this.http.get(`${this.url}site/cash-sale-line?Key=${Key}`);
    }
    suggestlines(receiptNo, customerNo) {
        return this.http.get(`${this.url}site/suggestlines?receiptNo=${receiptNo}&customerNo=${customerNo}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    // Post Lines Data
    postLine(line) {
        return this.http.post(`${this.url}site/cash-sale-line`, JSON.stringify(line))
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(() => {
            this._refresh$.next();
        }));
    }
    // Update Line
    updateLine(line) {
        return this.http.post(`${this.url}site/cash-sale-line`, JSON.stringify(line))
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(() => {
            this._refresh$.next();
        }));
    }
    get Customers() {
        return this.http.get(`${this.url}site/receipting-customers`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    /*
     * Get Customer By Search Name
     */
    Customer(searchName) {
        return this.http.get(`${this.url}site/receipting-customers?searchName=${searchName}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    /*
     * Get Customer By Sales Person Code
     */
    CustomerBySalesPerson(salesPersonCode) {
        return this.http.get(`${this.url}site/receipting-customers?Salesperson_Code=${salesPersonCode}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    // Get CustomerPriceGroups
    CustomerPriceGroups() {
        return this.http.get(`${this.url}site/get?service=CustomerPriceGroups`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    Mpesa() {
        return this.http.get(`${this.url}site/get?service=MPESATransactions`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    selectLine(CustomerNo, Line, ReceiptNo) {
        const payload = { Customer_No: CustomerNo, Line_No: Line, Receipt_No: ReceiptNo };
        return this.http.post(`${this.url}site/updatecashreceiptline`, JSON.stringify(payload));
    }
    setAmountToReceipt(CustomerNo, Line, ReceiptNo, AmountToReceipt) {
        const payload = { Customer_No: CustomerNo, Line_No: Line, Receipt_No: ReceiptNo, Amount_To_Receipt: AmountToReceipt };
        // console.log(payload); return;
        return this.http.post(`${this.url}site/updateamounttoreceipt`, JSON.stringify(payload));
    }
    postReceipt(No) {
        return this.http.get(`${this.url}site/postreceipt?No=${No}`);
    }
    getTotals(elements, subjectColumn) {
        let sum = 0;
        elements.forEach(obj => {
            // console.log(obj);
            for (const property in obj) {
                if (property === subjectColumn && !isNaN(+obj[property])) {
                    // console.log(+obj[property]);
                    sum += +obj[property];
                }
            }
        });
        return sum;
    }
    showToast(text) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return yield this.toastCtrl.create({
                message: text,
                duration: 4000,
                position: 'top'
            }).then(toastEl => {
                toastEl.present();
            });
        });
    }
    formatDate(date) {
        return this.orderService.formatDate(date);
    }
    FilterReceipts(startDate, userID) {
        return this.http.get(`${this.url}site/filterpayments?startdate=${startDate}&userid=${userID}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    FilterReceiptsbyRange(startDate, endDate, userID) {
        return this.http.get(`${this.url}site/filterpayments?startdate=${startDate}&enddate=${endDate}&userid=${userID}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
};
PaymentsService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
    { type: _orders_order_service__WEBPACK_IMPORTED_MODULE_5__["OrderService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] }
];
PaymentsService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], PaymentsService);



/***/ }),

/***/ "./src/app/utility.service.ts":
/*!************************************!*\
  !*** ./src/app/utility.service.ts ***!
  \************************************/
/*! exports provided: UtilityService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UtilityService", function() { return UtilityService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");



let UtilityService = class UtilityService {
    constructor(toastCtrl, alertCtrl, loadingCtrl) {
        this.toastCtrl = toastCtrl;
        this.alertCtrl = alertCtrl;
        this.loadingCtrl = loadingCtrl;
    }
    formatDate(datestring) {
        // Format Date to YYYY-MM-DD
        const recDate = new Date(datestring);
        const month = (recDate.getMonth() + 1) > 9 ? recDate.getMonth() + 1 : `0` + (recDate.getMonth() + 1);
        const day = (recDate.getDate()) > 9 ? recDate.getDate() : `0` + recDate.getDate();
        return `${recDate.getFullYear()}-${month}-${day}`;
    }
    showToast(text) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            let toastEl = this.toastCtrl.create({
                message: text,
                duration: 4000,
                position: 'top'
            });
            (yield toastEl).present();
        });
    }
    showAlert(text) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alertEl = yield this.alertCtrl.create({
                header: 'Operation Error',
                message: 'Message : ' + text,
                buttons: [{ text: 'Okay' }]
            });
            yield alertEl.present();
        });
    }
    presentLoading(message) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingCtrl.create({
                spinner: 'dots',
                animated: true,
                message: (message) ? message : 'Loading Data...'
            });
            yield loading.present();
        });
    }
};
UtilityService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] }
];
UtilityService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], UtilityService);



/***/ })

}]);
//# sourceMappingURL=customers-customers-module-es2015.js.map