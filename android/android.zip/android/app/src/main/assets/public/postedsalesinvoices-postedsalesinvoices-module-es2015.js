(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["postedsalesinvoices-postedsalesinvoices-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/postedsalesinvoices/postedsalesinvoices.page.html":
/*!*********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/postedsalesinvoices/postedsalesinvoices.page.html ***!
  \*********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <ion-title>Posted Sales Invoices</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <div *ngIf=\"isLoading\" class=\"ion-text-center\">\r\n    <ion-spinner name=\"lines-small\"></ion-spinner>\r\n  </div>\r\n\r\n  <ion-searchbar [(ngModel)]=\"searchTerm\" debounce=\"2000\" (ionChange)=\"searchSale($event)\"></ion-searchbar>\r\n  \r\n\r\n  <ion-grid fixed>\r\n\r\n    <ion-row>\r\n      <ion-col col-4 col-sm>Posting Date</ion-col>\r\n      <ion-col col-4 col-sm>Customer</ion-col>\r\n      <ion-col col-4 col-sm>Amount </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n  <ion-virtual-scroll [items]=\"sales\" approxItemHeight=\"47.2px\">\r\n              \r\n    <ion-item-sliding *virtualItem=\"let sale\" #sliding>\r\n      <ion-item [routerLink]=\"['/','postedsales',sale.Key]\" detail>\r\n        <ion-grid>\r\n          <ion-row>\r\n          <ion-col col-4 col-sm>\r\n            <ion-label>\r\n              <h3>{{ sale?.Posting_Date }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n          <ion-col col-4 col-sm>\r\n            <ion-label>\r\n              <h3>{{ sale?.Sell_to_Customer_Name }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n          <ion-col col-4 col-sm>\r\n            <ion-label>\r\n              <h3>{{ sale?.Amount }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n        </ion-row>\r\n        </ion-grid>\r\n  </ion-item>\r\n  <ion-item-options>\r\n    <ion-item-option color=\"secondary\" (click)=\"onReturn(sale.Key, sliding)\">\r\n      <ion-icon name=\"backspace\" slot=\"top\"></ion-icon>\r\n      Return\r\n    </ion-item-option>\r\n  </ion-item-options>\r\n  </ion-item-sliding>\r\n  \r\n  </ion-virtual-scroll>\r\n\r\n</ion-content>\r\n");

/***/ }),

/***/ "./src/app/orders/order.service.ts":
/*!*****************************************!*\
  !*** ./src/app/orders/order.service.ts ***!
  \*****************************************/
/*! exports provided: OrderService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrderService", function() { return OrderService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");





let OrderService = class OrderService {
    // private items  = new BehaviorSubject<[]>([]) ;
    constructor(http) {
        this.http = http;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
    }
    get orders() {
        return this.http.get(`${this.url}site/saleinvoices`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    // Create New Sales Invoice
    createInvoice() {
        return this.http.get(`${this.url}site/create-invoice`);
    }
    // Retrieve Sales Invoice Card / Details
    ordercard(id) {
        return this.http.get(`${this.url}site/saleinvoice/?id=${id}`);
    }
    // Post Lines Data
    postLine(line) {
        return this.http.post(`${this.url}site/addsalesinvoiceline`, JSON.stringify(line));
    }
    // Update Line
    updateInvoiceLine(line) {
        return this.http.post(`${this.url}site/updatesalesinvoiceline`, JSON.stringify(line));
    }
    // Fetch Line to Update
    getLine(docId, LineNo) {
        return this.http.get(`${this.url}site/getsalesinvoiceline?Document_No=${docId}&Line_No=${LineNo}`);
    }
    // Post Invoice Header
    postInvoice(invoice) {
        invoice.Posting_Date = this.formatDate(invoice.Posting_Date);
        invoice.Due_Date = this.formatDate(invoice.Due_Date);
        return this.http.post(`${this.url}site/update-invoice`, JSON.stringify(invoice));
    }
    // Get Customers
    get Customers() {
        return this.http.get(`${this.url}site/receipting-customers`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    postSalesInvoice(No) {
        return this.http.get(`${this.url}site/postsaleinvoice?No=${No}`);
    }
    // Format date utility
    formatDate(datestring) {
        // Format Date to YYYY-MM-DD
        const recDate = new Date(datestring);
        const month = (recDate.getMonth() + 1) > 9 ? recDate.getMonth() + 1 : `0` + (recDate.getMonth() + 1);
        const day = (recDate.getDate()) > 9 ? recDate.getDate() : `0` + recDate.getDate();
        return `${recDate.getFullYear()}-${month}-${day}`;
    }
};
OrderService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
OrderService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], OrderService);



/***/ }),

/***/ "./src/app/postedsalesinvoices/postedsalesinvoices-routing.module.ts":
/*!***************************************************************************!*\
  !*** ./src/app/postedsalesinvoices/postedsalesinvoices-routing.module.ts ***!
  \***************************************************************************/
/*! exports provided: PostedsalesinvoicesPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PostedsalesinvoicesPageRoutingModule", function() { return PostedsalesinvoicesPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _postedsalesinvoices_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./postedsalesinvoices.page */ "./src/app/postedsalesinvoices/postedsalesinvoices.page.ts");




const routes = [
    {
        path: '',
        component: _postedsalesinvoices_page__WEBPACK_IMPORTED_MODULE_3__["PostedsalesinvoicesPage"]
    },
    {
        path: 'sale-detail',
        loadChildren: () => __webpack_require__.e(/*! import() | sale-detail-sale-detail-module */ "default~postedsalesinvoices-sale-detail-sale-detail-module~sale-detail-sale-detail-module").then(__webpack_require__.bind(null, /*! ./sale-detail/sale-detail.module */ "./src/app/postedsalesinvoices/sale-detail/sale-detail.module.ts")).then(m => m.SaleDetailPageModule)
    },
    {
        path: 'dailyreport',
        loadChildren: () => __webpack_require__.e(/*! import() | dailyreport-dailyreport-module */ "common").then(__webpack_require__.bind(null, /*! ./dailyreport/dailyreport.module */ "./src/app/postedsalesinvoices/dailyreport/dailyreport.module.ts")).then(m => m.DailyreportPageModule)
    },
    {
        path: 'monthlyreport',
        loadChildren: () => __webpack_require__.e(/*! import() | monthlyreport-monthlyreport-module */ "common").then(__webpack_require__.bind(null, /*! ./monthlyreport/monthlyreport.module */ "./src/app/postedsalesinvoices/monthlyreport/monthlyreport.module.ts")).then(m => m.MonthlyreportPageModule)
    }
];
let PostedsalesinvoicesPageRoutingModule = class PostedsalesinvoicesPageRoutingModule {
};
PostedsalesinvoicesPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], PostedsalesinvoicesPageRoutingModule);



/***/ }),

/***/ "./src/app/postedsalesinvoices/postedsalesinvoices.module.ts":
/*!*******************************************************************!*\
  !*** ./src/app/postedsalesinvoices/postedsalesinvoices.module.ts ***!
  \*******************************************************************/
/*! exports provided: PostedsalesinvoicesPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PostedsalesinvoicesPageModule", function() { return PostedsalesinvoicesPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _postedsalesinvoices_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./postedsalesinvoices-routing.module */ "./src/app/postedsalesinvoices/postedsalesinvoices-routing.module.ts");
/* harmony import */ var _postedsalesinvoices_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./postedsalesinvoices.page */ "./src/app/postedsalesinvoices/postedsalesinvoices.page.ts");







let PostedsalesinvoicesPageModule = class PostedsalesinvoicesPageModule {
};
PostedsalesinvoicesPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _postedsalesinvoices_routing_module__WEBPACK_IMPORTED_MODULE_5__["PostedsalesinvoicesPageRoutingModule"]
        ],
        declarations: [_postedsalesinvoices_page__WEBPACK_IMPORTED_MODULE_6__["PostedsalesinvoicesPage"]]
    })
], PostedsalesinvoicesPageModule);



/***/ }),

/***/ "./src/app/postedsalesinvoices/postedsalesinvoices.page.scss":
/*!*******************************************************************!*\
  !*** ./src/app/postedsalesinvoices/postedsalesinvoices.page.scss ***!
  \*******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3Bvc3RlZHNhbGVzaW52b2ljZXMvcG9zdGVkc2FsZXNpbnZvaWNlcy5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/postedsalesinvoices/postedsalesinvoices.page.ts":
/*!*****************************************************************!*\
  !*** ./src/app/postedsalesinvoices/postedsalesinvoices.page.ts ***!
  \*****************************************************************/
/*! exports provided: PostedsalesinvoicesPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PostedsalesinvoicesPage", function() { return PostedsalesinvoicesPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _sales_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./sales.service */ "./src/app/postedsalesinvoices/sales.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");






let PostedsalesinvoicesPage = class PostedsalesinvoicesPage {
    constructor(salesService, alertCtrl, router) {
        this.salesService = salesService;
        this.alertCtrl = alertCtrl;
        this.router = router;
        this.FilterRange = { startDate: new Date(), endDate: new Date() };
        this.isLoading = true;
        this.searchTerm = null;
        this.Total = 0;
    }
    ngOnInit() {
        this.FetchSales();
    }
    ionViewWillEnter() {
        // this.FetchSales();
    }
    ionViewDidEnter() {
        // this.FetchSales();
    }
    FetchSales() {
        this.SalesSub = this.salesService.Sales
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["finalize"])(() => {
            this.isLoading = false;
        }))
            .subscribe(result => {
            this.sales = this.sort([...result]);
        }, error => {
            console.log(error.error);
            this.alertCtrl.create({
                header: 'Service Error!',
                message: 'Connection problem: ' + error.error.message,
                buttons: [{ text: 'Okay' }]
            }).then(alertEl => {
                alertEl.present();
            });
        });
    }
    searchSale($event) {
        const searchItems = [...this.sales];
        // Begin search only if searchTerm is provided
        if (this.searchTerm.trim().length && this.searchTerm !== '') {
            this.sales = searchItems.filter((sales) => {
                if (sales.Customer_Name && sales.Customer_Name.length > 1) {
                    return (sales.Customer_Name.toLowerCase().indexOf(this.searchTerm.toLowerCase()) > -1);
                }
            });
            return;
        }
        else { // Search Term not provide display all items
            this.FetchSales();
        }
    }
    getTotals(elements) {
        let sum = 0;
        elements.forEach(obj => {
            console.log(obj);
            for (const property in obj) {
                if (property === 'Amount_Including_VAT' && !isNaN(+obj[property])) {
                    console.log(+obj[property]);
                    sum += +obj[property];
                }
            }
        });
        return sum;
    }
    sort(dataArray) {
        return dataArray.sort((a, b) => (b.No > a.No) ? 1 : -1);
    }
    onReturn(Key, sliding) {
        sliding.close();
        //Create return request, send postedsales invoice key for retrieval of the rcord
        this.router.navigate(['../return/create/', Key]);
    }
    ngOnDestroy() {
        if (this.SalesSub) {
            this.SalesSub.unsubscribe();
        }
    }
};
PostedsalesinvoicesPage.ctorParameters = () => [
    { type: _sales_service__WEBPACK_IMPORTED_MODULE_2__["SalesService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"] }
];
PostedsalesinvoicesPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-postedsalesinvoices',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./postedsalesinvoices.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/postedsalesinvoices/postedsalesinvoices.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./postedsalesinvoices.page.scss */ "./src/app/postedsalesinvoices/postedsalesinvoices.page.scss")).default]
    })
], PostedsalesinvoicesPage);



/***/ }),

/***/ "./src/app/postedsalesinvoices/sales.service.ts":
/*!******************************************************!*\
  !*** ./src/app/postedsalesinvoices/sales.service.ts ***!
  \******************************************************/
/*! exports provided: SalesService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SalesService", function() { return SalesService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _orders_order_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../orders/order.service */ "./src/app/orders/order.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");







let SalesService = class SalesService {
    constructor(http, orderService, toastCtrl) {
        this.http = http;
        this.orderService = orderService;
        this.toastCtrl = toastCtrl;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].url;
    }
    get Sales() {
        return this.http.get(`${this.url}site/get?service=PostedSalesInvoices`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    getSale(id) {
        return this.http.get(`${this.url}site/sale/?Key=${id}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    formatDate(date) {
        return this.orderService.formatDate(date);
    }
    FilterSales(startDate, userID) {
        return this.http.get(`${this.url}site/filtersales?startdate=${startDate}&userid=${userID}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    FilterSalesbyRange(startDate, endDate, userID) {
        return this.http.get(`${this.url}site/filtersales?startdate=${startDate}&enddate=${endDate}&userid=${userID}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    showToast(text) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return yield this.toastCtrl.create({
                message: text,
                duration: 4000,
                position: 'top'
            }).then(toastEl => {
                toastEl.present();
            });
        });
    }
};
SalesService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] },
    { type: _orders_order_service__WEBPACK_IMPORTED_MODULE_5__["OrderService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] }
];
SalesService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], SalesService);



/***/ })

}]);
//# sourceMappingURL=postedsalesinvoices-postedsalesinvoices-module-es2015.js.map