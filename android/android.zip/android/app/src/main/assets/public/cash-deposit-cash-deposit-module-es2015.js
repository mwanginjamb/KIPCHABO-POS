(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["cash-deposit-cash-deposit-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/cash-deposit/cash-deposit.page.html":
/*!*******************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/cash-deposit/cash-deposit.page.html ***!
  \*******************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n      <ion-title>Cash Deposit List</ion-title>\r\n      <ion-buttons slot=\"end\">\r\n        <ion-button slot=\"icon-only\" fill=\"clear\" (click)=\"onAddDeposit()\">\r\n          <ion-icon name=\"add\"></ion-icon>\r\n        </ion-button>\r\n      </ion-buttons>\r\n\r\n    </ion-toolbar>\r\n</ion-header>\r\n\r\n<div *ngIf=\"isLoading\" class=\"ion-text-center\">\r\n  <ion-spinner name=\"crescent\"></ion-spinner>\r\n</div>\r\n<ion-content *ngIf=\"!isLoading\">\r\n  \r\n  <ion-searchbar [(ngModel)]=\"searchTerm\" debounce=\"2000\" (ionChange)=\"searchPayment($event)\"></ion-searchbar>\r\n  <ion-grid fixed>\r\n    <ion-row>\r\n      <ion-col col-4 col-sm>No.</ion-col>\r\n      <ion-col col-4 col-sm>Posting Date</ion-col>\r\n      <ion-col col-4 col-sm>Creator</ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n  \r\n  <ion-virtual-scroll *ngIf=\"!isLoading\" [items]=\"depositsList\" approxItemHeight=\"47.2px\">\r\n  \r\n    <ion-item [routerLink]=\"['/','cash-deposit', payment.Key ]\" detail *virtualItem=\"let payment\">\r\n  \r\n      <ion-grid>\r\n        <ion-row>\r\n  \r\n          <ion-col col-4 col-sm>\r\n            <ion-label>\r\n              <h3>{{ payment?.No }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n  \r\n          <ion-col col-4 col-sm>\r\n            <ion-label>\r\n              <h3>{{ payment?.Posting_Date }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n  \r\n          <ion-col col-6 col-sm>\r\n            <ion-label>\r\n              <h3>{{ payment.Created_By}}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n  \r\n        </ion-row>\r\n      </ion-grid>\r\n  \r\n    </ion-item>\r\n  \r\n  </ion-virtual-scroll>\r\n\r\n</ion-content>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/cash-deposit/new-deposit/new-deposit.component.html":
/*!***********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/cash-deposit/new-deposit/new-deposit.component.html ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>New Cash Deposit</ion-title>\r\n\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button (click)=\"onCancel()\">\r\n        <ion-icon name=\"close\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content *ngIf=\"cashDeposit.Key\">\r\n  <ion-grid>\r\n    <ion-row>\r\n      <ion-col>\r\n        <ion-card>\r\n          <ion-card-header>\r\n            <ion-card-title>\r\n              Cash Deposit Card\r\n            </ion-card-title>\r\n          </ion-card-header>\r\n\r\n          <ion-card-content>\r\n\r\n            <ion-fab vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\">\r\n              <ion-fab-button color=\"warning\" (click)=\"post(cashDeposit.No)\">\r\n                <ion-icon name=\"send\"></ion-icon>\r\n              </ion-fab-button>\r\n            </ion-fab>\r\n\r\n            <ion-row>\r\n              <ion-col>\r\n                <ion-item>\r\n                  <ion-label position=\"floating\">No.</ion-label>\r\n                  <ion-input [(ngModel)]=\"cashDeposit.No\"></ion-input>\r\n                </ion-item>\r\n              </ion-col>\r\n\r\n              <ion-col>\r\n                <ion-item>\r\n                  <ion-label position=\"floating\">Reference</ion-label>\r\n                  <ion-input [(ngModel)]=\"cashDeposit.Reference\" (ionBlur)=\"onUpdateDocument()\" placeholder=\"Add Transaction Reference\">\r\n                  </ion-input>\r\n                </ion-item>\r\n              </ion-col>\r\n            </ion-row>\r\n\r\n\r\n            <ion-row>\r\n              <ion-col>\r\n                <ion-item>\r\n                  <ion-label position=\"floating\">Posting Date: </ion-label>\r\n                  <ion-input [(ngModel)]=\"cashDeposit.Posting_Date\"></ion-input>\r\n                </ion-item>\r\n              </ion-col>\r\n\r\n              <ion-col>\r\n                <ion-item>\r\n                  <ion-label position=\"floating\">Amount:</ion-label>\r\n                  <ion-input [(ngModel)]=\"cashDeposit.Amount\" readonly></ion-input>\r\n                </ion-item>\r\n              </ion-col>\r\n            </ion-row>\r\n\r\n\r\n            <ion-row>\r\n              <ion-col>\r\n                <ion-item>\r\n                  <ion-label position=\"floating\">Created By</ion-label>\r\n                  <ion-input [(ngModel)]=\"cashDeposit.Created_By\"></ion-input>\r\n                </ion-item>\r\n              </ion-col>\r\n\r\n              <ion-col>\r\n\r\n              </ion-col>\r\n\r\n            </ion-row>\r\n\r\n\r\n\r\n          </ion-card-content>\r\n\r\n        </ion-card>\r\n\r\n\r\n        <!--Start Lines Card-->\r\n        <ion-card>\r\n          <ion-card-header>\r\n            <ion-card-title>Invoice Lines</ion-card-title>\r\n          </ion-card-header>\r\n          <ion-card-content>\r\n            <ion-grid>\r\n\r\n\r\n\r\n              <ion-row scrollX=\"true\">\r\n                <ion-col>\r\n                  <ion-label>Customer</ion-label>\r\n                </ion-col>\r\n\r\n                <ion-col>\r\n                  <ion-label>Amount</ion-label>\r\n                </ion-col>\r\n\r\n                <ion-col>\r\n                  <ion-label>Select</ion-label>\r\n                </ion-col>\r\n\r\n              </ion-row>\r\n\r\n\r\n\r\n              <ion-list *ngFor=\"let ln of cashDeposit?.Cash_Deposit_Lines?.Cash_Deposit_Lines\">\r\n                <ion-row>\r\n\r\n                  <ion-col>\r\n                    <ion-item>\r\n                      <ion-label>{{ln.Customer_Name }}</ion-label>\r\n                    </ion-item>\r\n                  </ion-col>\r\n\r\n                  <ion-col>\r\n                    <ion-item>\r\n                      <ion-label>{{ln.Amount | currency: 'Ksh.'}}</ion-label>\r\n                    </ion-item>\r\n                  </ion-col>\r\n\r\n                  <ion-col>\r\n                    <ion-item>\r\n                      <input type=\"checkbox\" [value]=\"ln.Select\" (click)=\"onUpdateLine(ln.Key)\" />\r\n                    </ion-item>\r\n                  </ion-col>\r\n\r\n\r\n                </ion-row>\r\n              </ion-list>\r\n\r\n\r\n            </ion-grid>\r\n          </ion-card-content>\r\n        </ion-card>\r\n        <!--End Lines Card-->\r\n\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n</ion-content>");

/***/ }),

/***/ "./src/app/cash-deposit/cash-deposit-routing.module.ts":
/*!*************************************************************!*\
  !*** ./src/app/cash-deposit/cash-deposit-routing.module.ts ***!
  \*************************************************************/
/*! exports provided: CashDepositPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CashDepositPageRoutingModule", function() { return CashDepositPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _cash_deposit_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./cash-deposit.page */ "./src/app/cash-deposit/cash-deposit.page.ts");




const routes = [
    {
        path: '',
        component: _cash_deposit_page__WEBPACK_IMPORTED_MODULE_3__["CashDepositPage"]
    },
    {
        path: 'cash-deposit-detail',
        loadChildren: () => __webpack_require__.e(/*! import() | cash-deposit-detail-cash-deposit-detail-module */ "common").then(__webpack_require__.bind(null, /*! ./cash-deposit-detail/cash-deposit-detail.module */ "./src/app/cash-deposit/cash-deposit-detail/cash-deposit-detail.module.ts")).then(m => m.CashDepositDetailPageModule)
    }
];
let CashDepositPageRoutingModule = class CashDepositPageRoutingModule {
};
CashDepositPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], CashDepositPageRoutingModule);



/***/ }),

/***/ "./src/app/cash-deposit/cash-deposit.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/cash-deposit/cash-deposit.module.ts ***!
  \*****************************************************/
/*! exports provided: CashDepositPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CashDepositPageModule", function() { return CashDepositPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _cash_deposit_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./cash-deposit-routing.module */ "./src/app/cash-deposit/cash-deposit-routing.module.ts");
/* harmony import */ var _cash_deposit_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./cash-deposit.page */ "./src/app/cash-deposit/cash-deposit.page.ts");
/* harmony import */ var _new_deposit_new_deposit_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./new-deposit/new-deposit.component */ "./src/app/cash-deposit/new-deposit/new-deposit.component.ts");








let CashDepositPageModule = class CashDepositPageModule {
};
CashDepositPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _cash_deposit_routing_module__WEBPACK_IMPORTED_MODULE_5__["CashDepositPageRoutingModule"]
        ],
        entryComponents: [_new_deposit_new_deposit_component__WEBPACK_IMPORTED_MODULE_7__["NewDepositComponent"]],
        declarations: [_cash_deposit_page__WEBPACK_IMPORTED_MODULE_6__["CashDepositPage"], _new_deposit_new_deposit_component__WEBPACK_IMPORTED_MODULE_7__["NewDepositComponent"]]
    })
], CashDepositPageModule);



/***/ }),

/***/ "./src/app/cash-deposit/cash-deposit.page.scss":
/*!*****************************************************!*\
  !*** ./src/app/cash-deposit/cash-deposit.page.scss ***!
  \*****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2Nhc2gtZGVwb3NpdC9jYXNoLWRlcG9zaXQucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/cash-deposit/cash-deposit.page.ts":
/*!***************************************************!*\
  !*** ./src/app/cash-deposit/cash-deposit.page.ts ***!
  \***************************************************/
/*! exports provided: CashDepositPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "CashDepositPage", function() { return CashDepositPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _auth_auth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../auth/auth-service */ "./src/app/auth/auth-service.ts");
/* harmony import */ var _models_cashdeposit_model__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../models/cashdeposit.model */ "./src/app/models/cashdeposit.model.ts");
/* harmony import */ var _models_cashdepositheader_model__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../models/cashdepositheader.model */ "./src/app/models/cashdepositheader.model.ts");
/* harmony import */ var _utility_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../utility.service */ "./src/app/utility.service.ts");
/* harmony import */ var _cash_deposit_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./cash-deposit.service */ "./src/app/cash-deposit/cash-deposit.service.ts");
/* harmony import */ var _new_deposit_new_deposit_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./new-deposit/new-deposit.component */ "./src/app/cash-deposit/new-deposit/new-deposit.component.ts");











let CashDepositPage = class CashDepositPage {
    constructor(authService, depositSvc, utilitySvc, modalCtrl, popoverCtrl) {
        this.authService = authService;
        this.depositSvc = depositSvc;
        this.utilitySvc = utilitySvc;
        this.modalCtrl = modalCtrl;
        this.popoverCtrl = popoverCtrl;
        this.isLoading = true;
        this.searchTerm = null;
        this.cashDeposit = new _models_cashdeposit_model__WEBPACK_IMPORTED_MODULE_6__["Cashdeposit"]();
        this.cashDepositHeader = new _models_cashdepositheader_model__WEBPACK_IMPORTED_MODULE_7__["Cashdepositheader"]();
        this.documentNo$ = new rxjs__WEBPACK_IMPORTED_MODULE_3__["Subject"]();
    }
    ngOnInit() {
        this.setUser();
        this.popoverCtrl.dismiss();
    }
    getDocumentNo$() {
        return this.documentNo$;
    }
    ionViewWillEnter() {
        this.setUser();
        console.log('Will Enter');
        this.FetchDeposits;
    }
    ionViewDidEnter() {
        this.setUser();
        console.table(this.user);
        console.log('Did Enter');
        this.FetchDeposits();
    }
    setUser() {
        var _a;
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.user = yield this.authService.getUser();
            this.userID = (_a = this.user) === null || _a === void 0 ? void 0 : _a.User_ID;
        });
    }
    FetchDeposits() {
        this.depositSub = this.depositSvc.getCashdeposits(this.userID)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["finalize"])(() => {
            this.isLoading = false;
        }))
            .subscribe(result => {
            this.depositsList = this.sort([...result]);
        }, error => {
            console.log(error.error);
            this.utilitySvc.showAlert(error.error.message);
        });
    }
    FetchCard(No) {
        this.cardSub = this.depositSvc.getCardByNo(No)
            .subscribe(result => {
            console.log(`Getting payload.....................`);
            console.table(result);
            this.cashDeposit = result;
            this.documentNo$.next(result.Key);
        });
    }
    sort(dataArray) {
        return dataArray.sort((a, b) => (b.No > a.No) ? 1 : -1);
    }
    initialRequest() {
        if (this.userID.length) {
            this.utilitySvc.presentLoading('Initializing Cash Deposit');
            this.cashDepositSub = this.depositSvc.newDeposit(this.userID)
                .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["finalize"])(() => {
                this.utilitySvc.loadingCtrl.dismiss();
            }))
                .subscribe(res => {
                console.log(`Initialize Cash Deposit`);
                if (typeof res === 'string') {
                    this.utilitySvc.showAlert(res);
                    return;
                }
                // FETCH THE DAMN cashCard
                this.FetchCard(res);
            }, error => {
                this.utilitySvc.showAlert(error.error.message);
            });
        }
    }
    onAddDeposit() {
        // Pull up the modal and populate the CashDeposit MODEL with initial ERP data
        this.initialRequest();
        this.getDocumentNo$().subscribe(res => {
            if (res) {
                this.modalCtrl.create({
                    component: _new_deposit_new_deposit_component__WEBPACK_IMPORTED_MODULE_10__["NewDepositComponent"],
                    componentProps: { cashDepo: this.cashDeposit }
                })
                    .then(modalEl => {
                    modalEl.present();
                });
            }
        });
    }
    searchPayment($event) {
        const searchItems = [...this.depositsList];
        // Begin search only if searchTerm is provided
        if (this.searchTerm.trim().length && this.searchTerm !== '') {
            this.depositsList = searchItems.filter((payment) => {
                if (payment.No && payment.No.length > 1) {
                    return (payment.No.toLowerCase().indexOf(this.searchTerm.toLowerCase()) > -1);
                }
            });
            return;
        }
        else { // Search Term not provide display all items
            this.FetchDeposits();
        }
    }
};
CashDepositPage.ctorParameters = () => [
    { type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_5__["AuthService"] },
    { type: _cash_deposit_service__WEBPACK_IMPORTED_MODULE_9__["CashDepositService"] },
    { type: _utility_service__WEBPACK_IMPORTED_MODULE_8__["UtilityService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PopoverController"] }
];
CashDepositPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-cash-deposit',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./cash-deposit.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/cash-deposit/cash-deposit.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./cash-deposit.page.scss */ "./src/app/cash-deposit/cash-deposit.page.scss")).default]
    })
], CashDepositPage);



/***/ }),

/***/ "./src/app/cash-deposit/new-deposit/new-deposit.component.scss":
/*!*********************************************************************!*\
  !*** ./src/app/cash-deposit/new-deposit/new-deposit.component.scss ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2Nhc2gtZGVwb3NpdC9uZXctZGVwb3NpdC9uZXctZGVwb3NpdC5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/cash-deposit/new-deposit/new-deposit.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/cash-deposit/new-deposit/new-deposit.component.ts ***!
  \*******************************************************************/
/*! exports provided: NewDepositComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewDepositComponent", function() { return NewDepositComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var src_app_models_cashdeposit_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/models/cashdeposit.model */ "./src/app/models/cashdeposit.model.ts");
/* harmony import */ var src_app_models_cashdepositline_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/models/cashdepositline.model */ "./src/app/models/cashdepositline.model.ts");
/* harmony import */ var src_app_utility_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/utility.service */ "./src/app/utility.service.ts");
/* harmony import */ var _cash_deposit_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../cash-deposit.service */ "./src/app/cash-deposit/cash-deposit.service.ts");







let NewDepositComponent = class NewDepositComponent {
    constructor(depositSvc, utilitySvc, modalCtrl) {
        this.depositSvc = depositSvc;
        this.utilitySvc = utilitySvc;
        this.modalCtrl = modalCtrl;
        this.cashDeposit = new src_app_models_cashdeposit_model__WEBPACK_IMPORTED_MODULE_3__["Cashdeposit"]();
        this.line = new src_app_models_cashdepositline_model__WEBPACK_IMPORTED_MODULE_4__["Cashdepositline"]();
    }
    ngOnInit() {
        // console.log(`Cash Deposit State passed to component:`);
        // console.table(this.cashDepo);
        Object.assign(this.cashDeposit, this.cashDepo);
        // check if lines have changed and update card accordingly
        this.depositSvc.lineRefresh$.subscribe(res => {
            console.log(`Updated Line.......`);
            console.log(res);
        });
    }
    onUpdateDocument() {
        this.updateSub = this.depositSvc.updateDeposit(this.cashDeposit)
            .subscribe(res => {
            if (typeof res === 'string') {
                this.utilitySvc.showAlert(res);
                return false;
            }
            else if (typeof res === 'object') {
                Object.assign(this.cashDeposit, res);
                this.utilitySvc.showToast('Cash Deposit Card Updated Successfully.');
            }
        }, error => {
            this.utilitySvc.showAlert(error.error.message);
        });
    }
    onUpdateLine(Key) {
        this.lineSub = this.depositSvc.getLine(Key).subscribe(line => {
            if (line) {
                this.line = line;
                this.line.Select = !(line === null || line === void 0 ? void 0 : line.Select);
                this.updateLine(line);
            }
        });
    }
    updateLine(line) {
        this.updateLineSub = this.depositSvc.updateLine(line)
            .subscribe(res => {
            if (typeof res === 'string') {
                this.utilitySvc.showAlert(res);
                return false;
            }
            else if (typeof res === 'object') {
                Object.assign(this.cashDeposit, res);
                this.utilitySvc.showToast('Cash Deposit Line Updated Successfully.');
            }
        }, error => {
            this.utilitySvc.showAlert(error);
        });
    }
    onCancel() {
        this.modalCtrl.dismiss();
    }
    post(No) {
        this.postSub = this.depositSvc.postDocument(No).subscribe(res => {
            console.log(`Posting Results`);
            console.log(res);
            if (typeof res === 'string') {
                this.utilitySvc.showAlert(res);
            }
            else {
                this.utilitySvc.showToast(`Document Posted Successfully.`);
            }
        }, error => {
            this.utilitySvc.showAlert(error);
        });
    }
};
NewDepositComponent.ctorParameters = () => [
    { type: _cash_deposit_service__WEBPACK_IMPORTED_MODULE_6__["CashDepositService"] },
    { type: src_app_utility_service__WEBPACK_IMPORTED_MODULE_5__["UtilityService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] }
];
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], NewDepositComponent.prototype, "cashDepo", void 0);
NewDepositComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-new-deposit',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./new-deposit.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/cash-deposit/new-deposit/new-deposit.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./new-deposit.component.scss */ "./src/app/cash-deposit/new-deposit/new-deposit.component.scss")).default]
    })
], NewDepositComponent);



/***/ }),

/***/ "./src/app/models/cashdeposit.model.ts":
/*!*********************************************!*\
  !*** ./src/app/models/cashdeposit.model.ts ***!
  \*********************************************/
/*! exports provided: Cashdeposit */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Cashdeposit", function() { return Cashdeposit; });
class Cashdeposit {
    constructor(Key, No, Posting_Date, Reference, Created_By, Amount, Cash_Deposit_Lines) {
        this.Key = Key;
        this.No = No;
        this.Posting_Date = Posting_Date;
        this.Reference = Reference;
        this.Created_By = Created_By;
        this.Amount = Amount;
        this.Cash_Deposit_Lines = Cash_Deposit_Lines;
    }
}


/***/ }),

/***/ "./src/app/models/cashdepositheader.model.ts":
/*!***************************************************!*\
  !*** ./src/app/models/cashdepositheader.model.ts ***!
  \***************************************************/
/*! exports provided: Cashdepositheader */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Cashdepositheader", function() { return Cashdepositheader; });
class Cashdepositheader {
    constructor(Key, No, Posting_Date, Reference, Created_By, Amount) {
        this.Key = Key;
        this.No = No;
        this.Posting_Date = Posting_Date;
        this.Reference = Reference;
        this.Created_By = Created_By;
        this.Amount = Amount;
    }
}


/***/ }),

/***/ "./src/app/models/cashdepositline.model.ts":
/*!*************************************************!*\
  !*** ./src/app/models/cashdepositline.model.ts ***!
  \*************************************************/
/*! exports provided: Cashdepositline */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Cashdepositline", function() { return Cashdepositline; });
class Cashdepositline {
    constructor(Key, Customer_Name, Amount, Select, No) {
        this.Key = Key;
        this.Customer_Name = Customer_Name;
        this.Amount = Amount;
        this.Select = Select;
        this.No = No;
    }
}


/***/ }),

/***/ "./src/app/utility.service.ts":
/*!************************************!*\
  !*** ./src/app/utility.service.ts ***!
  \************************************/
/*! exports provided: UtilityService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UtilityService", function() { return UtilityService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");



let UtilityService = class UtilityService {
    constructor(toastCtrl, alertCtrl, loadingCtrl) {
        this.toastCtrl = toastCtrl;
        this.alertCtrl = alertCtrl;
        this.loadingCtrl = loadingCtrl;
    }
    formatDate(datestring) {
        // Format Date to YYYY-MM-DD
        const recDate = new Date(datestring);
        const month = (recDate.getMonth() + 1) > 9 ? recDate.getMonth() + 1 : `0` + (recDate.getMonth() + 1);
        const day = (recDate.getDate()) > 9 ? recDate.getDate() : `0` + recDate.getDate();
        return `${recDate.getFullYear()}-${month}-${day}`;
    }
    showToast(text) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            let toastEl = this.toastCtrl.create({
                message: text,
                duration: 4000,
                position: 'top'
            });
            (yield toastEl).present();
        });
    }
    showAlert(text) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alertEl = yield this.alertCtrl.create({
                header: 'Operation Error',
                message: 'Message : ' + text,
                buttons: [{ text: 'Okay' }]
            });
            yield alertEl.present();
        });
    }
    presentLoading(message) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingCtrl.create({
                spinner: 'dots',
                animated: true,
                message: (message) ? message : 'Loading Data...'
            });
            yield loading.present();
        });
    }
};
UtilityService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] }
];
UtilityService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], UtilityService);



/***/ })

}]);
//# sourceMappingURL=cash-deposit-cash-deposit-module-es2015.js.map