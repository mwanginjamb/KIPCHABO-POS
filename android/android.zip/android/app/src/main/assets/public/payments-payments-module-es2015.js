(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["payments-payments-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/payments/payment-popover/payment-popover.component.html":
/*!***************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/payments/payment-popover/payment-popover.component.html ***!
  \***************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-list>\r\n  <ion-item lines=\"none\" [routerLink]=\"['payments','new-payment']\">\r\n    <ion-icon slot=\"start\" name=\"add-circle-sharp\"></ion-icon>\r\n    <ion-label>New Sale</ion-label>\r\n  </ion-item>\r\n\r\n  <ion-item lines=\"none\" [routerLink]=\"['cash-deposit']\">\r\n    <ion-icon slot=\"start\" name=\"add-circle-sharp\"></ion-icon>\r\n    <ion-label>Cash Deposits</ion-label>\r\n  </ion-item>\r\n</ion-list>");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/payments/payments.page.html":
/*!***********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/payments/payments.page.html ***!
  \***********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <ion-title>Sales</ion-title>\r\n    <ion-buttons slot=\"end\">\r\n    <ion-button slot=\"icon-only\" fill=\"clear\" (click)=\"presentPopover($event)\">\r\n      <ion-icon  name=\"ellipsis-vertical-outline\"></ion-icon>\r\n    </ion-button>      \r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <div *ngIf=\"isLoading\" class=\"ion-text-center\">\r\n    <ion-spinner  name=\"crescent\"></ion-spinner>\r\n  </div>\r\n\r\n<ion-searchbar [(ngModel)]=\"searchTerm\" debounce=\"2000\" (ionChange)=\"searchPayment($event)\"></ion-searchbar>\r\n<ion-grid fixed>\r\n  <ion-row>\r\n    <ion-col col-4 col-sm>Receipt No.</ion-col>\r\n    <ion-col col-4 col-sm>Sale Type </ion-col>\r\n    <!--<ion-col col-12 col-sm>Bank</ion-col>-->\r\n    <ion-col col-4 col-sm>Receipt Date</ion-col>\r\n  </ion-row>\r\n</ion-grid>\r\n\r\n<ion-virtual-scroll [items]=\"payments\" approxItemHeight=\"47.2px\">\r\n               \r\n  <ion-item \r\n    [routerLink] = \"['/','payments', payment.POS_Receipt_No ]\"\r\n   detail\r\n   *virtualItem=\"let payment\" > \r\n\r\n   <ion-grid >\r\n      <ion-row>\r\n\r\n        <ion-col col-4 col-sm>\r\n          <ion-label>\r\n            <h3>{{ payment?.POS_Receipt_No }}</h3>\r\n          </ion-label>\r\n        </ion-col>\r\n\r\n        <ion-col col-4 col-sm>\r\n          <ion-label>\r\n            <h3>{{ payment?.Type_Of_Sale }}</h3>\r\n          </ion-label>\r\n        </ion-col>\r\n\r\n       <!-- <ion-col col-12 col-sm>\r\n          <ion-label>\r\n            <h3>{{ payment.Bank_Account_Name }}</h3>\r\n          </ion-label>\r\n        </ion-col>-->\r\n\r\n        <ion-col col-6 col-sm>\r\n          <ion-label>\r\n            <h3>{{ payment.Receipt_Date}}</h3>\r\n          </ion-label>\r\n        </ion-col>\r\n\r\n      </ion-row>\r\n    </ion-grid>\r\n          \r\n</ion-item>\r\n\r\n</ion-virtual-scroll>\r\n\r\n\r\n</ion-content>\r\n");

/***/ }),

/***/ "./src/app/payments/payment-popover/payment-popover.component.scss":
/*!*************************************************************************!*\
  !*** ./src/app/payments/payment-popover/payment-popover.component.scss ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BheW1lbnRzL3BheW1lbnQtcG9wb3Zlci9wYXltZW50LXBvcG92ZXIuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/payments/payment-popover/payment-popover.component.ts":
/*!***********************************************************************!*\
  !*** ./src/app/payments/payment-popover/payment-popover.component.ts ***!
  \***********************************************************************/
/*! exports provided: PaymentPopoverComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PaymentPopoverComponent", function() { return PaymentPopoverComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


let PaymentPopoverComponent = class PaymentPopoverComponent {
    constructor() { }
    ngOnInit() { }
};
PaymentPopoverComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-payment-popover',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./payment-popover.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/payments/payment-popover/payment-popover.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./payment-popover.component.scss */ "./src/app/payments/payment-popover/payment-popover.component.scss")).default]
    })
], PaymentPopoverComponent);



/***/ }),

/***/ "./src/app/payments/payments-routing.module.ts":
/*!*****************************************************!*\
  !*** ./src/app/payments/payments-routing.module.ts ***!
  \*****************************************************/
/*! exports provided: PaymentsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PaymentsPageRoutingModule", function() { return PaymentsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _payments_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./payments.page */ "./src/app/payments/payments.page.ts");




const routes = [
    {
        path: '',
        component: _payments_page__WEBPACK_IMPORTED_MODULE_3__["PaymentsPage"]
    },
    {
        path: 'payment-detail',
        loadChildren: () => Promise.all(/*! import() | payment-detail-payment-detail-module */[__webpack_require__.e("default~new-payment-new-payment-module~payment-detail-payment-detail-module~payments-new-payment-new~adb5fad1"), __webpack_require__.e("default~payment-detail-payment-detail-module~payments-payment-detail-payment-detail-module")]).then(__webpack_require__.bind(null, /*! ./payment-detail/payment-detail.module */ "./src/app/payments/payment-detail/payment-detail.module.ts")).then(m => m.PaymentDetailPageModule)
    },
    {
        path: 'new-payment',
        loadChildren: () => Promise.all(/*! import() | new-payment-new-payment-module */[__webpack_require__.e("default~new-payment-new-payment-module~payment-detail-payment-detail-module~payments-new-payment-new~adb5fad1"), __webpack_require__.e("default~new-payment-new-payment-module~payments-new-payment-new-payment-module")]).then(__webpack_require__.bind(null, /*! ./new-payment/new-payment.module */ "./src/app/payments/new-payment/new-payment.module.ts")).then(m => m.NewPaymentPageModule)
    },
    {
        path: 'daily-report',
        loadChildren: () => __webpack_require__.e(/*! import() | daily-report-daily-report-module */ "common").then(__webpack_require__.bind(null, /*! ./daily-report/daily-report.module */ "./src/app/payments/daily-report/daily-report.module.ts")).then(m => m.DailyReportPageModule)
    },
    {
        path: 'monthly-report',
        loadChildren: () => __webpack_require__.e(/*! import() | monthly-report-monthly-report-module */ "common").then(__webpack_require__.bind(null, /*! ./monthly-report/monthly-report.module */ "./src/app/payments/monthly-report/monthly-report.module.ts")).then(m => m.MonthlyReportPageModule)
    },
    {
        path: 'mpesa',
        loadChildren: () => Promise.all(/*! import() | mpesa-mpesa-module */[__webpack_require__.e("common"), __webpack_require__.e("mpesa-mpesa-module")]).then(__webpack_require__.bind(null, /*! ./mpesa/mpesa.module */ "./src/app/payments/mpesa/mpesa.module.ts")).then(m => m.MpesaPageModule)
    }
];
let PaymentsPageRoutingModule = class PaymentsPageRoutingModule {
};
PaymentsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], PaymentsPageRoutingModule);



/***/ }),

/***/ "./src/app/payments/payments.module.ts":
/*!*********************************************!*\
  !*** ./src/app/payments/payments.module.ts ***!
  \*********************************************/
/*! exports provided: PaymentsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PaymentsPageModule", function() { return PaymentsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _payments_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./payments-routing.module */ "./src/app/payments/payments-routing.module.ts");
/* harmony import */ var _payments_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./payments.page */ "./src/app/payments/payments.page.ts");
/* harmony import */ var _payment_popover_payment_popover_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./payment-popover/payment-popover.component */ "./src/app/payments/payment-popover/payment-popover.component.ts");
/* harmony import */ var _bluetooth_bluetooth_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./bluetooth/bluetooth.component */ "./src/app/payments/bluetooth/bluetooth.component.ts");









let PaymentsPageModule = class PaymentsPageModule {
};
PaymentsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _payments_routing_module__WEBPACK_IMPORTED_MODULE_5__["PaymentsPageRoutingModule"],
        ],
        entryComponents: [_payment_popover_payment_popover_component__WEBPACK_IMPORTED_MODULE_7__["PaymentPopoverComponent"], _bluetooth_bluetooth_component__WEBPACK_IMPORTED_MODULE_8__["BluetoothComponent"]],
        declarations: [_payments_page__WEBPACK_IMPORTED_MODULE_6__["PaymentsPage"], _payment_popover_payment_popover_component__WEBPACK_IMPORTED_MODULE_7__["PaymentPopoverComponent"], _bluetooth_bluetooth_component__WEBPACK_IMPORTED_MODULE_8__["BluetoothComponent"]]
    })
], PaymentsPageModule);



/***/ }),

/***/ "./src/app/payments/payments.page.scss":
/*!*********************************************!*\
  !*** ./src/app/payments/payments.page.scss ***!
  \*********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BheW1lbnRzL3BheW1lbnRzLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/payments/payments.page.ts":
/*!*******************************************!*\
  !*** ./src/app/payments/payments.page.ts ***!
  \*******************************************/
/*! exports provided: PaymentsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PaymentsPage", function() { return PaymentsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _payment_popover_payment_popover_component__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./payment-popover/payment-popover.component */ "./src/app/payments/payment-popover/payment-popover.component.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _payments_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./payments.service */ "./src/app/payments/payments.service.ts");
/* harmony import */ var _print_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./print.service */ "./src/app/payments/print.service.ts");
/* harmony import */ var _bluetooth_bluetooth_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./bluetooth/bluetooth.component */ "./src/app/payments/bluetooth/bluetooth.component.ts");
/* harmony import */ var _auth_auth_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../auth/auth-service */ "./src/app/auth/auth-service.ts");








let PaymentsPage = class PaymentsPage {
    constructor(popoverCtrl, alertCtrl, modalCtrl, PaymentService, printService, authService) {
        this.popoverCtrl = popoverCtrl;
        this.alertCtrl = alertCtrl;
        this.modalCtrl = modalCtrl;
        this.PaymentService = PaymentService;
        this.printService = printService;
        this.authService = authService;
        this.isLoading = true;
        this.searchTerm = null;
    }
    ngOnInit() {
        this.setUser();
    }
    ionViewWillEnter() {
        this.setUser();
    }
    ionViewDidEnter() {
        this.setUser();
        console.table(this.user);
        console.log('Did Enter');
        this.FetchPayments();
    }
    setUser() {
        var _a;
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.user = yield this.authService.getUser();
            this.userID = (_a = this.user) === null || _a === void 0 ? void 0 : _a.User_ID;
        });
    }
    presentPopover(event) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return yield this.popoverCtrl.create({
                component: _payment_popover_payment_popover_component__WEBPACK_IMPORTED_MODULE_2__["PaymentPopoverComponent"],
                event
            }).then(pop => {
                pop.present();
            });
        });
    }
    FetchPayments() {
        this.paymentsSub = this.PaymentService.getPayments(this.userID).subscribe(result => {
            console.log(result);
            this.payments = this.sort([...result]);
            this.isLoading = false;
        }, error => {
            console.log(error.error);
            this.alertCtrl.create({
                header: 'Service Error!',
                message: 'Connection problem: ' + error.error.message,
                buttons: [{ text: 'Okay' }]
            }).then(alertEl => {
                alertEl.present();
            });
        });
    }
    searchPayment($event) {
        const searchItems = [...this.payments];
        // Begin search only if searchTerm is provided
        if (this.searchTerm.trim().length && this.searchTerm !== '') {
            this.payments = searchItems.filter((payment) => {
                if (payment.Customer_Name && payment.Customer_Name.length > 1) {
                    return (payment.Customer_Name.toLowerCase().indexOf(this.searchTerm.toLowerCase()) > -1);
                }
            });
            return;
        }
        else { // Search Term not provide display all items
            this.FetchPayments();
        }
    }
    showBluetoothDevices() {
        this.modalCtrl.create({
            component: _bluetooth_bluetooth_component__WEBPACK_IMPORTED_MODULE_6__["BluetoothComponent"],
        }).then(modalEl => {
            modalEl.present();
        });
    }
    sort(dataArray) {
        return dataArray.sort((a, b) => (b.POS_Receipt_No > a.POS_Receipt_No) ? 1 : -1);
    }
    ngOnDestroy() {
        if (this.paymentsSub) {
            this.paymentsSub.unsubscribe();
        }
    }
};
PaymentsPage.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["PopoverController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] },
    { type: _payments_service__WEBPACK_IMPORTED_MODULE_4__["PaymentsService"] },
    { type: _print_service__WEBPACK_IMPORTED_MODULE_5__["PrintService"] },
    { type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_7__["AuthService"] }
];
PaymentsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-payments',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./payments.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/payments/payments.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./payments.page.scss */ "./src/app/payments/payments.page.scss")).default]
    })
], PaymentsPage);



/***/ })

}]);
//# sourceMappingURL=payments-payments-module-es2015.js.map