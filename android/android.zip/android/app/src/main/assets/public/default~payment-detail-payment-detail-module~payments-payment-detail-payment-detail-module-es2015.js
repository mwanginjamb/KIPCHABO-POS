(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~payment-detail-payment-detail-module~payments-payment-detail-payment-detail-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/payments/payment-detail/payment-detail.page.html":
/*!********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/payments/payment-detail/payment-detail.page.html ***!
  \********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n    <ion-buttons slot=\"start\">\r\n     <ion-back-button defaultHref=\"payments\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>Cash Receipt Card -  {{ card?.POS_Receipt_No}} </ion-title>\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button slot=\"icon-only\" fill=\"clear\" (click)=\"presentPopover($event)\">\r\n        <ion-icon  name=\"ellipsis-vertical-outline\"></ion-icon>\r\n      </ion-button>      \r\n    </ion-buttons>\r\n\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content *ngIf=\"card?.POS_Receipt_No\">\r\n\r\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"refresh($event)\" pullMin=\"100\" pullMax=\"200\">\r\n    <ion-refresher-content pullingIcon=\"arrow-down-outline\" pullingText=\"Pull to Refresh\" refreshingSpinner=\"crescent\"\r\n      refreshingText=\"Refreshing...\">\r\n    </ion-refresher-content>\r\n  </ion-refresher>\r\n\r\n  <ion-grid>\r\n    <ion-row>\r\n      <ion-col >\r\n         <ion-card>\r\n           <ion-card-header>\r\n             <ion-card-title>\r\n               General Card Details\r\n             </ion-card-title>\r\n           </ion-card-header>\r\n\r\n           <ion-card-content>\r\n\r\n            <ion-fab vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\">\r\n              <ion-fab-button color=\"warning\" (click)=\"post(card.POS_Receipt_No)\">\r\n                <ion-icon name=\"send\"></ion-icon>\r\n              </ion-fab-button>\r\n            </ion-fab>\r\n\r\n             <ion-row>\r\n               <ion-col >\r\n                 <ion-item>\r\n                   <ion-label position=\"floating\">Receipt No.</ion-label>\r\n                   <ion-input [(ngModel)]=\"card.POS_Receipt_No\"></ion-input>\r\n                 </ion-item>\r\n               </ion-col>\r\n\r\n               <ion-col >\r\n                 <ion-item>\r\n                   <ion-label position=\"floating\">Bank Account</ion-label>\r\n                  <ion-select [(ngModel)]=\"card.Bank_Account_No\" (ionChange)=\"updateReceipt($event)\"\r\n                    [selectedText]=\"card.Bank_Account_Name\" placeholder=\"Receiving Bank A/C\">\r\n                     <ion-select-option *ngFor=\"let bank of banks\" [value]=\"bank.No\">{{bank.Name}}</ion-select-option>\r\n                   </ion-select>\r\n                 </ion-item>\r\n               </ion-col>\r\n             </ion-row>\r\n\r\n             \r\n\r\n\r\n             <ion-row>\r\n               <ion-col >\r\n                 <ion-item>\r\n                   <ion-label position=\"floating\">Receipt Date: </ion-label>\r\n                   <ion-input [(ngModel)]=\"card.Receipt_Date\"></ion-input>\r\n                 </ion-item>\r\n               </ion-col>\r\n\r\n               <ion-col >\r\n                 <ion-item>\r\n                   <ion-label position=\"floating\">Total Amount:</ion-label>\r\n                  <ion-input [(ngModel)]=\"card.Total_Amount\" readonly></ion-input>\r\n                  </ion-item>\r\n                </ion-col>\r\n                </ion-row>\r\n                  \r\n                  \r\n            <ion-row>\r\n                    <ion-col>\r\n                      <ion-item>\r\n                        <ion-label position=\"floating\">Type of Sale </ion-label>\r\n                        <ion-input [(ngModel)]=\"card.Type_Of_Sale\"></ion-input>\r\n                      </ion-item>\r\n                    </ion-col>\r\n                  \r\n                    <ion-col>\r\n                      <ion-item>\r\n                        <ion-label position=\"floating\">Reference No</ion-label>\r\n                        <ion-input [(ngModel)]=\"card.Reference_No\"></ion-input>\r\n                        </ion-item>\r\n                        </ion-col>\r\n                        \r\n                        </ion-row>\r\n                        \r\n                        <ion-row>\r\n                          <ion-col>\r\n                            <ion-item>\r\n                              <ion-label position=\"floating\">VAT AMT. </ion-label>\r\n                              <ion-input [(ngModel)]=\"card.VAT_Amount\"></ion-input>\r\n                            </ion-item>\r\n                          </ion-col>\r\n                        \r\n                          <ion-col>\r\n                            <ion-item>\r\n                              <ion-label position=\"floating\">AMT. Inc. VAT</ion-label>\r\n                              <ion-input [(ngModel)]=\"card.Amount_Inc_VAT\"></ion-input>\r\n                            </ion-item>\r\n                          </ion-col>\r\n\r\n            </ion-row>\r\n\r\n\r\n            \r\n\r\n           </ion-card-content>\r\n\r\n         </ion-card>\r\n\r\n\r\n          <!--Start Lines Card-->\r\n          <ion-card>\r\n            <ion-card-header>\r\n              <ion-card-title>Lines</ion-card-title>\r\n            </ion-card-header>\r\n            <ion-card-content>\r\n              <ion-grid>\r\n                \r\n                              \r\n                <ion-row>\r\n                  <ion-col>\r\n                    <ion-list>\r\n                      <ion-item>\r\n                        <ion-button type=\"button\" outline color=\"primary\" (click)=\"onAddLine(card?.POS_Receipt_No)\">New</ion-button>\r\n                      </ion-item>\r\n                    </ion-list>\r\n                  </ion-col>\r\n                </ion-row>\r\n\r\n                <ion-row scrollX=\"true\">\r\n                  <ion-col>\r\n                    <ion-label>Item</ion-label>\r\n                  </ion-col>\r\n\r\n                  <ion-col>\r\n                    <ion-label>Qty</ion-label>\r\n                  </ion-col>\r\n\r\n                  <!--<ion-col>\r\n                    <ion-label>Price</ion-label>\r\n                  </ion-col>-->\r\n\r\n                  <ion-col>\r\n                    <ion-label>Total</ion-label>\r\n                  </ion-col>\r\n                  \r\n                \r\n\r\n                 \r\n\r\n                  \r\n\r\n                </ion-row>\r\n              \r\n                \r\n               \r\n                <ion-list *ngFor=\"let line of card?.POS_Receipt_Lines?.POS_Receipt_Lines\">\r\n                    <ion-row >\r\n                        \r\n                      <ion-col> \r\n                        <ion-item (click)=\"onUpdateLine(line.Key)\" color=\"primary\">\r\n                            <ion-label>{{line.Description}}</ion-label>\r\n                        </ion-item>\r\n                      </ion-col>\r\n  \r\n                      <ion-col> \r\n                        <ion-item>                         \r\n                            <ion-label>{{line.Qty}}</ion-label>\r\n                        </ion-item>\r\n                      </ion-col>\r\n  \r\n                        \r\n                        <ion-col>\r\n                          <ion-item>\r\n                            <ion-label>{{line.Total_Amount | currency: 'Ksh. '}}</ion-label>\r\n                        </ion-item>\r\n                      </ion-col>\r\n                      \r\n  \r\n                    </ion-row>   \r\n                </ion-list>\r\n                 \r\n                \r\n              </ion-grid>\r\n            </ion-card-content>\r\n          </ion-card>\r\n          <!--End Lines Card-->\r\n\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n</ion-content>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/payments/receipt-popover/receipt-popover.component.html":
/*!***************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/payments/receipt-popover/receipt-popover.component.html ***!
  \***************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-list>\r\n\r\n  <ion-item lines=\"none\">\r\n    <ion-icon slot=\"start\" name=\"print\"></ion-icon>\r\n    <ion-label (click)=\"localPrint()\">Print Receipt</ion-label>\r\n    </ion-item>\r\n    \r\n    <ion-item lines=\"none\">\r\n      <ion-icon slot=\"start\" name=\"print\"></ion-icon>\r\n      <ion-label (click)=\"showBluetoothDevices()\">Print Receipt (Bluetooth)</ion-label>\r\n    </ion-item>\r\n\r\n  <ion-item lines=\"none\">\r\n    <ion-icon slot=\"start\" name=\"copy\"></ion-icon>\r\n    <ion-label (click)=\"showDaily()\">Daily Sales Report</ion-label>\r\n  </ion-item>\r\n\r\n  <ion-item lines=\"none\">\r\n    <ion-icon slot=\"start\" name=\"copy\"></ion-icon>\r\n    <ion-label (click)=\"showMonthly()\">Monthly Sales Report</ion-label>\r\n  </ion-item>\r\n</ion-list>\r\n");

/***/ }),

/***/ "./src/app/payments/payment-detail/payment-detail-routing.module.ts":
/*!**************************************************************************!*\
  !*** ./src/app/payments/payment-detail/payment-detail-routing.module.ts ***!
  \**************************************************************************/
/*! exports provided: PaymentDetailPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PaymentDetailPageRoutingModule", function() { return PaymentDetailPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _payment_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./payment-detail.page */ "./src/app/payments/payment-detail/payment-detail.page.ts");




const routes = [
    {
        path: '',
        component: _payment_detail_page__WEBPACK_IMPORTED_MODULE_3__["PaymentDetailPage"]
    }
];
let PaymentDetailPageRoutingModule = class PaymentDetailPageRoutingModule {
};
PaymentDetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], PaymentDetailPageRoutingModule);



/***/ }),

/***/ "./src/app/payments/payment-detail/payment-detail.module.ts":
/*!******************************************************************!*\
  !*** ./src/app/payments/payment-detail/payment-detail.module.ts ***!
  \******************************************************************/
/*! exports provided: PaymentDetailPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PaymentDetailPageModule", function() { return PaymentDetailPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _payment_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./payment-detail-routing.module */ "./src/app/payments/payment-detail/payment-detail-routing.module.ts");
/* harmony import */ var _payment_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./payment-detail.page */ "./src/app/payments/payment-detail/payment-detail.page.ts");
/* harmony import */ var _receipt_popover_receipt_popover_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../receipt-popover/receipt-popover.component */ "./src/app/payments/receipt-popover/receipt-popover.component.ts");
/* harmony import */ var _bluetooth_bluetooth_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../bluetooth/bluetooth.component */ "./src/app/payments/bluetooth/bluetooth.component.ts");









let PaymentDetailPageModule = class PaymentDetailPageModule {
};
PaymentDetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _payment_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__["PaymentDetailPageRoutingModule"]
        ],
        entryComponents: [_receipt_popover_receipt_popover_component__WEBPACK_IMPORTED_MODULE_7__["ReceiptPopoverComponent"], _bluetooth_bluetooth_component__WEBPACK_IMPORTED_MODULE_8__["BluetoothComponent"]],
        declarations: [_payment_detail_page__WEBPACK_IMPORTED_MODULE_6__["PaymentDetailPage"], _receipt_popover_receipt_popover_component__WEBPACK_IMPORTED_MODULE_7__["ReceiptPopoverComponent"], _bluetooth_bluetooth_component__WEBPACK_IMPORTED_MODULE_8__["BluetoothComponent"]]
    })
], PaymentDetailPageModule);



/***/ }),

/***/ "./src/app/payments/payment-detail/payment-detail.page.scss":
/*!******************************************************************!*\
  !*** ./src/app/payments/payment-detail/payment-detail.page.scss ***!
  \******************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BheW1lbnRzL3BheW1lbnQtZGV0YWlsL3BheW1lbnQtZGV0YWlsLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/payments/payment-detail/payment-detail.page.ts":
/*!****************************************************************!*\
  !*** ./src/app/payments/payment-detail/payment-detail.page.ts ***!
  \****************************************************************/
/*! exports provided: PaymentDetailPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PaymentDetailPage", function() { return PaymentDetailPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _payments_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../payments.service */ "./src/app/payments/payments.service.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _receipt_popover_receipt_popover_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../receipt-popover/receipt-popover.component */ "./src/app/payments/receipt-popover/receipt-popover.component.ts");
/* harmony import */ var _new_cash_line_new_cash_line_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../new-cash-line/new-cash-line.component */ "./src/app/payments/new-cash-line/new-cash-line.component.ts");
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/auth/auth-service */ "./src/app/auth/auth-service.ts");
/* harmony import */ var src_app_utility_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/utility.service */ "./src/app/utility.service.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");










let PaymentDetailPage = class PaymentDetailPage {
    constructor(paymentService, activatedRoute, popoverCtrl, alertCtrl, modalCtrl, toastCtrl, authService, router, utilitySvc) {
        this.paymentService = paymentService;
        this.activatedRoute = activatedRoute;
        this.popoverCtrl = popoverCtrl;
        this.alertCtrl = alertCtrl;
        this.modalCtrl = modalCtrl;
        this.toastCtrl = toastCtrl;
        this.authService = authService;
        this.router = router;
        this.utilitySvc = utilitySvc;
        this.No = null;
    }
    ngOnInit() {
        this.No = this.activatedRoute.snapshot.paramMap.get('id');
        this.FetchCard();
        this.FetchBanks();
        this.paymentService.refresh$.subscribe(() => {
            this.FetchCard();
        });
    }
    ionViewWillEnter() {
        this.setUser();
    }
    ionViewDidEnter() {
        this.setUser();
    }
    setUser() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.user = yield this.authService.getUser();
        });
    }
    FetchCard() {
        this.cardSub = this.paymentService.getPayment(this.No).subscribe(result => {
            this.card = result;
        });
    }
    refresh(event) {
        this.cardSub = this.paymentService.getPayment(this.No).subscribe(result => {
            this.card = result;
            if (event) {
                event.target.complete();
            }
        });
    }
    FetchBanks() {
        this.bankSub = this.paymentService.Banks.subscribe(result => {
            this.banks = result;
        });
    }
    selectInvoice(CustomerNo, Line, ReceiptNo) {
        // console.log(`Cust: ${CustomerNo} Line: ${Line} and Rec: ${ReceiptNo}`); return;
        this.paymentService.selectLine(CustomerNo, Line, ReceiptNo).subscribe(res => {
            // console.log(res);
            this.paymentService.showToast(' Invoice Line Updated Successfully.');
        }, error => {
            alert(error);
        });
    }
    post(ReceiptNo) {
        this.utilitySvc.presentLoading('Posting transaction .....');
        this.paymentService.postReceipt(ReceiptNo)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_9__["finalize"])(() => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.utilitySvc.loadingCtrl.dismiss();
        })))
            .subscribe(res => {
            if (typeof res === 'string') { // a string response represents a Nav Error, so we display it.
                this.alertCtrl.create({
                    header: 'Service Warning!',
                    message: res,
                    buttons: [{ text: 'Okay' }]
                }).then(alertEl => {
                    alertEl.present();
                });
            }
            else {
                this.paymentService.showToast(`Document Posted Successfully.`);
                setTimeout(() => {
                    this.router.navigate(['../payments']);
                }, 3000);
            }
        }, error => {
            alert(error.error.message);
        });
    }
    setAmountToReceipt(CustomerNo, Line, ReceiptNo, $event) {
        this.paymentService.setAmountToReceipt(CustomerNo, Line, ReceiptNo, $event.target.value).subscribe(res => {
            this.paymentService.showToast(' Invoice Line Updated Successfully.');
        }, error => {
            alert(error);
        });
    }
    presentPopover(event) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return yield this.popoverCtrl.create({
                component: _receipt_popover_receipt_popover_component__WEBPACK_IMPORTED_MODULE_5__["ReceiptPopoverComponent"],
                componentProps: { No: this.No, Card: this.card },
                event
            }).then(pop => {
                pop.present();
            });
        });
    }
    onAddLine(POS_Receipt_No) {
        this.modalCtrl.create({
            component: _new_cash_line_new_cash_line_component__WEBPACK_IMPORTED_MODULE_6__["NewCashLineComponent"],
            componentProps: { receiptNo: POS_Receipt_No }
        })
            .then(modalEl => {
            modalEl.present();
        });
    }
    onUpdateLine(Key) {
        console.log(Key);
        this.modalCtrl.create({
            component: _new_cash_line_new_cash_line_component__WEBPACK_IMPORTED_MODULE_6__["NewCashLineComponent"],
            componentProps: { Key }
        })
            .then(modalEl => {
            modalEl.present();
        });
    }
    updateReceipt($event) {
        var _a;
        this.card.Created_By = (_a = this.user) === null || _a === void 0 ? void 0 : _a.User_ID;
        // console.table(this.card); return;
        this.updateSub = this.paymentService.updateReceipt(this.card).subscribe(res => {
            console.log(res);
            if (typeof res === 'object') {
                Object.assign(this.card, res);
                this.toastCtrl.create({
                    message: `Receipt Updated Successfully.`,
                    duration: 2000,
                    position: 'top'
                }).then((toastData) => {
                    toastData.present();
                });
            }
            else {
                this.alertCtrl.create({
                    header: 'New Payment Error!',
                    message: 'ERP Error : ' + res,
                    buttons: [{ text: 'Okay' }]
                })
                    .then(alertEl => {
                    alertEl.present();
                });
            }
        }, error => {
            this.alertCtrl.create({
                header: 'New Payment Error!',
                message: 'Connection problem: ' + error.error.message,
                buttons: [{ text: 'Okay' }]
            })
                .then(alertEl => {
                alertEl.present();
            });
        });
    }
};
PaymentDetailPage.ctorParameters = () => [
    { type: _payments_service__WEBPACK_IMPORTED_MODULE_2__["PaymentsService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["PopoverController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"] },
    { type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_7__["AuthService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: src_app_utility_service__WEBPACK_IMPORTED_MODULE_8__["UtilityService"] }
];
PaymentDetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-payment-detail',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./payment-detail.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/payments/payment-detail/payment-detail.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./payment-detail.page.scss */ "./src/app/payments/payment-detail/payment-detail.page.scss")).default]
    })
], PaymentDetailPage);



/***/ }),

/***/ "./src/app/payments/receipt-popover/receipt-popover.component.scss":
/*!*************************************************************************!*\
  !*** ./src/app/payments/receipt-popover/receipt-popover.component.scss ***!
  \*************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BheW1lbnRzL3JlY2VpcHQtcG9wb3Zlci9yZWNlaXB0LXBvcG92ZXIuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/payments/receipt-popover/receipt-popover.component.ts":
/*!***********************************************************************!*\
  !*** ./src/app/payments/receipt-popover/receipt-popover.component.ts ***!
  \***********************************************************************/
/*! exports provided: ReceiptPopoverComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReceiptPopoverComponent", function() { return ReceiptPopoverComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _bluetooth_bluetooth_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../bluetooth/bluetooth.component */ "./src/app/payments/bluetooth/bluetooth.component.ts");
/* harmony import */ var _ionic_native_printer_ngx__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic-native/printer/ngx */ "./node_modules/@ionic-native/printer/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var src_app_utility_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/utility.service */ "./src/app/utility.service.ts");
/* harmony import */ var _payments_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../payments.service */ "./src/app/payments/payments.service.ts");








let ReceiptPopoverComponent = class ReceiptPopoverComponent {
    constructor(modalCtrl, router, printer, utilitySvc, paymentService) {
        this.modalCtrl = modalCtrl;
        this.router = router;
        this.printer = printer;
        this.utilitySvc = utilitySvc;
        this.paymentService = paymentService;
    }
    ngOnInit() {
        this.generateReceiptPrintable();
    }
    localPrint() {
        this.printer.isAvailable().then(() => {
            this.utilitySvc.showToast(`Printer Found and Getting Ready to Print.`);
        }, (err) => {
            this.utilitySvc.showAlert(err);
        });
        let options = {
            name: 'Receipt',
            duplex: true,
            orientation: 'portrait',
            monochrome: true
        };
        this.printer.print(this.myString, options).then(() => {
            this.utilitySvc.showToast(`Receipt Printed Successfully.`);
        }, (err) => {
            this.utilitySvc.showAlert(err);
        });
    }
    generateReceiptPrintable() {
        var _a, _b, _c;
        this.myString = `
    Kipchabo Tea Factory Receipt.

    Customer: ${(_a = this.Card) === null || _a === void 0 ? void 0 : _a.Customer_Name}


    Item | Qty  | Total Amount  

    `;
        // Filter Lines to Print
        const LinestoPrint = this.Card.POS_Receipt_Lines.POS_Receipt_Lines.filter(ln => ln.Total_Amount > 0);
        LinestoPrint.forEach(line => {
            this.myString += `

    ${line.Description}  | ${line.Price} | ${line.Total_Amount}  \r\n`;
        });
        const Total = this.paymentService.getTotals(this.Card.POS_Receipt_Lines.POS_Receipt_Lines, 'Total_Amount');
        const VAT = (_b = this.Card) === null || _b === void 0 ? void 0 : _b.VAT_Amount;
        const Amount_Inc_VAT = (_c = this.Card) === null || _c === void 0 ? void 0 : _c.Amount_Inc_VAT;
        this.myString += `

          Total Amount: ${Total}
          VAT: ${VAT}
          Amount_Inc_VAT: ${Amount_Inc_VAT}
                   `;
    }
    showBluetoothDevices() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return yield this.modalCtrl.create({
                component: _bluetooth_bluetooth_component__WEBPACK_IMPORTED_MODULE_4__["BluetoothComponent"],
                componentProps: { No: this.No, receiptCard: this.Card, Printable: 'Receipt' },
            }).then(modalEl => {
                modalEl.present();
            });
        });
    }
    showDaily() {
        return this.router.navigate(['./payments/daily-report']);
    }
    showMonthly() {
        return this.router.navigate(['./payments/monthly-report']);
    }
};
ReceiptPopoverComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"] },
    { type: _ionic_native_printer_ngx__WEBPACK_IMPORTED_MODULE_5__["Printer"] },
    { type: src_app_utility_service__WEBPACK_IMPORTED_MODULE_6__["UtilityService"] },
    { type: _payments_service__WEBPACK_IMPORTED_MODULE_7__["PaymentsService"] }
];
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], ReceiptPopoverComponent.prototype, "No", void 0);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], ReceiptPopoverComponent.prototype, "Card", void 0);
ReceiptPopoverComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-receipt-popover',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./receipt-popover.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/payments/receipt-popover/receipt-popover.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./receipt-popover.component.scss */ "./src/app/payments/receipt-popover/receipt-popover.component.scss")).default]
    })
], ReceiptPopoverComponent);



/***/ })

}]);
//# sourceMappingURL=default~payment-detail-payment-detail-module~payments-payment-detail-payment-detail-module-es2015.js.map