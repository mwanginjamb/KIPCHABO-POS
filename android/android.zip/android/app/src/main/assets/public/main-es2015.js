(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["main"],{

/***/ "./$$_lazy_route_resource lazy recursive":
/*!******************************************************!*\
  !*** ./$$_lazy_route_resource lazy namespace object ***!
  \******************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function webpackEmptyAsyncContext(req) {
	// Here Promise.resolve().then() is used instead of new Promise() to prevent
	// uncaught exception popping up in devtools
	return Promise.resolve().then(function() {
		var e = new Error("Cannot find module '" + req + "'");
		e.code = 'MODULE_NOT_FOUND';
		throw e;
	});
}
webpackEmptyAsyncContext.keys = function() { return []; };
webpackEmptyAsyncContext.resolve = webpackEmptyAsyncContext;
module.exports = webpackEmptyAsyncContext;
webpackEmptyAsyncContext.id = "./$$_lazy_route_resource lazy recursive";

/***/ }),

/***/ "./node_modules/@ionic/core/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$":
/*!*****************************************************************************************************************************************!*\
  !*** ./node_modules/@ionic/core/dist/esm lazy ^\.\/.*\.entry\.js$ include: \.entry\.js$ exclude: \.system\.entry\.js$ namespace object ***!
  \*****************************************************************************************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var map = {
	"./ion-action-sheet.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-action-sheet.entry.js",
		"common",
		0
	],
	"./ion-alert.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-alert.entry.js",
		"common",
		1
	],
	"./ion-app_8.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-app_8.entry.js",
		"common",
		2
	],
	"./ion-avatar_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-avatar_3.entry.js",
		"common",
		3
	],
	"./ion-back-button.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-back-button.entry.js",
		"common",
		4
	],
	"./ion-backdrop.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-backdrop.entry.js",
		5
	],
	"./ion-button_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-button_2.entry.js",
		"common",
		6
	],
	"./ion-card_5.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-card_5.entry.js",
		"common",
		7
	],
	"./ion-checkbox.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-checkbox.entry.js",
		"common",
		8
	],
	"./ion-chip.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-chip.entry.js",
		"common",
		9
	],
	"./ion-col_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-col_3.entry.js",
		10
	],
	"./ion-datetime_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-datetime_3.entry.js",
		"common",
		11
	],
	"./ion-fab_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-fab_3.entry.js",
		"common",
		12
	],
	"./ion-img.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-img.entry.js",
		13
	],
	"./ion-infinite-scroll_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-infinite-scroll_2.entry.js",
		14
	],
	"./ion-input.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-input.entry.js",
		"common",
		15
	],
	"./ion-item-option_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-item-option_3.entry.js",
		"common",
		16
	],
	"./ion-item_8.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-item_8.entry.js",
		"common",
		17
	],
	"./ion-loading.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-loading.entry.js",
		"common",
		18
	],
	"./ion-menu_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-menu_3.entry.js",
		"common",
		19
	],
	"./ion-modal.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-modal.entry.js",
		"common",
		20
	],
	"./ion-nav_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-nav_2.entry.js",
		"common",
		21
	],
	"./ion-popover.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-popover.entry.js",
		"common",
		22
	],
	"./ion-progress-bar.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-progress-bar.entry.js",
		"common",
		23
	],
	"./ion-radio_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-radio_2.entry.js",
		"common",
		24
	],
	"./ion-range.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-range.entry.js",
		"common",
		25
	],
	"./ion-refresher_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-refresher_2.entry.js",
		"common",
		26
	],
	"./ion-reorder_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-reorder_2.entry.js",
		"common",
		27
	],
	"./ion-ripple-effect.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-ripple-effect.entry.js",
		28
	],
	"./ion-route_4.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-route_4.entry.js",
		"common",
		29
	],
	"./ion-searchbar.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-searchbar.entry.js",
		"common",
		30
	],
	"./ion-segment_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-segment_2.entry.js",
		"common",
		31
	],
	"./ion-select_3.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-select_3.entry.js",
		"common",
		32
	],
	"./ion-slide_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-slide_2.entry.js",
		33
	],
	"./ion-spinner.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-spinner.entry.js",
		"common",
		34
	],
	"./ion-split-pane.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-split-pane.entry.js",
		35
	],
	"./ion-tab-bar_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-tab-bar_2.entry.js",
		"common",
		36
	],
	"./ion-tab_2.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-tab_2.entry.js",
		"common",
		37
	],
	"./ion-text.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-text.entry.js",
		"common",
		38
	],
	"./ion-textarea.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-textarea.entry.js",
		"common",
		39
	],
	"./ion-toast.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-toast.entry.js",
		"common",
		40
	],
	"./ion-toggle.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-toggle.entry.js",
		"common",
		41
	],
	"./ion-virtual-scroll.entry.js": [
		"./node_modules/@ionic/core/dist/esm/ion-virtual-scroll.entry.js",
		42
	]
};
function webpackAsyncContext(req) {
	if(!__webpack_require__.o(map, req)) {
		return Promise.resolve().then(function() {
			var e = new Error("Cannot find module '" + req + "'");
			e.code = 'MODULE_NOT_FOUND';
			throw e;
		});
	}

	var ids = map[req], id = ids[0];
	return Promise.all(ids.slice(1).map(__webpack_require__.e)).then(function() {
		return __webpack_require__(id);
	});
}
webpackAsyncContext.keys = function webpackAsyncContextKeys() {
	return Object.keys(map);
};
webpackAsyncContext.id = "./node_modules/@ionic/core/dist/esm lazy recursive ^\\.\\/.*\\.entry\\.js$ include: \\.entry\\.js$ exclude: \\.system\\.entry\\.js$";
module.exports = webpackAsyncContext;

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html":
/*!**************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html ***!
  \**************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<div *ngIf=\"showSplash\" class=\"splash\">\r\n  <div class=\"sk-cube-grid\">\r\n    <div class=\"sk-cube sk-cube1\"></div>\r\n    <div class=\"sk-cube sk-cube2\"></div>\r\n    <div class=\"sk-cube sk-cube3\"></div>\r\n    <div class=\"sk-cube sk-cube4\"></div>\r\n    <div class=\"sk-cube sk-cube5\"></div>\r\n    <div class=\"sk-cube sk-cube6\"></div>\r\n    <div class=\"sk-cube sk-cube7\"></div>\r\n    <div class=\"sk-cube sk-cube8\"></div>\r\n    <div class=\"sk-cube sk-cube9\"></div>\r\n  </div>\r\n</div>\r\n\r\n<ion-app>\r\n  <ion-menu side=\"start\" menuId=\"m1\">\r\n    <ion-header>\r\n      <ion-toolbar>\r\n        <ion-title> Kipchabo Tea Factory </ion-title>\r\n      </ion-toolbar>\r\n    </ion-header>\r\n\r\n    <ion-content>\r\n      <ion-list>\r\n        <ion-menu-toggle>\r\n          <ion-item lines=\"none\" [routerLink]=\"['dashboard']\">\r\n            <ion-icon name=\"home\" slot=\"start\"></ion-icon>\r\n            <ion-label>Home</ion-label>\r\n          </ion-item>\r\n        </ion-menu-toggle>\r\n\r\n        <ion-menu-toggle>\r\n          <ion-item lines=\"none\" [routerLink]=\"['customers']\">\r\n            <ion-icon name=\"home\" slot=\"start\"></ion-icon>\r\n            <ion-label>Customers</ion-label>\r\n          </ion-item>\r\n        </ion-menu-toggle>\r\n\r\n        <ion-menu-toggle>\r\n          <ion-item lines=\"none\" [routerLink]=\"['return']\">\r\n            <ion-icon name=\"home\" slot=\"start\"></ion-icon>\r\n            <ion-label>Returns</ion-label>\r\n          </ion-item>\r\n        </ion-menu-toggle>\r\n\r\n        <ion-menu-toggle>\r\n          <ion-item lines=\"none\" [routerLink]=\"['requisitions']\">\r\n            <ion-icon name=\"business\" slot=\"start\"></ion-icon>\r\n            <ion-label>Stock Requisitions</ion-label>\r\n          </ion-item>\r\n        </ion-menu-toggle>\r\n\r\n        <ion-menu-toggle>\r\n          <ion-item\r\n            lines=\"none\"\r\n            [routerLink]=\"['requisitions', 'released-requisitions']\"\r\n          >\r\n            <ion-icon name=\"business\" slot=\"start\"></ion-icon>\r\n            <ion-label>Shipped Requisitions</ion-label>\r\n          </ion-item>\r\n        </ion-menu-toggle>\r\n\r\n        <ion-menu-toggle>\r\n          <ion-item lines=\"none\" [routerLink]=\"['orders']\">\r\n            <ion-icon name=\"business\" slot=\"start\"></ion-icon>\r\n            <ion-label>Sales Invoice</ion-label>\r\n          </ion-item>\r\n        </ion-menu-toggle>\r\n\r\n        <ion-menu-toggle>\r\n          <ion-item lines=\"none\" [routerLink]=\"['payments']\">\r\n            <ion-icon name=\"business\" slot=\"start\"></ion-icon>\r\n            <ion-label>Payments</ion-label>\r\n          </ion-item>\r\n        </ion-menu-toggle>\r\n\r\n        <ion-menu-toggle>\r\n          <ion-item lines=\"none\" [routerLink]=\"['items']\">\r\n            <ion-icon name=\"business\" slot=\"start\"></ion-icon>\r\n            <ion-label>Items</ion-label>\r\n          </ion-item>\r\n        </ion-menu-toggle>\r\n\r\n        <!-- <ion-menu-toggle>\r\n          <ion-item lines=\"none\" [routerLink]=\"['farmer']\">\r\n            <ion-icon name=\"business\" slot=\"start\"></ion-icon>\r\n            <ion-label>Farmers</ion-label>\r\n          </ion-item>\r\n        </ion-menu-toggle>\r\n\r\n        <ion-menu-toggle>\r\n          <ion-item lines=\"none\" [routerLink]=\"['collection']\">\r\n            <ion-icon name=\"business\" slot=\"start\"></ion-icon>\r\n            <ion-label>Leaf Collection</ion-label>\r\n          </ion-item>\r\n        </ion-menu-toggle> -->\r\n\r\n        <ion-menu-toggle>\r\n          <ion-item lines=\"none\" (click)=\"exit()\" button>\r\n            <ion-icon name=\"exit\" slot=\"start\"></ion-icon>\r\n            <ion-label>Exit</ion-label>\r\n          </ion-item>\r\n        </ion-menu-toggle>\r\n\r\n        <ion-menu-toggle>\r\n          <ion-item lines=\"none\" (click)=\"logout()\" button>\r\n            <ion-icon name=\"log-out\" slot=\"start\"></ion-icon>\r\n            <ion-label>Logout</ion-label>\r\n          </ion-item>\r\n        </ion-menu-toggle>\r\n\r\n        <ion-item-divider>\r\n          <ion-label>Reports</ion-label>\r\n        </ion-item-divider>\r\n\r\n        <ion-menu-toggle>\r\n          <ion-item lines=\"none\" (click)=\"showDailySales()\" button>\r\n            <ion-icon name=\"clipboard\" slot=\"start\"></ion-icon>\r\n            <ion-label>Daily Sales</ion-label>\r\n          </ion-item>\r\n        </ion-menu-toggle>\r\n        <ion-menu-toggle>\r\n          <ion-item lines=\"none\" (click)=\"showMonthlySales()\" button>\r\n            <ion-icon name=\"clipboard\" slot=\"start\"></ion-icon>\r\n            <ion-label>Monthly Sales</ion-label>\r\n          </ion-item>\r\n        </ion-menu-toggle>\r\n\r\n        <ion-menu-toggle>\r\n          <ion-item lines=\"none\" (click)=\"showDailyReceipts()\" button>\r\n            <ion-icon name=\"clipboard\" slot=\"start\"></ion-icon>\r\n            <ion-label>Daily Cash Receipts</ion-label>\r\n          </ion-item>\r\n        </ion-menu-toggle>\r\n\r\n        <ion-menu-toggle>\r\n          <ion-item lines=\"none\" (click)=\"showMonthlyReceipts()\" button>\r\n            <ion-icon name=\"clipboard\" slot=\"start\"></ion-icon>\r\n            <ion-label>Monthly Cash Receipts</ion-label>\r\n          </ion-item>\r\n        </ion-menu-toggle>\r\n\r\n        <ion-menu-toggle>\r\n          <ion-item lines=\"none\" (click)=\"showAvailability()\" button>\r\n            <ion-icon name=\"clipboard\" slot=\"start\"></ion-icon>\r\n            <ion-label>Stock Availability By Location</ion-label>\r\n          </ion-item>\r\n        </ion-menu-toggle>\r\n      </ion-list>\r\n    </ion-content>\r\n  </ion-menu>\r\n\r\n  <ion-router-outlet main></ion-router-outlet>\r\n</ion-app>\r\n");

/***/ }),

/***/ "./src/app/app-routing.module.ts":
/*!***************************************!*\
  !*** ./src/app/app-routing.module.ts ***!
  \***************************************/
/*! exports provided: AppRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppRoutingModule", function() { return AppRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _auth_auth_guard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./auth/auth.guard */ "./src/app/auth/auth.guard.ts");




const routes = [
    {
        path: "home",
        loadChildren: () => __webpack_require__.e(/*! import() | home-home-module */ "home-home-module").then(__webpack_require__.bind(null, /*! ./home/home.module */ "./src/app/home/home.module.ts")).then((m) => m.HomePageModule),
    },
    {
        path: "",
        redirectTo: "auth",
        pathMatch: "full",
    },
    {
        path: "dashboard",
        loadChildren: () => __webpack_require__.e(/*! import() | dashboard-dashboard-module */ "dashboard-dashboard-module").then(__webpack_require__.bind(null, /*! ./dashboard/dashboard.module */ "./src/app/dashboard/dashboard.module.ts")).then((m) => m.DashboardPageModule),
        canLoad: [_auth_auth_guard__WEBPACK_IMPORTED_MODULE_3__["AuthGuard"]]
    },
    {
        path: "stockdetail",
        loadChildren: () => __webpack_require__.e(/*! import() | stock-details-stock-details-module */ "stock-details-stock-details-module").then(__webpack_require__.bind(null, /*! ./stock-details/stock-details.module */ "./src/app/stock-details/stock-details.module.ts")).then((m) => m.StockDetailsPageModule),
    },
    {
        path: "orders",
        children: [
            {
                path: "",
                loadChildren: () => Promise.all(/*! import() | orders-orders-module */[__webpack_require__.e("default~orders-order-detail-order-detail-module~orders-orders-module"), __webpack_require__.e("orders-orders-module")]).then(__webpack_require__.bind(null, /*! ./orders/orders.module */ "./src/app/orders/orders.module.ts")).then((m) => m.OrdersPageModule),
            },
            {
                path: ":No",
                loadChildren: () => Promise.all(/*! import() | orders-order-detail-order-detail-module */[__webpack_require__.e("default~orders-order-detail-order-detail-module~requisition-details-requisition-details-module~requi~ab00880c"), __webpack_require__.e("default~orders-order-detail-order-detail-module~orders-orders-module"), __webpack_require__.e("orders-order-detail-order-detail-module")]).then(__webpack_require__.bind(null, /*! ./orders/order-detail/order-detail.module */ "./src/app/orders/order-detail/order-detail.module.ts")).then((m) => m.OrderDetailPageModule),
            },
            {
                path: "new-order",
                loadChildren: () => Promise.all(/*! import() | orders-new-order-new-order-module */[__webpack_require__.e("default~new-order-new-order-module~orders-new-order-new-order-module"), __webpack_require__.e("orders-new-order-new-order-module")]).then(__webpack_require__.bind(null, /*! ./orders/new-order/new-order.module */ "./src/app/orders/new-order/new-order.module.ts")).then((m) => m.NewOrderPageModule),
            },
        ],
    },
    {
        path: "items",
        children: [
            {
                path: "",
                loadChildren: () => __webpack_require__.e(/*! import() | items-items-module */ "items-items-module").then(__webpack_require__.bind(null, /*! ./items/items.module */ "./src/app/items/items.module.ts")).then((m) => m.ItemsPageModule),
            },
            {
                path: ":id",
                loadChildren: () => Promise.all(/*! import() | items-item-detail-item-detail-module */[__webpack_require__.e("common"), __webpack_require__.e("items-item-detail-item-detail-module")]).then(__webpack_require__.bind(null, /*! ./items/item-detail/item-detail.module */ "./src/app/items/item-detail/item-detail.module.ts")).then((m) => m.ItemDetailPageModule),
            },
            {
                path: "availability",
                loadChildren: () => Promise.all(/*! import() | items-availability-by-location-availability-by-location-module */[__webpack_require__.e("common"), __webpack_require__.e("items-availability-by-location-availability-by-location-module")]).then(__webpack_require__.bind(null, /*! ./items/availability-by-location/availability-by-location.module */ "./src/app/items/availability-by-location/availability-by-location.module.ts")).then((m) => m.AvailabilityByLocationPageModule),
            },
            {
                path: "availability-card/:No",
                loadChildren: () => Promise.all(/*! import() | items-availability-card-availability-card-module */[__webpack_require__.e("common"), __webpack_require__.e("items-availability-card-availability-card-module")]).then(__webpack_require__.bind(null, /*! ./items/availability-card/availability-card.module */ "./src/app/items/availability-card/availability-card.module.ts")).then((m) => m.AvailabilityCardPageModule),
            },
        ],
    },
    {
        path: "requisitions",
        children: [
            {
                path: "",
                loadChildren: () => __webpack_require__.e(/*! import() | requisitions-requisitions-module */ "requisitions-requisitions-module").then(__webpack_require__.bind(null, /*! ./requisitions/requisitions.module */ "./src/app/requisitions/requisitions.module.ts")).then((m) => m.RequisitionsPageModule),
            },
            {
                path: ":id",
                loadChildren: () => Promise.all(/*! import() | requisitions-requisition-details-requisition-details-module */[__webpack_require__.e("default~orders-order-detail-order-detail-module~requisition-details-requisition-details-module~requi~ab00880c"), __webpack_require__.e("default~requisition-details-requisition-details-module~requisitions-requisition-details-requisition-~031c6e85"), __webpack_require__.e("requisitions-requisition-details-requisition-details-module")]).then(__webpack_require__.bind(null, /*! ./requisitions/requisition-details/requisition-details.module */ "./src/app/requisitions/requisition-details/requisition-details.module.ts")).then((m) => m.RequisitionDetailsPageModule),
            },
            {
                path: "new-requisition",
                loadChildren: () => Promise.all(/*! import() | requisitions-new-requisition-new-requisition-module */[__webpack_require__.e("default~new-requisition-new-requisition-module~requisitions-new-requisition-new-requisition-module"), __webpack_require__.e("requisitions-new-requisition-new-requisition-module")]).then(__webpack_require__.bind(null, /*! ./requisitions/new-requisition/new-requisition.module */ "./src/app/requisitions/new-requisition/new-requisition.module.ts")).then((m) => m.NewRequisitionPageModule),
            },
            {
                path: "released-requisitions",
                loadChildren: () => __webpack_require__.e(/*! import() | requisitions-released-requisitions-released-requisitions-module */ "released-requisitions-released-requisitions-module").then(__webpack_require__.bind(null, /*! ./requisitions/released-requisitions/released-requisitions.module */ "./src/app/requisitions/released-requisitions/released-requisitions.module.ts")).then((m) => m.ReleasedRequisitionsPageModule),
            },
        ],
    },
    {
        path: "payments",
        children: [
            {
                path: "",
                loadChildren: () => Promise.all(/*! import() | payments-payments-module */[__webpack_require__.e("default~payments-payment-detail-payment-detail-module~payments-payments-module"), __webpack_require__.e("payments-payments-module")]).then(__webpack_require__.bind(null, /*! ./payments/payments.module */ "./src/app/payments/payments.module.ts")).then((m) => m.PaymentsPageModule),
            },
            {
                path: ":id",
                loadChildren: () => Promise.all(/*! import() | payments-payment-detail-payment-detail-module */[__webpack_require__.e("default~new-payment-new-payment-module~payment-detail-payment-detail-module~payments-new-payment-new~adb5fad1"), __webpack_require__.e("default~payment-detail-payment-detail-module~payments-payment-detail-payment-detail-module"), __webpack_require__.e("default~payments-payment-detail-payment-detail-module~payments-payments-module")]).then(__webpack_require__.bind(null, /*! ./payments/payment-detail/payment-detail.module */ "./src/app/payments/payment-detail/payment-detail.module.ts")).then((m) => m.PaymentDetailPageModule),
            },
            {
                path: "new-payment",
                loadChildren: () => Promise.all(/*! import() | payments-new-payment-new-payment-module */[__webpack_require__.e("default~new-payment-new-payment-module~payment-detail-payment-detail-module~payments-new-payment-new~adb5fad1"), __webpack_require__.e("default~new-payment-new-payment-module~payments-new-payment-new-payment-module"), __webpack_require__.e("payments-new-payment-new-payment-module")]).then(__webpack_require__.bind(null, /*! ./payments/new-payment/new-payment.module */ "./src/app/payments/new-payment/new-payment.module.ts")).then((m) => m.NewPaymentPageModule),
            },
            {
                path: "daily-report",
                loadChildren: () => Promise.all(/*! import() | payments-daily-report-daily-report-module */[__webpack_require__.e("common"), __webpack_require__.e("payments-daily-report-daily-report-module")]).then(__webpack_require__.bind(null, /*! ./payments/daily-report/daily-report.module */ "./src/app/payments/daily-report/daily-report.module.ts")).then((m) => m.DailyReportPageModule),
            },
            {
                path: "monthly-report",
                loadChildren: () => Promise.all(/*! import() | payments-monthly-report-monthly-report-module */[__webpack_require__.e("common"), __webpack_require__.e("payments-monthly-report-monthly-report-module")]).then(__webpack_require__.bind(null, /*! ./payments/monthly-report/monthly-report.module */ "./src/app/payments/monthly-report/monthly-report.module.ts")).then((m) => m.MonthlyReportPageModule),
            },
            {
                path: "mpesa",
                loadChildren: () => Promise.all(/*! import() | payments-mpesa-mpesa-module */[__webpack_require__.e("common"), __webpack_require__.e("payments-mpesa-mpesa-module")]).then(__webpack_require__.bind(null, /*! ./payments/mpesa/mpesa.module */ "./src/app/payments/mpesa/mpesa.module.ts")).then((m) => m.MpesaPageModule)
            }
        ],
    },
    {
        path: "postedsales",
        children: [
            {
                path: "",
                loadChildren: () => __webpack_require__.e(/*! import() | postedsalesinvoices-postedsalesinvoices-module */ "postedsalesinvoices-postedsalesinvoices-module").then(__webpack_require__.bind(null, /*! ./postedsalesinvoices/postedsalesinvoices.module */ "./src/app/postedsalesinvoices/postedsalesinvoices.module.ts")).then((m) => m.PostedsalesinvoicesPageModule),
            },
            {
                path: ":id",
                loadChildren: () => Promise.all(/*! import() | postedsalesinvoices-sale-detail-sale-detail-module */[__webpack_require__.e("default~postedsalesinvoices-sale-detail-sale-detail-module~sale-detail-sale-detail-module"), __webpack_require__.e("postedsalesinvoices-sale-detail-sale-detail-module")]).then(__webpack_require__.bind(null, /*! ./postedsalesinvoices/sale-detail/sale-detail.module */ "./src/app/postedsalesinvoices/sale-detail/sale-detail.module.ts")).then((m) => m.SaleDetailPageModule),
            },
            {
                path: "dailyreport",
                loadChildren: () => Promise.all(/*! import() | postedsalesinvoices-dailyreport-dailyreport-module */[__webpack_require__.e("common"), __webpack_require__.e("postedsalesinvoices-dailyreport-dailyreport-module")]).then(__webpack_require__.bind(null, /*! ./postedsalesinvoices/dailyreport/dailyreport.module */ "./src/app/postedsalesinvoices/dailyreport/dailyreport.module.ts")).then((m) => m.DailyreportPageModule),
            },
            {
                path: "monthlyreport",
                loadChildren: () => Promise.all(/*! import() | postedsalesinvoices-monthlyreport-monthlyreport-module */[__webpack_require__.e("common"), __webpack_require__.e("postedsalesinvoices-monthlyreport-monthlyreport-module")]).then(__webpack_require__.bind(null, /*! ./postedsalesinvoices/monthlyreport/monthlyreport.module */ "./src/app/postedsalesinvoices/monthlyreport/monthlyreport.module.ts")).then((m) => m.MonthlyreportPageModule),
            },
        ],
    },
    {
        path: 'auth',
        loadChildren: () => __webpack_require__.e(/*! import() | auth-auth-module */ "auth-auth-module").then(__webpack_require__.bind(null, /*! ./auth/auth.module */ "./src/app/auth/auth.module.ts")).then(m => m.AuthPageModule)
    },
    {
        path: 'stock-details',
        loadChildren: () => __webpack_require__.e(/*! import() | stock-details-stock-details-module */ "stock-details-stock-details-module").then(__webpack_require__.bind(null, /*! ./stock-details/stock-details.module */ "./src/app/stock-details/stock-details.module.ts")).then(m => m.StockDetailsPageModule)
    },
    {
        path: 'credit',
        loadChildren: () => __webpack_require__.e(/*! import() | credit-credit-module */ "credit-credit-module").then(__webpack_require__.bind(null, /*! ./credit/credit.module */ "./src/app/credit/credit.module.ts")).then(m => m.CreditPageModule)
    },
    {
        path: 'return',
        children: [
            {
                path: "",
                loadChildren: () => Promise.all(/*! import() | return-return-list-return-list-module */[__webpack_require__.e("common"), __webpack_require__.e("return-return-list-return-list-module")]).then(__webpack_require__.bind(null, /*! ./return/return-list/return-list.module */ "./src/app/return/return-list/return-list.module.ts")).then(m => m.ReturnListPageModule)
            },
            {
                path: "create/:id",
                loadChildren: () => Promise.all(/*! import() | return-return-module */[__webpack_require__.e("default~return-return-card-return-card-module~return-return-module"), __webpack_require__.e("return-return-module")]).then(__webpack_require__.bind(null, /*! ./return/return.module */ "./src/app/return/return.module.ts")).then(m => m.ReturnPageModule)
            },
            {
                path: "card/:Key",
                loadChildren: () => Promise.all(/*! import() | return-return-card-return-card-module */[__webpack_require__.e("default~return-return-card-return-card-module~return-return-module"), __webpack_require__.e("default~return-card-return-card-module~return-return-card-return-card-module")]).then(__webpack_require__.bind(null, /*! ./return/return-card/return-card.module */ "./src/app/return/return-card/return-card.module.ts")).then(m => m.ReturnCardPageModule)
            }
        ]
        // loadChildren: () => import('./return/return.module').then( m => m.ReturnPageModule)
    },
    {
        path: 'customers',
        children: [
            {
                path: "",
                loadChildren: () => __webpack_require__.e(/*! import() | customers-customers-module */ "customers-customers-module").then(__webpack_require__.bind(null, /*! ./customers/customers.module */ "./src/app/customers/customers.module.ts")).then(m => m.CustomersPageModule)
            },
            {
                path: ":id",
                loadChildren: () => __webpack_require__.e(/*! import() | customers-customer-detail-customer-detail-module */ "customer-detail-customer-detail-module").then(__webpack_require__.bind(null, /*! ./customers/customer-detail/customer-detail.module */ "./src/app/customers/customer-detail/customer-detail.module.ts")).then(m => m.CustomerDetailPageModule)
            }
        ]
    },
    {
        path: 'cash-deposit',
        children: [
            {
                path: "",
                loadChildren: () => Promise.all(/*! import() | cash-deposit-cash-deposit-module */[__webpack_require__.e("common"), __webpack_require__.e("cash-deposit-cash-deposit-module")]).then(__webpack_require__.bind(null, /*! ./cash-deposit/cash-deposit.module */ "./src/app/cash-deposit/cash-deposit.module.ts")).then(m => m.CashDepositPageModule)
            },
            {
                path: ":Key",
                loadChildren: () => Promise.all(/*! import() | cash-deposit-cash-deposit-detail-cash-deposit-detail-module */[__webpack_require__.e("common"), __webpack_require__.e("cash-deposit-cash-deposit-detail-cash-deposit-detail-module")]).then(__webpack_require__.bind(null, /*! ./cash-deposit/cash-deposit-detail/cash-deposit-detail.module */ "./src/app/cash-deposit/cash-deposit-detail/cash-deposit-detail.module.ts")).then(m => m.CashDepositDetailPageModule)
            }
        ]
    },
];
let AppRoutingModule = class AppRoutingModule {
};
AppRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forRoot(routes, { preloadingStrategy: _angular_router__WEBPACK_IMPORTED_MODULE_2__["PreloadAllModules"] }),
        ],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AppRoutingModule);



/***/ }),

/***/ "./src/app/app.component.scss":
/*!************************************!*\
  !*** ./src/app/app.component.scss ***!
  \************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (".splash {\n  position: absolute;\n  width: 100%;\n  height: 100%;\n  z-index: 999;\n  display: flex;\n  align-items: center;\n  justify-content: center;\n  background-color: #d2b900;\n}\n\n.sk-cube-grid {\n  width: 40px;\n  height: 40px;\n  margin: 100px auto;\n}\n\n.sk-cube-grid .sk-cube {\n  width: 33%;\n  height: 33%;\n  background-color: #333;\n  float: left;\n  -webkit-animation: sk-cubeGridScaleDelay 1.3s infinite ease-in-out;\n  animation: sk-cubeGridScaleDelay 1.3s infinite ease-in-out;\n}\n\n.sk-cube-grid .sk-cube1 {\n  -webkit-animation-delay: 0.2s;\n  animation-delay: 0.2s;\n}\n\n.sk-cube-grid .sk-cube2 {\n  -webkit-animation-delay: 0.3s;\n  animation-delay: 0.3s;\n}\n\n.sk-cube-grid .sk-cube3 {\n  -webkit-animation-delay: 0.4s;\n  animation-delay: 0.4s;\n}\n\n.sk-cube-grid .sk-cube4 {\n  -webkit-animation-delay: 0.1s;\n  animation-delay: 0.1s;\n}\n\n.sk-cube-grid .sk-cube5 {\n  -webkit-animation-delay: 0.2s;\n  animation-delay: 0.2s;\n}\n\n.sk-cube-grid .sk-cube6 {\n  -webkit-animation-delay: 0.3s;\n  animation-delay: 0.3s;\n}\n\n.sk-cube-grid .sk-cube7 {\n  -webkit-animation-delay: 0s;\n  animation-delay: 0s;\n}\n\n.sk-cube-grid .sk-cube8 {\n  -webkit-animation-delay: 0.1s;\n  animation-delay: 0.1s;\n}\n\n.sk-cube-grid .sk-cube9 {\n  -webkit-animation-delay: 0.2s;\n  animation-delay: 0.2s;\n}\n\n@-webkit-keyframes sk-cubeGridScaleDelay {\n  0%, 70%, 100% {\n    transform: scale3D(1, 1, 1);\n  }\n  35% {\n    transform: scale3D(0, 0, 1);\n  }\n}\n\n@keyframes sk-cubeGridScaleDelay {\n  0%, 70%, 100% {\n    transform: scale3D(1, 1, 1);\n  }\n  35% {\n    transform: scale3D(0, 0, 1);\n  }\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvQzpcXFVzZXJzXFxIUCBFTElURUJPT0sgODQwIEc1XFxEZXNrdG9wXFxLaXBjaGFib19yZW1ha2VcXEtJUENIQUJPLVBPUy9zcmNcXGFwcFxcYXBwLmNvbXBvbmVudC5zY3NzIiwic3JjL2FwcC9hcHAuY29tcG9uZW50LnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUE7RUFDSSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxZQUFBO0VBQ0EsWUFBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLHVCQUFBO0VBQ0EseUJBQUE7QUNDSjs7QURFQTtFQUNJLFdBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7QUNDSjs7QURFRTtFQUNFLFVBQUE7RUFDQSxXQUFBO0VBQ0Esc0JBQUE7RUFDQSxXQUFBO0VBQ0Esa0VBQUE7RUFDUSwwREFBQTtBQ0NaOztBRENFO0VBQ0UsNkJBQUE7RUFDUSxxQkFBQTtBQ0VaOztBRERFO0VBQ0UsNkJBQUE7RUFDUSxxQkFBQTtBQ0laOztBREhFO0VBQ0UsNkJBQUE7RUFDUSxxQkFBQTtBQ01aOztBRExFO0VBQ0UsNkJBQUE7RUFDUSxxQkFBQTtBQ1FaOztBRFBFO0VBQ0UsNkJBQUE7RUFDUSxxQkFBQTtBQ1VaOztBRFRFO0VBQ0UsNkJBQUE7RUFDUSxxQkFBQTtBQ1laOztBRFhFO0VBQ0UsMkJBQUE7RUFDUSxtQkFBQTtBQ2NaOztBRGJFO0VBQ0UsNkJBQUE7RUFDUSxxQkFBQTtBQ2dCWjs7QURmRTtFQUNFLDZCQUFBO0VBQ1EscUJBQUE7QUNrQlo7O0FEaEJFO0VBQ0U7SUFFVSwyQkFBQTtFQ21CWjtFRGxCSTtJQUVRLDJCQUFBO0VDb0JaO0FBQ0Y7O0FEakJFO0VBQ0U7SUFFVSwyQkFBQTtFQ21CWjtFRGxCSTtJQUVRLDJCQUFBO0VDb0JaO0FBQ0YiLCJmaWxlIjoic3JjL2FwcC9hcHAuY29tcG9uZW50LnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIuc3BsYXNoIHtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgaGVpZ2h0OiAxMDAlO1xyXG4gICAgei1pbmRleDogOTk5O1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgIGJhY2tncm91bmQtY29sb3I6ICNkMmI5MDA7XHJcbn1cclxuXHJcbi5zay1jdWJlLWdyaWQge1xyXG4gICAgd2lkdGg6IDQwcHg7XHJcbiAgICBoZWlnaHQ6IDQwcHg7XHJcbiAgICBtYXJnaW46IDEwMHB4IGF1dG87XHJcbiAgfVxyXG4gIFxyXG4gIC5zay1jdWJlLWdyaWQgLnNrLWN1YmUge1xyXG4gICAgd2lkdGg6IDMzJTtcclxuICAgIGhlaWdodDogMzMlO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogIzMzMztcclxuICAgIGZsb2F0OiBsZWZ0O1xyXG4gICAgLXdlYmtpdC1hbmltYXRpb246IHNrLWN1YmVHcmlkU2NhbGVEZWxheSAxLjNzIGluZmluaXRlIGVhc2UtaW4tb3V0O1xyXG4gICAgICAgICAgICBhbmltYXRpb246IHNrLWN1YmVHcmlkU2NhbGVEZWxheSAxLjNzIGluZmluaXRlIGVhc2UtaW4tb3V0OyBcclxuICB9XHJcbiAgLnNrLWN1YmUtZ3JpZCAuc2stY3ViZTEge1xyXG4gICAgLXdlYmtpdC1hbmltYXRpb24tZGVsYXk6IDAuMnM7XHJcbiAgICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4yczsgfVxyXG4gIC5zay1jdWJlLWdyaWQgLnNrLWN1YmUyIHtcclxuICAgIC13ZWJraXQtYW5pbWF0aW9uLWRlbGF5OiAwLjNzO1xyXG4gICAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuM3M7IH1cclxuICAuc2stY3ViZS1ncmlkIC5zay1jdWJlMyB7XHJcbiAgICAtd2Via2l0LWFuaW1hdGlvbi1kZWxheTogMC40cztcclxuICAgICAgICAgICAgYW5pbWF0aW9uLWRlbGF5OiAwLjRzOyB9XHJcbiAgLnNrLWN1YmUtZ3JpZCAuc2stY3ViZTQge1xyXG4gICAgLXdlYmtpdC1hbmltYXRpb24tZGVsYXk6IDAuMXM7XHJcbiAgICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xczsgfVxyXG4gIC5zay1jdWJlLWdyaWQgLnNrLWN1YmU1IHtcclxuICAgIC13ZWJraXQtYW5pbWF0aW9uLWRlbGF5OiAwLjJzO1xyXG4gICAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuMnM7IH1cclxuICAuc2stY3ViZS1ncmlkIC5zay1jdWJlNiB7XHJcbiAgICAtd2Via2l0LWFuaW1hdGlvbi1kZWxheTogMC4zcztcclxuICAgICAgICAgICAgYW5pbWF0aW9uLWRlbGF5OiAwLjNzOyB9XHJcbiAgLnNrLWN1YmUtZ3JpZCAuc2stY3ViZTcge1xyXG4gICAgLXdlYmtpdC1hbmltYXRpb24tZGVsYXk6IDBzO1xyXG4gICAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDBzOyB9XHJcbiAgLnNrLWN1YmUtZ3JpZCAuc2stY3ViZTgge1xyXG4gICAgLXdlYmtpdC1hbmltYXRpb24tZGVsYXk6IDAuMXM7XHJcbiAgICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC4xczsgfVxyXG4gIC5zay1jdWJlLWdyaWQgLnNrLWN1YmU5IHtcclxuICAgIC13ZWJraXQtYW5pbWF0aW9uLWRlbGF5OiAwLjJzO1xyXG4gICAgICAgICAgICBhbmltYXRpb24tZGVsYXk6IDAuMnM7IH1cclxuICBcclxuICBALXdlYmtpdC1rZXlmcmFtZXMgc2stY3ViZUdyaWRTY2FsZURlbGF5IHtcclxuICAgIDAlLCA3MCUsIDEwMCUge1xyXG4gICAgICAtd2Via2l0LXRyYW5zZm9ybTogc2NhbGUzRCgxLCAxLCAxKTtcclxuICAgICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlM0QoMSwgMSwgMSk7XHJcbiAgICB9IDM1JSB7XHJcbiAgICAgIC13ZWJraXQtdHJhbnNmb3JtOiBzY2FsZTNEKDAsIDAsIDEpO1xyXG4gICAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUzRCgwLCAwLCAxKTsgXHJcbiAgICB9XHJcbiAgfVxyXG4gIFxyXG4gIEBrZXlmcmFtZXMgc2stY3ViZUdyaWRTY2FsZURlbGF5IHtcclxuICAgIDAlLCA3MCUsIDEwMCUge1xyXG4gICAgICAtd2Via2l0LXRyYW5zZm9ybTogc2NhbGUzRCgxLCAxLCAxKTtcclxuICAgICAgICAgICAgICB0cmFuc2Zvcm06IHNjYWxlM0QoMSwgMSwgMSk7XHJcbiAgICB9IDM1JSB7XHJcbiAgICAgIC13ZWJraXQtdHJhbnNmb3JtOiBzY2FsZTNEKDAsIDAsIDEpO1xyXG4gICAgICAgICAgICAgIHRyYW5zZm9ybTogc2NhbGUzRCgwLCAwLCAxKTtcclxuICAgIH0gXHJcbiAgfSIsIi5zcGxhc2gge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHdpZHRoOiAxMDAlO1xuICBoZWlnaHQ6IDEwMCU7XG4gIHotaW5kZXg6IDk5OTtcbiAgZGlzcGxheTogZmxleDtcbiAgYWxpZ24taXRlbXM6IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGJhY2tncm91bmQtY29sb3I6ICNkMmI5MDA7XG59XG5cbi5zay1jdWJlLWdyaWQge1xuICB3aWR0aDogNDBweDtcbiAgaGVpZ2h0OiA0MHB4O1xuICBtYXJnaW46IDEwMHB4IGF1dG87XG59XG5cbi5zay1jdWJlLWdyaWQgLnNrLWN1YmUge1xuICB3aWR0aDogMzMlO1xuICBoZWlnaHQ6IDMzJTtcbiAgYmFja2dyb3VuZC1jb2xvcjogIzMzMztcbiAgZmxvYXQ6IGxlZnQ7XG4gIC13ZWJraXQtYW5pbWF0aW9uOiBzay1jdWJlR3JpZFNjYWxlRGVsYXkgMS4zcyBpbmZpbml0ZSBlYXNlLWluLW91dDtcbiAgYW5pbWF0aW9uOiBzay1jdWJlR3JpZFNjYWxlRGVsYXkgMS4zcyBpbmZpbml0ZSBlYXNlLWluLW91dDtcbn1cblxuLnNrLWN1YmUtZ3JpZCAuc2stY3ViZTEge1xuICAtd2Via2l0LWFuaW1hdGlvbi1kZWxheTogMC4ycztcbiAgYW5pbWF0aW9uLWRlbGF5OiAwLjJzO1xufVxuXG4uc2stY3ViZS1ncmlkIC5zay1jdWJlMiB7XG4gIC13ZWJraXQtYW5pbWF0aW9uLWRlbGF5OiAwLjNzO1xuICBhbmltYXRpb24tZGVsYXk6IDAuM3M7XG59XG5cbi5zay1jdWJlLWdyaWQgLnNrLWN1YmUzIHtcbiAgLXdlYmtpdC1hbmltYXRpb24tZGVsYXk6IDAuNHM7XG4gIGFuaW1hdGlvbi1kZWxheTogMC40cztcbn1cblxuLnNrLWN1YmUtZ3JpZCAuc2stY3ViZTQge1xuICAtd2Via2l0LWFuaW1hdGlvbi1kZWxheTogMC4xcztcbiAgYW5pbWF0aW9uLWRlbGF5OiAwLjFzO1xufVxuXG4uc2stY3ViZS1ncmlkIC5zay1jdWJlNSB7XG4gIC13ZWJraXQtYW5pbWF0aW9uLWRlbGF5OiAwLjJzO1xuICBhbmltYXRpb24tZGVsYXk6IDAuMnM7XG59XG5cbi5zay1jdWJlLWdyaWQgLnNrLWN1YmU2IHtcbiAgLXdlYmtpdC1hbmltYXRpb24tZGVsYXk6IDAuM3M7XG4gIGFuaW1hdGlvbi1kZWxheTogMC4zcztcbn1cblxuLnNrLWN1YmUtZ3JpZCAuc2stY3ViZTcge1xuICAtd2Via2l0LWFuaW1hdGlvbi1kZWxheTogMHM7XG4gIGFuaW1hdGlvbi1kZWxheTogMHM7XG59XG5cbi5zay1jdWJlLWdyaWQgLnNrLWN1YmU4IHtcbiAgLXdlYmtpdC1hbmltYXRpb24tZGVsYXk6IDAuMXM7XG4gIGFuaW1hdGlvbi1kZWxheTogMC4xcztcbn1cblxuLnNrLWN1YmUtZ3JpZCAuc2stY3ViZTkge1xuICAtd2Via2l0LWFuaW1hdGlvbi1kZWxheTogMC4ycztcbiAgYW5pbWF0aW9uLWRlbGF5OiAwLjJzO1xufVxuXG5ALXdlYmtpdC1rZXlmcmFtZXMgc2stY3ViZUdyaWRTY2FsZURlbGF5IHtcbiAgMCUsIDcwJSwgMTAwJSB7XG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHNjYWxlM0QoMSwgMSwgMSk7XG4gICAgdHJhbnNmb3JtOiBzY2FsZTNEKDEsIDEsIDEpO1xuICB9XG4gIDM1JSB7XG4gICAgLXdlYmtpdC10cmFuc2Zvcm06IHNjYWxlM0QoMCwgMCwgMSk7XG4gICAgdHJhbnNmb3JtOiBzY2FsZTNEKDAsIDAsIDEpO1xuICB9XG59XG5Aa2V5ZnJhbWVzIHNrLWN1YmVHcmlkU2NhbGVEZWxheSB7XG4gIDAlLCA3MCUsIDEwMCUge1xuICAgIC13ZWJraXQtdHJhbnNmb3JtOiBzY2FsZTNEKDEsIDEsIDEpO1xuICAgIHRyYW5zZm9ybTogc2NhbGUzRCgxLCAxLCAxKTtcbiAgfVxuICAzNSUge1xuICAgIC13ZWJraXQtdHJhbnNmb3JtOiBzY2FsZTNEKDAsIDAsIDEpO1xuICAgIHRyYW5zZm9ybTogc2NhbGUzRCgwLCAwLCAxKTtcbiAgfVxufSJdfQ== */");

/***/ }),

/***/ "./src/app/app.component.ts":
/*!**********************************!*\
  !*** ./src/app/app.component.ts ***!
  \**********************************/
/*! exports provided: AppComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppComponent", function() { return AppComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _auth_auth_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./auth/auth-service */ "./src/app/auth/auth-service.ts");








let AppComponent = class AppComponent {
    constructor(platform, splashScreen, statusBar, router, auth) {
        this.platform = platform;
        this.splashScreen = splashScreen;
        this.statusBar = statusBar;
        this.router = router;
        this.auth = auth;
        this.showSplash = true;
        this.initializeApp();
    }
    initializeApp() {
        this.platform.ready().then(() => {
            this.statusBar.styleDefault();
            this.splashScreen.hide();
            Object(rxjs__WEBPACK_IMPORTED_MODULE_5__["timer"])(3000).subscribe(() => this.showSplash = false);
        });
    }
    exit() {
        console.log('You just logged me out!!');
        // Exit the App
        if (window.confirm(`Do you want to exit the app?`)) {
            navigator['app'].exitApp();
        }
    }
    logout() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.auth.logout();
            this.router.navigate(['./auth']);
        });
    }
    showDailySales() {
        return this.router.navigate(['./postedsales/dailyreport']);
    }
    showMonthlySales() {
        return this.router.navigate(['./postedsales/monthlyreport']);
    }
    showDailyReceipts() {
        return this.router.navigate(['./payments/daily-report']);
    }
    showMonthlyReceipts() {
        return this.router.navigate(['./payments/monthly-report']);
    }
    showAvailability() {
        return this.router.navigate(['./items/availability']);
    }
};
AppComponent.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["Platform"] },
    { type: _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_3__["SplashScreen"] },
    { type: _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_4__["StatusBar"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"] },
    { type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_7__["AuthService"] }
];
AppComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-root',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./app.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/app.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./app.component.scss */ "./src/app/app.component.scss")).default]
    })
], AppComponent);



/***/ }),

/***/ "./src/app/app.module.ts":
/*!*******************************!*\
  !*** ./src/app/app.module.ts ***!
  \*******************************/
/*! exports provided: AppModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AppModule", function() { return AppModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/platform-browser */ "./node_modules/@angular/platform-browser/__ivy_ngcc__/fesm2015/platform-browser.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/splash-screen/ngx */ "./node_modules/@ionic-native/splash-screen/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic-native/status-bar/ngx */ "./node_modules/@ionic-native/status-bar/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _app_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./app.component */ "./src/app/app.component.ts");
/* harmony import */ var _app_routing_module__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./app-routing.module */ "./src/app/app-routing.module.ts");
/* harmony import */ var _ionic_native_bluetooth_serial_ngx__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @ionic-native/bluetooth-serial/ngx */ "./node_modules/@ionic-native/bluetooth-serial/__ivy_ngcc__/ngx/index.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/__ivy_ngcc__/fesm2015/ionic-storage.js");
/* harmony import */ var _ionic_native_printer_ngx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic-native/printer/ngx */ "./node_modules/@ionic-native/printer/__ivy_ngcc__/ngx/index.js");














let AppModule = class AppModule {
};
AppModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        declarations: [_app_component__WEBPACK_IMPORTED_MODULE_8__["AppComponent"]],
        entryComponents: [],
        imports: [_angular_platform_browser__WEBPACK_IMPORTED_MODULE_2__["BrowserModule"], _angular_common_http__WEBPACK_IMPORTED_MODULE_4__["HttpClientModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicModule"].forRoot(), _app_routing_module__WEBPACK_IMPORTED_MODULE_9__["AppRoutingModule"], _angular_common__WEBPACK_IMPORTED_MODULE_11__["CommonModule"], _ionic_storage__WEBPACK_IMPORTED_MODULE_12__["IonicStorageModule"].forRoot()],
        providers: [
            _ionic_native_status_bar_ngx__WEBPACK_IMPORTED_MODULE_7__["StatusBar"],
            _ionic_native_splash_screen_ngx__WEBPACK_IMPORTED_MODULE_6__["SplashScreen"],
            _ionic_native_bluetooth_serial_ngx__WEBPACK_IMPORTED_MODULE_10__["BluetoothSerial"],
            _ionic_native_printer_ngx__WEBPACK_IMPORTED_MODULE_13__["Printer"],
            { provide: _angular_router__WEBPACK_IMPORTED_MODULE_3__["RouteReuseStrategy"], useClass: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["IonicRouteStrategy"] }
        ],
        bootstrap: [_app_component__WEBPACK_IMPORTED_MODULE_8__["AppComponent"]]
    })
], AppModule);



/***/ }),

/***/ "./src/app/auth/auth-service.ts":
/*!**************************************!*\
  !*** ./src/app/auth/auth-service.ts ***!
  \**************************************/
/*! exports provided: AuthService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthService", function() { return AuthService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _ionic_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/storage */ "./node_modules/@ionic/storage/__ivy_ngcc__/fesm2015/ionic-storage.js");





let AuthService = class AuthService {
    constructor(http, storage) {
        this.http = http;
        this.storage = storage;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].url;
    }
    authenticate(username, password) {
        const auth = { Password: password, Username: username };
        return this.http.post(`${this.url}/site/auth`, JSON.stringify(auth));
    }
    login(user) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const userData = JSON.stringify(user);
            return yield this.storage.set('user', userData);
        });
    }
    logout() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.storage.remove('user');
            yield this.storage.remove('Employee');
            yield this.authenticated(false);
        });
    }
    getUser() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const user = yield this.storage.get('user');
            return JSON.parse(user);
        });
    }
    fetchEmployee(No) {
        return this.http.get(`${this.url}site/employee?No=${No}`);
    }
    setEmployee(Employee) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const employee = JSON.stringify(Employee);
            return yield this.storage.set('Employee', employee);
        });
    }
    getEmployee() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const employee = yield this.storage.get('Employee');
            return JSON.parse(employee);
        });
    }
    authenticated(status) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return yield this.storage.set('Authenticated', status);
        });
    }
    isAuthenticated() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return yield this.storage.get('Authenticated');
        });
    }
};
AuthService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] },
    { type: _ionic_storage__WEBPACK_IMPORTED_MODULE_4__["Storage"] }
];
AuthService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
        providedIn: 'root'
    })
], AuthService);



/***/ }),

/***/ "./src/app/auth/auth.guard.ts":
/*!************************************!*\
  !*** ./src/app/auth/auth.guard.ts ***!
  \************************************/
/*! exports provided: AuthGuard */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AuthGuard", function() { return AuthGuard; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./auth-service */ "./src/app/auth/auth-service.ts");




let AuthGuard = class AuthGuard {
    constructor(auth, router) {
        this.auth = auth;
        this.router = router;
    }
    canLoad(route, segments) {
        if (!this.auth.isAuthenticated()) {
            return this.router.navigateByUrl('./auth');
        }
        return this.auth.isAuthenticated();
    }
};
AuthGuard.ctorParameters = () => [
    { type: _auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"] }
];
AuthGuard = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], AuthGuard);



/***/ }),

/***/ "./src/environments/environment.ts":
/*!*****************************************!*\
  !*** ./src/environments/environment.ts ***!
  \*****************************************/
/*! exports provided: environment */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "environment", function() { return environment; });
// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.
const environment = {
    production: false,
    // url: `http://192.168.1.118/`,
    // url: `http://192.168.87.33/`,
    // url: `http://192.168.43.20/`
    url: `http://197.248.96.58/`
};
/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.


/***/ }),

/***/ "./src/main.ts":
/*!*********************!*\
  !*** ./src/main.ts ***!
  \*********************/
/*! no exports provided */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/platform-browser-dynamic */ "./node_modules/@angular/platform-browser-dynamic/__ivy_ngcc__/fesm2015/platform-browser-dynamic.js");
/* harmony import */ var _app_app_module__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./app/app.module */ "./src/app/app.module.ts");
/* harmony import */ var _environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./environments/environment */ "./src/environments/environment.ts");




if (_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].production) {
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_0__["enableProdMode"])();
}
Object(_angular_platform_browser_dynamic__WEBPACK_IMPORTED_MODULE_1__["platformBrowserDynamic"])().bootstrapModule(_app_app_module__WEBPACK_IMPORTED_MODULE_2__["AppModule"])
    .catch(err => console.log(err));


/***/ }),

/***/ 0:
/*!***************************!*\
  !*** multi ./src/main.ts ***!
  \***************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! C:\Users\HP ELITEBOOK 840 G5\Desktop\Kipchabo_remake\KIPCHABO-POS\src\main.ts */"./src/main.ts");


/***/ })

},[[0,"runtime","vendor"]]]);
//# sourceMappingURL=main-es2015.js.map