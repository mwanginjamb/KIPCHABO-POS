function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~new-payment-new-payment-module~payment-detail-payment-detail-module~payments-new-payment-new~adb5fad1"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/payments/new-cash-line/new-cash-line.component.html":
  /*!***********************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/payments/new-cash-line/new-cash-line.component.html ***!
    \***********************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPaymentsNewCashLineNewCashLineComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>{{line.Key?'Update': 'New'}} Cash Receipt Line</ion-title>\r\n\r\n    <ion-buttons slot=\"primary\">\r\n      <ion-button (click)=\"onCancel()\">\r\n        <ion-icon name=\"close\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <ion-row>\r\n    <ion-col size-sm=\"6\" offset-sm=\"3\">\r\n      <ion-list>\r\n\r\n        <ion-item>\r\n          <ion-label position=\"floating\">Item</ion-label>\r\n          <ion-select [(ngModel)]=\"line.Item_No\" [selectedText]=\"line.Description\" placeholder=\"Select Item\">\r\n            <ion-select-option *ngFor=\"let item of items\" [value]=\"item.No\">{{ item.Description }}</ion-select-option>\r\n          </ion-select>\r\n        </ion-item>\r\n\r\n        <ion-item>\r\n          <ion-label position=\"floating\">Store</ion-label>\r\n          <ion-input [(ngModel)]=\"line.Store_Code\" type=\"text\" readonly></ion-input>\r\n          <!--<ion-select [(ngModel)]=\"line.Store_Code\" [selectedText]=\"line.Store_Name\" placeholder=\"Select Store\">\r\n            <ion-select-option *ngFor=\"let store of locations\" [value]=\"store.Code\">{{ store.Name }}</ion-select-option>\r\n          </ion-select>-->\r\n        </ion-item>\r\n\r\n        <ion-item>\r\n          <ion-label position=\"floating\"> Quantity.</ion-label>\r\n          <ion-input [(ngModel)]=\"line.Qty\" type=\"number\"></ion-input>\r\n        </ion-item>\r\n\r\n        <!---<ion-item>\r\n          <ion-label position=\"floating\"> Price</ion-label>\r\n          <ion-input [(ngModel)]=\"line.Price\" type=\"number\"></ion-input>\r\n        </ion-item>-->\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n      </ion-list>\r\n      <ion-button *ngIf=\"!line.Key\" color=\"primary\" (click)=\"addLine()\" expand=\"block\" fill=\"outline\">\r\n        Add Line\r\n      </ion-button>\r\n\r\n      <ion-button *ngIf=\"line.Key\" color=\"primary\" (click)=\"updateLine()\" expand=\"block\" fill=\"outline\">\r\n        Update Line\r\n      </ion-button>\r\n\r\n    </ion-col>\r\n  </ion-row>\r\n\r\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/items/item.service.ts":
  /*!***************************************!*\
    !*** ./src/app/items/item.service.ts ***!
    \***************************************/

  /*! exports provided: ItemService */

  /***/
  function srcAppItemsItemServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ItemService", function () {
      return ItemService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var ItemService = /*#__PURE__*/function () {
      function ItemService(http, toastCtrl) {
        _classCallCheck(this, ItemService);

        this.http = http;
        this.toastCtrl = toastCtrl;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
      }

      _createClass(ItemService, [{
        key: "items",
        get: function get() {
          return this.http.get("".concat(this.url, "site/items")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "itemcard",
        value: function itemcard(id) {
          return this.http.get("".concat(this.url, "site/itemcard/?id=").concat(id));
        }
      }, {
        key: "itemBalance",
        value: function itemBalance(No) {
          return this.http.get("".concat(this.url, "site/itemavailabilitybylocation/?No=").concat(No));
        }
      }, {
        key: "itemBalanceByLocation",
        value: function itemBalanceByLocation(No, LocationCode) {
          return this.http.get("".concat(this.url, "site/itemavailabilitybylocation/?No=").concat(No, "&Location=").concat(LocationCode)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "getTotals",
        value: function getTotals(elements, subjectColumn) {
          var sum = 0;
          elements.forEach(function (obj) {
            // console.log(obj);
            for (var property in obj) {
              if (property === subjectColumn && !isNaN(+obj[property])) {
                // console.log(+obj[property]);
                sum += +obj[property];
              }
            }
          });
          return sum;
        } // Get Locations List

      }, {
        key: "getLocations",
        value: function getLocations() {
          return this.http.get("".concat(this.url, "site/locationlist")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "showToast",
        value: function showToast(text) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.toastCtrl.create({
                      message: text,
                      duration: 4000,
                      position: 'top'
                    }).then(function (toastEl) {
                      toastEl.present();
                    });

                  case 2:
                    return _context.abrupt("return", _context.sent);

                  case 3:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }]);

      return ItemService;
    }();

    ItemService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"]
      }];
    };

    ItemService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], ItemService);
    /***/
  },

  /***/
  "./src/app/models/cashreceiptline.model.ts":
  /*!*************************************************!*\
    !*** ./src/app/models/cashreceiptline.model.ts ***!
    \*************************************************/

  /*! exports provided: Cashreceiptline */

  /***/
  function srcAppModelsCashreceiptlineModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Cashreceiptline", function () {
      return Cashreceiptline;
    });

    var Cashreceiptline = function Cashreceiptline(Key, Item_No, Description, Store_Code, Store_Name, Qty, Price, Total_Amount, POS_Receipt_No, Stock_Balance) {
      _classCallCheck(this, Cashreceiptline);

      this.Key = Key;
      this.Item_No = Item_No;
      this.Description = Description;
      this.Store_Code = Store_Code;
      this.Store_Name = Store_Name;
      this.Qty = Qty;
      this.Price = Price;
      this.Total_Amount = Total_Amount;
      this.POS_Receipt_No = POS_Receipt_No;
      this.Stock_Balance = Stock_Balance;
    };
    /***/

  },

  /***/
  "./src/app/payments/new-cash-line/new-cash-line.component.scss":
  /*!*********************************************************************!*\
    !*** ./src/app/payments/new-cash-line/new-cash-line.component.scss ***!
    \*********************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPaymentsNewCashLineNewCashLineComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BheW1lbnRzL25ldy1jYXNoLWxpbmUvbmV3LWNhc2gtbGluZS5jb21wb25lbnQuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/payments/new-cash-line/new-cash-line.component.ts":
  /*!*******************************************************************!*\
    !*** ./src/app/payments/new-cash-line/new-cash-line.component.ts ***!
    \*******************************************************************/

  /*! exports provided: NewCashLineComponent */

  /***/
  function srcAppPaymentsNewCashLineNewCashLineComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NewCashLineComponent", function () {
      return NewCashLineComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var src_app_requisitions_requisition_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/requisitions/requisition.service */
    "./src/app/requisitions/requisition.service.ts");
    /* harmony import */


    var _payments_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../payments.service */
    "./src/app/payments/payments.service.ts");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var src_app_items_item_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! src/app/items/item.service */
    "./src/app/items/item.service.ts");
    /* harmony import */


    var src_app_models_cashreceiptline_model__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! src/app/models/cashreceiptline.model */
    "./src/app/models/cashreceiptline.model.ts");
    /* harmony import */


    var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! src/app/auth/auth-service */
    "./src/app/auth/auth-service.ts");

    var NewCashLineComponent = /*#__PURE__*/function () {
      function NewCashLineComponent(paymentService, requisitionService, itemService, modalCtrl, alertCtrl, toastCtrl, loadingCtrl, authService) {
        _classCallCheck(this, NewCashLineComponent);

        this.paymentService = paymentService;
        this.requisitionService = requisitionService;
        this.itemService = itemService;
        this.modalCtrl = modalCtrl;
        this.alertCtrl = alertCtrl;
        this.toastCtrl = toastCtrl;
        this.loadingCtrl = loadingCtrl;
        this.authService = authService;
        this.items = [];
        this.line = new src_app_models_cashreceiptline_model__WEBPACK_IMPORTED_MODULE_7__["Cashreceiptline"]();
      }

      _createClass(NewCashLineComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.presentLoading();
          this.fetchItems();
          this.fetchLocations();
          this.setUser();
          this.line.Store_Code = this.Store_Code;

          if (this.Key) {
            //Update
            this.FetchLinetoUpdate();
          } else if (!this.Key) {
            // Create
            this.line.POS_Receipt_No = this.receiptNo;
          }
        }
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.setUser();
        }
      }, {
        key: "ionViewDidEnter",
        value: function ionViewDidEnter() {
          this.setUser();
        }
      }, {
        key: "setUser",
        value: function setUser() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.authService.getUser();

                  case 2:
                    this.user = _context2.sent;
                    this.Store_Code = this.user.Store_Code;
                    this.line.Store_Code = this.Store_Code;

                  case 5:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "fetchLocations",
        value: function fetchLocations() {
          var _this = this;

          this.locationSub = this.requisitionService.getLocations().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["finalize"])(function () {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
              return regeneratorRuntime.wrap(function _callee3$(_context3) {
                while (1) {
                  switch (_context3.prev = _context3.next) {
                    case 0:
                      _context3.next = 2;
                      return this.loading.dismiss();

                    case 2:
                    case "end":
                      return _context3.stop();
                  }
                }
              }, _callee3, this);
            }));
          })).subscribe(function (res) {
            _this.locations = res; // console.table(res);
          });
        }
      }, {
        key: "fetchItems",
        value: function fetchItems() {
          var _this2 = this;

          this.itemSub = this.itemService.items.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["finalize"])(function () {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this2, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
              return regeneratorRuntime.wrap(function _callee4$(_context4) {
                while (1) {
                  switch (_context4.prev = _context4.next) {
                    case 0:
                      _context4.next = 2;
                      return this.loading.dismiss();

                    case 2:
                    case "end":
                      return _context4.stop();
                  }
                }
              }, _callee4, this);
            }));
          })).subscribe(function (items) {
            _this2.items = items;
          });
        }
      }, {
        key: "InitLine",
        value: function InitLine() {
          var _this3 = this;

          this.setUser();
          console.log("Store Code : ".concat(this.Store_Code));
          this.paymentService.postLine(this.line).subscribe(function (line) {
            if (line) {
              _this3.line = line;
              _this3.line.Store_Code = _this3.Store_Code;
            } else {
              _this3.alertCtrl.create({
                header: 'Operation Error',
                message: 'Message : ' + line,
                buttons: [{
                  text: 'Okay',
                  handler: function handler() {
                    return _this3.modalCtrl.dismiss();
                  }
                }]
              }).then(function (alertEl) {
                alertEl.present();
              });
            }
          }, function (error) {
            console.log(error.error);

            _this3.alertCtrl.create({
              header: 'Service Error!',
              message: 'Connection problem: ' + error,
              buttons: [{
                text: 'Okay',
                handler: function handler() {
                  return _this3.modalCtrl.dismiss();
                }
              }]
            }).then(function (alertEl) {
              alertEl.present();
            });
          });
        }
      }, {
        key: "addLine",
        value: function addLine() {
          var _this4 = this;

          this.paymentService.postLine(this.line).subscribe(function (line) {
            console.log(line);

            if (line) {
              _this4.modalCtrl.dismiss(); // Show a Toast Notification


              _this4.toastCtrl.create({
                message: "Line Added Successfully.",
                duration: 2000,
                position: 'top'
              }).then(function (toastData) {
                toastData.present();
              });
            } else {
              _this4.alertCtrl.create({
                header: 'Operation Error',
                message: 'Message : ' + line,
                buttons: [{
                  text: 'Okay',
                  handler: function handler() {
                    return _this4.modalCtrl.dismiss();
                  }
                }]
              }).then(function (alertEl) {
                alertEl.present();
              });
            }
          }, function (error) {
            console.log(error.error);

            _this4.alertCtrl.create({
              header: 'Service Error!',
              message: 'Connection problem: ' + error,
              buttons: [{
                text: 'Okay',
                handler: function handler() {
                  return _this4.modalCtrl.dismiss();
                }
              }]
            }).then(function (alertEl) {
              alertEl.present();
            });
          });
        }
      }, {
        key: "updateLine",
        value: function updateLine() {
          var _this5 = this;

          this.paymentService.updateLine(this.line).subscribe(function (line) {
            if (typeof line !== 'string') {
              _this5.toastCtrl.create({
                message: "".concat(line.Description, " Line Updated Successfully."),
                duration: 3000,
                position: 'top'
              }).then(function (toastData) {
                toastData.present();
              });

              _this5.modalCtrl.dismiss();
            } else {
              // Alert the error
              _this5.alertCtrl.create({
                header: 'Operation Error',
                message: 'Message : ' + line,
                buttons: [{
                  text: 'Okay',
                  handler: function handler() {
                    return _this5.modalCtrl.dismiss();
                  }
                }]
              }).then(function (alertEl) {
                alertEl.present();
              });
            }
          }, function (error) {
            console.log(error.error);

            _this5.alertCtrl.create({
              header: 'Service Error!',
              message: 'Connection problem: ' + error.error.message,
              buttons: [{
                text: 'Okay',
                handler: function handler() {
                  return _this5.modalCtrl.dismiss();
                }
              }]
            }).then(function (alertEl) {
              alertEl.present();
            });
          });
        }
      }, {
        key: "FetchLinetoUpdate",
        value: function FetchLinetoUpdate() {
          var _this6 = this;

          this.updateLineSub = this.paymentService.getLine(this.Key).subscribe(function (res) {
            Object.assign(_this6.line, res);
          }, function (error) {
            _this6.alertCtrl.create({
              header: 'Service Error!',
              message: 'Connection problem: ' + error.error.message,
              buttons: [{
                text: 'Okay',
                handler: function handler() {
                  return _this6.modalCtrl.dismiss();
                }
              }]
            }).then(function (alertEl) {
              alertEl.present();
            });
          });
        }
      }, {
        key: "presentLoading",
        value: function presentLoading(message) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
            return regeneratorRuntime.wrap(function _callee5$(_context5) {
              while (1) {
                switch (_context5.prev = _context5.next) {
                  case 0:
                    _context5.next = 2;
                    return this.loadingCtrl.create({
                      spinner: 'dots',
                      animated: true,
                      message: message ? message : 'Loading..'
                    });

                  case 2:
                    this.loading = _context5.sent;
                    _context5.next = 5;
                    return this.loading.present();

                  case 5:
                  case "end":
                    return _context5.stop();
                }
              }
            }, _callee5, this);
          }));
        }
      }, {
        key: "onCancel",
        value: function onCancel() {
          this.modalCtrl.dismiss();
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          if (this.itemSub) {
            this.itemSub.unsubscribe();
          }

          if (this.locationSub) {
            this.locationSub.unsubscribe();
          }

          if (this.updateLineSub) {
            this.updateLineSub.unsubscribe();
          }
        }
      }]);

      return NewCashLineComponent;
    }();

    NewCashLineComponent.ctorParameters = function () {
      return [{
        type: _payments_service__WEBPACK_IMPORTED_MODULE_4__["PaymentsService"]
      }, {
        type: src_app_requisitions_requisition_service__WEBPACK_IMPORTED_MODULE_3__["RequisitionService"]
      }, {
        type: src_app_items_item_service__WEBPACK_IMPORTED_MODULE_6__["ItemService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]
      }, {
        type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_8__["AuthService"]
      }];
    };

    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], NewCashLineComponent.prototype, "receiptNo", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], NewCashLineComponent.prototype, "Key", void 0);
    NewCashLineComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-new-cash-line',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./new-cash-line.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/payments/new-cash-line/new-cash-line.component.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./new-cash-line.component.scss */
      "./src/app/payments/new-cash-line/new-cash-line.component.scss"))["default"]]
    })], NewCashLineComponent);
    /***/
  },

  /***/
  "./src/app/requisitions/requisition.service.ts":
  /*!*****************************************************!*\
    !*** ./src/app/requisitions/requisition.service.ts ***!
    \*****************************************************/

  /*! exports provided: RequisitionService */

  /***/
  function srcAppRequisitionsRequisitionServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RequisitionService", function () {
      return RequisitionService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");

    var RequisitionService = /*#__PURE__*/function () {
      function RequisitionService(http) {
        _classCallCheck(this, RequisitionService);

        this.http = http;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
        this._refresh$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__["Subject"]();
      } // Synthetic Getter for our refresh observerble


      _createClass(RequisitionService, [{
        key: "refresh$",
        get: function get() {
          return this._refresh$;
        }
      }, {
        key: "getRequisitions",
        value: function getRequisitions(userID) {
          return this.http.get("".concat(this.url, "site/requisitions?userid=").concat(userID)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "releasedrequisitions",
        get: function get() {
          return this.http.get("".concat(this.url, "site/releasedrequisitions")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        } // Retrieve Requisition Card / Details

      }, {
        key: "requisitioncard",
        value: function requisitioncard(id) {
          return this.http.get("".concat(this.url, "site/requisitioncard/?id=").concat(id));
        } // Create New Requisition

      }, {
        key: "createRequisition",
        value: function createRequisition(userID) {
          console.log('creator is:' + userID);
          return this.http.get("".concat(this.url, "site/create-requisition?userid=").concat(userID));
        } // get Units of Measure

      }, {
        key: "getunits",
        value: function getunits(itemNo) {
          return this.http.get("".concat(this.url, "site/unitmeasure?itemNo=").concat(itemNo)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        } // Get Locations List

      }, {
        key: "getLocations",
        value: function getLocations() {
          return this.http.get("".concat(this.url, "site/locationlist")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        } // Get any items from generic service getter function

      }, {
        key: "Dimensions",
        get: function get() {
          return this.http.get("".concat(this.url, "site/get?service=Dimensions")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "Departments",
        get: function get() {
          return this.http.get("".concat(this.url, "site/departments")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "Projects",
        get: function get() {
          return this.http.get("".concat(this.url, "site/projects")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        } // Post Lines Data

      }, {
        key: "postLine",
        value: function postLine(line) {
          var _this7 = this;

          return this.http.post("".concat(this.url, "site/requisition-lines"), JSON.stringify(line)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function () {
            _this7._refresh$.next();
          }));
        } // Update Line

      }, {
        key: "updateRequisitionLine",
        value: function updateRequisitionLine(line) {
          var _this8 = this;

          return this.http.post("".concat(this.url, "site/updaterequisitionline"), JSON.stringify(line)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function () {
            _this8._refresh$.next();
          }));
        } // Fetch Line to Update

      }, {
        key: "getLine",
        value: function getLine(Key) {
          return this.http.get("".concat(this.url, "site/requisition-lines?Key=").concat(Key));
        } // Post Requisition Header

      }, {
        key: "postRequisition",
        value: function postRequisition(requisition) {
          return this.http.post("".concat(this.url, "site/update-requisition"), JSON.stringify(requisition));
        } // Format date utility

      }, {
        key: "formatDate",
        value: function formatDate(datestring) {
          // Format Date to YYYY-MM-DD
          var recDate = new Date(datestring);
          var month = recDate.getMonth() + 1 > 9 ? recDate.getMonth() + 1 : "0" + (recDate.getMonth() + 1);
          var day = recDate.getDate() > 9 ? recDate.getDate() : "0" + recDate.getDate();
          return "".concat(recDate.getFullYear(), "-").concat(month, "-").concat(day);
        }
      }]);

      return RequisitionService;
    }();

    RequisitionService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }];
    };

    RequisitionService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], RequisitionService);
    /***/
  },

  /***/
  "./src/app/utility.service.ts":
  /*!************************************!*\
    !*** ./src/app/utility.service.ts ***!
    \************************************/

  /*! exports provided: UtilityService */

  /***/
  function srcAppUtilityServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "UtilityService", function () {
      return UtilityService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var UtilityService = /*#__PURE__*/function () {
      function UtilityService(toastCtrl, alertCtrl, loadingCtrl) {
        _classCallCheck(this, UtilityService);

        this.toastCtrl = toastCtrl;
        this.alertCtrl = alertCtrl;
        this.loadingCtrl = loadingCtrl;
      }

      _createClass(UtilityService, [{
        key: "formatDate",
        value: function formatDate(datestring) {
          // Format Date to YYYY-MM-DD
          var recDate = new Date(datestring);
          var month = recDate.getMonth() + 1 > 9 ? recDate.getMonth() + 1 : "0" + (recDate.getMonth() + 1);
          var day = recDate.getDate() > 9 ? recDate.getDate() : "0" + recDate.getDate();
          return "".concat(recDate.getFullYear(), "-").concat(month, "-").concat(day);
        }
      }, {
        key: "showToast",
        value: function showToast(text) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
            var toastEl;
            return regeneratorRuntime.wrap(function _callee6$(_context6) {
              while (1) {
                switch (_context6.prev = _context6.next) {
                  case 0:
                    toastEl = this.toastCtrl.create({
                      message: text,
                      duration: 4000,
                      position: 'top'
                    });
                    _context6.next = 3;
                    return toastEl;

                  case 3:
                    _context6.sent.present();

                  case 4:
                  case "end":
                    return _context6.stop();
                }
              }
            }, _callee6, this);
          }));
        }
      }, {
        key: "showAlert",
        value: function showAlert(text) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
            var alertEl;
            return regeneratorRuntime.wrap(function _callee7$(_context7) {
              while (1) {
                switch (_context7.prev = _context7.next) {
                  case 0:
                    _context7.next = 2;
                    return this.alertCtrl.create({
                      header: 'Operation Error',
                      message: 'Message : ' + text,
                      buttons: [{
                        text: 'Okay'
                      }]
                    });

                  case 2:
                    alertEl = _context7.sent;
                    _context7.next = 5;
                    return alertEl.present();

                  case 5:
                  case "end":
                    return _context7.stop();
                }
              }
            }, _callee7, this);
          }));
        }
      }, {
        key: "presentLoading",
        value: function presentLoading(message) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee8() {
            var loading;
            return regeneratorRuntime.wrap(function _callee8$(_context8) {
              while (1) {
                switch (_context8.prev = _context8.next) {
                  case 0:
                    _context8.next = 2;
                    return this.loadingCtrl.create({
                      spinner: 'dots',
                      animated: true,
                      message: message ? message : 'Loading Data...'
                    });

                  case 2:
                    loading = _context8.sent;
                    _context8.next = 5;
                    return loading.present();

                  case 5:
                  case "end":
                    return _context8.stop();
                }
              }
            }, _callee8, this);
          }));
        }
      }]);

      return UtilityService;
    }();

    UtilityService.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]
      }];
    };

    UtilityService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], UtilityService);
    /***/
  }
}]);
//# sourceMappingURL=default~new-payment-new-payment-module~payment-detail-payment-detail-module~payments-new-payment-new~adb5fad1-es5.js.map