function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~new-requisition-new-requisition-module~requisitions-new-requisition-new-requisition-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/requisitions/new-requisition/new-requisition.page.html":
  /*!**************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/requisitions/new-requisition/new-requisition.page.html ***!
    \**************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppRequisitionsNewRequisitionNewRequisitionPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <ion-title>New Requisition</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <form #Req=\"ngForm\" (ngSubmit)=\"onRequisitionupdate(Req)\">\r\n    <ion-grid>\r\n      <ion-row>\r\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\r\n          <ion-card>\r\n              <ion-card-header>\r\n                <ion-card-title>\r\n                  Stock Requisition Form\r\n                </ion-card-title>\r\n              </ion-card-header>\r\n\r\n              <ion-card-content>\r\n\r\n                <ion-row>\r\n                  <ion-col >\r\n                    <ion-item>\r\n                      <ion-label position=\"floating\">Req No.</ion-label>\r\n                      <ion-input type=\"text\" [(ngModel)]=\"requisition.Req_No\" name=\"Req_No\"></ion-input>\r\n                    </ion-item>\r\n                  </ion-col>\r\n                </ion-row>\r\n                \r\n                <ion-row>\r\n                  <ion-col >\r\n                    <ion-item>\r\n                      <ion-label position=\"floating\">Store Code.</ion-label>\r\n                      \r\n                      <ion-select [(ngModel)]=\"requisition.Store_Code\" name=\"Transfer_from_Code\" placeholder=\"Select ...\">\r\n                        <ion-select-option *ngFor=\"let loc of locations\" [value]=\"loc.Code\">{{loc.Name}}</ion-select-option>\r\n                      </ion-select>\r\n\r\n                    </ion-item>\r\n                  </ion-col>\r\n                </ion-row>\r\n\r\n                <ion-row>\r\n                  <ion-col >\r\n                    <ion-item>\r\n                      <ion-label position=\"floating\">Requisition Date</ion-label>\r\n                      <ion-input type=\"text\" [(ngModel)]=\"requisition.Requisition_Date\" name=\"Requisition_Date\"></ion-input>\r\n                      \r\n                    </ion-item>\r\n                  </ion-col>\r\n\r\n                  <ion-col >\r\n                    <ion-item>\r\n                      <ion-label position=\"floating\">Store Name</ion-label>\r\n                      <ion-input type=\"text\" [(ngModel)]=\"requisition.Store_Name\" name=\"Store_Name\"></ion-input>                  \r\n                     \r\n                    \r\n                    </ion-item>\r\n                  </ion-col>\r\n                </ion-row>\r\n\r\n                <ion-row>\r\n                  <ion-col >\r\n                    <ion-item>\r\n                      <ion-label position=\"floating\">Requested On</ion-label>\r\n                      <ion-input type=\"text\" [(ngModel)]=\"requisition.Requested_On\" name=\"Requested_On\"></ion-input>\r\n                    </ion-item>\r\n                  </ion-col>\r\n\r\n                  <ion-col >\r\n                    <ion-item>\r\n                      <ion-label position=\"floating\">Approval Status</ion-label>\r\n                      <ion-input type=\"text\" [(ngModel)]=\"requisition.Approval_Status\" name=\"Approval_Status\"></ion-input>\r\n                    </ion-item>\r\n                  </ion-col>\r\n                </ion-row>\r\n\r\n                \r\n\r\n                \r\n\r\n                <ion-row>\r\n                  <ion-col>\r\n                    \r\n                    <ion-input type=\"hidden\" [(ngModel)]=\"requisition.Key\" name=\"Key\"></ion-input>\r\n                  </ion-col>\r\n                </ion-row>\r\n\r\n                <ion-row>\r\n                  <ion-col size-sm=\"6\" offset-sm=\"3\">\r\n                    <ion-button type=\"submit\" color=\"primary\" expand=\"block\">Save Details</ion-button>\r\n                  </ion-col>\r\n                </ion-row>\r\n\r\n              </ion-card-content>\r\n\r\n            </ion-card> \r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </form>\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./src/app/requisitions/new-requisition/new-requisition-routing.module.ts":
  /*!********************************************************************************!*\
    !*** ./src/app/requisitions/new-requisition/new-requisition-routing.module.ts ***!
    \********************************************************************************/

  /*! exports provided: NewRequisitionPageRoutingModule */

  /***/
  function srcAppRequisitionsNewRequisitionNewRequisitionRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NewRequisitionPageRoutingModule", function () {
      return NewRequisitionPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _new_requisition_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./new-requisition.page */
    "./src/app/requisitions/new-requisition/new-requisition.page.ts");

    var routes = [{
      path: '',
      component: _new_requisition_page__WEBPACK_IMPORTED_MODULE_3__["NewRequisitionPage"]
    }];

    var NewRequisitionPageRoutingModule = function NewRequisitionPageRoutingModule() {
      _classCallCheck(this, NewRequisitionPageRoutingModule);
    };

    NewRequisitionPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], NewRequisitionPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/requisitions/new-requisition/new-requisition.module.ts":
  /*!************************************************************************!*\
    !*** ./src/app/requisitions/new-requisition/new-requisition.module.ts ***!
    \************************************************************************/

  /*! exports provided: NewRequisitionPageModule */

  /***/
  function srcAppRequisitionsNewRequisitionNewRequisitionModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NewRequisitionPageModule", function () {
      return NewRequisitionPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _new_requisition_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./new-requisition-routing.module */
    "./src/app/requisitions/new-requisition/new-requisition-routing.module.ts");
    /* harmony import */


    var _new_requisition_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./new-requisition.page */
    "./src/app/requisitions/new-requisition/new-requisition.page.ts");

    var NewRequisitionPageModule = function NewRequisitionPageModule() {
      _classCallCheck(this, NewRequisitionPageModule);
    };

    NewRequisitionPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _new_requisition_routing_module__WEBPACK_IMPORTED_MODULE_5__["NewRequisitionPageRoutingModule"]],
      declarations: [_new_requisition_page__WEBPACK_IMPORTED_MODULE_6__["NewRequisitionPage"]]
    })], NewRequisitionPageModule);
    /***/
  },

  /***/
  "./src/app/requisitions/new-requisition/new-requisition.page.scss":
  /*!************************************************************************!*\
    !*** ./src/app/requisitions/new-requisition/new-requisition.page.scss ***!
    \************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppRequisitionsNewRequisitionNewRequisitionPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3JlcXVpc2l0aW9ucy9uZXctcmVxdWlzaXRpb24vbmV3LXJlcXVpc2l0aW9uLnBhZ2Uuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/requisitions/new-requisition/new-requisition.page.ts":
  /*!**********************************************************************!*\
    !*** ./src/app/requisitions/new-requisition/new-requisition.page.ts ***!
    \**********************************************************************/

  /*! exports provided: NewRequisitionPage */

  /***/
  function srcAppRequisitionsNewRequisitionNewRequisitionPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NewRequisitionPage", function () {
      return NewRequisitionPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _requisition_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../requisition.model */
    "./src/app/requisitions/requisition.model.ts");
    /* harmony import */


    var _requisition_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../requisition.service */
    "./src/app/requisitions/requisition.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! src/app/auth/auth-service */
    "./src/app/auth/auth-service.ts");

    var NewRequisitionPage = /*#__PURE__*/function () {
      function NewRequisitionPage(popoverCtrl, requisitionService, toastCtrl, alertCtrl, router, authService) {
        _classCallCheck(this, NewRequisitionPage);

        this.popoverCtrl = popoverCtrl;
        this.requisitionService = requisitionService;
        this.toastCtrl = toastCtrl;
        this.alertCtrl = alertCtrl;
        this.router = router;
        this.authService = authService;
        this.requisition = new _requisition_model__WEBPACK_IMPORTED_MODULE_3__["Requisition"]();
      }

      _createClass(NewRequisitionPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.popoverCtrl.dismiss();
          this.fetchLocations();
          this.setUser();
        }
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.setUser();
          this.userID = this.user.User_ID;
        }
      }, {
        key: "ionViewDidEnter",
        value: function ionViewDidEnter() {
          this.setUser();
          this.userID = this.user.User_ID;
          this.Requisition();
        }
      }, {
        key: "setUser",
        value: function setUser() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.authService.getUser();

                  case 2:
                    this.user = _context.sent;

                  case 3:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "Requisition",
        value: function Requisition() {
          var _this = this;

          this.requisitionSub = this.requisitionService.createRequisition(this.userID).subscribe(function (result) {
            Object.assign(_this.requisition, result); //this.requisition.In_Transit_Code = 'IN-TRANSIT';
          });
        }
      }, {
        key: "onRequisitionupdate",
        value: function onRequisitionupdate(form) {
          var _this2 = this;

          this.requisitionPostSub = this.requisitionService.postRequisition(this.requisition).subscribe(function (res) {
            if (typeof res !== 'string') {
              // Show a Toast Notification
              _this2.toastCtrl.create({
                message: "".concat(res.Req_No, " Requisition Added Successfully."),
                duration: 2000,
                position: 'top'
              }).then(function (toastData) {
                toastData.present();

                _this2.router.navigate(['/', 'requisitions', res.Req_No]);
              });
            } else {
              _this2.alertCtrl.create({
                header: 'Operation Error',
                message: 'Message : ' + res,
                buttons: [{
                  text: 'Okay'
                }]
              }).then(function (alertEl) {
                alertEl.present();
              });
            }
          }, function (error) {
            console.log(error.error);

            _this2.alertCtrl.create({
              header: 'Service Error!',
              message: 'Connection problem: ' + error,
              buttons: [{
                text: 'Okay'
              }]
            }).then(function (alertEl) {
              alertEl.present();
            });
          });
        }
      }, {
        key: "fetchLocations",
        value: function fetchLocations() {
          var _this3 = this;

          this.locationSub = this.requisitionService.getLocations().subscribe(function (res) {
            console.log('Locations');
            console.log(res);
            _this3.locations = res;
          });
        }
      }, {
        key: "fetchDimensions",
        value: function fetchDimensions() {
          var _this4 = this;

          this.dimensionSub = this.requisitionService.Dimensions.subscribe(function (dim) {
            console.log('dimensions');
            console.log(dim);
            _this4.dimensions = dim;
          });
        }
      }, {
        key: "fetchDepartments",
        value: function fetchDepartments() {
          var _this5 = this;

          this.dimensionSub = this.requisitionService.Departments.subscribe(function (dim) {
            console.log('Department');
            console.log(dim);
            _this5.departments = dim;
          });
        }
      }, {
        key: "fetchProjects",
        value: function fetchProjects() {
          var _this6 = this;

          this.dimensionSub = this.requisitionService.Projects.subscribe(function (dim) {
            console.log('Projects');
            console.log(dim);
            _this6.projects = dim;
          });
        }
      }]);

      return NewRequisitionPage;
    }();

    NewRequisitionPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PopoverController"]
      }, {
        type: _requisition_service__WEBPACK_IMPORTED_MODULE_4__["RequisitionService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]
      }, {
        type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_6__["AuthService"]
      }];
    };

    NewRequisitionPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-new-requisition',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./new-requisition.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/requisitions/new-requisition/new-requisition.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./new-requisition.page.scss */
      "./src/app/requisitions/new-requisition/new-requisition.page.scss"))["default"]]
    })], NewRequisitionPage);
    /***/
  },

  /***/
  "./src/app/requisitions/requisition.model.ts":
  /*!***************************************************!*\
    !*** ./src/app/requisitions/requisition.model.ts ***!
    \***************************************************/

  /*! exports provided: Requisition */

  /***/
  function srcAppRequisitionsRequisitionModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Requisition", function () {
      return Requisition;
    });

    var Requisition = function Requisition(Key, Req_No, Requisition_Date, Requested_By, Requested_On, Store_Code, Store_Name, Approval_Status, Point_Of_Sale_Request_Lines) {
      _classCallCheck(this, Requisition);

      this.Key = Key;
      this.Req_No = Req_No;
      this.Requisition_Date = Requisition_Date;
      this.Requested_By = Requested_By;
      this.Requested_On = Requested_On;
      this.Store_Code = Store_Code;
      this.Store_Name = Store_Name;
      this.Approval_Status = Approval_Status;
      this.Point_Of_Sale_Request_Lines = Point_Of_Sale_Request_Lines;
    };
    /***/

  }
}]);
//# sourceMappingURL=default~new-requisition-new-requisition-module~requisitions-new-requisition-new-requisition-module-es5.js.map