(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["orders-orders-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/orders/orders.page.html":
/*!*******************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/orders/orders.page.html ***!
  \*******************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <ion-title>Sales Invoices</ion-title>\r\n    <ion-buttons slot=\"end\">      \r\n      <ion-button slot=\"icon-only\" fill=\"clear\" (click)=\"presentPopover($event)\">\r\n        <ion-icon  name=\"ellipsis-vertical-outline\"></ion-icon>\r\n      </ion-button>      \r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <div *ngIf=\"isLoading\" class=\"ion-text-center\">\r\n    <ion-spinner  name=\"crescent\"></ion-spinner>\r\n  </div>\r\n\r\n<ion-searchbar [(ngModel)]=\"searchTerm\" debounce=\"2000\" (ionChange)=\"searchInvoice($event)\"></ion-searchbar>\r\n<ion-grid fixed>\r\n  <ion-row>\r\n    <ion-col col-12 col-sm>Order No.</ion-col>\r\n    <ion-col col-12 col-sm>Customer </ion-col>\r\n    <ion-col col-12 col-sm>Ship To</ion-col>\r\n    <ion-col col-12 col-sm>Amount</ion-col>\r\n    <ion-col col-12 col-sm>Status</ion-col>\r\n  </ion-row>\r\n</ion-grid>\r\n\r\n<ion-virtual-scroll [items]=\"orders\" approxItemHeight=\"47.2px\">\r\n               \r\n  <ion-item \r\n    [routerLink] = \"['/','orders',order.No]\"\r\n   detail\r\n   *virtualItem=\"let order\" > \r\n\r\n   <ion-grid >\r\n      <ion-row>\r\n\r\n        <ion-col col-12 col-sm>\r\n          <ion-label>\r\n            <h3>{{ order?.No }}</h3>\r\n          </ion-label>\r\n        </ion-col>\r\n\r\n        <ion-col col-12 col-sm>\r\n          <ion-label>\r\n            <h3>{{ order?.Sell_to_Customer_Name }}</h3>\r\n          </ion-label>\r\n        </ion-col>\r\n\r\n        <ion-col col-12 col-sm>\r\n          <ion-label>\r\n            <h3>{{ order.Ship_to_Name }}</h3>\r\n          </ion-label>\r\n        </ion-col>\r\n\r\n        <ion-col col-12 col-sm>\r\n          <ion-label>\r\n            <h3>{{ order.Prices_Including_VAT}}</h3>\r\n          </ion-label>\r\n        </ion-col>\r\n\r\n        <ion-col col-12 col-sm >\r\n          <ion-label>\r\n            <h3>{{ order.Status}}</h3>\r\n          </ion-label>\r\n        </ion-col>\r\n\r\n      </ion-row>\r\n    </ion-grid>\r\n          \r\n</ion-item>\r\n\r\n</ion-virtual-scroll>\r\n\r\n\r\n\r\n  \r\n\r\n \r\n\r\n \r\n</ion-content>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/orders/popover/popover.component.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/orders/popover/popover.component.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-list>\r\n  <ion-item lines=\"none\" [routerLink]=\"['orders','new-order']\">\r\n    <ion-icon slot=\"start\" name=\"add-circle-sharp\"></ion-icon>\r\n    <ion-label>Raise Invoice</ion-label>\r\n  </ion-item>\r\n  \r\n</ion-list>");

/***/ }),

/***/ "./src/app/items/item.service.ts":
/*!***************************************!*\
  !*** ./src/app/items/item.service.ts ***!
  \***************************************/
/*! exports provided: ItemService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ItemService", function() { return ItemService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");






let ItemService = class ItemService {
    constructor(http, toastCtrl) {
        this.http = http;
        this.toastCtrl = toastCtrl;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
    }
    get items() {
        return this.http.get(`${this.url}site/items`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    itemcard(id) {
        return this.http.get(`${this.url}site/itemcard/?id=${id}`);
    }
    itemBalance(No) {
        return this.http.get(`${this.url}site/itemavailabilitybylocation/?No=${No}`);
    }
    itemBalanceByLocation(No, LocationCode) {
        return this.http.get(`${this.url}site/itemavailabilitybylocation/?No=${No}&Location=${LocationCode}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    getTotals(elements, subjectColumn) {
        let sum = 0;
        elements.forEach(obj => {
            // console.log(obj);
            for (const property in obj) {
                if (property === subjectColumn && !isNaN(+obj[property])) {
                    // console.log(+obj[property]);
                    sum += +obj[property];
                }
            }
        });
        return sum;
    }
    // Get Locations List
    getLocations() {
        return this.http.get(`${this.url}site/locationlist`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    showToast(text) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return yield this.toastCtrl.create({
                message: text,
                duration: 4000,
                position: 'top'
            }).then(toastEl => {
                toastEl.present();
            });
        });
    }
};
ItemService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"] }
];
ItemService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], ItemService);



/***/ }),

/***/ "./src/app/orders/orders-routing.module.ts":
/*!*************************************************!*\
  !*** ./src/app/orders/orders-routing.module.ts ***!
  \*************************************************/
/*! exports provided: OrdersPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrdersPageRoutingModule", function() { return OrdersPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _orders_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./orders.page */ "./src/app/orders/orders.page.ts");




const routes = [
    {
        path: '',
        component: _orders_page__WEBPACK_IMPORTED_MODULE_3__["OrdersPage"]
    },
    {
        path: 'new-order',
        loadChildren: () => __webpack_require__.e(/*! import() | new-order-new-order-module */ "default~new-order-new-order-module~orders-new-order-new-order-module").then(__webpack_require__.bind(null, /*! ./new-order/new-order.module */ "./src/app/orders/new-order/new-order.module.ts")).then(m => m.NewOrderPageModule)
    },
];
let OrdersPageRoutingModule = class OrdersPageRoutingModule {
};
OrdersPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], OrdersPageRoutingModule);



/***/ }),

/***/ "./src/app/orders/orders.module.ts":
/*!*****************************************!*\
  !*** ./src/app/orders/orders.module.ts ***!
  \*****************************************/
/*! exports provided: OrdersPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrdersPageModule", function() { return OrdersPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _orders_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./orders-routing.module */ "./src/app/orders/orders-routing.module.ts");
/* harmony import */ var _orders_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./orders.page */ "./src/app/orders/orders.page.ts");
/* harmony import */ var _popover_popover_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./popover/popover.component */ "./src/app/orders/popover/popover.component.ts");
/* harmony import */ var _lines_lines_component__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./lines/lines.component */ "./src/app/orders/lines/lines.component.ts");









let OrdersPageModule = class OrdersPageModule {
};
OrdersPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _orders_routing_module__WEBPACK_IMPORTED_MODULE_5__["OrdersPageRoutingModule"]
        ],
        entryComponents: [_popover_popover_component__WEBPACK_IMPORTED_MODULE_7__["PopoverComponent"], _lines_lines_component__WEBPACK_IMPORTED_MODULE_8__["LinesComponent"]],
        declarations: [_orders_page__WEBPACK_IMPORTED_MODULE_6__["OrdersPage"], _popover_popover_component__WEBPACK_IMPORTED_MODULE_7__["PopoverComponent"], _lines_lines_component__WEBPACK_IMPORTED_MODULE_8__["LinesComponent"]]
    })
], OrdersPageModule);



/***/ }),

/***/ "./src/app/orders/orders.page.scss":
/*!*****************************************!*\
  !*** ./src/app/orders/orders.page.scss ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL29yZGVycy9vcmRlcnMucGFnZS5zY3NzIn0= */");

/***/ }),

/***/ "./src/app/orders/orders.page.ts":
/*!***************************************!*\
  !*** ./src/app/orders/orders.page.ts ***!
  \***************************************/
/*! exports provided: OrdersPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrdersPage", function() { return OrdersPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _order_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./order.service */ "./src/app/orders/order.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _popover_popover_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./popover/popover.component */ "./src/app/orders/popover/popover.component.ts");





let OrdersPage = class OrdersPage {
    constructor(orderService, popoverCtrl, alertCtrl) {
        this.orderService = orderService;
        this.popoverCtrl = popoverCtrl;
        this.alertCtrl = alertCtrl;
        this.isLoading = false;
        this.searchTerm = null;
    }
    ngOnInit() {
        this.isLoading = true;
        this.orderSub = this.orderService.orders.subscribe(result => {
            console.log(result);
            this.orders = [...result];
            this.isLoading = false;
        }, error => {
            console.log(error.error);
            this.alertCtrl.create({
                header: 'Service Error!',
                message: 'Connection problem: ' + error.error.message,
                buttons: [{ text: 'Okay' }]
            }).then(alertEl => {
                alertEl.present();
            });
        });
    }
    ionViewWillEnter() {
    }
    presentPopover(event) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return yield this.popoverCtrl.create({
                component: _popover_popover_component__WEBPACK_IMPORTED_MODULE_4__["PopoverComponent"],
                event
            }).then(pop => {
                pop.present();
            });
        });
    }
    searchInvoice($event) {
        const searchItems = [...this.orders];
        // Begin search only if searchTerm is provided
        if (this.searchTerm.trim().length && this.searchTerm !== '') {
            this.orders = searchItems.filter((invoice) => {
                if (invoice.Sell_to_Customer_Name && invoice.Sell_to_Customer_Name.length > 1) {
                    return (invoice.Sell_to_Customer_Name.toLowerCase().indexOf(this.searchTerm.toLowerCase()) > -1);
                }
            });
            return;
        }
        else { // Search Term not provide display all items
            this.initializeItems();
        }
    }
    initializeItems() {
        this.orderSub = this.orderService.orders.subscribe(result => {
            console.log(result);
            this.orders = [...result];
            this.isLoading = false;
        }, error => {
            console.log(error.error);
            this.alertCtrl.create({
                header: 'Service Error!',
                message: 'Connection problem: ' + error.error.message,
                buttons: [{ text: 'Okay' }]
            }).then(alertEl => {
                alertEl.present();
            });
        });
    }
    ngOnDestroy() {
        if (this.orderSub) {
            this.orderSub.unsubscribe();
        }
    }
};
OrdersPage.ctorParameters = () => [
    { type: _order_service__WEBPACK_IMPORTED_MODULE_2__["OrderService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["PopoverController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] }
];
OrdersPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-orders',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./orders.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/orders/orders.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./orders.page.scss */ "./src/app/orders/orders.page.scss")).default]
    })
], OrdersPage);



/***/ }),

/***/ "./src/app/orders/popover/popover.component.scss":
/*!*******************************************************!*\
  !*** ./src/app/orders/popover/popover.component.scss ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL29yZGVycy9wb3BvdmVyL3BvcG92ZXIuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/orders/popover/popover.component.ts":
/*!*****************************************************!*\
  !*** ./src/app/orders/popover/popover.component.ts ***!
  \*****************************************************/
/*! exports provided: PopoverComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PopoverComponent", function() { return PopoverComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");


let PopoverComponent = class PopoverComponent {
    constructor() { }
    ngOnInit() { }
};
PopoverComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-popover',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./popover.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/orders/popover/popover.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./popover.component.scss */ "./src/app/orders/popover/popover.component.scss")).default]
    })
], PopoverComponent);



/***/ })

}]);
//# sourceMappingURL=orders-orders-module-es2015.js.map