function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["cash-deposit-cash-deposit-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/cash-deposit/cash-deposit.page.html":
  /*!*******************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/cash-deposit/cash-deposit.page.html ***!
    \*******************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppCashDepositCashDepositPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n      <ion-title>Cash Deposit List</ion-title>\r\n      <ion-buttons slot=\"end\">\r\n        <ion-button slot=\"icon-only\" fill=\"clear\" (click)=\"onAddDeposit()\">\r\n          <ion-icon name=\"add\"></ion-icon>\r\n        </ion-button>\r\n      </ion-buttons>\r\n\r\n    </ion-toolbar>\r\n</ion-header>\r\n\r\n<div *ngIf=\"isLoading\" class=\"ion-text-center\">\r\n  <ion-spinner name=\"crescent\"></ion-spinner>\r\n</div>\r\n<ion-content *ngIf=\"!isLoading\">\r\n  \r\n  <ion-searchbar [(ngModel)]=\"searchTerm\" debounce=\"2000\" (ionChange)=\"searchPayment($event)\"></ion-searchbar>\r\n  <ion-grid fixed>\r\n    <ion-row>\r\n      <ion-col col-4 col-sm>No.</ion-col>\r\n      <ion-col col-4 col-sm>Posting Date</ion-col>\r\n      <ion-col col-4 col-sm>Creator</ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n  \r\n  <ion-virtual-scroll *ngIf=\"!isLoading\" [items]=\"depositsList\" approxItemHeight=\"47.2px\">\r\n  \r\n    <ion-item [routerLink]=\"['/','cash-deposit', payment.Key ]\" detail *virtualItem=\"let payment\">\r\n  \r\n      <ion-grid>\r\n        <ion-row>\r\n  \r\n          <ion-col col-4 col-sm>\r\n            <ion-label>\r\n              <h3>{{ payment?.No }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n  \r\n          <ion-col col-4 col-sm>\r\n            <ion-label>\r\n              <h3>{{ payment?.Posting_Date }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n  \r\n          <ion-col col-6 col-sm>\r\n            <ion-label>\r\n              <h3>{{ payment.Created_By}}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n  \r\n        </ion-row>\r\n      </ion-grid>\r\n  \r\n    </ion-item>\r\n  \r\n  </ion-virtual-scroll>\r\n\r\n</ion-content>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/cash-deposit/new-deposit/new-deposit.component.html":
  /*!***********************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/cash-deposit/new-deposit/new-deposit.component.html ***!
    \***********************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppCashDepositNewDepositNewDepositComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>New Cash Deposit</ion-title>\r\n\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button (click)=\"onCancel()\">\r\n        <ion-icon name=\"close\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content *ngIf=\"cashDeposit.Key\">\r\n  <ion-grid>\r\n    <ion-row>\r\n      <ion-col>\r\n        <ion-card>\r\n          <ion-card-header>\r\n            <ion-card-title>\r\n              Cash Deposit Card\r\n            </ion-card-title>\r\n          </ion-card-header>\r\n\r\n          <ion-card-content>\r\n\r\n            <ion-fab vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\">\r\n              <ion-fab-button color=\"warning\" (click)=\"post(cashDeposit.No)\">\r\n                <ion-icon name=\"send\"></ion-icon>\r\n              </ion-fab-button>\r\n            </ion-fab>\r\n\r\n            <ion-row>\r\n              <ion-col>\r\n                <ion-item>\r\n                  <ion-label position=\"floating\">No.</ion-label>\r\n                  <ion-input [(ngModel)]=\"cashDeposit.No\"></ion-input>\r\n                </ion-item>\r\n              </ion-col>\r\n\r\n              <ion-col>\r\n                <ion-item>\r\n                  <ion-label position=\"floating\">Reference</ion-label>\r\n                  <ion-input [(ngModel)]=\"cashDeposit.Reference\" (ionBlur)=\"onUpdateDocument()\" placeholder=\"Add Transaction Reference\">\r\n                  </ion-input>\r\n                </ion-item>\r\n              </ion-col>\r\n            </ion-row>\r\n\r\n\r\n            <ion-row>\r\n              <ion-col>\r\n                <ion-item>\r\n                  <ion-label position=\"floating\">Posting Date: </ion-label>\r\n                  <ion-input [(ngModel)]=\"cashDeposit.Posting_Date\"></ion-input>\r\n                </ion-item>\r\n              </ion-col>\r\n\r\n              <ion-col>\r\n                <ion-item>\r\n                  <ion-label position=\"floating\">Amount:</ion-label>\r\n                  <ion-input [(ngModel)]=\"cashDeposit.Amount\" readonly></ion-input>\r\n                </ion-item>\r\n              </ion-col>\r\n            </ion-row>\r\n\r\n\r\n            <ion-row>\r\n              <ion-col>\r\n                <ion-item>\r\n                  <ion-label position=\"floating\">Created By</ion-label>\r\n                  <ion-input [(ngModel)]=\"cashDeposit.Created_By\"></ion-input>\r\n                </ion-item>\r\n              </ion-col>\r\n\r\n              <ion-col>\r\n\r\n              </ion-col>\r\n\r\n            </ion-row>\r\n\r\n\r\n\r\n          </ion-card-content>\r\n\r\n        </ion-card>\r\n\r\n\r\n        <!--Start Lines Card-->\r\n        <ion-card>\r\n          <ion-card-header>\r\n            <ion-card-title>Invoice Lines</ion-card-title>\r\n          </ion-card-header>\r\n          <ion-card-content>\r\n            <ion-grid>\r\n\r\n\r\n\r\n              <ion-row scrollX=\"true\">\r\n                <ion-col>\r\n                  <ion-label>Customer</ion-label>\r\n                </ion-col>\r\n\r\n                <ion-col>\r\n                  <ion-label>Amount</ion-label>\r\n                </ion-col>\r\n\r\n                <ion-col>\r\n                  <ion-label>Select</ion-label>\r\n                </ion-col>\r\n\r\n              </ion-row>\r\n\r\n\r\n\r\n              <ion-list *ngFor=\"let ln of cashDeposit?.Cash_Deposit_Lines?.Cash_Deposit_Lines\">\r\n                <ion-row>\r\n\r\n                  <ion-col>\r\n                    <ion-item>\r\n                      <ion-label>{{ln.Customer_Name }}</ion-label>\r\n                    </ion-item>\r\n                  </ion-col>\r\n\r\n                  <ion-col>\r\n                    <ion-item>\r\n                      <ion-label>{{ln.Amount | currency: 'Ksh.'}}</ion-label>\r\n                    </ion-item>\r\n                  </ion-col>\r\n\r\n                  <ion-col>\r\n                    <ion-item>\r\n                      <input type=\"checkbox\" [value]=\"ln.Select\" (click)=\"onUpdateLine(ln.Key)\" />\r\n                    </ion-item>\r\n                  </ion-col>\r\n\r\n\r\n                </ion-row>\r\n              </ion-list>\r\n\r\n\r\n            </ion-grid>\r\n          </ion-card-content>\r\n        </ion-card>\r\n        <!--End Lines Card-->\r\n\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/cash-deposit/cash-deposit-routing.module.ts":
  /*!*************************************************************!*\
    !*** ./src/app/cash-deposit/cash-deposit-routing.module.ts ***!
    \*************************************************************/

  /*! exports provided: CashDepositPageRoutingModule */

  /***/
  function srcAppCashDepositCashDepositRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CashDepositPageRoutingModule", function () {
      return CashDepositPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _cash_deposit_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./cash-deposit.page */
    "./src/app/cash-deposit/cash-deposit.page.ts");

    var routes = [{
      path: '',
      component: _cash_deposit_page__WEBPACK_IMPORTED_MODULE_3__["CashDepositPage"]
    }, {
      path: 'cash-deposit-detail',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | cash-deposit-detail-cash-deposit-detail-module */
        "common").then(__webpack_require__.bind(null,
        /*! ./cash-deposit-detail/cash-deposit-detail.module */
        "./src/app/cash-deposit/cash-deposit-detail/cash-deposit-detail.module.ts")).then(function (m) {
          return m.CashDepositDetailPageModule;
        });
      }
    }];

    var CashDepositPageRoutingModule = function CashDepositPageRoutingModule() {
      _classCallCheck(this, CashDepositPageRoutingModule);
    };

    CashDepositPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], CashDepositPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/cash-deposit/cash-deposit.module.ts":
  /*!*****************************************************!*\
    !*** ./src/app/cash-deposit/cash-deposit.module.ts ***!
    \*****************************************************/

  /*! exports provided: CashDepositPageModule */

  /***/
  function srcAppCashDepositCashDepositModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CashDepositPageModule", function () {
      return CashDepositPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _cash_deposit_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./cash-deposit-routing.module */
    "./src/app/cash-deposit/cash-deposit-routing.module.ts");
    /* harmony import */


    var _cash_deposit_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./cash-deposit.page */
    "./src/app/cash-deposit/cash-deposit.page.ts");
    /* harmony import */


    var _new_deposit_new_deposit_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./new-deposit/new-deposit.component */
    "./src/app/cash-deposit/new-deposit/new-deposit.component.ts");

    var CashDepositPageModule = function CashDepositPageModule() {
      _classCallCheck(this, CashDepositPageModule);
    };

    CashDepositPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _cash_deposit_routing_module__WEBPACK_IMPORTED_MODULE_5__["CashDepositPageRoutingModule"]],
      entryComponents: [_new_deposit_new_deposit_component__WEBPACK_IMPORTED_MODULE_7__["NewDepositComponent"]],
      declarations: [_cash_deposit_page__WEBPACK_IMPORTED_MODULE_6__["CashDepositPage"], _new_deposit_new_deposit_component__WEBPACK_IMPORTED_MODULE_7__["NewDepositComponent"]]
    })], CashDepositPageModule);
    /***/
  },

  /***/
  "./src/app/cash-deposit/cash-deposit.page.scss":
  /*!*****************************************************!*\
    !*** ./src/app/cash-deposit/cash-deposit.page.scss ***!
    \*****************************************************/

  /*! exports provided: default */

  /***/
  function srcAppCashDepositCashDepositPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2Nhc2gtZGVwb3NpdC9jYXNoLWRlcG9zaXQucGFnZS5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/cash-deposit/cash-deposit.page.ts":
  /*!***************************************************!*\
    !*** ./src/app/cash-deposit/cash-deposit.page.ts ***!
    \***************************************************/

  /*! exports provided: CashDepositPage */

  /***/
  function srcAppCashDepositCashDepositPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CashDepositPage", function () {
      return CashDepositPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _auth_auth_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../auth/auth-service */
    "./src/app/auth/auth-service.ts");
    /* harmony import */


    var _models_cashdeposit_model__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../models/cashdeposit.model */
    "./src/app/models/cashdeposit.model.ts");
    /* harmony import */


    var _models_cashdepositheader_model__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../models/cashdepositheader.model */
    "./src/app/models/cashdepositheader.model.ts");
    /* harmony import */


    var _utility_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ../utility.service */
    "./src/app/utility.service.ts");
    /* harmony import */


    var _cash_deposit_service__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ./cash-deposit.service */
    "./src/app/cash-deposit/cash-deposit.service.ts");
    /* harmony import */


    var _new_deposit_new_deposit_component__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! ./new-deposit/new-deposit.component */
    "./src/app/cash-deposit/new-deposit/new-deposit.component.ts");

    var CashDepositPage = /*#__PURE__*/function () {
      function CashDepositPage(authService, depositSvc, utilitySvc, modalCtrl, popoverCtrl) {
        _classCallCheck(this, CashDepositPage);

        this.authService = authService;
        this.depositSvc = depositSvc;
        this.utilitySvc = utilitySvc;
        this.modalCtrl = modalCtrl;
        this.popoverCtrl = popoverCtrl;
        this.isLoading = true;
        this.searchTerm = null;
        this.cashDeposit = new _models_cashdeposit_model__WEBPACK_IMPORTED_MODULE_6__["Cashdeposit"]();
        this.cashDepositHeader = new _models_cashdepositheader_model__WEBPACK_IMPORTED_MODULE_7__["Cashdepositheader"]();
        this.documentNo$ = new rxjs__WEBPACK_IMPORTED_MODULE_3__["Subject"]();
      }

      _createClass(CashDepositPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.setUser();
          this.popoverCtrl.dismiss();
        }
      }, {
        key: "getDocumentNo$",
        value: function getDocumentNo$() {
          return this.documentNo$;
        }
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.setUser();
          console.log('Will Enter');
          this.FetchDeposits;
        }
      }, {
        key: "ionViewDidEnter",
        value: function ionViewDidEnter() {
          this.setUser();
          console.table(this.user);
          console.log('Did Enter');
          this.FetchDeposits();
        }
      }, {
        key: "setUser",
        value: function setUser() {
          var _a;

          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.authService.getUser();

                  case 2:
                    this.user = _context.sent;
                    this.userID = (_a = this.user) === null || _a === void 0 ? void 0 : _a.User_ID;

                  case 4:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "FetchDeposits",
        value: function FetchDeposits() {
          var _this = this;

          this.depositSub = this.depositSvc.getCashdeposits(this.userID).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["finalize"])(function () {
            _this.isLoading = false;
          })).subscribe(function (result) {
            _this.depositsList = _this.sort(_toConsumableArray(result));
          }, function (error) {
            console.log(error.error);

            _this.utilitySvc.showAlert(error.error.message);
          });
        }
      }, {
        key: "FetchCard",
        value: function FetchCard(No) {
          var _this2 = this;

          this.cardSub = this.depositSvc.getCardByNo(No).subscribe(function (result) {
            console.log("Getting payload.....................");
            console.table(result);
            _this2.cashDeposit = result;

            _this2.documentNo$.next(result.Key);
          });
        }
      }, {
        key: "sort",
        value: function sort(dataArray) {
          return dataArray.sort(function (a, b) {
            return b.No > a.No ? 1 : -1;
          });
        }
      }, {
        key: "initialRequest",
        value: function initialRequest() {
          var _this3 = this;

          if (this.userID.length) {
            this.utilitySvc.presentLoading('Initializing Cash Deposit');
            this.cashDepositSub = this.depositSvc.newDeposit(this.userID).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["finalize"])(function () {
              _this3.utilitySvc.loadingCtrl.dismiss();
            })).subscribe(function (res) {
              console.log("Initialize Cash Deposit");

              if (typeof res === 'string') {
                _this3.utilitySvc.showAlert(res);

                return;
              } // FETCH THE DAMN cashCard


              _this3.FetchCard(res);
            }, function (error) {
              _this3.utilitySvc.showAlert(error.error.message);
            });
          }
        }
      }, {
        key: "onAddDeposit",
        value: function onAddDeposit() {
          var _this4 = this;

          // Pull up the modal and populate the CashDeposit MODEL with initial ERP data
          this.initialRequest();
          this.getDocumentNo$().subscribe(function (res) {
            if (res) {
              _this4.modalCtrl.create({
                component: _new_deposit_new_deposit_component__WEBPACK_IMPORTED_MODULE_10__["NewDepositComponent"],
                componentProps: {
                  cashDepo: _this4.cashDeposit
                }
              }).then(function (modalEl) {
                modalEl.present();
              });
            }
          });
        }
      }, {
        key: "searchPayment",
        value: function searchPayment($event) {
          var _this5 = this;

          var searchItems = _toConsumableArray(this.depositsList); // Begin search only if searchTerm is provided


          if (this.searchTerm.trim().length && this.searchTerm !== '') {
            this.depositsList = searchItems.filter(function (payment) {
              if (payment.No && payment.No.length > 1) {
                return payment.No.toLowerCase().indexOf(_this5.searchTerm.toLowerCase()) > -1;
              }
            });
            return;
          } else {
            // Search Term not provide display all items
            this.FetchDeposits();
          }
        }
      }]);

      return CashDepositPage;
    }();

    CashDepositPage.ctorParameters = function () {
      return [{
        type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_5__["AuthService"]
      }, {
        type: _cash_deposit_service__WEBPACK_IMPORTED_MODULE_9__["CashDepositService"]
      }, {
        type: _utility_service__WEBPACK_IMPORTED_MODULE_8__["UtilityService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PopoverController"]
      }];
    };

    CashDepositPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-cash-deposit',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./cash-deposit.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/cash-deposit/cash-deposit.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./cash-deposit.page.scss */
      "./src/app/cash-deposit/cash-deposit.page.scss"))["default"]]
    })], CashDepositPage);
    /***/
  },

  /***/
  "./src/app/cash-deposit/new-deposit/new-deposit.component.scss":
  /*!*********************************************************************!*\
    !*** ./src/app/cash-deposit/new-deposit/new-deposit.component.scss ***!
    \*********************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppCashDepositNewDepositNewDepositComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2Nhc2gtZGVwb3NpdC9uZXctZGVwb3NpdC9uZXctZGVwb3NpdC5jb21wb25lbnQuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/cash-deposit/new-deposit/new-deposit.component.ts":
  /*!*******************************************************************!*\
    !*** ./src/app/cash-deposit/new-deposit/new-deposit.component.ts ***!
    \*******************************************************************/

  /*! exports provided: NewDepositComponent */

  /***/
  function srcAppCashDepositNewDepositNewDepositComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NewDepositComponent", function () {
      return NewDepositComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var src_app_models_cashdeposit_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/models/cashdeposit.model */
    "./src/app/models/cashdeposit.model.ts");
    /* harmony import */


    var src_app_models_cashdepositline_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/models/cashdepositline.model */
    "./src/app/models/cashdepositline.model.ts");
    /* harmony import */


    var src_app_utility_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/utility.service */
    "./src/app/utility.service.ts");
    /* harmony import */


    var _cash_deposit_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../cash-deposit.service */
    "./src/app/cash-deposit/cash-deposit.service.ts");

    var NewDepositComponent = /*#__PURE__*/function () {
      function NewDepositComponent(depositSvc, utilitySvc, modalCtrl) {
        _classCallCheck(this, NewDepositComponent);

        this.depositSvc = depositSvc;
        this.utilitySvc = utilitySvc;
        this.modalCtrl = modalCtrl;
        this.cashDeposit = new src_app_models_cashdeposit_model__WEBPACK_IMPORTED_MODULE_3__["Cashdeposit"]();
        this.line = new src_app_models_cashdepositline_model__WEBPACK_IMPORTED_MODULE_4__["Cashdepositline"]();
      }

      _createClass(NewDepositComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          // console.log(`Cash Deposit State passed to component:`);
          // console.table(this.cashDepo);
          Object.assign(this.cashDeposit, this.cashDepo); // check if lines have changed and update card accordingly

          this.depositSvc.lineRefresh$.subscribe(function (res) {
            console.log("Updated Line.......");
            console.log(res);
          });
        }
      }, {
        key: "onUpdateDocument",
        value: function onUpdateDocument() {
          var _this6 = this;

          this.updateSub = this.depositSvc.updateDeposit(this.cashDeposit).subscribe(function (res) {
            if (typeof res === 'string') {
              _this6.utilitySvc.showAlert(res);

              return false;
            } else if (typeof res === 'object') {
              Object.assign(_this6.cashDeposit, res);

              _this6.utilitySvc.showToast('Cash Deposit Card Updated Successfully.');
            }
          }, function (error) {
            _this6.utilitySvc.showAlert(error.error.message);
          });
        }
      }, {
        key: "onUpdateLine",
        value: function onUpdateLine(Key) {
          var _this7 = this;

          this.lineSub = this.depositSvc.getLine(Key).subscribe(function (line) {
            if (line) {
              _this7.line = line;
              _this7.line.Select = !(line === null || line === void 0 ? void 0 : line.Select);

              _this7.updateLine(line);
            }
          });
        }
      }, {
        key: "updateLine",
        value: function updateLine(line) {
          var _this8 = this;

          this.updateLineSub = this.depositSvc.updateLine(line).subscribe(function (res) {
            if (typeof res === 'string') {
              _this8.utilitySvc.showAlert(res);

              return false;
            } else if (typeof res === 'object') {
              Object.assign(_this8.cashDeposit, res);

              _this8.utilitySvc.showToast('Cash Deposit Line Updated Successfully.');
            }
          }, function (error) {
            _this8.utilitySvc.showAlert(error);
          });
        }
      }, {
        key: "onCancel",
        value: function onCancel() {
          this.modalCtrl.dismiss();
        }
      }, {
        key: "post",
        value: function post(No) {
          var _this9 = this;

          this.postSub = this.depositSvc.postDocument(No).subscribe(function (res) {
            console.log("Posting Results");
            console.log(res);

            if (typeof res === 'string') {
              _this9.utilitySvc.showAlert(res);
            } else {
              _this9.utilitySvc.showToast("Document Posted Successfully.");
            }
          }, function (error) {
            _this9.utilitySvc.showAlert(error);
          });
        }
      }]);

      return NewDepositComponent;
    }();

    NewDepositComponent.ctorParameters = function () {
      return [{
        type: _cash_deposit_service__WEBPACK_IMPORTED_MODULE_6__["CashDepositService"]
      }, {
        type: src_app_utility_service__WEBPACK_IMPORTED_MODULE_5__["UtilityService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
      }];
    };

    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], NewDepositComponent.prototype, "cashDepo", void 0);
    NewDepositComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-new-deposit',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./new-deposit.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/cash-deposit/new-deposit/new-deposit.component.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./new-deposit.component.scss */
      "./src/app/cash-deposit/new-deposit/new-deposit.component.scss"))["default"]]
    })], NewDepositComponent);
    /***/
  },

  /***/
  "./src/app/models/cashdeposit.model.ts":
  /*!*********************************************!*\
    !*** ./src/app/models/cashdeposit.model.ts ***!
    \*********************************************/

  /*! exports provided: Cashdeposit */

  /***/
  function srcAppModelsCashdepositModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Cashdeposit", function () {
      return Cashdeposit;
    });

    var Cashdeposit = function Cashdeposit(Key, No, Posting_Date, Reference, Created_By, Amount, Cash_Deposit_Lines) {
      _classCallCheck(this, Cashdeposit);

      this.Key = Key;
      this.No = No;
      this.Posting_Date = Posting_Date;
      this.Reference = Reference;
      this.Created_By = Created_By;
      this.Amount = Amount;
      this.Cash_Deposit_Lines = Cash_Deposit_Lines;
    };
    /***/

  },

  /***/
  "./src/app/models/cashdepositheader.model.ts":
  /*!***************************************************!*\
    !*** ./src/app/models/cashdepositheader.model.ts ***!
    \***************************************************/

  /*! exports provided: Cashdepositheader */

  /***/
  function srcAppModelsCashdepositheaderModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Cashdepositheader", function () {
      return Cashdepositheader;
    });

    var Cashdepositheader = function Cashdepositheader(Key, No, Posting_Date, Reference, Created_By, Amount) {
      _classCallCheck(this, Cashdepositheader);

      this.Key = Key;
      this.No = No;
      this.Posting_Date = Posting_Date;
      this.Reference = Reference;
      this.Created_By = Created_By;
      this.Amount = Amount;
    };
    /***/

  },

  /***/
  "./src/app/models/cashdepositline.model.ts":
  /*!*************************************************!*\
    !*** ./src/app/models/cashdepositline.model.ts ***!
    \*************************************************/

  /*! exports provided: Cashdepositline */

  /***/
  function srcAppModelsCashdepositlineModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Cashdepositline", function () {
      return Cashdepositline;
    });

    var Cashdepositline = function Cashdepositline(Key, Customer_Name, Amount, Select, No) {
      _classCallCheck(this, Cashdepositline);

      this.Key = Key;
      this.Customer_Name = Customer_Name;
      this.Amount = Amount;
      this.Select = Select;
      this.No = No;
    };
    /***/

  },

  /***/
  "./src/app/utility.service.ts":
  /*!************************************!*\
    !*** ./src/app/utility.service.ts ***!
    \************************************/

  /*! exports provided: UtilityService */

  /***/
  function srcAppUtilityServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "UtilityService", function () {
      return UtilityService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var UtilityService = /*#__PURE__*/function () {
      function UtilityService(toastCtrl, alertCtrl, loadingCtrl) {
        _classCallCheck(this, UtilityService);

        this.toastCtrl = toastCtrl;
        this.alertCtrl = alertCtrl;
        this.loadingCtrl = loadingCtrl;
      }

      _createClass(UtilityService, [{
        key: "formatDate",
        value: function formatDate(datestring) {
          // Format Date to YYYY-MM-DD
          var recDate = new Date(datestring);
          var month = recDate.getMonth() + 1 > 9 ? recDate.getMonth() + 1 : "0" + (recDate.getMonth() + 1);
          var day = recDate.getDate() > 9 ? recDate.getDate() : "0" + recDate.getDate();
          return "".concat(recDate.getFullYear(), "-").concat(month, "-").concat(day);
        }
      }, {
        key: "showToast",
        value: function showToast(text) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var toastEl;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    toastEl = this.toastCtrl.create({
                      message: text,
                      duration: 4000,
                      position: 'top'
                    });
                    _context2.next = 3;
                    return toastEl;

                  case 3:
                    _context2.sent.present();

                  case 4:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "showAlert",
        value: function showAlert(text) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var alertEl;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.alertCtrl.create({
                      header: 'Operation Error',
                      message: 'Message : ' + text,
                      buttons: [{
                        text: 'Okay'
                      }]
                    });

                  case 2:
                    alertEl = _context3.sent;
                    _context3.next = 5;
                    return alertEl.present();

                  case 5:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "presentLoading",
        value: function presentLoading(message) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            var loading;
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    _context4.next = 2;
                    return this.loadingCtrl.create({
                      spinner: 'dots',
                      animated: true,
                      message: message ? message : 'Loading Data...'
                    });

                  case 2:
                    loading = _context4.sent;
                    _context4.next = 5;
                    return loading.present();

                  case 5:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this);
          }));
        }
      }]);

      return UtilityService;
    }();

    UtilityService.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]
      }];
    };

    UtilityService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], UtilityService);
    /***/
  }
}]);
//# sourceMappingURL=cash-deposit-cash-deposit-module-es5.js.map