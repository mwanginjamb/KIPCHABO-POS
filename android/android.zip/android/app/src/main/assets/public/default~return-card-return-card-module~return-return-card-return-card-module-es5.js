function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~return-card-return-card-module~return-return-card-return-card-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/return/return-card/return-card.page.html":
  /*!************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/return/return-card/return-card.page.html ***!
    \************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppReturnReturnCardReturnCardPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button defaultHref=\"return\"></ion-back-button>\r\n    </ion-buttons>\r\n\r\n    <ion-title>Return Card</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"refresh($event)\" pullMin=\"100\" pullMax=\"200\">\r\n    <ion-refresher-content pullingIcon=\"arrow-down-outline\" pullingText=\"Pull to Refresh\" refreshingSpinner=\"crescent\"\r\n      refreshingText=\"Refreshing...\">\r\n    </ion-refresher-content>\r\n  </ion-refresher>\r\n\r\n  <form>\r\n    <ion-grid>\r\n      <ion-row>\r\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\r\n          <ion-card>\r\n            <ion-card-header>\r\n              <ion-card-title>\r\n                Sale Return\r\n              </ion-card-title>\r\n            </ion-card-header>\r\n\r\n            <ion-card-content>\r\n\r\n              <ion-row>\r\n                <ion-col>\r\n                  <ion-item>\r\n                    <ion-label position=\"floating\">No.</ion-label>\r\n                    <ion-input type=\"text\" [(ngModel)]=\"card.No\" name=\"No\" readonly></ion-input>\r\n                    <ion-input type=\"hidden\" [(ngModel)]=\"card.Key\" name=\"Key\" readonly></ion-input>\r\n                  </ion-item>\r\n                </ion-col>\r\n\r\n\r\n                <ion-col>\r\n                  <ion-label position=\"floating\">Return Date</ion-label>\r\n                  <ion-datetime type=\"date\" [(ngModel)]=\"card.Return_Date\" name=\"Return_Date\" readonly></ion-datetime>\r\n                </ion-col>\r\n\r\n              </ion-row>\r\n\r\n              <ion-row>\r\n                <ion-col>\r\n                  <ion-item>\r\n                    <ion-label position=\"floating\">Customer.</ion-label>\r\n                    <ion-select [(ngModel)]=\"card.Customer_No\" name=\"Customer_No\" [selectedText]=\"card.Customer_Name\"\r\n                      placeholder=\"Select ...\" readonly>\r\n                      <ion-select-option *ngFor=\"let cust of customers\" [value]=\"cust.No\">{{cust.Name}}\r\n                      </ion-select-option>\r\n                    </ion-select>\r\n                  </ion-item>\r\n                </ion-col>\r\n\r\n                <ion-col>\r\n                  <ion-item>\r\n                    <ion-label position=\"floating\">Invoice No:</ion-label>\r\n\r\n                    <ion-input type=\"text\" readonly=\"true\" [(ngModel)]=\"card.Applies_to_Invoice_No\"\r\n                      name=\"Applies_to_Invoice_No\"></ion-input>\r\n\r\n                  </ion-item>\r\n                </ion-col>\r\n              </ion-row>\r\n\r\n              <ion-row>\r\n                <ion-col>\r\n                  <ion-item>\r\n                    <ion-label position=\"floating\">Created By:</ion-label>\r\n\r\n                    <ion-input type=\"text\" readonly=\"true\" [(ngModel)]=\"card.Created_By\" name=\"Created_By\"></ion-input>\r\n\r\n                  </ion-item>\r\n                </ion-col>\r\n\r\n\r\n\r\n                <ion-col>\r\n                  <ion-item>\r\n                    <ion-label position=\"floating\">Created On:</ion-label>\r\n\r\n                    <ion-input type=\"text\" readonly=\"true\" [(ngModel)]=\"card.Created_On\" name=\"Created_On\"></ion-input>\r\n\r\n                  </ion-item>\r\n                </ion-col>\r\n\r\n\r\n\r\n              </ion-row>\r\n\r\n\r\n\r\n\r\n\r\n\r\n            </ion-card-content>\r\n\r\n          </ion-card>\r\n\r\n          <!--Start Lines Card-->\r\n          <ion-card>\r\n            <ion-card-header>\r\n              <ion-card-title>Return Lines</ion-card-title>\r\n            </ion-card-header>\r\n            <ion-card-content>\r\n              <ion-grid>\r\n                <!--<ion-row>\r\n                  <ion-col>\r\n                    <ion-list>\r\n                      <ion-item>\r\n                        <ion-button type=\"button\" outline color=\"primary\" (click)=\"onAddLine(card?.No)\">New</ion-button>\r\n                      </ion-item>\r\n                    </ion-list>\r\n  \r\n                  </ion-col>\r\n                </ion-row>-->\r\n\r\n                <ion-row scrollX=\"true\">\r\n                  <ion-col>\r\n                    <ion-label>Description</ion-label>\r\n                  </ion-col>\r\n\r\n\r\n                  <ion-col>\r\n                    <ion-label>Unit Pieces</ion-label>\r\n                  </ion-col>\r\n\r\n\r\n                  <ion-col>\r\n                    <ion-label>Store</ion-label>\r\n                  </ion-col>\r\n\r\n\r\n\r\n                </ion-row>\r\n\r\n\r\n\r\n                <ion-list *ngFor=\"let item of card ?.POS_Return_Lines ?.POS_Return_Lines\">\r\n                  <ion-row>\r\n                    <ion-col>\r\n                      <ion-item>\r\n                        <ion-label>{{item.Description}}</ion-label>\r\n                      </ion-item>\r\n                    </ion-col>\r\n\r\n\r\n                    <ion-col>\r\n                      <ion-item>\r\n                        <ion-label>{{item.Quantity}}</ion-label>\r\n                      </ion-item>\r\n                    </ion-col>\r\n\r\n\r\n                    <ion-col>\r\n                      <ion-item>\r\n                        <ion-label>{{item.Store_Code}}</ion-label>\r\n                      </ion-item>\r\n                    </ion-col>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n                  </ion-row>\r\n                </ion-list>\r\n\r\n\r\n              </ion-grid>\r\n            </ion-card-content>\r\n          </ion-card>\r\n          <!--End Lines Card-->\r\n\r\n\r\n\r\n\r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </form>\r\n\r\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/return/return-card/return-card-routing.module.ts":
  /*!******************************************************************!*\
    !*** ./src/app/return/return-card/return-card-routing.module.ts ***!
    \******************************************************************/

  /*! exports provided: ReturnCardPageRoutingModule */

  /***/
  function srcAppReturnReturnCardReturnCardRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ReturnCardPageRoutingModule", function () {
      return ReturnCardPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _return_card_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./return-card.page */
    "./src/app/return/return-card/return-card.page.ts");

    var routes = [{
      path: '',
      component: _return_card_page__WEBPACK_IMPORTED_MODULE_3__["ReturnCardPage"]
    }];

    var ReturnCardPageRoutingModule = function ReturnCardPageRoutingModule() {
      _classCallCheck(this, ReturnCardPageRoutingModule);
    };

    ReturnCardPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], ReturnCardPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/return/return-card/return-card.module.ts":
  /*!**********************************************************!*\
    !*** ./src/app/return/return-card/return-card.module.ts ***!
    \**********************************************************/

  /*! exports provided: ReturnCardPageModule */

  /***/
  function srcAppReturnReturnCardReturnCardModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ReturnCardPageModule", function () {
      return ReturnCardPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _return_card_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./return-card-routing.module */
    "./src/app/return/return-card/return-card-routing.module.ts");
    /* harmony import */


    var _return_card_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./return-card.page */
    "./src/app/return/return-card/return-card.page.ts");

    var ReturnCardPageModule = function ReturnCardPageModule() {
      _classCallCheck(this, ReturnCardPageModule);
    };

    ReturnCardPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _return_card_routing_module__WEBPACK_IMPORTED_MODULE_5__["ReturnCardPageRoutingModule"]],
      declarations: [_return_card_page__WEBPACK_IMPORTED_MODULE_6__["ReturnCardPage"]]
    })], ReturnCardPageModule);
    /***/
  },

  /***/
  "./src/app/return/return-card/return-card.page.scss":
  /*!**********************************************************!*\
    !*** ./src/app/return/return-card/return-card.page.scss ***!
    \**********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppReturnReturnCardReturnCardPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3JldHVybi9yZXR1cm4tY2FyZC9yZXR1cm4tY2FyZC5wYWdlLnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/return/return-card/return-card.page.ts":
  /*!********************************************************!*\
    !*** ./src/app/return/return-card/return-card.page.ts ***!
    \********************************************************/

  /*! exports provided: ReturnCardPage */

  /***/
  function srcAppReturnReturnCardReturnCardPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ReturnCardPage", function () {
      return ReturnCardPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _auth_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../../auth/auth-service */
    "./src/app/auth/auth-service.ts");
    /* harmony import */


    var _models_return_model__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../../models/return.model */
    "./src/app/models/return.model.ts");
    /* harmony import */


    var _payments_payments_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../../payments/payments.service */
    "./src/app/payments/payments.service.ts");
    /* harmony import */


    var _postedsalesinvoices_sales_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../../postedsalesinvoices/sales.service */
    "./src/app/postedsalesinvoices/sales.service.ts");
    /* harmony import */


    var _utility_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ../../utility.service */
    "./src/app/utility.service.ts");
    /* harmony import */


    var _return_line_return_line_component__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(
    /*! ../return-line/return-line.component */
    "./src/app/return/return-line/return-line.component.ts");
    /* harmony import */


    var _return_service__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(
    /*! ../return.service */
    "./src/app/return/return.service.ts");

    var ReturnCardPage = /*#__PURE__*/function () {
      function ReturnCardPage(utilitySvc, activatedRoute, SalesSvs, returnSvc, authSvc, modalCtrl, paymentSvc) {
        _classCallCheck(this, ReturnCardPage);

        this.utilitySvc = utilitySvc;
        this.activatedRoute = activatedRoute;
        this.SalesSvs = SalesSvs;
        this.returnSvc = returnSvc;
        this.authSvc = authSvc;
        this.modalCtrl = modalCtrl;
        this.paymentSvc = paymentSvc;
        this.card = new _models_return_model__WEBPACK_IMPORTED_MODULE_5__["Return"]();
      }

      _createClass(ReturnCardPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.Key = this.activatedRoute.snapshot.paramMap.get('Key');
          this.FetchReturnByKey(this.Key);
        }
      }, {
        key: "FetchCustomers",
        value: function FetchCustomers() {
          var _this = this;

          this.customerListSub = this.paymentSvc.Customers.subscribe(function (cust) {
            console.log(cust);
            _this.customers = cust;
          });
        }
      }, {
        key: "FetchReturnByKey",
        value: function FetchReturnByKey(Key) {
          var _this2 = this;

          this.cardSub = this.returnSvc.getReturnTransaction(Key).subscribe(function (res) {
            if (typeof res === 'string') {
              _this2.utilitySvc.showAlert(res);

              return;
            }

            _this2.card = res;
            console.log("The return card...");
            console.log(res);
            return;
          }, function (err) {
            _this2.utilitySvc.showAlert(err.error.message);
          });
        }
      }, {
        key: "setUser",
        value: function setUser() {
          var _a;

          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.authSvc.getUser();

                  case 2:
                    this.user = _context.sent;
                    this.userID = (_a = this.user) === null || _a === void 0 ? void 0 : _a.User_ID;

                  case 4:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "FetchPostedInvoice",
        value: function FetchPostedInvoice() {
          var _this3 = this;

          console.log("Fetch Posted Invoice Invoked ............");
          this.postedSalesSub = this.SalesSvs.getSale(this.postedInvoiceNo).subscribe(function (result) {
            _this3.postedSalesInvoice = result;
            _this3.card.Applies_to_Invoice_No = result.No;
            _this3.card.Created_By = _this3.userID;
            console.log('Invoice To be returned.');
            console.table(result); // Get customer No

            _this3.custSub = _this3.paymentSvc.Customer(result.Sell_to_Customer_Name).subscribe(function (cust) {
              _this3.card.Customer_No = cust[0].No;
              /*console.log('Our Customer');
              console.table(cust[0]);
              console.log('Return Card to post.');
              console.table(this.card);*/

              _this3.CreateReturn();
            });
          });
        }
      }, {
        key: "CreateReturn",
        value: function CreateReturn() {
          var _this4 = this;

          console.log("Create called....");
          this.cardSub = this.returnSvc.ReturnTransaction(this.card).subscribe(function (res) {
            if (typeof res === 'string') {
              /*this.utilitySvc.showAlert(res);
              return;*/
            }

            _this4.card = res;
          }, function (err) {
            /* this.utilitySvc.showAlert(err);
             return;*/
          });
        }
      }, {
        key: "onReturnUpdate",
        value: function onReturnUpdate() {
          var _this5 = this;

          this.card.Return_Date = this.utilitySvc.formatDate(this.card.Created_On);
          this.cardSub = this.returnSvc.ReturnTransaction(this.card).subscribe(function (res) {
            if (typeof res === 'string') {
              /*this.utilitySvc.showAlert(res);
              return;*/
            }

            _this5.utilitySvc.showToast('Return Updated Successfully.');

            _this5.card = res;
          }, function (err) {
            /* this.utilitySvc.showAlert(err);
             return;*/
          });
        } // Pull Down to Refresh

      }, {
        key: "refresh",
        value: function refresh(event) {
          var _this6 = this;

          this.cardSub = this.returnSvc.getReturnTransaction(this.card.Key).subscribe(function (result) {
            _this6.card = result;

            if (event) {
              event.target.complete();
            }
          });
        } // Show Line modal form

      }, {
        key: "onAddLine",
        value: function onAddLine(Return_No) {
          this.modalCtrl.create({
            component: _return_line_return_line_component__WEBPACK_IMPORTED_MODULE_9__["ReturnLineComponent"],
            componentProps: {
              docId: Return_No
            }
          }).then(function (modalEl) {
            modalEl.present();
          });
        }
      }, {
        key: "onUpdateLine",
        value: function onUpdateLine(key) {
          var _this7 = this;

          this.lineSub = this.returnSvc.fetchLine(key).subscribe(function (res) {
            _this7.modalCtrl.create({
              component: _return_line_return_line_component__WEBPACK_IMPORTED_MODULE_9__["ReturnLineComponent"],
              componentProps: {
                line: res
              }
            }).then(function (modalEl) {
              modalEl.present();
            });
          });
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          if (this.cardSub) {
            this.cardSub.unsubscribe();
          }

          if (this.lineSub) {
            this.lineSub.unsubscribe();
          }

          if (this.custSub) {
            this.custSub.unsubscribe();
          }
        }
      }]);

      return ReturnCardPage;
    }();

    ReturnCardPage.ctorParameters = function () {
      return [{
        type: _utility_service__WEBPACK_IMPORTED_MODULE_8__["UtilityService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
      }, {
        type: _postedsalesinvoices_sales_service__WEBPACK_IMPORTED_MODULE_7__["SalesService"]
      }, {
        type: _return_service__WEBPACK_IMPORTED_MODULE_10__["ReturnService"]
      }, {
        type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"]
      }, {
        type: _payments_payments_service__WEBPACK_IMPORTED_MODULE_6__["PaymentsService"]
      }];
    };

    ReturnCardPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-return-card',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./return-card.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/return/return-card/return-card.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./return-card.page.scss */
      "./src/app/return/return-card/return-card.page.scss"))["default"]]
    })], ReturnCardPage);
    /***/
  }
}]);
//# sourceMappingURL=default~return-card-return-card-module~return-return-card-return-card-module-es5.js.map