(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["requisitions-requisition-details-requisition-details-module"],{

/***/ "./src/app/requisitions/requisition.service.ts":
/*!*****************************************************!*\
  !*** ./src/app/requisitions/requisition.service.ts ***!
  \*****************************************************/
/*! exports provided: RequisitionService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RequisitionService", function() { return RequisitionService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");






let RequisitionService = class RequisitionService {
    constructor(http) {
        this.http = http;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
        this._refresh$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__["Subject"]();
    }
    // Synthetic Getter for our refresh observerble
    get refresh$() {
        return this._refresh$;
    }
    getRequisitions(userID) {
        return this.http.get(`${this.url}site/requisitions?userid=${userID}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    get releasedrequisitions() {
        return this.http.get(`${this.url}site/releasedrequisitions`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    // Retrieve Requisition Card / Details
    requisitioncard(id) {
        return this.http.get(`${this.url}site/requisitioncard/?id=${id}`);
    }
    // Create New Requisition
    createRequisition(userID) {
        console.log('creator is:' + userID);
        return this.http.get(`${this.url}site/create-requisition?userid=${userID}`);
    }
    // get Units of Measure
    getunits(itemNo) {
        return this.http.get(`${this.url}site/unitmeasure?itemNo=${itemNo}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    // Get Locations List
    getLocations() {
        return this.http.get(`${this.url}site/locationlist`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    // Get any items from generic service getter function
    get Dimensions() {
        return this.http.get(`${this.url}site/get?service=Dimensions`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    get Departments() {
        return this.http.get(`${this.url}site/departments`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    get Projects() {
        return this.http.get(`${this.url}site/projects`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    // Post Lines Data
    postLine(line) {
        return this.http.post(`${this.url}site/requisition-lines`, JSON.stringify(line))
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(() => {
            this._refresh$.next();
        }));
    }
    // Update Line
    updateRequisitionLine(line) {
        return this.http.post(`${this.url}site/updaterequisitionline`, JSON.stringify(line))
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(() => {
            this._refresh$.next();
        }));
    }
    // Fetch Line to Update
    getLine(Key) {
        return this.http.get(`${this.url}site/requisition-lines?Key=${Key}`);
    }
    // Post Requisition Header
    postRequisition(requisition) {
        return this.http.post(`${this.url}site/update-requisition`, JSON.stringify(requisition));
    }
    // Format date utility
    formatDate(datestring) {
        // Format Date to YYYY-MM-DD
        const recDate = new Date(datestring);
        const month = (recDate.getMonth() + 1) > 9 ? recDate.getMonth() + 1 : `0` + (recDate.getMonth() + 1);
        const day = (recDate.getDate()) > 9 ? recDate.getDate() : `0` + recDate.getDate();
        return `${recDate.getFullYear()}-${month}-${day}`;
    }
};
RequisitionService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
RequisitionService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], RequisitionService);



/***/ })

}]);
//# sourceMappingURL=requisitions-requisition-details-requisition-details-module-es2015.js.map