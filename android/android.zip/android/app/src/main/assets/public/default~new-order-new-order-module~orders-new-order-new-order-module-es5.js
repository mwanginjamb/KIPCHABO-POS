function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~new-order-new-order-module~orders-new-order-new-order-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/orders/new-order/new-order.page.html":
  /*!********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/orders/new-order/new-order.page.html ***!
    \********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppOrdersNewOrderNewOrderPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <ion-title>New Sales Invoice</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <form #Req=\"ngForm\" (ngSubmit)=\"onInvoiceupdate(Req)\">\r\n    <ion-grid>\r\n      <ion-row>\r\n        <ion-col size-sm=\"6\" offset-sm=\"3\">\r\n          <ion-card>\r\n              <ion-card-header>\r\n                <ion-card-title>\r\n                  Invoice Form\r\n                </ion-card-title>\r\n              </ion-card-header>\r\n\r\n              <ion-card-content>\r\n\r\n                <ion-row>\r\n                  <ion-col >\r\n                    <ion-item>\r\n                      <ion-label position=\"floating\">No.</ion-label>\r\n                      <ion-input type=\"text\" [(ngModel)]=\"invoice.No\" name=\"No\" readonly></ion-input>\r\n                    </ion-item>\r\n                  </ion-col>\r\n\r\n                  \r\n                    <ion-col>\r\n                      <ion-label position=\"floating\">Key</ion-label>\r\n                      <ion-input type=\"text\" [(ngModel)]=\"invoice.Key\" name=\"Key\" readonly></ion-input>\r\n                    </ion-col>\r\n                 \r\n                </ion-row>\r\n\r\n                <ion-row>\r\n                  <ion-col >\r\n                    <ion-item>\r\n                      <ion-label position=\"floating\">Customer.</ion-label>                \r\n                      <ion-select [(ngModel)]=\"invoice.Sell_to_Customer_Name\" name=\"Sell_to_Customer_Name\" [selectedText]=\"invoice.Sell_to_Customer_Name\" placeholder=\"Select ...\">\r\n                        <ion-select-option *ngFor=\"let cust of customers\" [value]=\"cust.No\">{{cust.Name}}</ion-select-option>\r\n                      </ion-select>\r\n                    </ion-item>\r\n                  </ion-col>\r\n\r\n                  <ion-col >\r\n                    <ion-item>\r\n                      <ion-label position=\"floating\">Due Date</ion-label>\r\n                                         \r\n                      <ion-datetime type=\"date\" [(ngModel)]=\"invoice.Due_Date\" name=\"Due_Date\"></ion-datetime>\r\n                    \r\n                    </ion-item>\r\n                  </ion-col>\r\n                </ion-row>\r\n\r\n                <ion-row>\r\n                  <ion-col >\r\n                    <ion-item>\r\n                      <ion-label position=\"floating\">Posting Date</ion-label>\r\n                      <ion-datetime type=\"date\" [(ngModel)]=\"invoice.Posting_Date\" name=\"Posting_Date\" readonly></ion-datetime>\r\n                    </ion-item>\r\n                  </ion-col>\r\n\r\n                  <ion-col >\r\n                    <ion-item>\r\n                      <ion-label position=\"floating\">Status</ion-label>\r\n                      <ion-input type=\"text\" [(ngModel)]=\"invoice.Status\" name=\"Status\" readonly></ion-input>\r\n                    </ion-item>\r\n                  </ion-col>\r\n                </ion-row>                \r\n\r\n                <ion-row>\r\n                  <ion-col size-sm=\"6\" offset-sm=\"3\">\r\n                    <ion-button type=\"submit\" color=\"primary\" expand=\"block\">Save Details</ion-button>\r\n                  </ion-col>\r\n                </ion-row>\r\n\r\n              </ion-card-content>\r\n\r\n            </ion-card> \r\n        </ion-col>\r\n      </ion-row>\r\n    </ion-grid>\r\n  </form>\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./src/app/models/invoice.model.ts":
  /*!*****************************************!*\
    !*** ./src/app/models/invoice.model.ts ***!
    \*****************************************/

  /*! exports provided: Invoice */

  /***/
  function srcAppModelsInvoiceModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Invoice", function () {
      return Invoice;
    });

    var Invoice = function Invoice(Key, No, Sell_to_Customer_Name, Sell_to_Address, Sell_to_Address_2, Sell_to_Post_Code, Sell_to_City, Sell_to_Contact_No, Sell_to_Contact, Your_Reference, Document_Date, Posting_Date, Due_Date, Incoming_Document_Entry_No, External_Document_No, Salesperson_Code, Campaign_No, Responsibility_Center, Assigned_User_ID, Status, Job_Queue_Status, WorkDescription, Currency_Code, Shipment_Date, Quote_No, Prices_Including_VAT, VAT_Bus_Posting_Group, Payment_Terms_Code, Payment_Method_Code, SelectedPayments, Transaction_Type, Shortcut_Dimension_1_Code, Shortcut_Dimension_2_Code, Payment_Discount_Percent, Pmt_Discount_Date, Direct_Debit_Mandate_ID, Location_Code, ShippingOptions, Ship_to_Code, Ship_to_Name, Ship_to_Address, Ship_to_Address_2, Ship_to_Post_Code, Ship_to_City, Ship_to_Country_Region_Code, Ship_to_Contact, Shipment_Method_Code, Shipping_Agent_Code, Shipping_Agent_Service_Code, Package_Tracking_No, BillToOptions, Bill_to_Name, Bill_to_Address, Bill_to_Address_2, Bill_to_Post_Code, Bill_to_City, Bill_to_Contact_No, Bill_to_Contact, EU_3_Party_Trade, Transaction_Specification, Transport_Method, Exit_Point, Area, SalesLines) {
      _classCallCheck(this, Invoice);

      this.Key = Key;
      this.No = No;
      this.Sell_to_Customer_Name = Sell_to_Customer_Name;
      this.Sell_to_Address = Sell_to_Address;
      this.Sell_to_Address_2 = Sell_to_Address_2;
      this.Sell_to_Post_Code = Sell_to_Post_Code;
      this.Sell_to_City = Sell_to_City;
      this.Sell_to_Contact_No = Sell_to_Contact_No;
      this.Sell_to_Contact = Sell_to_Contact;
      this.Your_Reference = Your_Reference;
      this.Document_Date = Document_Date;
      this.Posting_Date = Posting_Date;
      this.Due_Date = Due_Date;
      this.Incoming_Document_Entry_No = Incoming_Document_Entry_No;
      this.External_Document_No = External_Document_No;
      this.Salesperson_Code = Salesperson_Code;
      this.Campaign_No = Campaign_No;
      this.Responsibility_Center = Responsibility_Center;
      this.Assigned_User_ID = Assigned_User_ID;
      this.Status = Status;
      this.Job_Queue_Status = Job_Queue_Status;
      this.WorkDescription = WorkDescription;
      this.Currency_Code = Currency_Code;
      this.Shipment_Date = Shipment_Date;
      this.Quote_No = Quote_No;
      this.Prices_Including_VAT = Prices_Including_VAT;
      this.VAT_Bus_Posting_Group = VAT_Bus_Posting_Group;
      this.Payment_Terms_Code = Payment_Terms_Code;
      this.Payment_Method_Code = Payment_Method_Code;
      this.SelectedPayments = SelectedPayments;
      this.Transaction_Type = Transaction_Type;
      this.Shortcut_Dimension_1_Code = Shortcut_Dimension_1_Code;
      this.Shortcut_Dimension_2_Code = Shortcut_Dimension_2_Code;
      this.Payment_Discount_Percent = Payment_Discount_Percent;
      this.Pmt_Discount_Date = Pmt_Discount_Date;
      this.Direct_Debit_Mandate_ID = Direct_Debit_Mandate_ID;
      this.Location_Code = Location_Code;
      this.ShippingOptions = ShippingOptions;
      this.Ship_to_Code = Ship_to_Code;
      this.Ship_to_Name = Ship_to_Name;
      this.Ship_to_Address = Ship_to_Address;
      this.Ship_to_Address_2 = Ship_to_Address_2;
      this.Ship_to_Post_Code = Ship_to_Post_Code;
      this.Ship_to_City = Ship_to_City;
      this.Ship_to_Country_Region_Code = Ship_to_Country_Region_Code;
      this.Ship_to_Contact = Ship_to_Contact;
      this.Shipment_Method_Code = Shipment_Method_Code;
      this.Shipping_Agent_Code = Shipping_Agent_Code;
      this.Shipping_Agent_Service_Code = Shipping_Agent_Service_Code;
      this.Package_Tracking_No = Package_Tracking_No;
      this.BillToOptions = BillToOptions;
      this.Bill_to_Name = Bill_to_Name;
      this.Bill_to_Address = Bill_to_Address;
      this.Bill_to_Address_2 = Bill_to_Address_2;
      this.Bill_to_Post_Code = Bill_to_Post_Code;
      this.Bill_to_City = Bill_to_City;
      this.Bill_to_Contact_No = Bill_to_Contact_No;
      this.Bill_to_Contact = Bill_to_Contact;
      this.EU_3_Party_Trade = EU_3_Party_Trade;
      this.Transaction_Specification = Transaction_Specification;
      this.Transport_Method = Transport_Method;
      this.Exit_Point = Exit_Point;
      this.Area = Area;
      this.SalesLines = SalesLines;
    };
    /***/

  },

  /***/
  "./src/app/orders/new-order/new-order-routing.module.ts":
  /*!**************************************************************!*\
    !*** ./src/app/orders/new-order/new-order-routing.module.ts ***!
    \**************************************************************/

  /*! exports provided: NewOrderPageRoutingModule */

  /***/
  function srcAppOrdersNewOrderNewOrderRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NewOrderPageRoutingModule", function () {
      return NewOrderPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _new_order_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./new-order.page */
    "./src/app/orders/new-order/new-order.page.ts");

    var routes = [{
      path: '',
      component: _new_order_page__WEBPACK_IMPORTED_MODULE_3__["NewOrderPage"]
    }];

    var NewOrderPageRoutingModule = function NewOrderPageRoutingModule() {
      _classCallCheck(this, NewOrderPageRoutingModule);
    };

    NewOrderPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], NewOrderPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/orders/new-order/new-order.module.ts":
  /*!******************************************************!*\
    !*** ./src/app/orders/new-order/new-order.module.ts ***!
    \******************************************************/

  /*! exports provided: NewOrderPageModule */

  /***/
  function srcAppOrdersNewOrderNewOrderModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NewOrderPageModule", function () {
      return NewOrderPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _new_order_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./new-order-routing.module */
    "./src/app/orders/new-order/new-order-routing.module.ts");
    /* harmony import */


    var _new_order_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./new-order.page */
    "./src/app/orders/new-order/new-order.page.ts");

    var NewOrderPageModule = function NewOrderPageModule() {
      _classCallCheck(this, NewOrderPageModule);
    };

    NewOrderPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _new_order_routing_module__WEBPACK_IMPORTED_MODULE_5__["NewOrderPageRoutingModule"]],
      declarations: [_new_order_page__WEBPACK_IMPORTED_MODULE_6__["NewOrderPage"]]
    })], NewOrderPageModule);
    /***/
  },

  /***/
  "./src/app/orders/new-order/new-order.page.scss":
  /*!******************************************************!*\
    !*** ./src/app/orders/new-order/new-order.page.scss ***!
    \******************************************************/

  /*! exports provided: default */

  /***/
  function srcAppOrdersNewOrderNewOrderPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL29yZGVycy9uZXctb3JkZXIvbmV3LW9yZGVyLnBhZ2Uuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/orders/new-order/new-order.page.ts":
  /*!****************************************************!*\
    !*** ./src/app/orders/new-order/new-order.page.ts ***!
    \****************************************************/

  /*! exports provided: NewOrderPage */

  /***/
  function srcAppOrdersNewOrderNewOrderPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "NewOrderPage", function () {
      return NewOrderPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _order_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../order.service */
    "./src/app/orders/order.service.ts");
    /* harmony import */


    var src_app_models_invoice_model__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/models/invoice.model */
    "./src/app/models/invoice.model.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");

    var NewOrderPage = /*#__PURE__*/function () {
      function NewOrderPage(popoverCtrl, toastCtrl, alertCtrl, orderService, router) {
        _classCallCheck(this, NewOrderPage);

        this.popoverCtrl = popoverCtrl;
        this.toastCtrl = toastCtrl;
        this.alertCtrl = alertCtrl;
        this.orderService = orderService;
        this.router = router;
        this.invoice = new src_app_models_invoice_model__WEBPACK_IMPORTED_MODULE_4__["Invoice"]();
      }

      _createClass(NewOrderPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.popoverCtrl.dismiss();
          this.InitInvoice();
          this.fetchCustomers();
        }
      }, {
        key: "InitInvoice",
        value: function InitInvoice() {
          var _this = this;

          this.InvoiceSub = this.orderService.createInvoice().subscribe(function (result) {
            Object.assign(_this.invoice, result);
          });
        }
      }, {
        key: "onInvoiceupdate",
        value: function onInvoiceupdate(form) {
          var _this2 = this;

          this.orderSub = this.orderService.postInvoice(this.invoice).subscribe(function (res) {
            if (typeof res !== 'string') {
              // Show a Toast Notification
              _this2.toastCtrl.create({
                message: "".concat(res.No, " Sales Invoice Created Successfully."),
                duration: 2000,
                position: 'top'
              }).then(function (toastData) {
                toastData.present();

                _this2.router.navigate(['/', 'orders', res.No]);
              });
            } else {
              _this2.alertCtrl.create({
                header: 'Operation Error',
                message: 'Message : ' + res,
                buttons: [{
                  text: 'Okay'
                }]
              }).then(function (alertEl) {
                alertEl.present();
              });
            }
          }, function (error) {
            console.log(error.error);

            _this2.alertCtrl.create({
              header: 'Service Error!',
              message: 'Connection problem: ' + error,
              buttons: [{
                text: 'Okay'
              }]
            }).then(function (alertEl) {
              alertEl.present();
            });
          });
        }
      }, {
        key: "fetchCustomers",
        value: function fetchCustomers() {
          var _this3 = this;

          this.customerListSub = this.orderService.Customers.subscribe(function (cust) {
            _this3.customers = cust;
          });
        }
      }]);

      return NewOrderPage;
    }();

    NewOrderPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PopoverController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }, {
        type: _order_service__WEBPACK_IMPORTED_MODULE_3__["OrderService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_5__["Router"]
      }];
    };

    NewOrderPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-new-order',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./new-order.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/orders/new-order/new-order.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./new-order.page.scss */
      "./src/app/orders/new-order/new-order.page.scss"))["default"]]
    })], NewOrderPage);
    /***/
  }
}]);
//# sourceMappingURL=default~new-order-new-order-module~orders-new-order-new-order-module-es5.js.map