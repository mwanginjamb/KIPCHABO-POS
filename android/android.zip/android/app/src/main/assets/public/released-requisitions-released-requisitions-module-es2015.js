(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["released-requisitions-released-requisitions-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/requisitions/released-requisitions/released-requisitions.page.html":
/*!**************************************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/requisitions/released-requisitions/released-requisitions.page.html ***!
  \**************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <ion-title>Shipped Requisitions</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n\r\n  <ion-searchbar [(ngModel)]=\"searchTerm\" debounce=\"2000\" (ionChange)=\"search($event)\" placeholder=\"Search Requisition\" ></ion-searchbar>\r\n\r\n  <ion-grid>\r\n    <ion-row>\r\n      <ion-col >Stock Issue No</ion-col>\r\n      <ion-col >Order No</ion-col>\r\n      <ion-col >Issued By</ion-col>\r\n      \r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n  <ion-virtual-scroll [items]=\"requisitions\" approxItemHeight=\"47.2px\">\r\n               \r\n    <ion-item \r\n      [routerLink] = \"['../../../','stockdetail',requisition.Stock_Issue_No]\"\r\n     detail\r\n     *virtualItem=\"let requisition\" > \r\n\r\n     <ion-grid>\r\n        <ion-row>\r\n\r\n          <ion-col >\r\n            <ion-label>\r\n              <h3>{{ requisition.Stock_Issue_No }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n\r\n          <ion-col >\r\n            <ion-label>\r\n              <h3>{{ requisition.Order_No }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n\r\n          <ion-col >\r\n            <ion-label>\r\n              <h3>{{ requisition.Issued_By }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n\r\n         \r\n\r\n        </ion-row>\r\n      </ion-grid>\r\n            \r\n</ion-item>\r\n\r\n</ion-virtual-scroll>\r\n\r\n</ion-content>\r\n\r\n");

/***/ }),

/***/ "./src/app/requisitions/released-requisitions/released-requisitions-routing.module.ts":
/*!********************************************************************************************!*\
  !*** ./src/app/requisitions/released-requisitions/released-requisitions-routing.module.ts ***!
  \********************************************************************************************/
/*! exports provided: ReleasedRequisitionsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReleasedRequisitionsPageRoutingModule", function() { return ReleasedRequisitionsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _released_requisitions_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./released-requisitions.page */ "./src/app/requisitions/released-requisitions/released-requisitions.page.ts");




const routes = [
    {
        path: '',
        component: _released_requisitions_page__WEBPACK_IMPORTED_MODULE_3__["ReleasedRequisitionsPage"]
    },
];
let ReleasedRequisitionsPageRoutingModule = class ReleasedRequisitionsPageRoutingModule {
};
ReleasedRequisitionsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], ReleasedRequisitionsPageRoutingModule);



/***/ }),

/***/ "./src/app/requisitions/released-requisitions/released-requisitions.module.ts":
/*!************************************************************************************!*\
  !*** ./src/app/requisitions/released-requisitions/released-requisitions.module.ts ***!
  \************************************************************************************/
/*! exports provided: ReleasedRequisitionsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReleasedRequisitionsPageModule", function() { return ReleasedRequisitionsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _released_requisitions_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./released-requisitions-routing.module */ "./src/app/requisitions/released-requisitions/released-requisitions-routing.module.ts");
/* harmony import */ var _released_requisitions_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./released-requisitions.page */ "./src/app/requisitions/released-requisitions/released-requisitions.page.ts");







let ReleasedRequisitionsPageModule = class ReleasedRequisitionsPageModule {
};
ReleasedRequisitionsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _released_requisitions_routing_module__WEBPACK_IMPORTED_MODULE_5__["ReleasedRequisitionsPageRoutingModule"]
        ],
        declarations: [_released_requisitions_page__WEBPACK_IMPORTED_MODULE_6__["ReleasedRequisitionsPage"]]
    })
], ReleasedRequisitionsPageModule);



/***/ }),

/***/ "./src/app/requisitions/released-requisitions/released-requisitions.page.scss":
/*!************************************************************************************!*\
  !*** ./src/app/requisitions/released-requisitions/released-requisitions.page.scss ***!
  \************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3JlcXVpc2l0aW9ucy9yZWxlYXNlZC1yZXF1aXNpdGlvbnMvcmVsZWFzZWQtcmVxdWlzaXRpb25zLnBhZ2Uuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/requisitions/released-requisitions/released-requisitions.page.ts":
/*!**********************************************************************************!*\
  !*** ./src/app/requisitions/released-requisitions/released-requisitions.page.ts ***!
  \**********************************************************************************/
/*! exports provided: ReleasedRequisitionsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReleasedRequisitionsPage", function() { return ReleasedRequisitionsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_app_stock_details_stockdetail_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/app/stock-details/stockdetail.service */ "./src/app/stock-details/stockdetail.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");




let ReleasedRequisitionsPage = class ReleasedRequisitionsPage {
    constructor(stockService, alertCtrl) {
        this.stockService = stockService;
        this.alertCtrl = alertCtrl;
        this.searchTerm = null;
    }
    ngOnInit() {
        this.requisitionSub = this.stockService.releasedrequisitions.subscribe(result => {
            this.requisitions = result;
        });
    }
    search($event) {
        // get a copy of requisitions
        const searchItems = [...this.requisitions];
        // Begin search, only if searchTerm is provided
        if (this.searchTerm.trim().length && this.searchTerm !== '') {
            this.requisitions = searchItems.filter((req) => {
                if (req.Stock_Issue_No && req.Stock_Issue_No.length > 1) {
                    return (req.Stock_Issue_No.toLowerCase().indexOf(this.searchTerm.toLowerCase()) > -1);
                }
            });
            return;
        }
        else { // Search Term not provided display all requisitions
            this.initializeItems();
        }
    }
    initializeItems() {
        this.requisitionSub = this.stockService.releasedrequisitions.subscribe(result => {
            this.requisitions = result;
        });
    }
    ngOnDestroy() {
        if (this.requisitionSub) {
            this.requisitionSub.unsubscribe();
        }
    }
};
ReleasedRequisitionsPage.ctorParameters = () => [
    { type: src_app_stock_details_stockdetail_service__WEBPACK_IMPORTED_MODULE_2__["StockdetailService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] }
];
ReleasedRequisitionsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-released-requisitions',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./released-requisitions.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/requisitions/released-requisitions/released-requisitions.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./released-requisitions.page.scss */ "./src/app/requisitions/released-requisitions/released-requisitions.page.scss")).default]
    })
], ReleasedRequisitionsPage);



/***/ }),

/***/ "./src/app/stock-details/stockdetail.service.ts":
/*!******************************************************!*\
  !*** ./src/app/stock-details/stockdetail.service.ts ***!
  \******************************************************/
/*! exports provided: StockdetailService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StockdetailService", function() { return StockdetailService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");






let StockdetailService = class StockdetailService {
    constructor(http, toastCtrl) {
        this.http = http;
        this.toastCtrl = toastCtrl;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].url;
    }
    get releasedrequisitions() {
        return this.http.get(`${this.url}site/releasedrequisitions`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    // Retrieve Stock Issue Card / Details
    requisitioncard(id) {
        return this.http.get(`${this.url}site/stockissue/?id=${id}`);
    }
    // Create New Requisition
    createRequisition() {
        return this.http.get(`${this.url}site/create-requisition`);
    }
    //Update Stock Issue
    updateStockIssue(Card) {
        return this.http.post(`${this.url}site/stock-issue-card`, JSON.stringify(Card));
    }
    // get Units of Measure
    getunits(itemNo) {
        return this.http.get(`${this.url}site/unitmeasure?itemNo=${itemNo}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    // Get Locations List
    getLocations() {
        return this.http.get(`${this.url}site/locationlist`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    // Get any items from generic service getter function
    get Dimensions() {
        return this.http.get(`${this.url}site/get?service=Dimensions`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    get Departments() {
        return this.http.get(`${this.url}site/departments`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    get Projects() {
        return this.http.get(`${this.url}site/projects`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    // Post Lines Data
    postLine(line) {
        return this.http.post(`${this.url}site/addline`, JSON.stringify(line));
    }
    // Update Line
    updateRequisitionLine(line) {
        return this.http.post(`${this.url}site/updateissueline`, JSON.stringify(line));
    }
    // Fetch Line to Update
    getLine(Key) {
        return this.http.get(`${this.url}site/stock-issue-line?Key=${Key}`);
    }
    // Post Requisition Header
    postRequisition(requisition) {
        return this.http.post(`${this.url}site/update-requisition`, JSON.stringify(requisition));
    }
    // Format date utility
    formatDate(datestring) {
        // Format Date to YYYY-MM-DD
        const recDate = new Date(datestring);
        const month = (recDate.getMonth() + 1) > 9 ? recDate.getMonth() + 1 : `0` + (recDate.getMonth() + 1);
        const day = (recDate.getDate()) > 9 ? recDate.getDate() : `0` + recDate.getDate();
        return `${recDate.getFullYear()}-${month}-${day}`;
    }
    acknowledgeStockIssue(No) {
        return this.http.get(`${this.url}site/acknowledge-stock-issue?No=${No}`);
    }
    postDocument(No) {
        return this.http.get(`${this.url}site/acknowledge-stock-issue?No=${No}`);
    }
    showToast(text) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return yield this.toastCtrl.create({
                message: text,
                duration: 4000,
                position: 'top'
            }).then(toastEl => {
                toastEl.present();
            });
        });
    }
};
StockdetailService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"] }
];
StockdetailService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
        providedIn: 'root'
    })
], StockdetailService);



/***/ })

}]);
//# sourceMappingURL=released-requisitions-released-requisitions-module-es2015.js.map