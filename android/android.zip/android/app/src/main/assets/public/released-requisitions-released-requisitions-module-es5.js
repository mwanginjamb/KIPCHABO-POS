function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["released-requisitions-released-requisitions-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/requisitions/released-requisitions/released-requisitions.page.html":
  /*!**************************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/requisitions/released-requisitions/released-requisitions.page.html ***!
    \**************************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppRequisitionsReleasedRequisitionsReleasedRequisitionsPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <ion-title>Shipped Requisitions</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n\r\n  <ion-searchbar [(ngModel)]=\"searchTerm\" debounce=\"2000\" (ionChange)=\"search($event)\" placeholder=\"Search Requisition\" ></ion-searchbar>\r\n\r\n  <ion-grid>\r\n    <ion-row>\r\n      <ion-col >Stock Issue No</ion-col>\r\n      <ion-col >Order No</ion-col>\r\n      <ion-col >Issued By</ion-col>\r\n      \r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n  <ion-virtual-scroll [items]=\"requisitions\" approxItemHeight=\"47.2px\">\r\n               \r\n    <ion-item \r\n      [routerLink] = \"['../../../','stockdetail',requisition.Stock_Issue_No]\"\r\n     detail\r\n     *virtualItem=\"let requisition\" > \r\n\r\n     <ion-grid>\r\n        <ion-row>\r\n\r\n          <ion-col >\r\n            <ion-label>\r\n              <h3>{{ requisition.Stock_Issue_No }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n\r\n          <ion-col >\r\n            <ion-label>\r\n              <h3>{{ requisition.Order_No }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n\r\n          <ion-col >\r\n            <ion-label>\r\n              <h3>{{ requisition.Issued_By }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n\r\n         \r\n\r\n        </ion-row>\r\n      </ion-grid>\r\n            \r\n</ion-item>\r\n\r\n</ion-virtual-scroll>\r\n\r\n</ion-content>\r\n\r\n";
    /***/
  },

  /***/
  "./src/app/requisitions/released-requisitions/released-requisitions-routing.module.ts":
  /*!********************************************************************************************!*\
    !*** ./src/app/requisitions/released-requisitions/released-requisitions-routing.module.ts ***!
    \********************************************************************************************/

  /*! exports provided: ReleasedRequisitionsPageRoutingModule */

  /***/
  function srcAppRequisitionsReleasedRequisitionsReleasedRequisitionsRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ReleasedRequisitionsPageRoutingModule", function () {
      return ReleasedRequisitionsPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _released_requisitions_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./released-requisitions.page */
    "./src/app/requisitions/released-requisitions/released-requisitions.page.ts");

    var routes = [{
      path: '',
      component: _released_requisitions_page__WEBPACK_IMPORTED_MODULE_3__["ReleasedRequisitionsPage"]
    }];

    var ReleasedRequisitionsPageRoutingModule = function ReleasedRequisitionsPageRoutingModule() {
      _classCallCheck(this, ReleasedRequisitionsPageRoutingModule);
    };

    ReleasedRequisitionsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], ReleasedRequisitionsPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/requisitions/released-requisitions/released-requisitions.module.ts":
  /*!************************************************************************************!*\
    !*** ./src/app/requisitions/released-requisitions/released-requisitions.module.ts ***!
    \************************************************************************************/

  /*! exports provided: ReleasedRequisitionsPageModule */

  /***/
  function srcAppRequisitionsReleasedRequisitionsReleasedRequisitionsModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ReleasedRequisitionsPageModule", function () {
      return ReleasedRequisitionsPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _released_requisitions_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./released-requisitions-routing.module */
    "./src/app/requisitions/released-requisitions/released-requisitions-routing.module.ts");
    /* harmony import */


    var _released_requisitions_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./released-requisitions.page */
    "./src/app/requisitions/released-requisitions/released-requisitions.page.ts");

    var ReleasedRequisitionsPageModule = function ReleasedRequisitionsPageModule() {
      _classCallCheck(this, ReleasedRequisitionsPageModule);
    };

    ReleasedRequisitionsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _released_requisitions_routing_module__WEBPACK_IMPORTED_MODULE_5__["ReleasedRequisitionsPageRoutingModule"]],
      declarations: [_released_requisitions_page__WEBPACK_IMPORTED_MODULE_6__["ReleasedRequisitionsPage"]]
    })], ReleasedRequisitionsPageModule);
    /***/
  },

  /***/
  "./src/app/requisitions/released-requisitions/released-requisitions.page.scss":
  /*!************************************************************************************!*\
    !*** ./src/app/requisitions/released-requisitions/released-requisitions.page.scss ***!
    \************************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppRequisitionsReleasedRequisitionsReleasedRequisitionsPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3JlcXVpc2l0aW9ucy9yZWxlYXNlZC1yZXF1aXNpdGlvbnMvcmVsZWFzZWQtcmVxdWlzaXRpb25zLnBhZ2Uuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/requisitions/released-requisitions/released-requisitions.page.ts":
  /*!**********************************************************************************!*\
    !*** ./src/app/requisitions/released-requisitions/released-requisitions.page.ts ***!
    \**********************************************************************************/

  /*! exports provided: ReleasedRequisitionsPage */

  /***/
  function srcAppRequisitionsReleasedRequisitionsReleasedRequisitionsPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ReleasedRequisitionsPage", function () {
      return ReleasedRequisitionsPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var src_app_stock_details_stockdetail_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/stock-details/stockdetail.service */
    "./src/app/stock-details/stockdetail.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var ReleasedRequisitionsPage = /*#__PURE__*/function () {
      function ReleasedRequisitionsPage(stockService, alertCtrl) {
        _classCallCheck(this, ReleasedRequisitionsPage);

        this.stockService = stockService;
        this.alertCtrl = alertCtrl;
        this.searchTerm = null;
      }

      _createClass(ReleasedRequisitionsPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this = this;

          this.requisitionSub = this.stockService.releasedrequisitions.subscribe(function (result) {
            _this.requisitions = result;
          });
        }
      }, {
        key: "search",
        value: function search($event) {
          var _this2 = this;

          // get a copy of requisitions
          var searchItems = _toConsumableArray(this.requisitions); // Begin search, only if searchTerm is provided


          if (this.searchTerm.trim().length && this.searchTerm !== '') {
            this.requisitions = searchItems.filter(function (req) {
              if (req.Stock_Issue_No && req.Stock_Issue_No.length > 1) {
                return req.Stock_Issue_No.toLowerCase().indexOf(_this2.searchTerm.toLowerCase()) > -1;
              }
            });
            return;
          } else {
            // Search Term not provided display all requisitions
            this.initializeItems();
          }
        }
      }, {
        key: "initializeItems",
        value: function initializeItems() {
          var _this3 = this;

          this.requisitionSub = this.stockService.releasedrequisitions.subscribe(function (result) {
            _this3.requisitions = result;
          });
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          if (this.requisitionSub) {
            this.requisitionSub.unsubscribe();
          }
        }
      }]);

      return ReleasedRequisitionsPage;
    }();

    ReleasedRequisitionsPage.ctorParameters = function () {
      return [{
        type: src_app_stock_details_stockdetail_service__WEBPACK_IMPORTED_MODULE_2__["StockdetailService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"]
      }];
    };

    ReleasedRequisitionsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-released-requisitions',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./released-requisitions.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/requisitions/released-requisitions/released-requisitions.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./released-requisitions.page.scss */
      "./src/app/requisitions/released-requisitions/released-requisitions.page.scss"))["default"]]
    })], ReleasedRequisitionsPage);
    /***/
  },

  /***/
  "./src/app/stock-details/stockdetail.service.ts":
  /*!******************************************************!*\
    !*** ./src/app/stock-details/stockdetail.service.ts ***!
    \******************************************************/

  /*! exports provided: StockdetailService */

  /***/
  function srcAppStockDetailsStockdetailServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "StockdetailService", function () {
      return StockdetailService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var StockdetailService = /*#__PURE__*/function () {
      function StockdetailService(http, toastCtrl) {
        _classCallCheck(this, StockdetailService);

        this.http = http;
        this.toastCtrl = toastCtrl;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].url;
      }

      _createClass(StockdetailService, [{
        key: "releasedrequisitions",
        get: function get() {
          return this.http.get("".concat(this.url, "site/releasedrequisitions")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        } // Retrieve Stock Issue Card / Details

      }, {
        key: "requisitioncard",
        value: function requisitioncard(id) {
          return this.http.get("".concat(this.url, "site/stockissue/?id=").concat(id));
        } // Create New Requisition

      }, {
        key: "createRequisition",
        value: function createRequisition() {
          return this.http.get("".concat(this.url, "site/create-requisition"));
        } //Update Stock Issue

      }, {
        key: "updateStockIssue",
        value: function updateStockIssue(Card) {
          return this.http.post("".concat(this.url, "site/stock-issue-card"), JSON.stringify(Card));
        } // get Units of Measure

      }, {
        key: "getunits",
        value: function getunits(itemNo) {
          return this.http.get("".concat(this.url, "site/unitmeasure?itemNo=").concat(itemNo)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        } // Get Locations List

      }, {
        key: "getLocations",
        value: function getLocations() {
          return this.http.get("".concat(this.url, "site/locationlist")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        } // Get any items from generic service getter function

      }, {
        key: "Dimensions",
        get: function get() {
          return this.http.get("".concat(this.url, "site/get?service=Dimensions")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "Departments",
        get: function get() {
          return this.http.get("".concat(this.url, "site/departments")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "Projects",
        get: function get() {
          return this.http.get("".concat(this.url, "site/projects")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        } // Post Lines Data

      }, {
        key: "postLine",
        value: function postLine(line) {
          return this.http.post("".concat(this.url, "site/addline"), JSON.stringify(line));
        } // Update Line

      }, {
        key: "updateRequisitionLine",
        value: function updateRequisitionLine(line) {
          return this.http.post("".concat(this.url, "site/updateissueline"), JSON.stringify(line));
        } // Fetch Line to Update

      }, {
        key: "getLine",
        value: function getLine(Key) {
          return this.http.get("".concat(this.url, "site/stock-issue-line?Key=").concat(Key));
        } // Post Requisition Header

      }, {
        key: "postRequisition",
        value: function postRequisition(requisition) {
          return this.http.post("".concat(this.url, "site/update-requisition"), JSON.stringify(requisition));
        } // Format date utility

      }, {
        key: "formatDate",
        value: function formatDate(datestring) {
          // Format Date to YYYY-MM-DD
          var recDate = new Date(datestring);
          var month = recDate.getMonth() + 1 > 9 ? recDate.getMonth() + 1 : "0" + (recDate.getMonth() + 1);
          var day = recDate.getDate() > 9 ? recDate.getDate() : "0" + recDate.getDate();
          return "".concat(recDate.getFullYear(), "-").concat(month, "-").concat(day);
        }
      }, {
        key: "acknowledgeStockIssue",
        value: function acknowledgeStockIssue(No) {
          return this.http.get("".concat(this.url, "site/acknowledge-stock-issue?No=").concat(No));
        }
      }, {
        key: "postDocument",
        value: function postDocument(No) {
          return this.http.get("".concat(this.url, "site/acknowledge-stock-issue?No=").concat(No));
        }
      }, {
        key: "showToast",
        value: function showToast(text) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.toastCtrl.create({
                      message: text,
                      duration: 4000,
                      position: 'top'
                    }).then(function (toastEl) {
                      toastEl.present();
                    });

                  case 2:
                    return _context.abrupt("return", _context.sent);

                  case 3:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }]);

      return StockdetailService;
    }();

    StockdetailService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"]
      }];
    };

    StockdetailService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
      providedIn: 'root'
    })], StockdetailService);
    /***/
  }
}]);
//# sourceMappingURL=released-requisitions-released-requisitions-module-es5.js.map