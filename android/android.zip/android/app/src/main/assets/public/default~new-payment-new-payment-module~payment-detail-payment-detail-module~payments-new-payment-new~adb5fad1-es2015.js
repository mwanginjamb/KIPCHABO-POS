(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~new-payment-new-payment-module~payment-detail-payment-detail-module~payments-new-payment-new~adb5fad1"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/payments/new-cash-line/new-cash-line.component.html":
/*!***********************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/payments/new-cash-line/new-cash-line.component.html ***!
  \***********************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>{{line.Key?'Update': 'New'}} Cash Receipt Line</ion-title>\r\n\r\n    <ion-buttons slot=\"primary\">\r\n      <ion-button (click)=\"onCancel()\">\r\n        <ion-icon name=\"close\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <ion-row>\r\n    <ion-col size-sm=\"6\" offset-sm=\"3\">\r\n      <ion-list>\r\n\r\n        <ion-item>\r\n          <ion-label position=\"floating\">Item</ion-label>\r\n          <ion-select [(ngModel)]=\"line.Item_No\" [selectedText]=\"line.Description\" placeholder=\"Select Item\">\r\n            <ion-select-option *ngFor=\"let item of items\" [value]=\"item.No\">{{ item.Description }}</ion-select-option>\r\n          </ion-select>\r\n        </ion-item>\r\n\r\n        <ion-item>\r\n          <ion-label position=\"floating\">Store</ion-label>\r\n          <ion-input [(ngModel)]=\"line.Store_Code\" type=\"text\" readonly></ion-input>\r\n          <!--<ion-select [(ngModel)]=\"line.Store_Code\" [selectedText]=\"line.Store_Name\" placeholder=\"Select Store\">\r\n            <ion-select-option *ngFor=\"let store of locations\" [value]=\"store.Code\">{{ store.Name }}</ion-select-option>\r\n          </ion-select>-->\r\n        </ion-item>\r\n\r\n        <ion-item>\r\n          <ion-label position=\"floating\"> Quantity.</ion-label>\r\n          <ion-input [(ngModel)]=\"line.Qty\" type=\"number\"></ion-input>\r\n        </ion-item>\r\n\r\n        <!---<ion-item>\r\n          <ion-label position=\"floating\"> Price</ion-label>\r\n          <ion-input [(ngModel)]=\"line.Price\" type=\"number\"></ion-input>\r\n        </ion-item>-->\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n      </ion-list>\r\n      <ion-button *ngIf=\"!line.Key\" color=\"primary\" (click)=\"addLine()\" expand=\"block\" fill=\"outline\">\r\n        Add Line\r\n      </ion-button>\r\n\r\n      <ion-button *ngIf=\"line.Key\" color=\"primary\" (click)=\"updateLine()\" expand=\"block\" fill=\"outline\">\r\n        Update Line\r\n      </ion-button>\r\n\r\n    </ion-col>\r\n  </ion-row>\r\n\r\n</ion-content>");

/***/ }),

/***/ "./src/app/items/item.service.ts":
/*!***************************************!*\
  !*** ./src/app/items/item.service.ts ***!
  \***************************************/
/*! exports provided: ItemService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ItemService", function() { return ItemService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");






let ItemService = class ItemService {
    constructor(http, toastCtrl) {
        this.http = http;
        this.toastCtrl = toastCtrl;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
    }
    get items() {
        return this.http.get(`${this.url}site/items`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    itemcard(id) {
        return this.http.get(`${this.url}site/itemcard/?id=${id}`);
    }
    itemBalance(No) {
        return this.http.get(`${this.url}site/itemavailabilitybylocation/?No=${No}`);
    }
    itemBalanceByLocation(No, LocationCode) {
        return this.http.get(`${this.url}site/itemavailabilitybylocation/?No=${No}&Location=${LocationCode}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    getTotals(elements, subjectColumn) {
        let sum = 0;
        elements.forEach(obj => {
            // console.log(obj);
            for (const property in obj) {
                if (property === subjectColumn && !isNaN(+obj[property])) {
                    // console.log(+obj[property]);
                    sum += +obj[property];
                }
            }
        });
        return sum;
    }
    // Get Locations List
    getLocations() {
        return this.http.get(`${this.url}site/locationlist`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    showToast(text) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return yield this.toastCtrl.create({
                message: text,
                duration: 4000,
                position: 'top'
            }).then(toastEl => {
                toastEl.present();
            });
        });
    }
};
ItemService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"] }
];
ItemService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], ItemService);



/***/ }),

/***/ "./src/app/models/cashreceiptline.model.ts":
/*!*************************************************!*\
  !*** ./src/app/models/cashreceiptline.model.ts ***!
  \*************************************************/
/*! exports provided: Cashreceiptline */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Cashreceiptline", function() { return Cashreceiptline; });
class Cashreceiptline {
    constructor(Key, Item_No, Description, Store_Code, Store_Name, Qty, Price, Total_Amount, POS_Receipt_No, Stock_Balance) {
        this.Key = Key;
        this.Item_No = Item_No;
        this.Description = Description;
        this.Store_Code = Store_Code;
        this.Store_Name = Store_Name;
        this.Qty = Qty;
        this.Price = Price;
        this.Total_Amount = Total_Amount;
        this.POS_Receipt_No = POS_Receipt_No;
        this.Stock_Balance = Stock_Balance;
    }
}


/***/ }),

/***/ "./src/app/payments/new-cash-line/new-cash-line.component.scss":
/*!*********************************************************************!*\
  !*** ./src/app/payments/new-cash-line/new-cash-line.component.scss ***!
  \*********************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BheW1lbnRzL25ldy1jYXNoLWxpbmUvbmV3LWNhc2gtbGluZS5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/payments/new-cash-line/new-cash-line.component.ts":
/*!*******************************************************************!*\
  !*** ./src/app/payments/new-cash-line/new-cash-line.component.ts ***!
  \*******************************************************************/
/*! exports provided: NewCashLineComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NewCashLineComponent", function() { return NewCashLineComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var src_app_requisitions_requisition_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/requisitions/requisition.service */ "./src/app/requisitions/requisition.service.ts");
/* harmony import */ var _payments_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../payments.service */ "./src/app/payments/payments.service.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var src_app_items_item_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/items/item.service */ "./src/app/items/item.service.ts");
/* harmony import */ var src_app_models_cashreceiptline_model__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/models/cashreceiptline.model */ "./src/app/models/cashreceiptline.model.ts");
/* harmony import */ var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! src/app/auth/auth-service */ "./src/app/auth/auth-service.ts");









let NewCashLineComponent = class NewCashLineComponent {
    constructor(paymentService, requisitionService, itemService, modalCtrl, alertCtrl, toastCtrl, loadingCtrl, authService) {
        this.paymentService = paymentService;
        this.requisitionService = requisitionService;
        this.itemService = itemService;
        this.modalCtrl = modalCtrl;
        this.alertCtrl = alertCtrl;
        this.toastCtrl = toastCtrl;
        this.loadingCtrl = loadingCtrl;
        this.authService = authService;
        this.items = [];
        this.line = new src_app_models_cashreceiptline_model__WEBPACK_IMPORTED_MODULE_7__["Cashreceiptline"]();
    }
    ngOnInit() {
        this.presentLoading();
        this.fetchItems();
        this.fetchLocations();
        this.setUser();
        this.line.Store_Code = this.Store_Code;
        if (this.Key) { //Update
            this.FetchLinetoUpdate();
        }
        else if (!this.Key) { // Create
            this.line.POS_Receipt_No = this.receiptNo;
        }
    }
    ionViewWillEnter() {
        this.setUser();
    }
    ionViewDidEnter() {
        this.setUser();
    }
    setUser() {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.user = yield this.authService.getUser();
            this.Store_Code = this.user.Store_Code;
            this.line.Store_Code = this.Store_Code;
        });
    }
    fetchLocations() {
        this.locationSub = this.requisitionService.getLocations()
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["finalize"])(() => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.loading.dismiss();
        })))
            .subscribe(res => {
            this.locations = res;
            // console.table(res);
        });
    }
    fetchItems() {
        this.itemSub = this.itemService.items
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["finalize"])(() => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.loading.dismiss();
        })))
            .subscribe(items => {
            this.items = items;
        });
    }
    InitLine() {
        this.setUser();
        console.log(`Store Code : ${this.Store_Code}`);
        this.paymentService.postLine(this.line).subscribe(line => {
            if (line) {
                this.line = line;
                this.line.Store_Code = this.Store_Code;
            }
            else {
                this.alertCtrl.create({
                    header: 'Operation Error',
                    message: 'Message : ' + line,
                    buttons: [{ text: 'Okay', handler: () => this.modalCtrl.dismiss() }]
                }).then(alertEl => {
                    alertEl.present();
                });
            }
        }, error => {
            console.log(error.error);
            this.alertCtrl.create({
                header: 'Service Error!',
                message: 'Connection problem: ' + error,
                buttons: [{ text: 'Okay', handler: () => this.modalCtrl.dismiss() }]
            })
                .then(alertEl => {
                alertEl.present();
            });
        });
    }
    addLine() {
        this.paymentService.postLine(this.line).subscribe(line => {
            console.log(line);
            if (line) {
                this.modalCtrl.dismiss();
                // Show a Toast Notification
                this.toastCtrl.create({
                    message: `Line Added Successfully.`,
                    duration: 2000,
                    position: 'top'
                }).then((toastData) => {
                    toastData.present();
                });
            }
            else {
                this.alertCtrl.create({
                    header: 'Operation Error',
                    message: 'Message : ' + line,
                    buttons: [{ text: 'Okay', handler: () => this.modalCtrl.dismiss() }]
                }).then(alertEl => {
                    alertEl.present();
                });
            }
        }, error => {
            console.log(error.error);
            this.alertCtrl.create({
                header: 'Service Error!',
                message: 'Connection problem: ' + error,
                buttons: [{ text: 'Okay', handler: () => this.modalCtrl.dismiss() }]
            })
                .then(alertEl => {
                alertEl.present();
            });
        });
    }
    updateLine() {
        this.paymentService.updateLine(this.line).subscribe(line => {
            if (typeof line !== 'string') {
                this.toastCtrl.create({
                    message: `${line.Description} Line Updated Successfully.`,
                    duration: 3000,
                    position: 'top'
                }).then((toastData) => {
                    toastData.present();
                });
                this.modalCtrl.dismiss();
            }
            else {
                // Alert the error
                this.alertCtrl.create({
                    header: 'Operation Error',
                    message: 'Message : ' + line,
                    buttons: [{ text: 'Okay', handler: () => this.modalCtrl.dismiss() }]
                }).then(alertEl => {
                    alertEl.present();
                });
            }
        }, error => {
            console.log(error.error);
            this.alertCtrl.create({
                header: 'Service Error!',
                message: 'Connection problem: ' + error.error.message,
                buttons: [{ text: 'Okay', handler: () => this.modalCtrl.dismiss() }]
            })
                .then(alertEl => {
                alertEl.present();
            });
        });
    }
    FetchLinetoUpdate() {
        this.updateLineSub = this.paymentService.getLine(this.Key)
            .subscribe(res => {
            Object.assign(this.line, res);
        }, error => {
            this.alertCtrl.create({
                header: 'Service Error!',
                message: 'Connection problem: ' + error.error.message,
                buttons: [{ text: 'Okay', handler: () => this.modalCtrl.dismiss() }]
            })
                .then(alertEl => {
                alertEl.present();
            });
        });
    }
    presentLoading(message) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.loading = yield this.loadingCtrl.create({
                spinner: 'dots',
                animated: true,
                message: (message) ? message : 'Loading..'
            });
            yield this.loading.present();
        });
    }
    onCancel() {
        this.modalCtrl.dismiss();
    }
    ngOnDestroy() {
        if (this.itemSub) {
            this.itemSub.unsubscribe();
        }
        if (this.locationSub) {
            this.locationSub.unsubscribe();
        }
        if (this.updateLineSub) {
            this.updateLineSub.unsubscribe();
        }
    }
};
NewCashLineComponent.ctorParameters = () => [
    { type: _payments_service__WEBPACK_IMPORTED_MODULE_4__["PaymentsService"] },
    { type: src_app_requisitions_requisition_service__WEBPACK_IMPORTED_MODULE_3__["RequisitionService"] },
    { type: src_app_items_item_service__WEBPACK_IMPORTED_MODULE_6__["ItemService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] },
    { type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_8__["AuthService"] }
];
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], NewCashLineComponent.prototype, "receiptNo", void 0);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], NewCashLineComponent.prototype, "Key", void 0);
NewCashLineComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-new-cash-line',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./new-cash-line.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/payments/new-cash-line/new-cash-line.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./new-cash-line.component.scss */ "./src/app/payments/new-cash-line/new-cash-line.component.scss")).default]
    })
], NewCashLineComponent);



/***/ }),

/***/ "./src/app/requisitions/requisition.service.ts":
/*!*****************************************************!*\
  !*** ./src/app/requisitions/requisition.service.ts ***!
  \*****************************************************/
/*! exports provided: RequisitionService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RequisitionService", function() { return RequisitionService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");






let RequisitionService = class RequisitionService {
    constructor(http) {
        this.http = http;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
        this._refresh$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__["Subject"]();
    }
    // Synthetic Getter for our refresh observerble
    get refresh$() {
        return this._refresh$;
    }
    getRequisitions(userID) {
        return this.http.get(`${this.url}site/requisitions?userid=${userID}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    get releasedrequisitions() {
        return this.http.get(`${this.url}site/releasedrequisitions`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    // Retrieve Requisition Card / Details
    requisitioncard(id) {
        return this.http.get(`${this.url}site/requisitioncard/?id=${id}`);
    }
    // Create New Requisition
    createRequisition(userID) {
        console.log('creator is:' + userID);
        return this.http.get(`${this.url}site/create-requisition?userid=${userID}`);
    }
    // get Units of Measure
    getunits(itemNo) {
        return this.http.get(`${this.url}site/unitmeasure?itemNo=${itemNo}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    // Get Locations List
    getLocations() {
        return this.http.get(`${this.url}site/locationlist`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    // Get any items from generic service getter function
    get Dimensions() {
        return this.http.get(`${this.url}site/get?service=Dimensions`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    get Departments() {
        return this.http.get(`${this.url}site/departments`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    get Projects() {
        return this.http.get(`${this.url}site/projects`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    // Post Lines Data
    postLine(line) {
        return this.http.post(`${this.url}site/requisition-lines`, JSON.stringify(line))
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(() => {
            this._refresh$.next();
        }));
    }
    // Update Line
    updateRequisitionLine(line) {
        return this.http.post(`${this.url}site/updaterequisitionline`, JSON.stringify(line))
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(() => {
            this._refresh$.next();
        }));
    }
    // Fetch Line to Update
    getLine(Key) {
        return this.http.get(`${this.url}site/requisition-lines?Key=${Key}`);
    }
    // Post Requisition Header
    postRequisition(requisition) {
        return this.http.post(`${this.url}site/update-requisition`, JSON.stringify(requisition));
    }
    // Format date utility
    formatDate(datestring) {
        // Format Date to YYYY-MM-DD
        const recDate = new Date(datestring);
        const month = (recDate.getMonth() + 1) > 9 ? recDate.getMonth() + 1 : `0` + (recDate.getMonth() + 1);
        const day = (recDate.getDate()) > 9 ? recDate.getDate() : `0` + recDate.getDate();
        return `${recDate.getFullYear()}-${month}-${day}`;
    }
};
RequisitionService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
RequisitionService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], RequisitionService);



/***/ }),

/***/ "./src/app/utility.service.ts":
/*!************************************!*\
  !*** ./src/app/utility.service.ts ***!
  \************************************/
/*! exports provided: UtilityService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UtilityService", function() { return UtilityService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");



let UtilityService = class UtilityService {
    constructor(toastCtrl, alertCtrl, loadingCtrl) {
        this.toastCtrl = toastCtrl;
        this.alertCtrl = alertCtrl;
        this.loadingCtrl = loadingCtrl;
    }
    formatDate(datestring) {
        // Format Date to YYYY-MM-DD
        const recDate = new Date(datestring);
        const month = (recDate.getMonth() + 1) > 9 ? recDate.getMonth() + 1 : `0` + (recDate.getMonth() + 1);
        const day = (recDate.getDate()) > 9 ? recDate.getDate() : `0` + recDate.getDate();
        return `${recDate.getFullYear()}-${month}-${day}`;
    }
    showToast(text) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            let toastEl = this.toastCtrl.create({
                message: text,
                duration: 4000,
                position: 'top'
            });
            (yield toastEl).present();
        });
    }
    showAlert(text) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alertEl = yield this.alertCtrl.create({
                header: 'Operation Error',
                message: 'Message : ' + text,
                buttons: [{ text: 'Okay' }]
            });
            yield alertEl.present();
        });
    }
    presentLoading(message) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingCtrl.create({
                spinner: 'dots',
                animated: true,
                message: (message) ? message : 'Loading Data...'
            });
            yield loading.present();
        });
    }
};
UtilityService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] }
];
UtilityService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], UtilityService);



/***/ })

}]);
//# sourceMappingURL=default~new-payment-new-payment-module~payment-detail-payment-detail-module~payments-new-payment-new~adb5fad1-es2015.js.map