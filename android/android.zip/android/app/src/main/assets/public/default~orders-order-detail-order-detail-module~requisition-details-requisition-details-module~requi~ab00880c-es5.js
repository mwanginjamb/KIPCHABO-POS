function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~orders-order-detail-order-detail-module~requisition-details-requisition-details-module~requi~ab00880c"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/requisitions/lines/lines.component.html":
  /*!***********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/requisitions/lines/lines.component.html ***!
    \***********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppRequisitionsLinesLinesComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>{{line.Line_No?'Update': 'New'}} Requisition Line</ion-title>\r\n\r\n    <ion-buttons slot=\"primary\">\r\n      <ion-button (click)=\"onCancel()\">\r\n        <ion-icon name=\"close\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <ion-row>\r\n    <ion-col size-sm=\"6\" offset-sm=\"3\">\r\n      <ion-list>\r\n\r\n        <ion-item>\r\n          <ion-label position=\"floating\">Item</ion-label>\r\n          <ion-select [(ngModel)]=\"line.Item_No\" (ionChange)=\"getUnit($event)\" [selectedText]=\"line.Description\" placeholder=\"Select Item\">\r\n            <ion-select-option *ngFor=\"let item of items\" [value]=\"item.No\" >{{ item.Description }}</ion-select-option>\r\n          </ion-select>\r\n        </ion-item>\r\n\r\n        <ion-item>\r\n          <ion-label position=\"floating\">Unit of Measure</ion-label>\r\n          <ion-select [(ngModel)] = \"line.U_O_M\" [selectedText]=\"line.U_O_M\" placeholder=\"Select Unit\">\r\n            <ion-select-option *ngFor=\"let unit of units\" [value]=\"unit.Code\" >{{ unit.Code }}</ion-select-option>\r\n          </ion-select>\r\n        </ion-item>\r\n\r\n        <ion-item>\r\n          <ion-label position=\"floating\">Requested Qty.</ion-label>\r\n          <ion-input [(ngModel)]=\"line.Pieces_To_Request\" type=\"number\"></ion-input>\r\n        </ion-item>\r\n\r\n        <!--<ion-item *ngIf=\"line.Line_No\">\r\n          <ion-label  position=\"floating\">Quantity Received</ion-label>\r\n          <ion-input [(ngModel)]=\"line.Quantity_Received\" type=\"number\"></ion-input>\r\n        </ion-item>\r\n\r\n        <ion-item *ngIf=\"line.Line_No\">\r\n          <ion-label position=\"floating\">Receipt Date</ion-label>\r\n          <ion-datetime [(ngModel)]=\"line.Receipt_Date\" type=\"number\" displayFormat=\"YYYY-MM-DD\"></ion-datetime>\r\n        </ion-item>\r\n      -->\r\n\r\n        \r\n\r\n\r\n      </ion-list>\r\n\r\n\r\n      <ion-button  *ngIf=\"!line.Line_No\" color=\"primary\" (click)=\"addLine()\" expand=\"block\" fill=\"outline\" >\r\n        Save Line\r\n      </ion-button>\r\n\r\n      <ion-button *ngIf=\"line.Line_No\"  color=\"primary\" (click)=\"updateLine()\" expand=\"block\" fill=\"outline\" >\r\n        Update Line\r\n      </ion-button>\r\n\r\n    </ion-col>\r\n  </ion-row>\r\n\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./src/app/items/item.service.ts":
  /*!***************************************!*\
    !*** ./src/app/items/item.service.ts ***!
    \***************************************/

  /*! exports provided: ItemService */

  /***/
  function srcAppItemsItemServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ItemService", function () {
      return ItemService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var ItemService = /*#__PURE__*/function () {
      function ItemService(http, toastCtrl) {
        _classCallCheck(this, ItemService);

        this.http = http;
        this.toastCtrl = toastCtrl;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
      }

      _createClass(ItemService, [{
        key: "items",
        get: function get() {
          return this.http.get("".concat(this.url, "site/items")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "itemcard",
        value: function itemcard(id) {
          return this.http.get("".concat(this.url, "site/itemcard/?id=").concat(id));
        }
      }, {
        key: "itemBalance",
        value: function itemBalance(No) {
          return this.http.get("".concat(this.url, "site/itemavailabilitybylocation/?No=").concat(No));
        }
      }, {
        key: "itemBalanceByLocation",
        value: function itemBalanceByLocation(No, LocationCode) {
          return this.http.get("".concat(this.url, "site/itemavailabilitybylocation/?No=").concat(No, "&Location=").concat(LocationCode)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "getTotals",
        value: function getTotals(elements, subjectColumn) {
          var sum = 0;
          elements.forEach(function (obj) {
            // console.log(obj);
            for (var property in obj) {
              if (property === subjectColumn && !isNaN(+obj[property])) {
                // console.log(+obj[property]);
                sum += +obj[property];
              }
            }
          });
          return sum;
        } // Get Locations List

      }, {
        key: "getLocations",
        value: function getLocations() {
          return this.http.get("".concat(this.url, "site/locationlist")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "showToast",
        value: function showToast(text) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.toastCtrl.create({
                      message: text,
                      duration: 4000,
                      position: 'top'
                    }).then(function (toastEl) {
                      toastEl.present();
                    });

                  case 2:
                    return _context.abrupt("return", _context.sent);

                  case 3:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }]);

      return ItemService;
    }();

    ItemService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"]
      }];
    };

    ItemService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], ItemService);
    /***/
  },

  /***/
  "./src/app/models/requisitionline.model.ts":
  /*!*************************************************!*\
    !*** ./src/app/models/requisitionline.model.ts ***!
    \*************************************************/

  /*! exports provided: Requisitionline */

  /***/
  function srcAppModelsRequisitionlineModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Requisitionline", function () {
      return Requisitionline;
    });

    var Requisitionline = function Requisitionline(Item_No, Description, U_O_M, Available_Stock_Kgs, Available_Stock_pieces, Pieces_To_Request, Line_No, Req_No) {
      _classCallCheck(this, Requisitionline);

      this.Item_No = Item_No;
      this.Description = Description;
      this.U_O_M = U_O_M;
      this.Available_Stock_Kgs = Available_Stock_Kgs;
      this.Available_Stock_pieces = Available_Stock_pieces;
      this.Pieces_To_Request = Pieces_To_Request;
      this.Line_No = Line_No;
      this.Req_No = Req_No;
    };
    /***/

  },

  /***/
  "./src/app/requisitions/lines/lines.component.scss":
  /*!*********************************************************!*\
    !*** ./src/app/requisitions/lines/lines.component.scss ***!
    \*********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppRequisitionsLinesLinesComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3JlcXVpc2l0aW9ucy9saW5lcy9saW5lcy5jb21wb25lbnQuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/requisitions/lines/lines.component.ts":
  /*!*******************************************************!*\
    !*** ./src/app/requisitions/lines/lines.component.ts ***!
    \*******************************************************/

  /*! exports provided: Planning_Flexibility, LinesComponent */

  /***/
  function srcAppRequisitionsLinesLinesComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Planning_Flexibility", function () {
      return Planning_Flexibility;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "LinesComponent", function () {
      return LinesComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _items_item_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ../../items/item.service */
    "./src/app/items/item.service.ts");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _requisition_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../requisition.service */
    "./src/app/requisitions/requisition.service.ts");
    /* harmony import */


    var src_app_models_requisitionline_model__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/models/requisitionline.model */
    "./src/app/models/requisitionline.model.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");

    var Planning_Flexibility;

    (function (Planning_Flexibility) {
      Planning_Flexibility["a"] = "Unlimited";
      Planning_Flexibility["b"] = "None";
    })(Planning_Flexibility || (Planning_Flexibility = {}));

    var LinesComponent = /*#__PURE__*/function () {
      function LinesComponent(itemService, requisitionService, modalCtrl, navCtrl, toastCtrl, alertCtrl, loadingCtrl, router) {
        _classCallCheck(this, LinesComponent);

        this.itemService = itemService;
        this.requisitionService = requisitionService;
        this.modalCtrl = modalCtrl;
        this.navCtrl = navCtrl;
        this.toastCtrl = toastCtrl;
        this.alertCtrl = alertCtrl;
        this.loadingCtrl = loadingCtrl;
        this.router = router;
        this.items = [];
        this.units = [];
        this.line = new src_app_models_requisitionline_model__WEBPACK_IMPORTED_MODULE_5__["Requisitionline"]();
      }

      _createClass(LinesComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this = this;

          this.presentLoading('Loading Items...');
          this.itemSub = this.itemService.items.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["finalize"])(function () {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
              return regeneratorRuntime.wrap(function _callee2$(_context2) {
                while (1) {
                  switch (_context2.prev = _context2.next) {
                    case 0:
                      _context2.next = 2;
                      return this.loading.dismiss();

                    case 2:
                    case "end":
                      return _context2.stop();
                  }
                }
              }, _callee2, this);
            }));
          })).subscribe(function (items) {
            _this.items = items;
          }); // If a Line_No is provided, then we are updating

          if (this.Key) {
            this.FetchLinetoUpdate();
          }
        }
      }, {
        key: "getUnit",
        value: function getUnit($event) {
          var _this2 = this;

          this.unitSub = this.requisitionService.getunits(this.line.Item_No).subscribe(function (units) {
            _this2.units = units;
            _this2.line.Req_No = _this2.docId; // console.log(this.docId);
          });
        }
      }, {
        key: "addLine",
        value: function addLine() {
          var _this3 = this;

          this.requisitionService.postLine(this.line).subscribe(function (line) {
            console.log(line);

            if (typeof line == 'object') {
              _this3.modalCtrl.dismiss(); // Show a Toast Notification


              _this3.toastCtrl.create({
                message: "Requisition Line Added Successfully.",
                duration: 2000,
                position: 'top'
              }).then(function (toastData) {
                toastData.present();
              });
            } else {
              _this3.alertCtrl.create({
                header: 'Operation Error',
                message: 'Error : ' + line,
                buttons: [{
                  text: 'Okay',
                  handler: function handler() {
                    return _this3.modalCtrl.dismiss();
                  }
                }]
              }).then(function (alertEl) {
                alertEl.present();
              });
            }
          }, function (error) {
            console.log(error.error);

            _this3.alertCtrl.create({
              header: 'Service Error!',
              message: 'Connection problem: ' + error,
              buttons: [{
                text: 'Okay',
                handler: function handler() {
                  return _this3.modalCtrl.dismiss();
                }
              }]
            }).then(function (alertEl) {
              alertEl.present();
            });
          });
        }
      }, {
        key: "updateLine",
        value: function updateLine() {
          var _this4 = this;

          // Format Date to YYYY-MM-DD
          // const recDate = new Date(this.line.Receipt_Date);
          // const month = (recDate.getMonth() + 1) > 9 ? recDate.getMonth() + 1 : `0` + (recDate.getMonth() + 1);
          // const day = ( recDate.getDate() ) > 9 ? recDate.getDate() : `0` + recDate.getDate();
          // this.line.Receipt_Date =  `${recDate.getFullYear()}-${month}-${day}`;
          // console.table(this.line); return;
          this.requisitionService.updateRequisitionLine(this.line).subscribe(function (line) {
            if (typeof line !== 'string') {
              console.log("Updated Line.......");
              console.table(line);

              _this4.toastCtrl.create({
                message: "".concat(line.Description, " Requisition Line Updated Successfully."),
                duration: 3000,
                position: 'top'
              }).then(function (toastData) {
                toastData.present();
              });

              _this4.modalCtrl.dismiss(); // this.router.navigate(['/requisitions/' + line.Document_No]);

            } else {
              // Alert the error
              _this4.alertCtrl.create({
                header: 'Operation Error',
                message: 'Message : ' + line,
                buttons: [{
                  text: 'Okay',
                  handler: function handler() {
                    return _this4.modalCtrl.dismiss();
                  }
                }]
              }).then(function (alertEl) {
                alertEl.present();
              });
            }
          }, function (error) {
            console.log(error.error);

            _this4.alertCtrl.create({
              header: 'Service Error!',
              message: 'Connection problem: ' + error.error,
              buttons: [{
                text: 'Okay',
                handler: function handler() {
                  return _this4.modalCtrl.dismiss();
                }
              }]
            }).then(function (alertEl) {
              alertEl.present();
            });
          });
        }
      }, {
        key: "FetchLinetoUpdate",
        value: function FetchLinetoUpdate() {
          var _this5 = this;

          this.updateLineSub = this.requisitionService.getLine(this.Key).subscribe(function (res) {
            Object.assign(_this5.line, res);
          }, function (error) {
            console.log(error.error);

            _this5.alertCtrl.create({
              header: 'Service Error!',
              message: 'Connection problem: ' + error.error.message,
              buttons: [{
                text: 'Okay',
                handler: function handler() {
                  return _this5.modalCtrl.dismiss();
                }
              }]
            }).then(function (alertEl) {
              alertEl.present();
            });
          });
        } // Closing component modal

      }, {
        key: "onCancel",
        value: function onCancel() {
          this.modalCtrl.dismiss();
        }
      }, {
        key: "presentLoading",
        value: function presentLoading(message) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.loadingCtrl.create({
                      spinner: 'dots',
                      animated: true,
                      message: message ? message : 'Loading..'
                    });

                  case 2:
                    this.loading = _context3.sent;
                    _context3.next = 5;
                    return this.loading.present();

                  case 5:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          if (this.itemSub) {
            this.itemSub.unsubscribe();
          }

          if (this.unitSub) {
            this.unitSub.unsubscribe();
          }

          if (this.updateLineSub) {
            this.updateLineSub.unsubscribe();
          }
        }
      }]);

      return LinesComponent;
    }();

    LinesComponent.ctorParameters = function () {
      return [{
        type: _items_item_service__WEBPACK_IMPORTED_MODULE_2__["ItemService"]
      }, {
        type: _requisition_service__WEBPACK_IMPORTED_MODULE_4__["RequisitionService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ModalController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["NavController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["AlertController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["LoadingController"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"]
      }];
    };

    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], LinesComponent.prototype, "docId", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], LinesComponent.prototype, "Key", void 0);
    LinesComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-lines',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./lines.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/requisitions/lines/lines.component.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./lines.component.scss */
      "./src/app/requisitions/lines/lines.component.scss"))["default"]]
    })], LinesComponent);
    /***/
  }
}]);
//# sourceMappingURL=default~orders-order-detail-order-detail-module~requisition-details-requisition-details-module~requi~ab00880c-es5.js.map