function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["customers-customers-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/customers/customers.page.html":
  /*!*************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/customers/customers.page.html ***!
    \*************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppCustomersCustomersPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n\r\n    <ion-title>My Customers</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content *ngIf=\"customers\">\r\n\r\n  <ion-searchbar [(ngModel)]=\"searchTerm\" debounce=\"2000\" (ionChange)=\"search($event)\" placeholder=\"Search Requisition\">\r\n  </ion-searchbar>\r\n\r\n  <ion-grid>\r\n    <ion-row>\r\n      <ion-col size=\"3\">Name</ion-col>\r\n      <ion-col size=\"3\">Region</ion-col>\r\n      <ion-col size=\"3\">Location</ion-col>\r\n      <ion-col size=\"3\">Phone No.</ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n\r\n  <ion-virtual-scroll [items]=\"customers\" approxItemHeight=\"47.2px\">\r\n\r\n    <ion-item *virtualItem=\"let cust\">\r\n\r\n      <ion-grid>\r\n        <ion-row>\r\n\r\n          <ion-col size=\"3\">\r\n            <ion-label>\r\n              <h3>{{ cust?.Name }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n\r\n          <ion-col size=\"3\">\r\n            <ion-label>\r\n              <h3>{{ cust.Country_Region_Code }}</h3>\r\n              </ion-label>\r\n          </ion-col>\r\n          <ion-col size=\"3\">\r\n            <ion-label>\r\n              <h3>{{ cust.Location_Market }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n              \r\n          <ion-col size=\"3\">\r\n                <ion-label>\r\n                  <h3>{{ cust.Phone_No }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n\r\n        </ion-row>\r\n      </ion-grid>\r\n\r\n    </ion-item>\r\n\r\n  </ion-virtual-scroll>\r\n\r\n\r\n\r\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/customers/customers-routing.module.ts":
  /*!*******************************************************!*\
    !*** ./src/app/customers/customers-routing.module.ts ***!
    \*******************************************************/

  /*! exports provided: CustomersPageRoutingModule */

  /***/
  function srcAppCustomersCustomersRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CustomersPageRoutingModule", function () {
      return CustomersPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _customers_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./customers.page */
    "./src/app/customers/customers.page.ts");

    var routes = [{
      path: '',
      component: _customers_page__WEBPACK_IMPORTED_MODULE_3__["CustomersPage"]
    }, {
      path: 'customer-detail',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | customer-detail-customer-detail-module */
        "customer-detail-customer-detail-module").then(__webpack_require__.bind(null,
        /*! ./customer-detail/customer-detail.module */
        "./src/app/customers/customer-detail/customer-detail.module.ts")).then(function (m) {
          return m.CustomerDetailPageModule;
        });
      }
    }];

    var CustomersPageRoutingModule = function CustomersPageRoutingModule() {
      _classCallCheck(this, CustomersPageRoutingModule);
    };

    CustomersPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], CustomersPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/customers/customers.module.ts":
  /*!***********************************************!*\
    !*** ./src/app/customers/customers.module.ts ***!
    \***********************************************/

  /*! exports provided: CustomersPageModule */

  /***/
  function srcAppCustomersCustomersModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CustomersPageModule", function () {
      return CustomersPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _customers_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./customers-routing.module */
    "./src/app/customers/customers-routing.module.ts");
    /* harmony import */


    var _customers_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./customers.page */
    "./src/app/customers/customers.page.ts");

    var CustomersPageModule = function CustomersPageModule() {
      _classCallCheck(this, CustomersPageModule);
    };

    CustomersPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _customers_routing_module__WEBPACK_IMPORTED_MODULE_5__["CustomersPageRoutingModule"]],
      declarations: [_customers_page__WEBPACK_IMPORTED_MODULE_6__["CustomersPage"]]
    })], CustomersPageModule);
    /***/
  },

  /***/
  "./src/app/customers/customers.page.scss":
  /*!***********************************************!*\
    !*** ./src/app/customers/customers.page.scss ***!
    \***********************************************/

  /*! exports provided: default */

  /***/
  function srcAppCustomersCustomersPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2N1c3RvbWVycy9jdXN0b21lcnMucGFnZS5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/customers/customers.page.ts":
  /*!*********************************************!*\
    !*** ./src/app/customers/customers.page.ts ***!
    \*********************************************/

  /*! exports provided: CustomersPage */

  /***/
  function srcAppCustomersCustomersPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CustomersPage", function () {
      return CustomersPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _auth_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../auth/auth-service */
    "./src/app/auth/auth-service.ts");
    /* harmony import */


    var _payments_payments_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../payments/payments.service */
    "./src/app/payments/payments.service.ts");
    /* harmony import */


    var _utility_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../utility.service */
    "./src/app/utility.service.ts");

    var CustomersPage = /*#__PURE__*/function () {
      function CustomersPage(utilitySvc, paymentService, authSvc) {
        _classCallCheck(this, CustomersPage);

        this.utilitySvc = utilitySvc;
        this.paymentService = paymentService;
        this.authSvc = authSvc;
        this.customers = null;
        this.searchTerm = null;
      }

      _createClass(CustomersPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.setUser();
        }
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.setUser();
        }
      }, {
        key: "ionViewDidEnter",
        value: function ionViewDidEnter() {
          this.FetchCustomers();
        }
      }, {
        key: "FetchCustomers",
        value: function FetchCustomers() {
          var _this = this;

          this.utilitySvc.presentLoading('Loading Customers ....');
          this.customerListSub = this.paymentService.CustomerBySalesPerson(this.userID).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["finalize"])(function () {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      this.utilitySvc.loadingCtrl.dismiss();

                    case 1:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          })).subscribe(function (cust) {
            console.log(cust);
            _this.customers = cust;
          });
        }
      }, {
        key: "setUser",
        value: function setUser() {
          var _a;

          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.authSvc.getUser();

                  case 2:
                    this.user = _context2.sent;
                    this.userID = (_a = this.user) === null || _a === void 0 ? void 0 : _a.User_ID;

                  case 4:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "search",
        value: function search($event) {
          var _this2 = this;

          // get a copy of requisitions
          var searchItems = _toConsumableArray(this.customers); // Begin search, only if searchTerm is provided


          if (this.searchTerm.trim().length && this.searchTerm !== '') {
            this.customers = searchItems.filter(function (req) {
              if (req.Name && req.Name.length > 1) {
                return req.Name.toLowerCase().indexOf(_this2.searchTerm.toLowerCase()) > -1;
              }
            });
            return;
          } else {
            // Search Term not provided display all requisitions
            this.initializeItems();
          }
        }
      }, {
        key: "initializeItems",
        value: function initializeItems() {
          this.FetchCustomers();
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          if (this.customerListSub) {
            this.customerListSub.unsubscribe();
          }
        }
      }]);

      return CustomersPage;
    }();

    CustomersPage.ctorParameters = function () {
      return [{
        type: _utility_service__WEBPACK_IMPORTED_MODULE_5__["UtilityService"]
      }, {
        type: _payments_payments_service__WEBPACK_IMPORTED_MODULE_4__["PaymentsService"]
      }, {
        type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]
      }];
    };

    CustomersPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-customers',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./customers.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/customers/customers.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./customers.page.scss */
      "./src/app/customers/customers.page.scss"))["default"]]
    })], CustomersPage);
    /***/
  },

  /***/
  "./src/app/orders/order.service.ts":
  /*!*****************************************!*\
    !*** ./src/app/orders/order.service.ts ***!
    \*****************************************/

  /*! exports provided: OrderService */

  /***/
  function srcAppOrdersOrderServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "OrderService", function () {
      return OrderService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");

    var OrderService = /*#__PURE__*/function () {
      // private items  = new BehaviorSubject<[]>([]) ;
      function OrderService(http) {
        _classCallCheck(this, OrderService);

        this.http = http;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
      }

      _createClass(OrderService, [{
        key: "orders",
        get: function get() {
          return this.http.get("".concat(this.url, "site/saleinvoices")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        } // Create New Sales Invoice

      }, {
        key: "createInvoice",
        value: function createInvoice() {
          return this.http.get("".concat(this.url, "site/create-invoice"));
        } // Retrieve Sales Invoice Card / Details

      }, {
        key: "ordercard",
        value: function ordercard(id) {
          return this.http.get("".concat(this.url, "site/saleinvoice/?id=").concat(id));
        } // Post Lines Data

      }, {
        key: "postLine",
        value: function postLine(line) {
          return this.http.post("".concat(this.url, "site/addsalesinvoiceline"), JSON.stringify(line));
        } // Update Line

      }, {
        key: "updateInvoiceLine",
        value: function updateInvoiceLine(line) {
          return this.http.post("".concat(this.url, "site/updatesalesinvoiceline"), JSON.stringify(line));
        } // Fetch Line to Update

      }, {
        key: "getLine",
        value: function getLine(docId, LineNo) {
          return this.http.get("".concat(this.url, "site/getsalesinvoiceline?Document_No=").concat(docId, "&Line_No=").concat(LineNo));
        } // Post Invoice Header

      }, {
        key: "postInvoice",
        value: function postInvoice(invoice) {
          invoice.Posting_Date = this.formatDate(invoice.Posting_Date);
          invoice.Due_Date = this.formatDate(invoice.Due_Date);
          return this.http.post("".concat(this.url, "site/update-invoice"), JSON.stringify(invoice));
        } // Get Customers

      }, {
        key: "Customers",
        get: function get() {
          return this.http.get("".concat(this.url, "site/receipting-customers")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "postSalesInvoice",
        value: function postSalesInvoice(No) {
          return this.http.get("".concat(this.url, "site/postsaleinvoice?No=").concat(No));
        } // Format date utility

      }, {
        key: "formatDate",
        value: function formatDate(datestring) {
          // Format Date to YYYY-MM-DD
          var recDate = new Date(datestring);
          var month = recDate.getMonth() + 1 > 9 ? recDate.getMonth() + 1 : "0" + (recDate.getMonth() + 1);
          var day = recDate.getDate() > 9 ? recDate.getDate() : "0" + recDate.getDate();
          return "".concat(recDate.getFullYear(), "-").concat(month, "-").concat(day);
        }
      }]);

      return OrderService;
    }();

    OrderService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }];
    };

    OrderService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], OrderService);
    /***/
  },

  /***/
  "./src/app/payments/payments.service.ts":
  /*!**********************************************!*\
    !*** ./src/app/payments/payments.service.ts ***!
    \**********************************************/

  /*! exports provided: PaymentsService */

  /***/
  function srcAppPaymentsPaymentsServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PaymentsService", function () {
      return PaymentsService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _orders_order_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../orders/order.service */
    "./src/app/orders/order.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");

    var PaymentsService = /*#__PURE__*/function () {
      function PaymentsService(http, orderService, toastCtrl) {
        _classCallCheck(this, PaymentsService);

        this.http = http;
        this.orderService = orderService;
        this.toastCtrl = toastCtrl;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].url;
        this._refresh$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__["Subject"]();
      } // Define a synthetic getter for the subject


      _createClass(PaymentsService, [{
        key: "refresh$",
        get: function get() {
          return this._refresh$;
        }
      }, {
        key: "newPayment",
        value: function newPayment(receipt) {
          return this.http.post("".concat(this.url, "site/cash-sale"), JSON.stringify(receipt));
        }
      }, {
        key: "updateReceipt",
        value: function updateReceipt(receipt) {
          return this.http.post("".concat(this.url, "site/cash-sale"), JSON.stringify(receipt));
        }
      }, {
        key: "getPayments",
        value: function getPayments(userID) {
          return this.http.get("".concat(this.url, "site/get?service=POSReceiptList&userid=").concat(userID)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "getPayment",
        value: function getPayment(id) {
          return this.http.get("".concat(this.url, "site/receipt/?id=").concat(id)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "Banks",
        get: function get() {
          return this.http.get("".concat(this.url, "site/get?service=BankAccounts")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "getLine",
        value: function getLine(Key) {
          return this.http.get("".concat(this.url, "site/cash-sale-line?Key=").concat(Key));
        }
      }, {
        key: "suggestlines",
        value: function suggestlines(receiptNo, customerNo) {
          return this.http.get("".concat(this.url, "site/suggestlines?receiptNo=").concat(receiptNo, "&customerNo=").concat(customerNo)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        } // Post Lines Data

      }, {
        key: "postLine",
        value: function postLine(line) {
          var _this3 = this;

          return this.http.post("".concat(this.url, "site/cash-sale-line"), JSON.stringify(line)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function () {
            _this3._refresh$.next();
          }));
        } // Update Line

      }, {
        key: "updateLine",
        value: function updateLine(line) {
          var _this4 = this;

          return this.http.post("".concat(this.url, "site/cash-sale-line"), JSON.stringify(line)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function () {
            _this4._refresh$.next();
          }));
        }
      }, {
        key: "Customers",
        get: function get() {
          return this.http.get("".concat(this.url, "site/receipting-customers")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
        /*
         * Get Customer By Search Name
         */

      }, {
        key: "Customer",
        value: function Customer(searchName) {
          return this.http.get("".concat(this.url, "site/receipting-customers?searchName=").concat(searchName)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
        /*
         * Get Customer By Sales Person Code
         */

      }, {
        key: "CustomerBySalesPerson",
        value: function CustomerBySalesPerson(salesPersonCode) {
          return this.http.get("".concat(this.url, "site/receipting-customers?Salesperson_Code=").concat(salesPersonCode)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        } // Get CustomerPriceGroups

      }, {
        key: "CustomerPriceGroups",
        value: function CustomerPriceGroups() {
          return this.http.get("".concat(this.url, "site/get?service=CustomerPriceGroups")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "Mpesa",
        value: function Mpesa() {
          return this.http.get("".concat(this.url, "site/get?service=MPESATransactions")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "selectLine",
        value: function selectLine(CustomerNo, Line, ReceiptNo) {
          var payload = {
            Customer_No: CustomerNo,
            Line_No: Line,
            Receipt_No: ReceiptNo
          };
          return this.http.post("".concat(this.url, "site/updatecashreceiptline"), JSON.stringify(payload));
        }
      }, {
        key: "setAmountToReceipt",
        value: function setAmountToReceipt(CustomerNo, Line, ReceiptNo, AmountToReceipt) {
          var payload = {
            Customer_No: CustomerNo,
            Line_No: Line,
            Receipt_No: ReceiptNo,
            Amount_To_Receipt: AmountToReceipt
          }; // console.log(payload); return;

          return this.http.post("".concat(this.url, "site/updateamounttoreceipt"), JSON.stringify(payload));
        }
      }, {
        key: "postReceipt",
        value: function postReceipt(No) {
          return this.http.get("".concat(this.url, "site/postreceipt?No=").concat(No));
        }
      }, {
        key: "getTotals",
        value: function getTotals(elements, subjectColumn) {
          var sum = 0;
          elements.forEach(function (obj) {
            // console.log(obj);
            for (var property in obj) {
              if (property === subjectColumn && !isNaN(+obj[property])) {
                // console.log(+obj[property]);
                sum += +obj[property];
              }
            }
          });
          return sum;
        }
      }, {
        key: "showToast",
        value: function showToast(text) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.toastCtrl.create({
                      message: text,
                      duration: 4000,
                      position: 'top'
                    }).then(function (toastEl) {
                      toastEl.present();
                    });

                  case 2:
                    return _context3.abrupt("return", _context3.sent);

                  case 3:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "formatDate",
        value: function formatDate(date) {
          return this.orderService.formatDate(date);
        }
      }, {
        key: "FilterReceipts",
        value: function FilterReceipts(startDate, userID) {
          return this.http.get("".concat(this.url, "site/filterpayments?startdate=").concat(startDate, "&userid=").concat(userID)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "FilterReceiptsbyRange",
        value: function FilterReceiptsbyRange(startDate, endDate, userID) {
          return this.http.get("".concat(this.url, "site/filterpayments?startdate=").concat(startDate, "&enddate=").concat(endDate, "&userid=").concat(userID)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }]);

      return PaymentsService;
    }();

    PaymentsService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]
      }, {
        type: _orders_order_service__WEBPACK_IMPORTED_MODULE_5__["OrderService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"]
      }];
    };

    PaymentsService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], PaymentsService);
    /***/
  },

  /***/
  "./src/app/utility.service.ts":
  /*!************************************!*\
    !*** ./src/app/utility.service.ts ***!
    \************************************/

  /*! exports provided: UtilityService */

  /***/
  function srcAppUtilityServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "UtilityService", function () {
      return UtilityService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var UtilityService = /*#__PURE__*/function () {
      function UtilityService(toastCtrl, alertCtrl, loadingCtrl) {
        _classCallCheck(this, UtilityService);

        this.toastCtrl = toastCtrl;
        this.alertCtrl = alertCtrl;
        this.loadingCtrl = loadingCtrl;
      }

      _createClass(UtilityService, [{
        key: "formatDate",
        value: function formatDate(datestring) {
          // Format Date to YYYY-MM-DD
          var recDate = new Date(datestring);
          var month = recDate.getMonth() + 1 > 9 ? recDate.getMonth() + 1 : "0" + (recDate.getMonth() + 1);
          var day = recDate.getDate() > 9 ? recDate.getDate() : "0" + recDate.getDate();
          return "".concat(recDate.getFullYear(), "-").concat(month, "-").concat(day);
        }
      }, {
        key: "showToast",
        value: function showToast(text) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            var toastEl;
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    toastEl = this.toastCtrl.create({
                      message: text,
                      duration: 4000,
                      position: 'top'
                    });
                    _context4.next = 3;
                    return toastEl;

                  case 3:
                    _context4.sent.present();

                  case 4:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this);
          }));
        }
      }, {
        key: "showAlert",
        value: function showAlert(text) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
            var alertEl;
            return regeneratorRuntime.wrap(function _callee5$(_context5) {
              while (1) {
                switch (_context5.prev = _context5.next) {
                  case 0:
                    _context5.next = 2;
                    return this.alertCtrl.create({
                      header: 'Operation Error',
                      message: 'Message : ' + text,
                      buttons: [{
                        text: 'Okay'
                      }]
                    });

                  case 2:
                    alertEl = _context5.sent;
                    _context5.next = 5;
                    return alertEl.present();

                  case 5:
                  case "end":
                    return _context5.stop();
                }
              }
            }, _callee5, this);
          }));
        }
      }, {
        key: "presentLoading",
        value: function presentLoading(message) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
            var loading;
            return regeneratorRuntime.wrap(function _callee6$(_context6) {
              while (1) {
                switch (_context6.prev = _context6.next) {
                  case 0:
                    _context6.next = 2;
                    return this.loadingCtrl.create({
                      spinner: 'dots',
                      animated: true,
                      message: message ? message : 'Loading Data...'
                    });

                  case 2:
                    loading = _context6.sent;
                    _context6.next = 5;
                    return loading.present();

                  case 5:
                  case "end":
                    return _context6.stop();
                }
              }
            }, _callee6, this);
          }));
        }
      }]);

      return UtilityService;
    }();

    UtilityService.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]
      }];
    };

    UtilityService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], UtilityService);
    /***/
  }
}]);
//# sourceMappingURL=customers-customers-module-es5.js.map