function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~return-return-card-return-card-module~return-return-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/return/return-line/return-line.component.html":
  /*!*****************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/return/return-line/return-line.component.html ***!
    \*****************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppReturnReturnLineReturnLineComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>{{line.No?'Update': 'New'}} Return Line</ion-title>\r\n\r\n    <ion-buttons slot=\"primary\">\r\n      <ion-button (click)=\"onCancel()\">\r\n        <ion-icon name=\"close\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content padding>\r\n  <ion-row>\r\n    <ion-col size-sm=\"6\" offset-sm=\"3\">\r\n      <ion-list>\r\n\r\n        <ion-item>\r\n          <ion-label position=\"floating\">Item</ion-label>\r\n          <ion-select [(ngModel)]=\"line.Item_No\" [selectedText]=\"line.Description\" placeholder=\"Select Item\">\r\n            <ion-select-option *ngFor=\"let item of items\" [value]=\"item.No\">{{ item.Description }}</ion-select-option>\r\n          </ion-select>\r\n        </ion-item>\r\n\r\n        <ion-item>\r\n          <ion-label position=\"floating\">Store</ion-label>\r\n          <ion-select [(ngModel)]=\"line.Store_Code\" [selectedText]=\"line.Store_Name\" placeholder=\"Select Store\">\r\n            <ion-select-option *ngFor=\"let loc of locations\" [value]=\"loc.Code\">{{ loc.Name }}\r\n            </ion-select-option>\r\n          </ion-select>\r\n        </ion-item>\r\n\r\n        <ion-item>\r\n          <ion-label position=\"floating\">Qty.</ion-label>\r\n          <ion-input [(ngModel)]=\"line.Quantity\" type=\"number\"></ion-input>\r\n        </ion-item>\r\n\r\n        <ion-item>\r\n          <ion-label position=\"floating\">Price</ion-label>\r\n          <ion-input [(ngModel)]=\"line.Price\" type=\"number\"></ion-input>\r\n        </ion-item>\r\n\r\n        <!--<ion-item *ngIf=\"line.Line_No\">\r\n          <ion-label position=\"floating\">Receipt Date</ion-label>\r\n          <ion-datetime [(ngModel)]=\"line.Receipt_Date\" type=\"number\" displayFormat=\"YYYY-MM-DD\"></ion-datetime>\r\n        </ion-item>\r\n      -->\r\n\r\n\r\n\r\n\r\n      </ion-list>\r\n\r\n\r\n      <ion-button *ngIf=\"!line.No\" color=\"primary\" (click)=\"addLine()\" expand=\"block\" fill=\"outline\">\r\n        Save Line\r\n      </ion-button>\r\n\r\n      <ion-button *ngIf=\"line.No\" color=\"primary\" (click)=\"updateLine()\" expand=\"block\" fill=\"outline\">\r\n        Update Line\r\n      </ion-button>\r\n\r\n    </ion-col>\r\n  </ion-row>\r\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/items/item.service.ts":
  /*!***************************************!*\
    !*** ./src/app/items/item.service.ts ***!
    \***************************************/

  /*! exports provided: ItemService */

  /***/
  function srcAppItemsItemServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ItemService", function () {
      return ItemService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var ItemService = /*#__PURE__*/function () {
      function ItemService(http, toastCtrl) {
        _classCallCheck(this, ItemService);

        this.http = http;
        this.toastCtrl = toastCtrl;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
      }

      _createClass(ItemService, [{
        key: "items",
        get: function get() {
          return this.http.get("".concat(this.url, "site/items")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "itemcard",
        value: function itemcard(id) {
          return this.http.get("".concat(this.url, "site/itemcard/?id=").concat(id));
        }
      }, {
        key: "itemBalance",
        value: function itemBalance(No) {
          return this.http.get("".concat(this.url, "site/itemavailabilitybylocation/?No=").concat(No));
        }
      }, {
        key: "itemBalanceByLocation",
        value: function itemBalanceByLocation(No, LocationCode) {
          return this.http.get("".concat(this.url, "site/itemavailabilitybylocation/?No=").concat(No, "&Location=").concat(LocationCode)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "getTotals",
        value: function getTotals(elements, subjectColumn) {
          var sum = 0;
          elements.forEach(function (obj) {
            // console.log(obj);
            for (var property in obj) {
              if (property === subjectColumn && !isNaN(+obj[property])) {
                // console.log(+obj[property]);
                sum += +obj[property];
              }
            }
          });
          return sum;
        } // Get Locations List

      }, {
        key: "getLocations",
        value: function getLocations() {
          return this.http.get("".concat(this.url, "site/locationlist")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "showToast",
        value: function showToast(text) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.toastCtrl.create({
                      message: text,
                      duration: 4000,
                      position: 'top'
                    }).then(function (toastEl) {
                      toastEl.present();
                    });

                  case 2:
                    return _context.abrupt("return", _context.sent);

                  case 3:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }]);

      return ItemService;
    }();

    ItemService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"]
      }];
    };

    ItemService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], ItemService);
    /***/
  },

  /***/
  "./src/app/models/return.model.ts":
  /*!****************************************!*\
    !*** ./src/app/models/return.model.ts ***!
    \****************************************/

  /*! exports provided: Return */

  /***/
  function srcAppModelsReturnModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Return", function () {
      return Return;
    });

    var Return = function Return(Key, No, Return_Date, Customer_No, Customer_Name, Applies_to_Invoice_No, Created_By, Created_On, POS_Return_Lines) {
      _classCallCheck(this, Return);

      this.Key = Key;
      this.No = No;
      this.Return_Date = Return_Date;
      this.Customer_No = Customer_No;
      this.Customer_Name = Customer_Name;
      this.Applies_to_Invoice_No = Applies_to_Invoice_No;
      this.Created_By = Created_By;
      this.Created_On = Created_On;
      this.POS_Return_Lines = POS_Return_Lines;
    };
    /***/

  },

  /***/
  "./src/app/models/returnline.model.ts":
  /*!********************************************!*\
    !*** ./src/app/models/returnline.model.ts ***!
    \********************************************/

  /*! exports provided: Returnline */

  /***/
  function srcAppModelsReturnlineModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Returnline", function () {
      return Returnline;
    });

    var Returnline = function Returnline(Key, No, Item_No, Description, Store_Code, Store_Name, Quantity, Price, Amount) {
      _classCallCheck(this, Returnline);

      this.Key = Key;
      this.No = No;
      this.Item_No = Item_No;
      this.Description = Description;
      this.Store_Code = Store_Code;
      this.Store_Name = Store_Name;
      this.Quantity = Quantity;
      this.Price = Price;
      this.Amount = Amount;
    };
    /***/

  },

  /***/
  "./src/app/orders/order.service.ts":
  /*!*****************************************!*\
    !*** ./src/app/orders/order.service.ts ***!
    \*****************************************/

  /*! exports provided: OrderService */

  /***/
  function srcAppOrdersOrderServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "OrderService", function () {
      return OrderService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");

    var OrderService = /*#__PURE__*/function () {
      // private items  = new BehaviorSubject<[]>([]) ;
      function OrderService(http) {
        _classCallCheck(this, OrderService);

        this.http = http;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
      }

      _createClass(OrderService, [{
        key: "orders",
        get: function get() {
          return this.http.get("".concat(this.url, "site/saleinvoices")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        } // Create New Sales Invoice

      }, {
        key: "createInvoice",
        value: function createInvoice() {
          return this.http.get("".concat(this.url, "site/create-invoice"));
        } // Retrieve Sales Invoice Card / Details

      }, {
        key: "ordercard",
        value: function ordercard(id) {
          return this.http.get("".concat(this.url, "site/saleinvoice/?id=").concat(id));
        } // Post Lines Data

      }, {
        key: "postLine",
        value: function postLine(line) {
          return this.http.post("".concat(this.url, "site/addsalesinvoiceline"), JSON.stringify(line));
        } // Update Line

      }, {
        key: "updateInvoiceLine",
        value: function updateInvoiceLine(line) {
          return this.http.post("".concat(this.url, "site/updatesalesinvoiceline"), JSON.stringify(line));
        } // Fetch Line to Update

      }, {
        key: "getLine",
        value: function getLine(docId, LineNo) {
          return this.http.get("".concat(this.url, "site/getsalesinvoiceline?Document_No=").concat(docId, "&Line_No=").concat(LineNo));
        } // Post Invoice Header

      }, {
        key: "postInvoice",
        value: function postInvoice(invoice) {
          invoice.Posting_Date = this.formatDate(invoice.Posting_Date);
          invoice.Due_Date = this.formatDate(invoice.Due_Date);
          return this.http.post("".concat(this.url, "site/update-invoice"), JSON.stringify(invoice));
        } // Get Customers

      }, {
        key: "Customers",
        get: function get() {
          return this.http.get("".concat(this.url, "site/receipting-customers")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "postSalesInvoice",
        value: function postSalesInvoice(No) {
          return this.http.get("".concat(this.url, "site/postsaleinvoice?No=").concat(No));
        } // Format date utility

      }, {
        key: "formatDate",
        value: function formatDate(datestring) {
          // Format Date to YYYY-MM-DD
          var recDate = new Date(datestring);
          var month = recDate.getMonth() + 1 > 9 ? recDate.getMonth() + 1 : "0" + (recDate.getMonth() + 1);
          var day = recDate.getDate() > 9 ? recDate.getDate() : "0" + recDate.getDate();
          return "".concat(recDate.getFullYear(), "-").concat(month, "-").concat(day);
        }
      }]);

      return OrderService;
    }();

    OrderService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }];
    };

    OrderService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], OrderService);
    /***/
  },

  /***/
  "./src/app/payments/payments.service.ts":
  /*!**********************************************!*\
    !*** ./src/app/payments/payments.service.ts ***!
    \**********************************************/

  /*! exports provided: PaymentsService */

  /***/
  function srcAppPaymentsPaymentsServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PaymentsService", function () {
      return PaymentsService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _orders_order_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../orders/order.service */
    "./src/app/orders/order.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");

    var PaymentsService = /*#__PURE__*/function () {
      function PaymentsService(http, orderService, toastCtrl) {
        _classCallCheck(this, PaymentsService);

        this.http = http;
        this.orderService = orderService;
        this.toastCtrl = toastCtrl;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].url;
        this._refresh$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__["Subject"]();
      } // Define a synthetic getter for the subject


      _createClass(PaymentsService, [{
        key: "refresh$",
        get: function get() {
          return this._refresh$;
        }
      }, {
        key: "newPayment",
        value: function newPayment(receipt) {
          return this.http.post("".concat(this.url, "site/cash-sale"), JSON.stringify(receipt));
        }
      }, {
        key: "updateReceipt",
        value: function updateReceipt(receipt) {
          return this.http.post("".concat(this.url, "site/cash-sale"), JSON.stringify(receipt));
        }
      }, {
        key: "getPayments",
        value: function getPayments(userID) {
          return this.http.get("".concat(this.url, "site/get?service=POSReceiptList&userid=").concat(userID)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "getPayment",
        value: function getPayment(id) {
          return this.http.get("".concat(this.url, "site/receipt/?id=").concat(id)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "Banks",
        get: function get() {
          return this.http.get("".concat(this.url, "site/get?service=BankAccounts")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "getLine",
        value: function getLine(Key) {
          return this.http.get("".concat(this.url, "site/cash-sale-line?Key=").concat(Key));
        }
      }, {
        key: "suggestlines",
        value: function suggestlines(receiptNo, customerNo) {
          return this.http.get("".concat(this.url, "site/suggestlines?receiptNo=").concat(receiptNo, "&customerNo=").concat(customerNo)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        } // Post Lines Data

      }, {
        key: "postLine",
        value: function postLine(line) {
          var _this = this;

          return this.http.post("".concat(this.url, "site/cash-sale-line"), JSON.stringify(line)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function () {
            _this._refresh$.next();
          }));
        } // Update Line

      }, {
        key: "updateLine",
        value: function updateLine(line) {
          var _this2 = this;

          return this.http.post("".concat(this.url, "site/cash-sale-line"), JSON.stringify(line)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function () {
            _this2._refresh$.next();
          }));
        }
      }, {
        key: "Customers",
        get: function get() {
          return this.http.get("".concat(this.url, "site/receipting-customers")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
        /*
         * Get Customer By Search Name
         */

      }, {
        key: "Customer",
        value: function Customer(searchName) {
          return this.http.get("".concat(this.url, "site/receipting-customers?searchName=").concat(searchName)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
        /*
         * Get Customer By Sales Person Code
         */

      }, {
        key: "CustomerBySalesPerson",
        value: function CustomerBySalesPerson(salesPersonCode) {
          return this.http.get("".concat(this.url, "site/receipting-customers?Salesperson_Code=").concat(salesPersonCode)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        } // Get CustomerPriceGroups

      }, {
        key: "CustomerPriceGroups",
        value: function CustomerPriceGroups() {
          return this.http.get("".concat(this.url, "site/get?service=CustomerPriceGroups")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "Mpesa",
        value: function Mpesa() {
          return this.http.get("".concat(this.url, "site/get?service=MPESATransactions")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "selectLine",
        value: function selectLine(CustomerNo, Line, ReceiptNo) {
          var payload = {
            Customer_No: CustomerNo,
            Line_No: Line,
            Receipt_No: ReceiptNo
          };
          return this.http.post("".concat(this.url, "site/updatecashreceiptline"), JSON.stringify(payload));
        }
      }, {
        key: "setAmountToReceipt",
        value: function setAmountToReceipt(CustomerNo, Line, ReceiptNo, AmountToReceipt) {
          var payload = {
            Customer_No: CustomerNo,
            Line_No: Line,
            Receipt_No: ReceiptNo,
            Amount_To_Receipt: AmountToReceipt
          }; // console.log(payload); return;

          return this.http.post("".concat(this.url, "site/updateamounttoreceipt"), JSON.stringify(payload));
        }
      }, {
        key: "postReceipt",
        value: function postReceipt(No) {
          return this.http.get("".concat(this.url, "site/postreceipt?No=").concat(No));
        }
      }, {
        key: "getTotals",
        value: function getTotals(elements, subjectColumn) {
          var sum = 0;
          elements.forEach(function (obj) {
            // console.log(obj);
            for (var property in obj) {
              if (property === subjectColumn && !isNaN(+obj[property])) {
                // console.log(+obj[property]);
                sum += +obj[property];
              }
            }
          });
          return sum;
        }
      }, {
        key: "showToast",
        value: function showToast(text) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.toastCtrl.create({
                      message: text,
                      duration: 4000,
                      position: 'top'
                    }).then(function (toastEl) {
                      toastEl.present();
                    });

                  case 2:
                    return _context2.abrupt("return", _context2.sent);

                  case 3:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "formatDate",
        value: function formatDate(date) {
          return this.orderService.formatDate(date);
        }
      }, {
        key: "FilterReceipts",
        value: function FilterReceipts(startDate, userID) {
          return this.http.get("".concat(this.url, "site/filterpayments?startdate=").concat(startDate, "&userid=").concat(userID)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "FilterReceiptsbyRange",
        value: function FilterReceiptsbyRange(startDate, endDate, userID) {
          return this.http.get("".concat(this.url, "site/filterpayments?startdate=").concat(startDate, "&enddate=").concat(endDate, "&userid=").concat(userID)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }]);

      return PaymentsService;
    }();

    PaymentsService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]
      }, {
        type: _orders_order_service__WEBPACK_IMPORTED_MODULE_5__["OrderService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"]
      }];
    };

    PaymentsService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], PaymentsService);
    /***/
  },

  /***/
  "./src/app/postedsalesinvoices/sales.service.ts":
  /*!******************************************************!*\
    !*** ./src/app/postedsalesinvoices/sales.service.ts ***!
    \******************************************************/

  /*! exports provided: SalesService */

  /***/
  function srcAppPostedsalesinvoicesSalesServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SalesService", function () {
      return SalesService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _orders_order_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../orders/order.service */
    "./src/app/orders/order.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var SalesService = /*#__PURE__*/function () {
      function SalesService(http, orderService, toastCtrl) {
        _classCallCheck(this, SalesService);

        this.http = http;
        this.orderService = orderService;
        this.toastCtrl = toastCtrl;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].url;
      }

      _createClass(SalesService, [{
        key: "Sales",
        get: function get() {
          return this.http.get("".concat(this.url, "site/get?service=PostedSalesInvoices")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "getSale",
        value: function getSale(id) {
          return this.http.get("".concat(this.url, "site/sale/?Key=").concat(id)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "formatDate",
        value: function formatDate(date) {
          return this.orderService.formatDate(date);
        }
      }, {
        key: "FilterSales",
        value: function FilterSales(startDate, userID) {
          return this.http.get("".concat(this.url, "site/filtersales?startdate=").concat(startDate, "&userid=").concat(userID)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "FilterSalesbyRange",
        value: function FilterSalesbyRange(startDate, endDate, userID) {
          return this.http.get("".concat(this.url, "site/filtersales?startdate=").concat(startDate, "&enddate=").concat(endDate, "&userid=").concat(userID)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "showToast",
        value: function showToast(text) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.toastCtrl.create({
                      message: text,
                      duration: 4000,
                      position: 'top'
                    }).then(function (toastEl) {
                      toastEl.present();
                    });

                  case 2:
                    return _context3.abrupt("return", _context3.sent);

                  case 3:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }]);

      return SalesService;
    }();

    SalesService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }, {
        type: _orders_order_service__WEBPACK_IMPORTED_MODULE_5__["OrderService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"]
      }];
    };

    SalesService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], SalesService);
    /***/
  },

  /***/
  "./src/app/requisitions/requisition.service.ts":
  /*!*****************************************************!*\
    !*** ./src/app/requisitions/requisition.service.ts ***!
    \*****************************************************/

  /*! exports provided: RequisitionService */

  /***/
  function srcAppRequisitionsRequisitionServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RequisitionService", function () {
      return RequisitionService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");

    var RequisitionService = /*#__PURE__*/function () {
      function RequisitionService(http) {
        _classCallCheck(this, RequisitionService);

        this.http = http;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
        this._refresh$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__["Subject"]();
      } // Synthetic Getter for our refresh observerble


      _createClass(RequisitionService, [{
        key: "refresh$",
        get: function get() {
          return this._refresh$;
        }
      }, {
        key: "getRequisitions",
        value: function getRequisitions(userID) {
          return this.http.get("".concat(this.url, "site/requisitions?userid=").concat(userID)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "releasedrequisitions",
        get: function get() {
          return this.http.get("".concat(this.url, "site/releasedrequisitions")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        } // Retrieve Requisition Card / Details

      }, {
        key: "requisitioncard",
        value: function requisitioncard(id) {
          return this.http.get("".concat(this.url, "site/requisitioncard/?id=").concat(id));
        } // Create New Requisition

      }, {
        key: "createRequisition",
        value: function createRequisition(userID) {
          console.log('creator is:' + userID);
          return this.http.get("".concat(this.url, "site/create-requisition?userid=").concat(userID));
        } // get Units of Measure

      }, {
        key: "getunits",
        value: function getunits(itemNo) {
          return this.http.get("".concat(this.url, "site/unitmeasure?itemNo=").concat(itemNo)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        } // Get Locations List

      }, {
        key: "getLocations",
        value: function getLocations() {
          return this.http.get("".concat(this.url, "site/locationlist")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        } // Get any items from generic service getter function

      }, {
        key: "Dimensions",
        get: function get() {
          return this.http.get("".concat(this.url, "site/get?service=Dimensions")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "Departments",
        get: function get() {
          return this.http.get("".concat(this.url, "site/departments")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "Projects",
        get: function get() {
          return this.http.get("".concat(this.url, "site/projects")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        } // Post Lines Data

      }, {
        key: "postLine",
        value: function postLine(line) {
          var _this3 = this;

          return this.http.post("".concat(this.url, "site/requisition-lines"), JSON.stringify(line)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function () {
            _this3._refresh$.next();
          }));
        } // Update Line

      }, {
        key: "updateRequisitionLine",
        value: function updateRequisitionLine(line) {
          var _this4 = this;

          return this.http.post("".concat(this.url, "site/updaterequisitionline"), JSON.stringify(line)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function () {
            _this4._refresh$.next();
          }));
        } // Fetch Line to Update

      }, {
        key: "getLine",
        value: function getLine(Key) {
          return this.http.get("".concat(this.url, "site/requisition-lines?Key=").concat(Key));
        } // Post Requisition Header

      }, {
        key: "postRequisition",
        value: function postRequisition(requisition) {
          return this.http.post("".concat(this.url, "site/update-requisition"), JSON.stringify(requisition));
        } // Format date utility

      }, {
        key: "formatDate",
        value: function formatDate(datestring) {
          // Format Date to YYYY-MM-DD
          var recDate = new Date(datestring);
          var month = recDate.getMonth() + 1 > 9 ? recDate.getMonth() + 1 : "0" + (recDate.getMonth() + 1);
          var day = recDate.getDate() > 9 ? recDate.getDate() : "0" + recDate.getDate();
          return "".concat(recDate.getFullYear(), "-").concat(month, "-").concat(day);
        }
      }]);

      return RequisitionService;
    }();

    RequisitionService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }];
    };

    RequisitionService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], RequisitionService);
    /***/
  },

  /***/
  "./src/app/return/return-line/return-line.component.scss":
  /*!***************************************************************!*\
    !*** ./src/app/return/return-line/return-line.component.scss ***!
    \***************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppReturnReturnLineReturnLineComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3JldHVybi9yZXR1cm4tbGluZS9yZXR1cm4tbGluZS5jb21wb25lbnQuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/return/return-line/return-line.component.ts":
  /*!*************************************************************!*\
    !*** ./src/app/return/return-line/return-line.component.ts ***!
    \*************************************************************/

  /*! exports provided: ReturnLineComponent */

  /***/
  function srcAppReturnReturnLineReturnLineComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ReturnLineComponent", function () {
      return ReturnLineComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var src_app_items_item_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/items/item.service */
    "./src/app/items/item.service.ts");
    /* harmony import */


    var src_app_models_returnline_model__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/models/returnline.model */
    "./src/app/models/returnline.model.ts");
    /* harmony import */


    var src_app_requisitions_requisition_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! src/app/requisitions/requisition.service */
    "./src/app/requisitions/requisition.service.ts");
    /* harmony import */


    var src_app_utility_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! src/app/utility.service */
    "./src/app/utility.service.ts");
    /* harmony import */


    var _return_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(
    /*! ../return.service */
    "./src/app/return/return.service.ts");

    var ReturnLineComponent = /*#__PURE__*/function () {
      function ReturnLineComponent(returnSvc, utilitySvc, modalCtrl, itemSvc, requisitionSvc) {
        _classCallCheck(this, ReturnLineComponent);

        this.returnSvc = returnSvc;
        this.utilitySvc = utilitySvc;
        this.modalCtrl = modalCtrl;
        this.itemSvc = itemSvc;
        this.requisitionSvc = requisitionSvc;
        this.line = new src_app_models_returnline_model__WEBPACK_IMPORTED_MODULE_5__["Returnline"]();
        this.items = [];
      }

      _createClass(ReturnLineComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.fetchLocations();
          this.fetchItems();
        }
      }, {
        key: "fetchItems",
        value: function fetchItems() {
          var _this5 = this;

          this.utilitySvc.presentLoading("Loading Items...");
          this.itemSub = this.itemSvc.items.pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["finalize"])(function () {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this5, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
              return regeneratorRuntime.wrap(function _callee4$(_context4) {
                while (1) {
                  switch (_context4.prev = _context4.next) {
                    case 0:
                      this.utilitySvc.loadingCtrl.dismiss();

                    case 1:
                    case "end":
                      return _context4.stop();
                  }
                }
              }, _callee4, this);
            }));
          })).subscribe(function (items) {
            _this5.items = items;
          });
        }
      }, {
        key: "fetchLocations",
        value: function fetchLocations() {
          var _this6 = this;

          this.locationSub = this.requisitionSvc.getLocations().subscribe(function (res) {
            console.log('Locations');
            console.log(res);
            _this6.locations = res;
          });
        }
      }, {
        key: "addLine",
        value: function addLine() {
          var _this7 = this;

          this.utilitySvc.presentLoading('Saving ....');
          this.line.No = this.docId;
          this.lineSub = this.returnSvc.returnLine(this.line).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["finalize"])(function () {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this7, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
              return regeneratorRuntime.wrap(function _callee5$(_context5) {
                while (1) {
                  switch (_context5.prev = _context5.next) {
                    case 0:
                      this.utilitySvc.loadingCtrl.dismiss();

                    case 1:
                    case "end":
                      return _context5.stop();
                  }
                }
              }, _callee5, this);
            }));
          })).subscribe(function (res) {
            if (typeof res === 'string') {
              _this7.utilitySvc.showAlert(res);

              return;
            }

            _this7.utilitySvc.showToast('Line Added Successfully.');

            setTimeout(function () {
              _this7.modalCtrl.dismiss();
            }, 2500);
          }, function (err) {
            _this7.utilitySvc.showAlert(err.message);
          });
        }
      }, {
        key: "updateLine",
        value: function updateLine() {
          var _this8 = this;

          this.lineSub = this.returnSvc.returnLine(this.line).subscribe(function (res) {
            if (typeof res === 'string') {
              _this8.utilitySvc.showAlert(res);
            }

            _this8.utilitySvc.showToast('Line Updated Successfully.');

            setTimeout(function () {
              _this8.modalCtrl.dismiss();
            }, 2500);
          }, function (err) {
            _this8.utilitySvc.showAlert(err.message);
          });
        }
      }, {
        key: "onCancel",
        value: function onCancel() {
          this.modalCtrl.dismiss();
        }
      }]);

      return ReturnLineComponent;
    }();

    ReturnLineComponent.ctorParameters = function () {
      return [{
        type: _return_service__WEBPACK_IMPORTED_MODULE_8__["ReturnService"]
      }, {
        type: src_app_utility_service__WEBPACK_IMPORTED_MODULE_7__["UtilityService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
      }, {
        type: src_app_items_item_service__WEBPACK_IMPORTED_MODULE_4__["ItemService"]
      }, {
        type: src_app_requisitions_requisition_service__WEBPACK_IMPORTED_MODULE_6__["RequisitionService"]
      }];
    };

    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], ReturnLineComponent.prototype, "docId", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], ReturnLineComponent.prototype, "key", void 0);
    ReturnLineComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-return-line',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./return-line.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/return/return-line/return-line.component.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./return-line.component.scss */
      "./src/app/return/return-line/return-line.component.scss"))["default"]]
    })], ReturnLineComponent);
    /***/
  },

  /***/
  "./src/app/return/return.service.ts":
  /*!******************************************!*\
    !*** ./src/app/return/return.service.ts ***!
    \******************************************/

  /*! exports provided: ReturnService */

  /***/
  function srcAppReturnReturnServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ReturnService", function () {
      return ReturnService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var _utility_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../utility.service */
    "./src/app/utility.service.ts");

    var ReturnService = /*#__PURE__*/function () {
      function ReturnService(http, utilitySvc) {
        _classCallCheck(this, ReturnService);

        this.http = http;
        this.utilitySvc = utilitySvc;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
      }

      _createClass(ReturnService, [{
        key: "formatDate",
        value: function formatDate(date) {
          return this.utilitySvc.formatDate(date);
        } // Can create or Update

      }, {
        key: "ReturnTransaction",
        value: function ReturnTransaction(returnData) {
          return this.http.post("".concat(this.url, "site/return"), JSON.stringify(returnData)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        } // Read a single Return

      }, {
        key: "getReturnTransaction",
        value: function getReturnTransaction(Key) {
          return this.http.get("".concat(this.url, "site/view-return/?Key=").concat(Key)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        } // Get a list of returns for a particular user

      }, {
        key: "getReturnTransactions",
        value: function getReturnTransactions(userID) {
          return this.http.get("".concat(this.url, "site/get?service=POSReturnList&userid=").concat(userID)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        } // Add Update Return Line

      }, {
        key: "returnLine",
        value: function returnLine(lineData) {
          return this.http.post("".concat(this.url, "site/return-line"), JSON.stringify(lineData));
        } // Fetch return Line By Key

      }, {
        key: "fetchLine",
        value: function fetchLine(Key) {
          return this.http.get("".concat(this.url, "site/fetch-return-line?Key=").concat(Key));
        }
      }]);

      return ReturnService;
    }();

    ReturnService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]
      }, {
        type: _utility_service__WEBPACK_IMPORTED_MODULE_5__["UtilityService"]
      }];
    };

    ReturnService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
      providedIn: 'root'
    })], ReturnService);
    /***/
  },

  /***/
  "./src/app/utility.service.ts":
  /*!************************************!*\
    !*** ./src/app/utility.service.ts ***!
    \************************************/

  /*! exports provided: UtilityService */

  /***/
  function srcAppUtilityServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "UtilityService", function () {
      return UtilityService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var UtilityService = /*#__PURE__*/function () {
      function UtilityService(toastCtrl, alertCtrl, loadingCtrl) {
        _classCallCheck(this, UtilityService);

        this.toastCtrl = toastCtrl;
        this.alertCtrl = alertCtrl;
        this.loadingCtrl = loadingCtrl;
      }

      _createClass(UtilityService, [{
        key: "formatDate",
        value: function formatDate(datestring) {
          // Format Date to YYYY-MM-DD
          var recDate = new Date(datestring);
          var month = recDate.getMonth() + 1 > 9 ? recDate.getMonth() + 1 : "0" + (recDate.getMonth() + 1);
          var day = recDate.getDate() > 9 ? recDate.getDate() : "0" + recDate.getDate();
          return "".concat(recDate.getFullYear(), "-").concat(month, "-").concat(day);
        }
      }, {
        key: "showToast",
        value: function showToast(text) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
            var toastEl;
            return regeneratorRuntime.wrap(function _callee6$(_context6) {
              while (1) {
                switch (_context6.prev = _context6.next) {
                  case 0:
                    toastEl = this.toastCtrl.create({
                      message: text,
                      duration: 4000,
                      position: 'top'
                    });
                    _context6.next = 3;
                    return toastEl;

                  case 3:
                    _context6.sent.present();

                  case 4:
                  case "end":
                    return _context6.stop();
                }
              }
            }, _callee6, this);
          }));
        }
      }, {
        key: "showAlert",
        value: function showAlert(text) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
            var alertEl;
            return regeneratorRuntime.wrap(function _callee7$(_context7) {
              while (1) {
                switch (_context7.prev = _context7.next) {
                  case 0:
                    _context7.next = 2;
                    return this.alertCtrl.create({
                      header: 'Operation Error',
                      message: 'Message : ' + text,
                      buttons: [{
                        text: 'Okay'
                      }]
                    });

                  case 2:
                    alertEl = _context7.sent;
                    _context7.next = 5;
                    return alertEl.present();

                  case 5:
                  case "end":
                    return _context7.stop();
                }
              }
            }, _callee7, this);
          }));
        }
      }, {
        key: "presentLoading",
        value: function presentLoading(message) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee8() {
            var loading;
            return regeneratorRuntime.wrap(function _callee8$(_context8) {
              while (1) {
                switch (_context8.prev = _context8.next) {
                  case 0:
                    _context8.next = 2;
                    return this.loadingCtrl.create({
                      spinner: 'dots',
                      animated: true,
                      message: message ? message : 'Loading Data...'
                    });

                  case 2:
                    loading = _context8.sent;
                    _context8.next = 5;
                    return loading.present();

                  case 5:
                  case "end":
                    return _context8.stop();
                }
              }
            }, _callee8, this);
          }));
        }
      }]);

      return UtilityService;
    }();

    UtilityService.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]
      }];
    };

    UtilityService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], UtilityService);
    /***/
  }
}]);
//# sourceMappingURL=default~return-return-card-return-card-module~return-return-module-es5.js.map