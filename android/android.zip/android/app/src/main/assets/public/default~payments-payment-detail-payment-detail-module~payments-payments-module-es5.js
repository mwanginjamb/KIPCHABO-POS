function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~payments-payment-detail-payment-detail-module~payments-payments-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/payments/bluetooth/bluetooth.component.html":
  /*!***************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/payments/bluetooth/bluetooth.component.html ***!
    \***************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPaymentsBluetoothBluetoothComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n    <ion-title>Select Bluetooth Printer</ion-title>\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button  (click)=\"closeModal()\">\r\n        <ion-icon slot=\"icon-only\" name=\"close\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n<ion-button color=\"primary\" expand=\"block\" (click)=\"listPrinters()\">Scan\r\n\r\n</ion-button>\r\n\r\n  <ion-list>\r\n    <ion-list-header *ngIf=\"!scanning\">Available Devices</ion-list-header>\r\n\r\n    <ion-item *ngFor=\"let dev of  btDevices\" (click)=\"selectPrinter(dev.id)\">{{dev.name}}</ion-item>\r\n    \r\n  </ion-list>\r\n\r\n  <ion-spinner name=\"crescent\" *ngIf=\"scanning\"></ion-spinner>\r\n\r\n</ion-content>\r\n    \r\n\r\n";
    /***/
  },

  /***/
  "./src/app/orders/order.service.ts":
  /*!*****************************************!*\
    !*** ./src/app/orders/order.service.ts ***!
    \*****************************************/

  /*! exports provided: OrderService */

  /***/
  function srcAppOrdersOrderServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "OrderService", function () {
      return OrderService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");

    var OrderService = /*#__PURE__*/function () {
      // private items  = new BehaviorSubject<[]>([]) ;
      function OrderService(http) {
        _classCallCheck(this, OrderService);

        this.http = http;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
      }

      _createClass(OrderService, [{
        key: "orders",
        get: function get() {
          return this.http.get("".concat(this.url, "site/saleinvoices")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        } // Create New Sales Invoice

      }, {
        key: "createInvoice",
        value: function createInvoice() {
          return this.http.get("".concat(this.url, "site/create-invoice"));
        } // Retrieve Sales Invoice Card / Details

      }, {
        key: "ordercard",
        value: function ordercard(id) {
          return this.http.get("".concat(this.url, "site/saleinvoice/?id=").concat(id));
        } // Post Lines Data

      }, {
        key: "postLine",
        value: function postLine(line) {
          return this.http.post("".concat(this.url, "site/addsalesinvoiceline"), JSON.stringify(line));
        } // Update Line

      }, {
        key: "updateInvoiceLine",
        value: function updateInvoiceLine(line) {
          return this.http.post("".concat(this.url, "site/updatesalesinvoiceline"), JSON.stringify(line));
        } // Fetch Line to Update

      }, {
        key: "getLine",
        value: function getLine(docId, LineNo) {
          return this.http.get("".concat(this.url, "site/getsalesinvoiceline?Document_No=").concat(docId, "&Line_No=").concat(LineNo));
        } // Post Invoice Header

      }, {
        key: "postInvoice",
        value: function postInvoice(invoice) {
          invoice.Posting_Date = this.formatDate(invoice.Posting_Date);
          invoice.Due_Date = this.formatDate(invoice.Due_Date);
          return this.http.post("".concat(this.url, "site/update-invoice"), JSON.stringify(invoice));
        } // Get Customers

      }, {
        key: "Customers",
        get: function get() {
          return this.http.get("".concat(this.url, "site/receipting-customers")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "postSalesInvoice",
        value: function postSalesInvoice(No) {
          return this.http.get("".concat(this.url, "site/postsaleinvoice?No=").concat(No));
        } // Format date utility

      }, {
        key: "formatDate",
        value: function formatDate(datestring) {
          // Format Date to YYYY-MM-DD
          var recDate = new Date(datestring);
          var month = recDate.getMonth() + 1 > 9 ? recDate.getMonth() + 1 : "0" + (recDate.getMonth() + 1);
          var day = recDate.getDate() > 9 ? recDate.getDate() : "0" + recDate.getDate();
          return "".concat(recDate.getFullYear(), "-").concat(month, "-").concat(day);
        }
      }]);

      return OrderService;
    }();

    OrderService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }];
    };

    OrderService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], OrderService);
    /***/
  },

  /***/
  "./src/app/payments/bluetooth/bluetooth.component.scss":
  /*!*************************************************************!*\
    !*** ./src/app/payments/bluetooth/bluetooth.component.scss ***!
    \*************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPaymentsBluetoothBluetoothComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BheW1lbnRzL2JsdWV0b290aC9ibHVldG9vdGguY29tcG9uZW50LnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/payments/bluetooth/bluetooth.component.ts":
  /*!***********************************************************!*\
    !*** ./src/app/payments/bluetooth/bluetooth.component.ts ***!
    \***********************************************************/

  /*! exports provided: BluetoothComponent */

  /***/
  function srcAppPaymentsBluetoothBluetoothComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "BluetoothComponent", function () {
      return BluetoothComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _print_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../print.service */
    "./src/app/payments/print.service.ts");
    /* harmony import */


    var _ionic_native_bluetooth_serial_ngx__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic-native/bluetooth-serial/ngx */
    "./node_modules/@ionic-native/bluetooth-serial/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _payments_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../payments.service */
    "./src/app/payments/payments.service.ts");

    var BluetoothComponent = /*#__PURE__*/function () {
      function BluetoothComponent(modalCtrl, printService, bluetoothSerial, alertCtrl, toastCtrl, popOverCtrl, paymentService) {
        var _this = this;

        _classCallCheck(this, BluetoothComponent);

        this.modalCtrl = modalCtrl;
        this.printService = printService;
        this.bluetoothSerial = bluetoothSerial;
        this.alertCtrl = alertCtrl;
        this.toastCtrl = toastCtrl;
        this.popOverCtrl = popOverCtrl;
        this.paymentService = paymentService;
        this.btDevices = [];
        this.pairedDevices = null;
        this.unpairedDevices = null;
        this.myString = null;

        this.success = function (data) {
          _this.deviceConnected();

          if (_this.Printable === 'Invoice') {
            _this.generatePostedSalesInvoicePrintable();
          } else if (_this.Printable === 'Receipt') {
            _this.generateReceiptPrintable();
          }

          _this.print(_this.myString);
        };

        this.fail = function (error) {
          alert(error);
        };

        this.bluetoothSerial.enable();
      }

      _createClass(BluetoothComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.popOverCtrl.dismiss();
        }
      }, {
        key: "closeModal",
        value: function closeModal() {
          this.modalCtrl.dismiss();
        }
      }, {
        key: "listPrinters",
        value: function listPrinters() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this2 = this;

            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    this.scanning = true;
                    _context.next = 3;
                    return this.printService.searchBluetoothPrinter().then(function (res) {
                      _this2.btDevices = res;
                      _this2.scanning = false;
                    }, function (error) {
                      console.log(error);
                    });

                  case 3:
                    return _context.abrupt("return", _context.sent);

                  case 4:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "selectPrinter",
        value: function selectPrinter(macAddress) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var _this3 = this;

            var alert;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.alertCtrl.create({
                      header: 'Connect',
                      message: 'Do you want to connect with selected device ?',
                      buttons: [{
                        text: 'Cancel',
                        role: 'cancel',
                        handler: function handler() {
                          _this3.showToast('Connection Intent Cancelled.');
                        }
                      }, {
                        text: 'Connect',
                        handler: function handler() {
                          _this3.selectPrinter = macAddress;

                          _this3.bluetoothSerial.connect(macAddress).subscribe(_this3.success, _this3.fail);
                        }
                      }]
                    });

                  case 2:
                    alert = _context2.sent;
                    _context2.next = 5;
                    return alert.present();

                  case 5:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "deviceConnected",
        value: function deviceConnected() {
          this.bluetoothSerial.isConnected().then(function (success) {
            alert("Connected Successfully. ");
          }, function (error) {
            alert('error' + JSON.stringify('error'));
          });
        }
      }, {
        key: "print",
        value: function print(stringtoPrint) {
          this.printService.sendToBluetoothPrinter(stringtoPrint);
        }
      }, {
        key: "showToast",
        value: function showToast(text) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.toastCtrl.create({
                      message: text,
                      duration: 3000,
                      position: 'top'
                    }).then(function (toastEl) {
                      toastEl.present();
                    });

                  case 2:
                    return _context3.abrupt("return", _context3.sent);

                  case 3:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "generatePostedSalesInvoicePrintable",
        value: function generatePostedSalesInvoicePrintable() {
          var _this4 = this;

          var _a, _b, _c;

          this.myString = "\n    Kipchabo Tea Factory Ltd - Invoice.\n\n    Customer: ".concat((_a = this.Card) === null || _a === void 0 ? void 0 : _a.Customer_Name, "\n\n    Sale Date: ").concat(this.Card.Posting_Date, "\n\n    Invoice No: ").concat(this.Card.No, "\n\n    Item | Quantity  | Unit Price (Ksh) | Total  (Incl. VAT)\n\n    ");
          /* this.Card.SalesInvLines.Posted_Sales_Invoice_Line.forEach(line => {
            this.myString += `
          ${line.Description}  | ${line.Quantity} | ${line.Unit_Price} | ${line.Line_Amount } \r\n` ;
          });*/
          // Filter Lines to print

          var LinestoPrint = this.Card.SalesInvLines.Posted_Sales_Invoice_Line.filter(function (ln) {
            return ln.Line_Amount > 0;
          });
          LinestoPrint.forEach(function (line) {
            _this4.myString += "\n    ".concat(line.Description, "  | ").concat(line.Quantity, " | ").concat(line.Unit_Price, " | ").concat(line.Line_Amount, " \r\n");
          });
          var VAT = ((_b = this.Card) === null || _b === void 0 ? void 0 : _b.Amount) * 0.16;
          this.myString += "\n\n     Total Amount: ".concat((_c = this.Card) === null || _c === void 0 ? void 0 : _c.Amount, "\n\n     VAT: ").concat(VAT, "\n     ");
        }
      }, {
        key: "generateReceiptPrintable",
        value: function generateReceiptPrintable() {
          var _this5 = this;

          var _a;

          this.myString = "\n    Kipchabo Tea Factory Receipt.\n\n    Customer: ".concat((_a = this.receiptCard) === null || _a === void 0 ? void 0 : _a.Customer_Name, "\n\n\n    Invoice No | Amount  | Amount to receipt \n\n    "); // Filter Lines to Print

          var LinestoPrint = this.receiptCard.POS_Receipt_Lines.POS_Receipt_Lines.filter(function (ln) {
            return ln.Total_Amount > 0;
          });
          LinestoPrint.forEach(function (line) {
            _this5.myString += "\n\n    ".concat(line.Description, "  | ").concat(line.Price, " | ").concat(line.Total_Amount, "  \r\n");
          });
          var Total = this.paymentService.getTotals(this.receiptCard.POS_Receipt_Lines.POS_Receipt_Lines, 'Amount_To_Receipt');
          this.myString += "\n\n          Total Amount: ".concat(Total, "\n\n                   ");
        }
      }]);

      return BluetoothComponent;
    }();

    BluetoothComponent.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
      }, {
        type: _print_service__WEBPACK_IMPORTED_MODULE_3__["PrintService"]
      }, {
        type: _ionic_native_bluetooth_serial_ngx__WEBPACK_IMPORTED_MODULE_4__["BluetoothSerial"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PopoverController"]
      }, {
        type: _payments_service__WEBPACK_IMPORTED_MODULE_5__["PaymentsService"]
      }];
    };

    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], BluetoothComponent.prototype, "No", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], BluetoothComponent.prototype, "Card", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], BluetoothComponent.prototype, "receiptCard", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], BluetoothComponent.prototype, "Printable", void 0);
    BluetoothComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-bluetooth',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./bluetooth.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/payments/bluetooth/bluetooth.component.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./bluetooth.component.scss */
      "./src/app/payments/bluetooth/bluetooth.component.scss"))["default"]]
    })], BluetoothComponent);
    /***/
  },

  /***/
  "./src/app/payments/payments.service.ts":
  /*!**********************************************!*\
    !*** ./src/app/payments/payments.service.ts ***!
    \**********************************************/

  /*! exports provided: PaymentsService */

  /***/
  function srcAppPaymentsPaymentsServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PaymentsService", function () {
      return PaymentsService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _orders_order_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../orders/order.service */
    "./src/app/orders/order.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");

    var PaymentsService = /*#__PURE__*/function () {
      function PaymentsService(http, orderService, toastCtrl) {
        _classCallCheck(this, PaymentsService);

        this.http = http;
        this.orderService = orderService;
        this.toastCtrl = toastCtrl;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].url;
        this._refresh$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__["Subject"]();
      } // Define a synthetic getter for the subject


      _createClass(PaymentsService, [{
        key: "refresh$",
        get: function get() {
          return this._refresh$;
        }
      }, {
        key: "newPayment",
        value: function newPayment(receipt) {
          return this.http.post("".concat(this.url, "site/cash-sale"), JSON.stringify(receipt));
        }
      }, {
        key: "updateReceipt",
        value: function updateReceipt(receipt) {
          return this.http.post("".concat(this.url, "site/cash-sale"), JSON.stringify(receipt));
        }
      }, {
        key: "getPayments",
        value: function getPayments(userID) {
          return this.http.get("".concat(this.url, "site/get?service=POSReceiptList&userid=").concat(userID)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "getPayment",
        value: function getPayment(id) {
          return this.http.get("".concat(this.url, "site/receipt/?id=").concat(id)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "Banks",
        get: function get() {
          return this.http.get("".concat(this.url, "site/get?service=BankAccounts")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "getLine",
        value: function getLine(Key) {
          return this.http.get("".concat(this.url, "site/cash-sale-line?Key=").concat(Key));
        }
      }, {
        key: "suggestlines",
        value: function suggestlines(receiptNo, customerNo) {
          return this.http.get("".concat(this.url, "site/suggestlines?receiptNo=").concat(receiptNo, "&customerNo=").concat(customerNo)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        } // Post Lines Data

      }, {
        key: "postLine",
        value: function postLine(line) {
          var _this6 = this;

          return this.http.post("".concat(this.url, "site/cash-sale-line"), JSON.stringify(line)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function () {
            _this6._refresh$.next();
          }));
        } // Update Line

      }, {
        key: "updateLine",
        value: function updateLine(line) {
          var _this7 = this;

          return this.http.post("".concat(this.url, "site/cash-sale-line"), JSON.stringify(line)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function () {
            _this7._refresh$.next();
          }));
        }
      }, {
        key: "Customers",
        get: function get() {
          return this.http.get("".concat(this.url, "site/receipting-customers")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
        /*
         * Get Customer By Search Name
         */

      }, {
        key: "Customer",
        value: function Customer(searchName) {
          return this.http.get("".concat(this.url, "site/receipting-customers?searchName=").concat(searchName)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
        /*
         * Get Customer By Sales Person Code
         */

      }, {
        key: "CustomerBySalesPerson",
        value: function CustomerBySalesPerson(salesPersonCode) {
          return this.http.get("".concat(this.url, "site/receipting-customers?Salesperson_Code=").concat(salesPersonCode)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        } // Get CustomerPriceGroups

      }, {
        key: "CustomerPriceGroups",
        value: function CustomerPriceGroups() {
          return this.http.get("".concat(this.url, "site/get?service=CustomerPriceGroups")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "Mpesa",
        value: function Mpesa() {
          return this.http.get("".concat(this.url, "site/get?service=MPESATransactions")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "selectLine",
        value: function selectLine(CustomerNo, Line, ReceiptNo) {
          var payload = {
            Customer_No: CustomerNo,
            Line_No: Line,
            Receipt_No: ReceiptNo
          };
          return this.http.post("".concat(this.url, "site/updatecashreceiptline"), JSON.stringify(payload));
        }
      }, {
        key: "setAmountToReceipt",
        value: function setAmountToReceipt(CustomerNo, Line, ReceiptNo, AmountToReceipt) {
          var payload = {
            Customer_No: CustomerNo,
            Line_No: Line,
            Receipt_No: ReceiptNo,
            Amount_To_Receipt: AmountToReceipt
          }; // console.log(payload); return;

          return this.http.post("".concat(this.url, "site/updateamounttoreceipt"), JSON.stringify(payload));
        }
      }, {
        key: "postReceipt",
        value: function postReceipt(No) {
          return this.http.get("".concat(this.url, "site/postreceipt?No=").concat(No));
        }
      }, {
        key: "getTotals",
        value: function getTotals(elements, subjectColumn) {
          var sum = 0;
          elements.forEach(function (obj) {
            // console.log(obj);
            for (var property in obj) {
              if (property === subjectColumn && !isNaN(+obj[property])) {
                // console.log(+obj[property]);
                sum += +obj[property];
              }
            }
          });
          return sum;
        }
      }, {
        key: "showToast",
        value: function showToast(text) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
            return regeneratorRuntime.wrap(function _callee4$(_context4) {
              while (1) {
                switch (_context4.prev = _context4.next) {
                  case 0:
                    _context4.next = 2;
                    return this.toastCtrl.create({
                      message: text,
                      duration: 4000,
                      position: 'top'
                    }).then(function (toastEl) {
                      toastEl.present();
                    });

                  case 2:
                    return _context4.abrupt("return", _context4.sent);

                  case 3:
                  case "end":
                    return _context4.stop();
                }
              }
            }, _callee4, this);
          }));
        }
      }, {
        key: "formatDate",
        value: function formatDate(date) {
          return this.orderService.formatDate(date);
        }
      }, {
        key: "FilterReceipts",
        value: function FilterReceipts(startDate, userID) {
          return this.http.get("".concat(this.url, "site/filterpayments?startdate=").concat(startDate, "&userid=").concat(userID)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "FilterReceiptsbyRange",
        value: function FilterReceiptsbyRange(startDate, endDate, userID) {
          return this.http.get("".concat(this.url, "site/filterpayments?startdate=").concat(startDate, "&enddate=").concat(endDate, "&userid=").concat(userID)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }]);

      return PaymentsService;
    }();

    PaymentsService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]
      }, {
        type: _orders_order_service__WEBPACK_IMPORTED_MODULE_5__["OrderService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"]
      }];
    };

    PaymentsService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], PaymentsService);
    /***/
  },

  /***/
  "./src/app/payments/print.service.ts":
  /*!*******************************************!*\
    !*** ./src/app/payments/print.service.ts ***!
    \*******************************************/

  /*! exports provided: PrintService */

  /***/
  function srcAppPaymentsPrintServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PrintService", function () {
      return PrintService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_native_bluetooth_serial_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic-native/bluetooth-serial/ngx */
    "./node_modules/@ionic-native/bluetooth-serial/__ivy_ngcc__/ngx/index.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var PrintService = /*#__PURE__*/function () {
      function PrintService(btSerial, toastCtrl) {
        var _this8 = this;

        _classCallCheck(this, PrintService);

        this.btSerial = btSerial;
        this.toastCtrl = toastCtrl;

        this.success = function (data) {
          _this8.showToast("Printing Successfull !");
        };

        this.fail = function (error) {
          alert(error);
        };

        btSerial.enable();
      }

      _createClass(PrintService, [{
        key: "searchBluetoothPrinter",
        value: function searchBluetoothPrinter() {
          return this.btSerial.list();
        }
      }, {
        key: "connectToBluetoothPrinter",
        value: function connectToBluetoothPrinter(macAddress) {
          return this.btSerial.connect(macAddress);
        }
      }, {
        key: "disconnectBluetoothPrinter",
        value: function disconnectBluetoothPrinter() {
          return this.btSerial.disconnect();
        }
      }, {
        key: "sendToBluetoothPrinter",
        value: function sendToBluetoothPrinter(dataString) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
            return regeneratorRuntime.wrap(function _callee5$(_context5) {
              while (1) {
                switch (_context5.prev = _context5.next) {
                  case 0:
                    _context5.next = 2;
                    return this.btSerial.write(dataString).then(this.success, this.fail);

                  case 2:
                    // Disconnect the Printer.
                    this.disconnectBluetoothPrinter();

                  case 3:
                  case "end":
                    return _context5.stop();
                }
              }
            }, _callee5, this);
          }));
        }
      }, {
        key: "showToast",
        value: function showToast(text) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
            return regeneratorRuntime.wrap(function _callee6$(_context6) {
              while (1) {
                switch (_context6.prev = _context6.next) {
                  case 0:
                    _context6.next = 2;
                    return this.toastCtrl.create({
                      message: text,
                      duration: 4000,
                      position: 'top'
                    }).then(function (toastEl) {
                      toastEl.present();
                    });

                  case 2:
                    return _context6.abrupt("return", _context6.sent);

                  case 3:
                  case "end":
                    return _context6.stop();
                }
              }
            }, _callee6, this);
          }));
        }
      }]);

      return PrintService;
    }();

    PrintService.ctorParameters = function () {
      return [{
        type: _ionic_native_bluetooth_serial_ngx__WEBPACK_IMPORTED_MODULE_2__["BluetoothSerial"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"]
      }];
    };

    PrintService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], PrintService);
    /***/
  }
}]);
//# sourceMappingURL=default~payments-payment-detail-payment-detail-module~payments-payments-module-es5.js.map