function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["requisitions-requisitions-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/requisitions/req-popover/req-popover.component.html":
  /*!***********************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/requisitions/req-popover/req-popover.component.html ***!
    \***********************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppRequisitionsReqPopoverReqPopoverComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-list>\r\n  <ion-item lines=\"none\" [routerLink]=\"['requisitions','new-requisition']\">\r\n    <ion-icon slot=\"start\" name=\"add-circle-sharp\"></ion-icon>\r\n    <ion-label>New Requisition</ion-label>\r\n  </ion-item>\r\n  <ion-item (click)=\"close()\" lines=\"none\">\r\n    <ion-icon slot=\"start\" name=\"close-circle-sharp\"></ion-icon>\r\n    <ion-label>Close</ion-label>\r\n  </ion-item>\r\n</ion-list>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/requisitions/requisitions.page.html":
  /*!*******************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/requisitions/requisitions.page.html ***!
    \*******************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppRequisitionsRequisitionsPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n\r\n    <ion-title>New Requisitions List</ion-title>\r\n\r\n    <ion-buttons slot=\"end\">      \r\n      <ion-button slot=\"icon-only\" fill=\"clear\" (click)=\"presentPopover($event)\">\r\n        <ion-icon  name=\"ellipsis-vertical-outline\"></ion-icon>\r\n      </ion-button>      \r\n    </ion-buttons>\r\n\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <div *ngIf=\"isLoading\" class=\"ion-text-center\">\r\n    <ion-spinner  name=\"crescent\"></ion-spinner>\r\n  </div>\r\n  \r\n  <ion-searchbar [(ngModel)]=\"searchTerm\" debounce=\"2000\" (ionChange)=\"search($event)\" placeholder=\"Search Requisition\" ></ion-searchbar>\r\n\r\n  <ion-grid>\r\n    <ion-row>\r\n      <ion-col size=\"4\">No.</ion-col>\r\n      <ion-col size=\"4\">Requisition Date</ion-col>\r\n      <ion-col size=\"4\">Status</ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n  <ion-virtual-scroll [items]=\"requisitions\" approxItemHeight=\"47.2px\">\r\n               \r\n    <ion-item \r\n      [routerLink] = \"['/','requisitions',requisition.Req_No]\"\r\n     detail\r\n     *virtualItem=\"let requisition\" > \r\n\r\n     <ion-grid>\r\n        <ion-row>\r\n\r\n          <ion-col size=\"4\">\r\n            <ion-label>\r\n              <h3>{{ requisition.Req_No }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n\r\n          <ion-col size=\"4\">\r\n            <ion-label>\r\n              <h3>{{ requisition.Requisition_Date }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n\r\n        \r\n\r\n          <ion-col size=\"4\">\r\n            <ion-label>\r\n              <h3>{{ requisition.Approval_Status}}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n\r\n        </ion-row>\r\n      </ion-grid>\r\n            \r\n</ion-item>\r\n\r\n</ion-virtual-scroll>\r\n\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./src/app/requisitions/req-popover/req-popover.component.scss":
  /*!*********************************************************************!*\
    !*** ./src/app/requisitions/req-popover/req-popover.component.scss ***!
    \*********************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppRequisitionsReqPopoverReqPopoverComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3JlcXVpc2l0aW9ucy9yZXEtcG9wb3Zlci9yZXEtcG9wb3Zlci5jb21wb25lbnQuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/requisitions/req-popover/req-popover.component.ts":
  /*!*******************************************************************!*\
    !*** ./src/app/requisitions/req-popover/req-popover.component.ts ***!
    \*******************************************************************/

  /*! exports provided: ReqPopoverComponent */

  /***/
  function srcAppRequisitionsReqPopoverReqPopoverComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ReqPopoverComponent", function () {
      return ReqPopoverComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var ReqPopoverComponent = /*#__PURE__*/function () {
      function ReqPopoverComponent(popoverCtrl) {
        _classCallCheck(this, ReqPopoverComponent);

        this.popoverCtrl = popoverCtrl;
      }

      _createClass(ReqPopoverComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "close",
        value: function close() {
          this.popoverCtrl.dismiss();
        }
      }]);

      return ReqPopoverComponent;
    }();

    ReqPopoverComponent.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["PopoverController"]
      }];
    };

    ReqPopoverComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-req-popover',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./req-popover.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/requisitions/req-popover/req-popover.component.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./req-popover.component.scss */
      "./src/app/requisitions/req-popover/req-popover.component.scss"))["default"]]
    })], ReqPopoverComponent);
    /***/
  },

  /***/
  "./src/app/requisitions/requisition.service.ts":
  /*!*****************************************************!*\
    !*** ./src/app/requisitions/requisition.service.ts ***!
    \*****************************************************/

  /*! exports provided: RequisitionService */

  /***/
  function srcAppRequisitionsRequisitionServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RequisitionService", function () {
      return RequisitionService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");

    var RequisitionService = /*#__PURE__*/function () {
      function RequisitionService(http) {
        _classCallCheck(this, RequisitionService);

        this.http = http;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
        this._refresh$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__["Subject"]();
      } // Synthetic Getter for our refresh observerble


      _createClass(RequisitionService, [{
        key: "refresh$",
        get: function get() {
          return this._refresh$;
        }
      }, {
        key: "getRequisitions",
        value: function getRequisitions(userID) {
          return this.http.get("".concat(this.url, "site/requisitions?userid=").concat(userID)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "releasedrequisitions",
        get: function get() {
          return this.http.get("".concat(this.url, "site/releasedrequisitions")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        } // Retrieve Requisition Card / Details

      }, {
        key: "requisitioncard",
        value: function requisitioncard(id) {
          return this.http.get("".concat(this.url, "site/requisitioncard/?id=").concat(id));
        } // Create New Requisition

      }, {
        key: "createRequisition",
        value: function createRequisition(userID) {
          console.log('creator is:' + userID);
          return this.http.get("".concat(this.url, "site/create-requisition?userid=").concat(userID));
        } // get Units of Measure

      }, {
        key: "getunits",
        value: function getunits(itemNo) {
          return this.http.get("".concat(this.url, "site/unitmeasure?itemNo=").concat(itemNo)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        } // Get Locations List

      }, {
        key: "getLocations",
        value: function getLocations() {
          return this.http.get("".concat(this.url, "site/locationlist")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        } // Get any items from generic service getter function

      }, {
        key: "Dimensions",
        get: function get() {
          return this.http.get("".concat(this.url, "site/get?service=Dimensions")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "Departments",
        get: function get() {
          return this.http.get("".concat(this.url, "site/departments")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "Projects",
        get: function get() {
          return this.http.get("".concat(this.url, "site/projects")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        } // Post Lines Data

      }, {
        key: "postLine",
        value: function postLine(line) {
          var _this = this;

          return this.http.post("".concat(this.url, "site/requisition-lines"), JSON.stringify(line)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function () {
            _this._refresh$.next();
          }));
        } // Update Line

      }, {
        key: "updateRequisitionLine",
        value: function updateRequisitionLine(line) {
          var _this2 = this;

          return this.http.post("".concat(this.url, "site/updaterequisitionline"), JSON.stringify(line)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function () {
            _this2._refresh$.next();
          }));
        } // Fetch Line to Update

      }, {
        key: "getLine",
        value: function getLine(Key) {
          return this.http.get("".concat(this.url, "site/requisition-lines?Key=").concat(Key));
        } // Post Requisition Header

      }, {
        key: "postRequisition",
        value: function postRequisition(requisition) {
          return this.http.post("".concat(this.url, "site/update-requisition"), JSON.stringify(requisition));
        } // Format date utility

      }, {
        key: "formatDate",
        value: function formatDate(datestring) {
          // Format Date to YYYY-MM-DD
          var recDate = new Date(datestring);
          var month = recDate.getMonth() + 1 > 9 ? recDate.getMonth() + 1 : "0" + (recDate.getMonth() + 1);
          var day = recDate.getDate() > 9 ? recDate.getDate() : "0" + recDate.getDate();
          return "".concat(recDate.getFullYear(), "-").concat(month, "-").concat(day);
        }
      }]);

      return RequisitionService;
    }();

    RequisitionService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }];
    };

    RequisitionService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], RequisitionService);
    /***/
  },

  /***/
  "./src/app/requisitions/requisitions-routing.module.ts":
  /*!*************************************************************!*\
    !*** ./src/app/requisitions/requisitions-routing.module.ts ***!
    \*************************************************************/

  /*! exports provided: RequisitionsPageRoutingModule */

  /***/
  function srcAppRequisitionsRequisitionsRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RequisitionsPageRoutingModule", function () {
      return RequisitionsPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _requisitions_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./requisitions.page */
    "./src/app/requisitions/requisitions.page.ts");

    var routes = [{
      path: '',
      component: _requisitions_page__WEBPACK_IMPORTED_MODULE_3__["RequisitionsPage"]
    }, {
      path: 'requisition-details',
      loadChildren: function loadChildren() {
        return Promise.all(
        /*! import() | requisition-details-requisition-details-module */
        [__webpack_require__.e("default~orders-order-detail-order-detail-module~requisition-details-requisition-details-module~requi~ab00880c"), __webpack_require__.e("default~requisition-details-requisition-details-module~requisitions-requisition-details-requisition-~031c6e85")]).then(__webpack_require__.bind(null,
        /*! ./requisition-details/requisition-details.module */
        "./src/app/requisitions/requisition-details/requisition-details.module.ts")).then(function (m) {
          return m.RequisitionDetailsPageModule;
        });
      }
    }, {
      path: 'new-requisition',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | new-requisition-new-requisition-module */
        "default~new-requisition-new-requisition-module~requisitions-new-requisition-new-requisition-module").then(__webpack_require__.bind(null,
        /*! ./new-requisition/new-requisition.module */
        "./src/app/requisitions/new-requisition/new-requisition.module.ts")).then(function (m) {
          return m.NewRequisitionPageModule;
        });
      }
    }, {
      path: 'released-requisitions',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | released-requisitions-released-requisitions-module */
        "released-requisitions-released-requisitions-module").then(__webpack_require__.bind(null,
        /*! ./released-requisitions/released-requisitions.module */
        "./src/app/requisitions/released-requisitions/released-requisitions.module.ts")).then(function (m) {
          return m.ReleasedRequisitionsPageModule;
        });
      }
    }];

    var RequisitionsPageRoutingModule = function RequisitionsPageRoutingModule() {
      _classCallCheck(this, RequisitionsPageRoutingModule);
    };

    RequisitionsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], RequisitionsPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/requisitions/requisitions.module.ts":
  /*!*****************************************************!*\
    !*** ./src/app/requisitions/requisitions.module.ts ***!
    \*****************************************************/

  /*! exports provided: RequisitionsPageModule */

  /***/
  function srcAppRequisitionsRequisitionsModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RequisitionsPageModule", function () {
      return RequisitionsPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _requisitions_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./requisitions-routing.module */
    "./src/app/requisitions/requisitions-routing.module.ts");
    /* harmony import */


    var _requisitions_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./requisitions.page */
    "./src/app/requisitions/requisitions.page.ts");
    /* harmony import */


    var _req_popover_req_popover_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./req-popover/req-popover.component */
    "./src/app/requisitions/req-popover/req-popover.component.ts");

    var RequisitionsPageModule = function RequisitionsPageModule() {
      _classCallCheck(this, RequisitionsPageModule);
    };

    RequisitionsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _requisitions_routing_module__WEBPACK_IMPORTED_MODULE_5__["RequisitionsPageRoutingModule"]],
      entryComponents: [_req_popover_req_popover_component__WEBPACK_IMPORTED_MODULE_7__["ReqPopoverComponent"]],
      declarations: [_requisitions_page__WEBPACK_IMPORTED_MODULE_6__["RequisitionsPage"], _req_popover_req_popover_component__WEBPACK_IMPORTED_MODULE_7__["ReqPopoverComponent"]]
    })], RequisitionsPageModule);
    /***/
  },

  /***/
  "./src/app/requisitions/requisitions.page.scss":
  /*!*****************************************************!*\
    !*** ./src/app/requisitions/requisitions.page.scss ***!
    \*****************************************************/

  /*! exports provided: default */

  /***/
  function srcAppRequisitionsRequisitionsPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3JlcXVpc2l0aW9ucy9yZXF1aXNpdGlvbnMucGFnZS5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/requisitions/requisitions.page.ts":
  /*!***************************************************!*\
    !*** ./src/app/requisitions/requisitions.page.ts ***!
    \***************************************************/

  /*! exports provided: RequisitionsPage */

  /***/
  function srcAppRequisitionsRequisitionsPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RequisitionsPage", function () {
      return RequisitionsPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _requisition_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./requisition.service */
    "./src/app/requisitions/requisition.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _req_popover_req_popover_component__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ./req-popover/req-popover.component */
    "./src/app/requisitions/req-popover/req-popover.component.ts");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _auth_auth_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../auth/auth-service */
    "./src/app/auth/auth-service.ts");

    var RequisitionsPage = /*#__PURE__*/function () {
      function RequisitionsPage(requisitionService, menuCtrl, popoverCtrl, alertCtrl, authService) {
        _classCallCheck(this, RequisitionsPage);

        this.requisitionService = requisitionService;
        this.menuCtrl = menuCtrl;
        this.popoverCtrl = popoverCtrl;
        this.alertCtrl = alertCtrl;
        this.authService = authService;
        this.isLoading = false;
        this.searchTerm = null;
      }

      _createClass(RequisitionsPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.isLoading = true;
          this.setUser();
        }
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.setUser();
          console.log('Will Enter');
        }
      }, {
        key: "ionViewDidEnter",
        value: function ionViewDidEnter() {
          this.setUser();
          this.FetchRequisitions();
        }
      }, {
        key: "setUser",
        value: function setUser() {
          var _a;

          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.authService.getUser();

                  case 2:
                    this.user = _context.sent;
                    this.userID = (_a = this.user) === null || _a === void 0 ? void 0 : _a.User_ID;

                  case 4:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "FetchRequisitions",
        value: function FetchRequisitions() {
          var _this3 = this;

          this.requisitionSub = this.requisitionService.getRequisitions(this.userID).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["finalize"])(function () {
            _this3.isLoading = false;
          })).subscribe(function (result) {
            _this3.requisitions = _this3.sort(_toConsumableArray(result));
          }, function (error) {
            _this3.isLoading = false;
            console.log(error.error);

            _this3.alertCtrl.create({
              header: 'Service Error!',
              message: 'Connection problem: ' + error.error.message,
              buttons: [{
                text: 'Okay'
              }]
            }).then(function (alertEl) {
              alertEl.present();
            });
          });
        }
      }, {
        key: "search",
        value: function search($event) {
          var _this4 = this;

          // get a copy of requisitions
          var searchItems = _toConsumableArray(this.requisitions); // Begin search, only if searchTerm is provided


          if (this.searchTerm.trim().length && this.searchTerm !== '') {
            this.requisitions = searchItems.filter(function (req) {
              if (req.Req_No && req.Req_No.length > 1) {
                return req.Req_No.toLowerCase().indexOf(_this4.searchTerm.toLowerCase()) > -1;
              }
            });
            return;
          } else {
            // Search Term not provided display all requisitions
            this.initializeItems();
          }
        }
      }, {
        key: "initializeItems",
        value: function initializeItems() {
          var _this5 = this;

          this.requisitionSub = this.requisitionService.getRequisitions(this.userID).subscribe(function (result) {
            _this5.requisitions = result; // console.log(this.requisitions);
          });
        }
      }, {
        key: "openMenu",
        value: function openMenu() {
          this.menuCtrl.toggle();
        }
      }, {
        key: "presentPopover",
        value: function presentPopover(event) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.popoverCtrl.create({
                      component: _req_popover_req_popover_component__WEBPACK_IMPORTED_MODULE_4__["ReqPopoverComponent"],
                      event: event
                    }).then(function (pop) {
                      pop.present();
                    });

                  case 2:
                    return _context2.abrupt("return", _context2.sent);

                  case 3:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "sort",
        value: function sort(dataArray) {
          return dataArray.sort(function (a, b) {
            return b.Req_No > a.Req_No ? 1 : -1;
          });
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          // check if subscription is active / truthy then terrorize it. Like ( not same as) a destructor in php
          if (this.requisitionSub) {
            this.requisitionSub.unsubscribe();
          }
        }
      }]);

      return RequisitionsPage;
    }();

    RequisitionsPage.ctorParameters = function () {
      return [{
        type: _requisition_service__WEBPACK_IMPORTED_MODULE_2__["RequisitionService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["MenuController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["PopoverController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"]
      }, {
        type: _auth_auth_service__WEBPACK_IMPORTED_MODULE_6__["AuthService"]
      }];
    };

    RequisitionsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-requisitions',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./requisitions.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/requisitions/requisitions.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./requisitions.page.scss */
      "./src/app/requisitions/requisitions.page.scss"))["default"]]
    })], RequisitionsPage);
    /***/
  }
}]);
//# sourceMappingURL=requisitions-requisitions-module-es5.js.map