function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~orders-order-detail-order-detail-module~orders-orders-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/orders/lines/lines.component.html":
  /*!*****************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/orders/lines/lines.component.html ***!
    \*****************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppOrdersLinesLinesComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>{{line.No?'Update': 'New'}} Sales Invoice Line</ion-title>\r\n    <ion-buttons slot=\"primary\">\r\n      <ion-button (click)=\"onCancel()\">\r\n        <ion-icon name=\"close\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <ion-row>\r\n    <ion-col size-sm=\"6\" offset-sm=\"3\">\r\n      <ion-list>\r\n        \r\n        <ion-item>\r\n          <ion-label position=\"floating\">Item</ion-label>\r\n          <ion-select [(ngModel)]=\"line.No\" (ionChange)=\"getUnit($event)\" [selectedText]=\"line.Description\" placeholder=\"Select Item\">\r\n            <ion-select-option *ngFor=\"let item of items\" [value]=\"item?.No\" >{{ item.Description }}</ion-select-option>\r\n          </ion-select>\r\n        </ion-item>\r\n\r\n        <ion-item>\r\n          <ion-label position=\"floating\">Location Code</ion-label>\r\n          <ion-select [(ngModel)]=\"line.Location_Code\" required [selectedText]=\"line.Location_Code\" placeholder=\"Select Location\">\r\n            <ion-select-option *ngFor=\"let loc of locations\" [value]=\"loc?.Code\">{{loc.Name}}</ion-select-option>\r\n          </ion-select>\r\n        </ion-item>\r\n\r\n        <ion-item>\r\n          <ion-label  position=\"floating\">Quantity</ion-label>\r\n          <ion-input [(ngModel)]=\"line.Quantity\" type=\"number\"></ion-input>\r\n        </ion-item>\r\n\r\n        <ion-item >\r\n          <ion-label position=\"floating\">Unit Price</ion-label>\r\n          <ion-input [(ngModel)]=\"line.Unit_Price\" type=\"number\"></ion-input>\r\n        </ion-item>\r\n\r\n        <ion-item *ngIf=\"line.Line_No\">\r\n          <ion-label position=\"floating\">Line Amount</ion-label>\r\n          <ion-input [(ngModel)]=\"line.Line_Amount\" type=\"number\" disabled ></ion-input>\r\n        </ion-item>\r\n\r\n        \r\n\r\n\r\n      </ion-list>\r\n\r\n\r\n      <ion-button  *ngIf=\"!line.Line_No\" color=\"primary\" (click)=\"addLine()\" expand=\"block\" fill=\"outline\" >\r\n        Add Line\r\n      </ion-button>\r\n\r\n      <ion-button *ngIf=\"line.Line_No\"  color=\"primary\" (click)=\"updateLine()\" expand=\"block\" fill=\"outline\" >\r\n        Update Line\r\n      </ion-button>\r\n\r\n    </ion-col>\r\n  </ion-row>\r\n\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./src/app/models/salesinvoiceline.model.ts":
  /*!**************************************************!*\
    !*** ./src/app/models/salesinvoiceline.model.ts ***!
    \**************************************************/

  /*! exports provided: Salesinvoiceline */

  /***/
  function srcAppModelsSalesinvoicelineModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Salesinvoiceline", function () {
      return Salesinvoiceline;
    });

    var Salesinvoiceline = function Salesinvoiceline(Key, Type, No, Cross_Reference_No, IC_Partner_Code, IC_Partner_Ref_Type, IC_Partner_Reference, Variant_Code, Nonstock, VAT_Prod_Posting_Group, Description, Return_Reason_Code, Location_Code, Bin_Code, Quantity, Unit_of_Measure_Code, Unit_of_Measure, Unit_Cost_LCY, PriceExists, Unit_Price, Line_Discount_Percent, Line_Amount, LineDiscExists, Line_Discount_Amount, Allow_Invoice_Disc, Inv_Discount_Amount, Allow_Item_Charge_Assignment, Qty_to_Assign, Qty_Assigned, Job_No, Job_Task_No, Job_Contract_Entry_No, Tax_Category, Shipping_Agent_Code, Shipping_Agent_Service_Code, Work_Type_Code, Blanket_Order_No, Blanket_Order_Line_No, FA_Posting_Date, Depr_until_FA_Posting_Date, Depreciation_Book_Code, Use_Duplication_List, Duplicate_in_Depreciation_Book, Appl_from_Item_Entry, Appl_to_Item_Entry, Deferral_Code, Shortcut_Dimension_1_Code, Shortcut_Dimension_2_Code, ShortcutDimCode_x005B_3_x005D_, ShortcutDimCode_x005B_4_x005D_, ShortcutDimCode_x005B_5_x005D_, ShortcutDimCode_x005B_6_x005D_, ShortcutDimCode_x005B_7_x005D_, ShortcutDimCode_x005B_8_x005D_, Document_No, Line_No, TotalSalesLine_Line_Amount, Invoice_Discount_Amount, Invoice_Disc_Pct, Total_Amount_Excl_VAT, Total_VAT_Amount, Total_Amount_Incl_VAT, error) {
      _classCallCheck(this, Salesinvoiceline);

      this.Key = Key;
      this.Type = Type;
      this.No = No;
      this.Cross_Reference_No = Cross_Reference_No;
      this.IC_Partner_Code = IC_Partner_Code;
      this.IC_Partner_Ref_Type = IC_Partner_Ref_Type;
      this.IC_Partner_Reference = IC_Partner_Reference;
      this.Variant_Code = Variant_Code;
      this.Nonstock = Nonstock;
      this.VAT_Prod_Posting_Group = VAT_Prod_Posting_Group;
      this.Description = Description;
      this.Return_Reason_Code = Return_Reason_Code;
      this.Location_Code = Location_Code;
      this.Bin_Code = Bin_Code;
      this.Quantity = Quantity;
      this.Unit_of_Measure_Code = Unit_of_Measure_Code;
      this.Unit_of_Measure = Unit_of_Measure;
      this.Unit_Cost_LCY = Unit_Cost_LCY;
      this.PriceExists = PriceExists;
      this.Unit_Price = Unit_Price;
      this.Line_Discount_Percent = Line_Discount_Percent;
      this.Line_Amount = Line_Amount;
      this.LineDiscExists = LineDiscExists;
      this.Line_Discount_Amount = Line_Discount_Amount;
      this.Allow_Invoice_Disc = Allow_Invoice_Disc;
      this.Inv_Discount_Amount = Inv_Discount_Amount;
      this.Allow_Item_Charge_Assignment = Allow_Item_Charge_Assignment;
      this.Qty_to_Assign = Qty_to_Assign;
      this.Qty_Assigned = Qty_Assigned;
      this.Job_No = Job_No;
      this.Job_Task_No = Job_Task_No;
      this.Job_Contract_Entry_No = Job_Contract_Entry_No;
      this.Tax_Category = Tax_Category;
      this.Shipping_Agent_Code = Shipping_Agent_Code;
      this.Shipping_Agent_Service_Code = Shipping_Agent_Service_Code;
      this.Work_Type_Code = Work_Type_Code;
      this.Blanket_Order_No = Blanket_Order_No;
      this.Blanket_Order_Line_No = Blanket_Order_Line_No;
      this.FA_Posting_Date = FA_Posting_Date;
      this.Depr_until_FA_Posting_Date = Depr_until_FA_Posting_Date;
      this.Depreciation_Book_Code = Depreciation_Book_Code;
      this.Use_Duplication_List = Use_Duplication_List;
      this.Duplicate_in_Depreciation_Book = Duplicate_in_Depreciation_Book;
      this.Appl_from_Item_Entry = Appl_from_Item_Entry;
      this.Appl_to_Item_Entry = Appl_to_Item_Entry;
      this.Deferral_Code = Deferral_Code;
      this.Shortcut_Dimension_1_Code = Shortcut_Dimension_1_Code;
      this.Shortcut_Dimension_2_Code = Shortcut_Dimension_2_Code;
      this.ShortcutDimCode_x005B_3_x005D_ = ShortcutDimCode_x005B_3_x005D_;
      this.ShortcutDimCode_x005B_4_x005D_ = ShortcutDimCode_x005B_4_x005D_;
      this.ShortcutDimCode_x005B_5_x005D_ = ShortcutDimCode_x005B_5_x005D_;
      this.ShortcutDimCode_x005B_6_x005D_ = ShortcutDimCode_x005B_6_x005D_;
      this.ShortcutDimCode_x005B_7_x005D_ = ShortcutDimCode_x005B_7_x005D_;
      this.ShortcutDimCode_x005B_8_x005D_ = ShortcutDimCode_x005B_8_x005D_;
      this.Document_No = Document_No;
      this.Line_No = Line_No;
      this.TotalSalesLine_Line_Amount = TotalSalesLine_Line_Amount;
      this.Invoice_Discount_Amount = Invoice_Discount_Amount;
      this.Invoice_Disc_Pct = Invoice_Disc_Pct;
      this.Total_Amount_Excl_VAT = Total_Amount_Excl_VAT;
      this.Total_VAT_Amount = Total_VAT_Amount;
      this.Total_Amount_Incl_VAT = Total_Amount_Incl_VAT;
      this.error = error;
    };
    /***/

  },

  /***/
  "./src/app/orders/lines/lines.component.scss":
  /*!***************************************************!*\
    !*** ./src/app/orders/lines/lines.component.scss ***!
    \***************************************************/

  /*! exports provided: default */

  /***/
  function srcAppOrdersLinesLinesComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL29yZGVycy9saW5lcy9saW5lcy5jb21wb25lbnQuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/orders/lines/lines.component.ts":
  /*!*************************************************!*\
    !*** ./src/app/orders/lines/lines.component.ts ***!
    \*************************************************/

  /*! exports provided: LinesComponent */

  /***/
  function srcAppOrdersLinesLinesComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "LinesComponent", function () {
      return LinesComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var src_app_models_salesinvoiceline_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/models/salesinvoiceline.model */
    "./src/app/models/salesinvoiceline.model.ts");
    /* harmony import */


    var _items_item_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../../items/item.service */
    "./src/app/items/item.service.ts");
    /* harmony import */


    var src_app_requisitions_requisition_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/requisitions/requisition.service */
    "./src/app/requisitions/requisition.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _order_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../order.service */
    "./src/app/orders/order.service.ts");

    var LinesComponent = /*#__PURE__*/function () {
      function LinesComponent(modalCtrl, itemService, requisitionService, navCtrl, toastCtrl, alertCtr, router, orderService, alertCtrl) {
        _classCallCheck(this, LinesComponent);

        this.modalCtrl = modalCtrl;
        this.itemService = itemService;
        this.requisitionService = requisitionService;
        this.navCtrl = navCtrl;
        this.toastCtrl = toastCtrl;
        this.alertCtr = alertCtr;
        this.router = router;
        this.orderService = orderService;
        this.alertCtrl = alertCtrl;
        this.items = null;
        this.units = [];
        this.line = new src_app_models_salesinvoiceline_model__WEBPACK_IMPORTED_MODULE_3__["Salesinvoiceline"]();
      }

      _createClass(LinesComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this = this;

          this.itemSub = this.itemService.items.subscribe(function (res) {
            console.log(typeof res);

            if (typeof res === 'object') {
              _this.items = _toConsumableArray(res);
            }
          });

          if (this.LineNo) {
            this.FetchLinetoUpdate();
          }

          this.FetchLocations();
        }
      }, {
        key: "getUnit",
        value: function getUnit($event) {
          var _this2 = this;

          this.unitSub = this.requisitionService.getunits(this.line.No).subscribe(function (units) {
            _this2.units = units;
            _this2.line.Document_No = _this2.docID;
          });
        }
      }, {
        key: "addLine",
        value: function addLine() {
          var _this3 = this;

          this.orderService.postLine(this.line).subscribe(function (line) {
            console.log(line);

            if (line) {
              // this.navCtrl.navigateForward('/requisitions/' + this.docId);
              _this3.modalCtrl.dismiss(); // Show a Toast Notification


              _this3.toastCtrl.create({
                message: "Sales Invoice Line Added Successfully.",
                duration: 3000,
                position: 'top'
              }).then(function (toastData) {
                toastData.present();
              });
            } else {
              // Alert the error
              console.log(line);

              _this3.alertCtrl.create({
                header: 'Operation Error',
                message: 'Message : ' + (line === null || line === void 0 ? void 0 : line.error),
                buttons: [{
                  text: 'Okay',
                  handler: function handler() {
                    return _this3.modalCtrl.dismiss();
                  }
                }]
              }).then(function (alertEl) {
                alertEl.present();
              });
            }
          }, function (error) {
            console.log(error.error);

            _this3.alertCtr.create({
              header: 'Service Error!',
              message: 'Connection problem: ' + error,
              buttons: [{
                text: 'Okay',
                handler: function handler() {
                  return _this3.modalCtrl.dismiss();
                }
              }]
            }).then(function (alertEl) {
              alertEl.present();
            });
          });
        }
      }, {
        key: "updateLine",
        value: function updateLine() {
          var _this4 = this;

          this.orderService.updateInvoiceLine(this.line).subscribe(function (line) {
            if (line) {
              console.log(line);

              _this4.toastCtrl.create({
                header: 'Success!',
                message: "".concat(line.Description, " Invoice Line Updated Successfully."),
                duration: 3000,
                position: 'top'
              }).then(function (toastData) {
                toastData.present();
              });

              _this4.modalCtrl.dismiss();

              _this4.router.navigate(['/orders/' + line.Document_No]);
            } else {
              // Alert the error
              _this4.alertCtrl.create({
                header: 'Operation Error',
                message: 'Message : ' + line,
                buttons: [{
                  text: 'Okay',
                  handler: function handler() {
                    return _this4.modalCtrl.dismiss();
                  }
                }]
              }).then(function (alertEl) {
                alertEl.present();
              });
            }
          }, function (error) {
            console.log(error.error);

            _this4.alertCtr.create({
              header: 'Service Error!',
              message: 'Connection problem: ' + error,
              buttons: [{
                text: 'Okay',
                handler: function handler() {
                  return _this4.modalCtrl.dismiss();
                }
              }]
            }).then(function (alertEl) {
              alertEl.present();
            });
          });
        }
      }, {
        key: "FetchLinetoUpdate",
        value: function FetchLinetoUpdate() {
          var _this5 = this;

          this.updateLineSub = this.orderService.getLine(this.docID, this.LineNo).subscribe(function (res) {
            Object.assign(_this5.line, res);
          });
        }
      }, {
        key: "FetchLocations",
        value: function FetchLocations() {
          var _this6 = this;

          this.locationsSub = this.requisitionService.getLocations().subscribe(function (loc) {
            _this6.locations = loc;
          });
        }
      }, {
        key: "onCancel",
        value: function onCancel() {
          this.modalCtrl.dismiss();
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          if (this.itemSub) {
            this.itemSub.unsubscribe();
          }

          if (this.unitSub) {
            this.unitSub.unsubscribe();
          }

          if (this.updateLineSub) {
            this.updateLineSub.unsubscribe();
          }
        }
      }]);

      return LinesComponent;
    }();

    LinesComponent.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
      }, {
        type: _items_item_service__WEBPACK_IMPORTED_MODULE_4__["ItemService"]
      }, {
        type: src_app_requisitions_requisition_service__WEBPACK_IMPORTED_MODULE_5__["RequisitionService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["NavController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_6__["Router"]
      }, {
        type: _order_service__WEBPACK_IMPORTED_MODULE_7__["OrderService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }];
    };

    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], LinesComponent.prototype, "docID", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], LinesComponent.prototype, "LineNo", void 0);
    LinesComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-lines',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./lines.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/orders/lines/lines.component.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./lines.component.scss */
      "./src/app/orders/lines/lines.component.scss"))["default"]]
    })], LinesComponent);
    /***/
  },

  /***/
  "./src/app/orders/order.service.ts":
  /*!*****************************************!*\
    !*** ./src/app/orders/order.service.ts ***!
    \*****************************************/

  /*! exports provided: OrderService */

  /***/
  function srcAppOrdersOrderServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "OrderService", function () {
      return OrderService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");

    var OrderService = /*#__PURE__*/function () {
      // private items  = new BehaviorSubject<[]>([]) ;
      function OrderService(http) {
        _classCallCheck(this, OrderService);

        this.http = http;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
      }

      _createClass(OrderService, [{
        key: "orders",
        get: function get() {
          return this.http.get("".concat(this.url, "site/saleinvoices")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        } // Create New Sales Invoice

      }, {
        key: "createInvoice",
        value: function createInvoice() {
          return this.http.get("".concat(this.url, "site/create-invoice"));
        } // Retrieve Sales Invoice Card / Details

      }, {
        key: "ordercard",
        value: function ordercard(id) {
          return this.http.get("".concat(this.url, "site/saleinvoice/?id=").concat(id));
        } // Post Lines Data

      }, {
        key: "postLine",
        value: function postLine(line) {
          return this.http.post("".concat(this.url, "site/addsalesinvoiceline"), JSON.stringify(line));
        } // Update Line

      }, {
        key: "updateInvoiceLine",
        value: function updateInvoiceLine(line) {
          return this.http.post("".concat(this.url, "site/updatesalesinvoiceline"), JSON.stringify(line));
        } // Fetch Line to Update

      }, {
        key: "getLine",
        value: function getLine(docId, LineNo) {
          return this.http.get("".concat(this.url, "site/getsalesinvoiceline?Document_No=").concat(docId, "&Line_No=").concat(LineNo));
        } // Post Invoice Header

      }, {
        key: "postInvoice",
        value: function postInvoice(invoice) {
          invoice.Posting_Date = this.formatDate(invoice.Posting_Date);
          invoice.Due_Date = this.formatDate(invoice.Due_Date);
          return this.http.post("".concat(this.url, "site/update-invoice"), JSON.stringify(invoice));
        } // Get Customers

      }, {
        key: "Customers",
        get: function get() {
          return this.http.get("".concat(this.url, "site/receipting-customers")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "postSalesInvoice",
        value: function postSalesInvoice(No) {
          return this.http.get("".concat(this.url, "site/postsaleinvoice?No=").concat(No));
        } // Format date utility

      }, {
        key: "formatDate",
        value: function formatDate(datestring) {
          // Format Date to YYYY-MM-DD
          var recDate = new Date(datestring);
          var month = recDate.getMonth() + 1 > 9 ? recDate.getMonth() + 1 : "0" + (recDate.getMonth() + 1);
          var day = recDate.getDate() > 9 ? recDate.getDate() : "0" + recDate.getDate();
          return "".concat(recDate.getFullYear(), "-").concat(month, "-").concat(day);
        }
      }]);

      return OrderService;
    }();

    OrderService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }];
    };

    OrderService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], OrderService);
    /***/
  },

  /***/
  "./src/app/requisitions/requisition.service.ts":
  /*!*****************************************************!*\
    !*** ./src/app/requisitions/requisition.service.ts ***!
    \*****************************************************/

  /*! exports provided: RequisitionService */

  /***/
  function srcAppRequisitionsRequisitionServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "RequisitionService", function () {
      return RequisitionService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");

    var RequisitionService = /*#__PURE__*/function () {
      function RequisitionService(http) {
        _classCallCheck(this, RequisitionService);

        this.http = http;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
        this._refresh$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__["Subject"]();
      } // Synthetic Getter for our refresh observerble


      _createClass(RequisitionService, [{
        key: "refresh$",
        get: function get() {
          return this._refresh$;
        }
      }, {
        key: "getRequisitions",
        value: function getRequisitions(userID) {
          return this.http.get("".concat(this.url, "site/requisitions?userid=").concat(userID)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "releasedrequisitions",
        get: function get() {
          return this.http.get("".concat(this.url, "site/releasedrequisitions")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        } // Retrieve Requisition Card / Details

      }, {
        key: "requisitioncard",
        value: function requisitioncard(id) {
          return this.http.get("".concat(this.url, "site/requisitioncard/?id=").concat(id));
        } // Create New Requisition

      }, {
        key: "createRequisition",
        value: function createRequisition(userID) {
          console.log('creator is:' + userID);
          return this.http.get("".concat(this.url, "site/create-requisition?userid=").concat(userID));
        } // get Units of Measure

      }, {
        key: "getunits",
        value: function getunits(itemNo) {
          return this.http.get("".concat(this.url, "site/unitmeasure?itemNo=").concat(itemNo)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        } // Get Locations List

      }, {
        key: "getLocations",
        value: function getLocations() {
          return this.http.get("".concat(this.url, "site/locationlist")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        } // Get any items from generic service getter function

      }, {
        key: "Dimensions",
        get: function get() {
          return this.http.get("".concat(this.url, "site/get?service=Dimensions")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "Departments",
        get: function get() {
          return this.http.get("".concat(this.url, "site/departments")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "Projects",
        get: function get() {
          return this.http.get("".concat(this.url, "site/projects")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        } // Post Lines Data

      }, {
        key: "postLine",
        value: function postLine(line) {
          var _this7 = this;

          return this.http.post("".concat(this.url, "site/requisition-lines"), JSON.stringify(line)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function () {
            _this7._refresh$.next();
          }));
        } // Update Line

      }, {
        key: "updateRequisitionLine",
        value: function updateRequisitionLine(line) {
          var _this8 = this;

          return this.http.post("".concat(this.url, "site/updaterequisitionline"), JSON.stringify(line)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(function () {
            _this8._refresh$.next();
          }));
        } // Fetch Line to Update

      }, {
        key: "getLine",
        value: function getLine(Key) {
          return this.http.get("".concat(this.url, "site/requisition-lines?Key=").concat(Key));
        } // Post Requisition Header

      }, {
        key: "postRequisition",
        value: function postRequisition(requisition) {
          return this.http.post("".concat(this.url, "site/update-requisition"), JSON.stringify(requisition));
        } // Format date utility

      }, {
        key: "formatDate",
        value: function formatDate(datestring) {
          // Format Date to YYYY-MM-DD
          var recDate = new Date(datestring);
          var month = recDate.getMonth() + 1 > 9 ? recDate.getMonth() + 1 : "0" + (recDate.getMonth() + 1);
          var day = recDate.getDate() > 9 ? recDate.getDate() : "0" + recDate.getDate();
          return "".concat(recDate.getFullYear(), "-").concat(month, "-").concat(day);
        }
      }]);

      return RequisitionService;
    }();

    RequisitionService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }];
    };

    RequisitionService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], RequisitionService);
    /***/
  }
}]);
//# sourceMappingURL=default~orders-order-detail-order-detail-module~orders-orders-module-es5.js.map