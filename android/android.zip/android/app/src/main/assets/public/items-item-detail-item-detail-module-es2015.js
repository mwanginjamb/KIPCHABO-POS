(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["items-item-detail-item-detail-module"],{

/***/ "./src/app/items/item.service.ts":
/*!***************************************!*\
  !*** ./src/app/items/item.service.ts ***!
  \***************************************/
/*! exports provided: ItemService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ItemService", function() { return ItemService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");






let ItemService = class ItemService {
    constructor(http, toastCtrl) {
        this.http = http;
        this.toastCtrl = toastCtrl;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
    }
    get items() {
        return this.http.get(`${this.url}site/items`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    itemcard(id) {
        return this.http.get(`${this.url}site/itemcard/?id=${id}`);
    }
    itemBalance(No) {
        return this.http.get(`${this.url}site/itemavailabilitybylocation/?No=${No}`);
    }
    itemBalanceByLocation(No, LocationCode) {
        return this.http.get(`${this.url}site/itemavailabilitybylocation/?No=${No}&Location=${LocationCode}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    getTotals(elements, subjectColumn) {
        let sum = 0;
        elements.forEach(obj => {
            // console.log(obj);
            for (const property in obj) {
                if (property === subjectColumn && !isNaN(+obj[property])) {
                    // console.log(+obj[property]);
                    sum += +obj[property];
                }
            }
        });
        return sum;
    }
    // Get Locations List
    getLocations() {
        return this.http.get(`${this.url}site/locationlist`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    showToast(text) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return yield this.toastCtrl.create({
                message: text,
                duration: 4000,
                position: 'top'
            }).then(toastEl => {
                toastEl.present();
            });
        });
    }
};
ItemService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"] }
];
ItemService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], ItemService);



/***/ })

}]);
//# sourceMappingURL=items-item-detail-item-detail-module-es2015.js.map