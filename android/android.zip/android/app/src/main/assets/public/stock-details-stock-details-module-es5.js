function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["stock-details-stock-details-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/stock-details/lines/lines.component.html":
  /*!************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/stock-details/lines/lines.component.html ***!
    \************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppStockDetailsLinesLinesComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>Stock Issue Line</ion-title>\r\n\r\n    <ion-buttons slot=\"primary\">\r\n      <ion-button (click)=\"onCancel()\">\r\n        <ion-icon name=\"close\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <ion-row>\r\n    <ion-col size-sm=\"6\" offset-sm=\"3\">\r\n      <ion-list>\r\n\r\n      \r\n\r\n        <ion-item>\r\n          <ion-label position=\"floating\">Description</ion-label>\r\n          <ion-input [(ngModel)]=\"line.Description\" type=\"text\" readonly></ion-input>\r\n        </ion-item>\r\n\r\n        <ion-item>\r\n          <ion-label  position=\"floating\">Qty. Requested</ion-label>\r\n          <ion-input [(ngModel)]=\"line.Requested_Pieces\" type=\"number\" readonly></ion-input>\r\n        </ion-item>\r\n\r\n        <ion-item>\r\n          <ion-label  position=\"floating\">Qty. Issues</ion-label>\r\n          <ion-input [(ngModel)]=\"line.Issued_Pieces\" type=\"number\" readonly></ion-input>\r\n        </ion-item>\r\n\r\n        <ion-item>\r\n          <ion-label position=\"floating\">Pieces Received</ion-label>\r\n          <ion-input [(ngModel)]=\"line.Pieces_Received\" type=\"number\"></ion-input>\r\n        </ion-item>\r\n      \r\n\r\n        \r\n\r\n\r\n      </ion-list>\r\n\r\n\r\n\r\n      <ion-button  color=\"primary\" (click)=\"updateLine()\" expand=\"block\" fill=\"outline\" >\r\n        Update Line\r\n      </ion-button>\r\n\r\n    </ion-col>\r\n  </ion-row>\r\n\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/stock-details/stock-details.page.html":
  /*!*********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/stock-details/stock-details.page.html ***!
    \*********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppStockDetailsStockDetailsPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button defaultHref=\"requisitions/released-requisitions\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>Shipped Stock Details</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content *ngIf=\"card?.Stock_Issue_No\">\r\n\r\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"refresh($event)\" pullMin=\"100\" pullMax=\"200\">\r\n    <ion-refresher-content pullingIcon=\"arrow-down-outline\" pullingText=\"Pull to Refresh\" refreshingSpinner=\"crescent\"\r\n      refreshingText=\"Refreshing...\">\r\n    </ion-refresher-content>\r\n  </ion-refresher>\r\n\r\n<ion-fab vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\">\r\n  <ion-fab-button color=\"warning\" (click)=\"post(card.Stock_Issue_No)\">\r\n    <ion-icon name=\"send\"></ion-icon>\r\n  </ion-fab-button>\r\n</ion-fab>\r\n\r\n  <ion-grid>\r\n    <ion-row>\r\n      <ion-col >\r\n         <ion-card>\r\n           <ion-card-header>\r\n             <ion-card-title>\r\n               General Card Details\r\n             </ion-card-title>\r\n           </ion-card-header>\r\n\r\n           <ion-card-content>\r\n\r\n             <ion-row>\r\n               <ion-col >\r\n                 <ion-item>\r\n                   <ion-label position=\"fixed\">Issue. No</ion-label>\r\n                   <ion-text>{{ card?.Stock_Issue_No }}</ion-text>\r\n                 </ion-item>\r\n               </ion-col>\r\n\r\n               <ion-col >\r\n                 <ion-item>\r\n                   <ion-label position=\"fixed\">Receiving Store</ion-label>\r\n                   <ion-text>{{ card?.Receiving_Store_Name }}</ion-text>\r\n                 </ion-item>\r\n               </ion-col>\r\n             </ion-row>\r\n\r\n             <ion-row>\r\n               <ion-col >\r\n                 <ion-item>\r\n                   <ion-label position=\"fixed\">Receipt Date</ion-label>\r\n                  <!-- <ion-text>{{ card?.Receipt_Date }}</ion-text>-->\r\n                  <ion-datetime type=\"date\" [(ngModel)]=\"card.Receipt_Date\" (ionChange)=\"onUpdateCard($event)\" name=\"Receipt_Date\">\r\n                  </ion-datetime>\r\n                 </ion-item>\r\n               </ion-col>\r\n\r\n               <ion-col >\r\n                 <ion-item>\r\n                   <ion-label position=\"fixed\">Order No.</ion-label>\r\n                   <ion-text>{{ card?.Order_No }}</ion-text>\r\n                 </ion-item>\r\n               </ion-col>\r\n             </ion-row>\r\n\r\n            \r\n\r\n             \r\n\r\n            \r\n           </ion-card-content>\r\n\r\n         </ion-card> \r\n\r\n         <!--Start Lines Card-->\r\n         <ion-card>\r\n           <ion-card-header>\r\n             <ion-card-title>Lines</ion-card-title>\r\n           </ion-card-header>\r\n           <ion-card-content>\r\n             <ion-grid>\r\n               \r\n\r\n               <ion-row scrollX=\"true\">\r\n                 <ion-col>\r\n                   <ion-label>Description</ion-label>\r\n                 </ion-col>\r\n\r\n                 \r\n                 <ion-col>\r\n                   <ion-label>Requested</ion-label>\r\n                 </ion-col>\r\n\r\n                 \r\n                 <ion-col>\r\n                   <ion-label>Issued</ion-label>\r\n                 </ion-col>\r\n\r\n                 <ion-col>\r\n                  <ion-label>Received</ion-label>\r\n                </ion-col>\r\n\r\n                \r\n\r\n               </ion-row>\r\n             \r\n                \r\n              \r\n               <ion-list *ngFor=\"let item of card ?.Point_Of_Sale_Issue_Line_Ship ?.Point_Of_Sale_Issue_Line_Ship\">\r\n                   <ion-row >\r\n                     <ion-col> \r\n                      <ion-item (click)=\"onUpdateLine(item?.Key)\" color=\"primary\">\r\n                           <ion-label>{{item.Description}}</ion-label>\r\n                       </ion-item>\r\n                     </ion-col>\r\n \r\n                    \r\n \r\n                     \r\n \r\n                     <ion-col> \r\n                       <ion-item>                         \r\n                           <ion-label>{{item.Requested_Pieces}}</ion-label>\r\n                       </ion-item>\r\n                     </ion-col>\r\n \r\n                     \r\n \r\n                     <ion-col> \r\n                       <ion-item>                         \r\n                           <ion-label>{{item.Issued_Pieces}}</ion-label>\r\n                       </ion-item>\r\n                     </ion-col>\r\n\r\n                     <ion-col> \r\n                      <ion-item>                         \r\n                          <ion-label>{{item.Pieces_Received}}</ion-label>\r\n                      </ion-item>\r\n                    </ion-col>\r\n \r\n                     \r\n \r\n                   </ion-row>   \r\n               </ion-list>\r\n                \r\n               \r\n             </ion-grid>\r\n           </ion-card-content>\r\n         </ion-card>\r\n         <!--End Lines Card-->\r\n      </ion-col>\r\n    </ion-row>\r\n </ion-grid>\r\n\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./src/app/models/stockissueline.model.ts":
  /*!************************************************!*\
    !*** ./src/app/models/stockissueline.model.ts ***!
    \************************************************/

  /*! exports provided: Stockissueline */

  /***/
  function srcAppModelsStockissuelineModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Stockissueline", function () {
      return Stockissueline;
    });

    var Stockissueline = function Stockissueline(Key, Item_No, Description, Requested_Pieces, Issued_Pieces, Pieces_Received, Stock_Issue_No) {
      _classCallCheck(this, Stockissueline);

      this.Key = Key;
      this.Item_No = Item_No;
      this.Description = Description;
      this.Requested_Pieces = Requested_Pieces;
      this.Issued_Pieces = Issued_Pieces;
      this.Pieces_Received = Pieces_Received;
      this.Stock_Issue_No = Stock_Issue_No;
    };
    /***/

  },

  /***/
  "./src/app/stock-details/lines/lines.component.scss":
  /*!**********************************************************!*\
    !*** ./src/app/stock-details/lines/lines.component.scss ***!
    \**********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppStockDetailsLinesLinesComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3N0b2NrLWRldGFpbHMvbGluZXMvbGluZXMuY29tcG9uZW50LnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/stock-details/lines/lines.component.ts":
  /*!********************************************************!*\
    !*** ./src/app/stock-details/lines/lines.component.ts ***!
    \********************************************************/

  /*! exports provided: LinesComponent */

  /***/
  function srcAppStockDetailsLinesLinesComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "LinesComponent", function () {
      return LinesComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var src_app_models_stockissueline_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/models/stockissueline.model */
    "./src/app/models/stockissueline.model.ts");
    /* harmony import */


    var _stockdetail_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../stockdetail.service */
    "./src/app/stock-details/stockdetail.service.ts");

    var LinesComponent = /*#__PURE__*/function () {
      function LinesComponent(stockService, modalCtrl, toastCtrl, alertCtrl) {
        _classCallCheck(this, LinesComponent);

        this.stockService = stockService;
        this.modalCtrl = modalCtrl;
        this.toastCtrl = toastCtrl;
        this.alertCtrl = alertCtrl;
        this.line = new src_app_models_stockissueline_model__WEBPACK_IMPORTED_MODULE_3__["Stockissueline"]();
      }

      _createClass(LinesComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          console.log(this.Key);

          if (this.Key) {
            this.FetchLinetoUpdate();
          }
        }
      }, {
        key: "updateLine",
        value: function updateLine() {
          var _this = this;

          this.stockService.updateRequisitionLine(this.line).subscribe(function (line) {
            if (typeof line !== 'string') {
              console.log("Updated Line.......");
              console.table(line);

              _this.toastCtrl.create({
                message: "".concat(line.Description, " Requisition Line Updated Successfully."),
                duration: 3000,
                position: 'top'
              }).then(function (toastData) {
                toastData.present();
              });

              _this.modalCtrl.dismiss(); // this.router.navigate(['/requisitions/' + line.Document_No]);

            } else {
              // Alert the error
              _this.alertCtrl.create({
                header: 'Operation Error',
                message: 'Message : ' + line,
                buttons: [{
                  text: 'Okay',
                  handler: function handler() {
                    return _this.modalCtrl.dismiss();
                  }
                }]
              }).then(function (alertEl) {
                alertEl.present();
              });
            }
          }, function (error) {
            console.log(error.error);

            _this.alertCtrl.create({
              header: 'Service Error!',
              message: 'Connection problem: ' + error.error,
              buttons: [{
                text: 'Okay',
                handler: function handler() {
                  return _this.modalCtrl.dismiss();
                }
              }]
            }).then(function (alertEl) {
              alertEl.present();
            });
          });
        }
      }, {
        key: "FetchLinetoUpdate",
        value: function FetchLinetoUpdate() {
          var _this2 = this;

          this.updateLineSub = this.stockService.getLine(this.Key).subscribe(function (res) {
            Object.assign(_this2.line, res);
          }, function (error) {
            console.log(error.error);

            _this2.alertCtrl.create({
              header: 'Service Error!',
              message: 'Connection problem: ' + error.error.message,
              buttons: [{
                text: 'Okay',
                handler: function handler() {
                  return _this2.modalCtrl.dismiss();
                }
              }]
            }).then(function (alertEl) {
              alertEl.present();
            });
          });
        } // Closing component modal

      }, {
        key: "onCancel",
        value: function onCancel() {
          this.modalCtrl.dismiss();
        }
      }]);

      return LinesComponent;
    }();

    LinesComponent.ctorParameters = function () {
      return [{
        type: _stockdetail_service__WEBPACK_IMPORTED_MODULE_4__["StockdetailService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"]
      }];
    };

    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], LinesComponent.prototype, "Key", void 0);
    LinesComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-lines',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./lines.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/stock-details/lines/lines.component.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./lines.component.scss */
      "./src/app/stock-details/lines/lines.component.scss"))["default"]]
    })], LinesComponent);
    /***/
  },

  /***/
  "./src/app/stock-details/stock-details-routing.module.ts":
  /*!***************************************************************!*\
    !*** ./src/app/stock-details/stock-details-routing.module.ts ***!
    \***************************************************************/

  /*! exports provided: StockDetailsPageRoutingModule */

  /***/
  function srcAppStockDetailsStockDetailsRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "StockDetailsPageRoutingModule", function () {
      return StockDetailsPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _stock_details_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./stock-details.page */
    "./src/app/stock-details/stock-details.page.ts");

    var routes = [{
      path: ':id',
      component: _stock_details_page__WEBPACK_IMPORTED_MODULE_3__["StockDetailsPage"]
    }];

    var StockDetailsPageRoutingModule = function StockDetailsPageRoutingModule() {
      _classCallCheck(this, StockDetailsPageRoutingModule);
    };

    StockDetailsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], StockDetailsPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/stock-details/stock-details.module.ts":
  /*!*******************************************************!*\
    !*** ./src/app/stock-details/stock-details.module.ts ***!
    \*******************************************************/

  /*! exports provided: StockDetailsPageModule */

  /***/
  function srcAppStockDetailsStockDetailsModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "StockDetailsPageModule", function () {
      return StockDetailsPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _stock_details_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./stock-details-routing.module */
    "./src/app/stock-details/stock-details-routing.module.ts");
    /* harmony import */


    var _stock_details_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./stock-details.page */
    "./src/app/stock-details/stock-details.page.ts");
    /* harmony import */


    var _lines_lines_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ./lines/lines.component */
    "./src/app/stock-details/lines/lines.component.ts");

    var StockDetailsPageModule = function StockDetailsPageModule() {
      _classCallCheck(this, StockDetailsPageModule);
    };

    StockDetailsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _stock_details_routing_module__WEBPACK_IMPORTED_MODULE_5__["StockDetailsPageRoutingModule"]],
      declarations: [_stock_details_page__WEBPACK_IMPORTED_MODULE_6__["StockDetailsPage"], _lines_lines_component__WEBPACK_IMPORTED_MODULE_7__["LinesComponent"]],
      entryComponents: [_lines_lines_component__WEBPACK_IMPORTED_MODULE_7__["LinesComponent"]]
    })], StockDetailsPageModule);
    /***/
  },

  /***/
  "./src/app/stock-details/stock-details.page.scss":
  /*!*******************************************************!*\
    !*** ./src/app/stock-details/stock-details.page.scss ***!
    \*******************************************************/

  /*! exports provided: default */

  /***/
  function srcAppStockDetailsStockDetailsPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3N0b2NrLWRldGFpbHMvc3RvY2stZGV0YWlscy5wYWdlLnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/stock-details/stock-details.page.ts":
  /*!*****************************************************!*\
    !*** ./src/app/stock-details/stock-details.page.ts ***!
    \*****************************************************/

  /*! exports provided: StockDetailsPage */

  /***/
  function srcAppStockDetailsStockDetailsPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "StockDetailsPage", function () {
      return StockDetailsPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _lines_lines_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./lines/lines.component */
    "./src/app/stock-details/lines/lines.component.ts");
    /* harmony import */


    var _stockdetail_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./stockdetail.service */
    "./src/app/stock-details/stockdetail.service.ts");

    var StockDetailsPage = /*#__PURE__*/function () {
      function StockDetailsPage(stockService, activatedRoute, modalCtrl, loadingCtrl, alertCtrl, toastCtrl) {
        _classCallCheck(this, StockDetailsPage);

        this.stockService = stockService;
        this.activatedRoute = activatedRoute;
        this.modalCtrl = modalCtrl;
        this.loadingCtrl = loadingCtrl;
        this.alertCtrl = alertCtrl;
        this.toastCtrl = toastCtrl;
      }

      _createClass(StockDetailsPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this3 = this;

          // this.presentLoading();
          this.id = this.activatedRoute.snapshot.paramMap.get('id'); // console.log(this.id);

          this.cardSub = this.stockService.requisitioncard(this.id).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["finalize"])(function () {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this3, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
              return regeneratorRuntime.wrap(function _callee$(_context) {
                while (1) {
                  switch (_context.prev = _context.next) {
                    case 0:
                      _context.next = 2;
                      return this.loading.dismiss();

                    case 2:
                    case "end":
                      return _context.stop();
                  }
                }
              }, _callee, this);
            }));
          })).subscribe(function (cardInfo) {
            _this3.card = cardInfo;
            console.log(_this3.card);
          });
        }
      }, {
        key: "refresh",
        value: function refresh(event) {
          var _this4 = this;

          this.cardSub = this.stockService.requisitioncard(this.id).subscribe(function (result) {
            _this4.card = result;

            if (event) {
              event.target.complete();
            }
          });
        }
      }, {
        key: "onUpdateLine",
        value: function onUpdateLine(Key) {
          this.modalCtrl.create({
            component: _lines_lines_component__WEBPACK_IMPORTED_MODULE_5__["LinesComponent"],
            componentProps: {
              Key: Key
            }
          }).then(function (modalEl) {
            modalEl.present();
          });
        }
      }, {
        key: "onUpdateCard",
        value: function onUpdateCard(event) {
          var _this5 = this;

          var issue_date = event.target.value;
          this.card.Receipt_Date = this.stockService.formatDate(issue_date);
          this.stockService.updateStockIssue(this.card).subscribe(function (line) {
            if (typeof line !== 'string') {
              _this5.toastCtrl.create({
                message: "Document ".concat(line.Stock_Issue_No, "  Updated Successfully."),
                duration: 3000,
                position: 'top'
              }).then(function (toastData) {
                toastData.present();
              });

              _this5.modalCtrl.dismiss(); // this.router.navigate(['/requisitions/' + line.Document_No]);

            } else {
              // Alert the error
              _this5.alertCtrl.create({
                header: 'Operation Error',
                message: 'Error : ' + line,
                buttons: [{
                  text: 'Okay',
                  handler: function handler() {
                    return _this5.modalCtrl.dismiss();
                  }
                }]
              }).then(function (alertEl) {
                alertEl.present();
              });
            }
          }, function (error) {
            console.log(error.error);

            _this5.alertCtrl.create({
              header: 'Service Error!',
              message: 'Connection problem: ' + error.message,
              buttons: [{
                text: 'Okay',
                handler: function handler() {
                  return _this5.modalCtrl.dismiss();
                }
              }]
            }).then(function (alertEl) {
              alertEl.present();
            });
          });
        }
      }, {
        key: "presentLoading",
        value: function presentLoading(message) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.loadingCtrl.create({
                      spinner: 'dots',
                      animated: true,
                      message: message ? message : 'Loading Data...'
                    });

                  case 2:
                    this.loading = _context2.sent;
                    _context2.next = 5;
                    return this.loading.present();

                  case 5:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "post",
        value: function post(ReceiptNo) {
          var _this6 = this;

          console.log(ReceiptNo);
          this.stockService.acknowledgeStockIssue(ReceiptNo).subscribe(function (res) {
            if (typeof res === 'string') {
              // a string response represents a Nav Error, so we display it.
              _this6.alertCtrl.create({
                header: 'Service Warning!',
                message: res,
                buttons: [{
                  text: 'Okay'
                }]
              }).then(function (alertEl) {
                alertEl.present();
              });
            } else {
              // alert(res);
              _this6.stockService.showToast("Document Posted Successfully.");
            }
          }, function (error) {
            alert(error);
          });
        }
      }]);

      return StockDetailsPage;
    }();

    StockDetailsPage.ctorParameters = function () {
      return [{
        type: _stockdetail_service__WEBPACK_IMPORTED_MODULE_6__["StockdetailService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"]
      }];
    };

    StockDetailsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-stock-details',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./stock-details.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/stock-details/stock-details.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./stock-details.page.scss */
      "./src/app/stock-details/stock-details.page.scss"))["default"]]
    })], StockDetailsPage);
    /***/
  },

  /***/
  "./src/app/stock-details/stockdetail.service.ts":
  /*!******************************************************!*\
    !*** ./src/app/stock-details/stockdetail.service.ts ***!
    \******************************************************/

  /*! exports provided: StockdetailService */

  /***/
  function srcAppStockDetailsStockdetailServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "StockdetailService", function () {
      return StockdetailService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var StockdetailService = /*#__PURE__*/function () {
      function StockdetailService(http, toastCtrl) {
        _classCallCheck(this, StockdetailService);

        this.http = http;
        this.toastCtrl = toastCtrl;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].url;
      }

      _createClass(StockdetailService, [{
        key: "releasedrequisitions",
        get: function get() {
          return this.http.get("".concat(this.url, "site/releasedrequisitions")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        } // Retrieve Stock Issue Card / Details

      }, {
        key: "requisitioncard",
        value: function requisitioncard(id) {
          return this.http.get("".concat(this.url, "site/stockissue/?id=").concat(id));
        } // Create New Requisition

      }, {
        key: "createRequisition",
        value: function createRequisition() {
          return this.http.get("".concat(this.url, "site/create-requisition"));
        } //Update Stock Issue

      }, {
        key: "updateStockIssue",
        value: function updateStockIssue(Card) {
          return this.http.post("".concat(this.url, "site/stock-issue-card"), JSON.stringify(Card));
        } // get Units of Measure

      }, {
        key: "getunits",
        value: function getunits(itemNo) {
          return this.http.get("".concat(this.url, "site/unitmeasure?itemNo=").concat(itemNo)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        } // Get Locations List

      }, {
        key: "getLocations",
        value: function getLocations() {
          return this.http.get("".concat(this.url, "site/locationlist")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        } // Get any items from generic service getter function

      }, {
        key: "Dimensions",
        get: function get() {
          return this.http.get("".concat(this.url, "site/get?service=Dimensions")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "Departments",
        get: function get() {
          return this.http.get("".concat(this.url, "site/departments")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "Projects",
        get: function get() {
          return this.http.get("".concat(this.url, "site/projects")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        } // Post Lines Data

      }, {
        key: "postLine",
        value: function postLine(line) {
          return this.http.post("".concat(this.url, "site/addline"), JSON.stringify(line));
        } // Update Line

      }, {
        key: "updateRequisitionLine",
        value: function updateRequisitionLine(line) {
          return this.http.post("".concat(this.url, "site/updateissueline"), JSON.stringify(line));
        } // Fetch Line to Update

      }, {
        key: "getLine",
        value: function getLine(Key) {
          return this.http.get("".concat(this.url, "site/stock-issue-line?Key=").concat(Key));
        } // Post Requisition Header

      }, {
        key: "postRequisition",
        value: function postRequisition(requisition) {
          return this.http.post("".concat(this.url, "site/update-requisition"), JSON.stringify(requisition));
        } // Format date utility

      }, {
        key: "formatDate",
        value: function formatDate(datestring) {
          // Format Date to YYYY-MM-DD
          var recDate = new Date(datestring);
          var month = recDate.getMonth() + 1 > 9 ? recDate.getMonth() + 1 : "0" + (recDate.getMonth() + 1);
          var day = recDate.getDate() > 9 ? recDate.getDate() : "0" + recDate.getDate();
          return "".concat(recDate.getFullYear(), "-").concat(month, "-").concat(day);
        }
      }, {
        key: "acknowledgeStockIssue",
        value: function acknowledgeStockIssue(No) {
          return this.http.get("".concat(this.url, "site/acknowledge-stock-issue?No=").concat(No));
        }
      }, {
        key: "postDocument",
        value: function postDocument(No) {
          return this.http.get("".concat(this.url, "site/acknowledge-stock-issue?No=").concat(No));
        }
      }, {
        key: "showToast",
        value: function showToast(text) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.toastCtrl.create({
                      message: text,
                      duration: 4000,
                      position: 'top'
                    }).then(function (toastEl) {
                      toastEl.present();
                    });

                  case 2:
                    return _context3.abrupt("return", _context3.sent);

                  case 3:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }]);

      return StockdetailService;
    }();

    StockdetailService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"]
      }];
    };

    StockdetailService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
      providedIn: 'root'
    })], StockdetailService);
    /***/
  }
}]);
//# sourceMappingURL=stock-details-stock-details-module-es5.js.map