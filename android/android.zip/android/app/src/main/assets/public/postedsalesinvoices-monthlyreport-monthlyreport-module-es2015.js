(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["postedsalesinvoices-monthlyreport-monthlyreport-module"],{

/***/ "./src/app/orders/order.service.ts":
/*!*****************************************!*\
  !*** ./src/app/orders/order.service.ts ***!
  \*****************************************/
/*! exports provided: OrderService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrderService", function() { return OrderService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");





let OrderService = class OrderService {
    // private items  = new BehaviorSubject<[]>([]) ;
    constructor(http) {
        this.http = http;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
    }
    get orders() {
        return this.http.get(`${this.url}site/saleinvoices`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    // Create New Sales Invoice
    createInvoice() {
        return this.http.get(`${this.url}site/create-invoice`);
    }
    // Retrieve Sales Invoice Card / Details
    ordercard(id) {
        return this.http.get(`${this.url}site/saleinvoice/?id=${id}`);
    }
    // Post Lines Data
    postLine(line) {
        return this.http.post(`${this.url}site/addsalesinvoiceline`, JSON.stringify(line));
    }
    // Update Line
    updateInvoiceLine(line) {
        return this.http.post(`${this.url}site/updatesalesinvoiceline`, JSON.stringify(line));
    }
    // Fetch Line to Update
    getLine(docId, LineNo) {
        return this.http.get(`${this.url}site/getsalesinvoiceline?Document_No=${docId}&Line_No=${LineNo}`);
    }
    // Post Invoice Header
    postInvoice(invoice) {
        invoice.Posting_Date = this.formatDate(invoice.Posting_Date);
        invoice.Due_Date = this.formatDate(invoice.Due_Date);
        return this.http.post(`${this.url}site/update-invoice`, JSON.stringify(invoice));
    }
    // Get Customers
    get Customers() {
        return this.http.get(`${this.url}site/receipting-customers`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    postSalesInvoice(No) {
        return this.http.get(`${this.url}site/postsaleinvoice?No=${No}`);
    }
    // Format date utility
    formatDate(datestring) {
        // Format Date to YYYY-MM-DD
        const recDate = new Date(datestring);
        const month = (recDate.getMonth() + 1) > 9 ? recDate.getMonth() + 1 : `0` + (recDate.getMonth() + 1);
        const day = (recDate.getDate()) > 9 ? recDate.getDate() : `0` + recDate.getDate();
        return `${recDate.getFullYear()}-${month}-${day}`;
    }
};
OrderService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
OrderService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], OrderService);



/***/ }),

/***/ "./src/app/postedsalesinvoices/sales.service.ts":
/*!******************************************************!*\
  !*** ./src/app/postedsalesinvoices/sales.service.ts ***!
  \******************************************************/
/*! exports provided: SalesService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SalesService", function() { return SalesService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _orders_order_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../orders/order.service */ "./src/app/orders/order.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");







let SalesService = class SalesService {
    constructor(http, orderService, toastCtrl) {
        this.http = http;
        this.orderService = orderService;
        this.toastCtrl = toastCtrl;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].url;
    }
    get Sales() {
        return this.http.get(`${this.url}site/get?service=PostedSalesInvoices`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    getSale(id) {
        return this.http.get(`${this.url}site/sale/?Key=${id}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    formatDate(date) {
        return this.orderService.formatDate(date);
    }
    FilterSales(startDate, userID) {
        return this.http.get(`${this.url}site/filtersales?startdate=${startDate}&userid=${userID}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    FilterSalesbyRange(startDate, endDate, userID) {
        return this.http.get(`${this.url}site/filtersales?startdate=${startDate}&enddate=${endDate}&userid=${userID}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    showToast(text) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return yield this.toastCtrl.create({
                message: text,
                duration: 4000,
                position: 'top'
            }).then(toastEl => {
                toastEl.present();
            });
        });
    }
};
SalesService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] },
    { type: _orders_order_service__WEBPACK_IMPORTED_MODULE_5__["OrderService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] }
];
SalesService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], SalesService);



/***/ })

}]);
//# sourceMappingURL=postedsalesinvoices-monthlyreport-monthlyreport-module-es2015.js.map