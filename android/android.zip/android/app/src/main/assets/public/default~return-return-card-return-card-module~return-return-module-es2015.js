(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~return-return-card-return-card-module~return-return-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/return/return-line/return-line.component.html":
/*!*****************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/return/return-line/return-line.component.html ***!
  \*****************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>{{line.No?'Update': 'New'}} Return Line</ion-title>\r\n\r\n    <ion-buttons slot=\"primary\">\r\n      <ion-button (click)=\"onCancel()\">\r\n        <ion-icon name=\"close\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content padding>\r\n  <ion-row>\r\n    <ion-col size-sm=\"6\" offset-sm=\"3\">\r\n      <ion-list>\r\n\r\n        <ion-item>\r\n          <ion-label position=\"floating\">Item</ion-label>\r\n          <ion-select [(ngModel)]=\"line.Item_No\" [selectedText]=\"line.Description\" placeholder=\"Select Item\">\r\n            <ion-select-option *ngFor=\"let item of items\" [value]=\"item.No\">{{ item.Description }}</ion-select-option>\r\n          </ion-select>\r\n        </ion-item>\r\n\r\n        <ion-item>\r\n          <ion-label position=\"floating\">Store</ion-label>\r\n          <ion-select [(ngModel)]=\"line.Store_Code\" [selectedText]=\"line.Store_Name\" placeholder=\"Select Store\">\r\n            <ion-select-option *ngFor=\"let loc of locations\" [value]=\"loc.Code\">{{ loc.Name }}\r\n            </ion-select-option>\r\n          </ion-select>\r\n        </ion-item>\r\n\r\n        <ion-item>\r\n          <ion-label position=\"floating\">Qty.</ion-label>\r\n          <ion-input [(ngModel)]=\"line.Quantity\" type=\"number\"></ion-input>\r\n        </ion-item>\r\n\r\n        <ion-item>\r\n          <ion-label position=\"floating\">Price</ion-label>\r\n          <ion-input [(ngModel)]=\"line.Price\" type=\"number\"></ion-input>\r\n        </ion-item>\r\n\r\n        <!--<ion-item *ngIf=\"line.Line_No\">\r\n          <ion-label position=\"floating\">Receipt Date</ion-label>\r\n          <ion-datetime [(ngModel)]=\"line.Receipt_Date\" type=\"number\" displayFormat=\"YYYY-MM-DD\"></ion-datetime>\r\n        </ion-item>\r\n      -->\r\n\r\n\r\n\r\n\r\n      </ion-list>\r\n\r\n\r\n      <ion-button *ngIf=\"!line.No\" color=\"primary\" (click)=\"addLine()\" expand=\"block\" fill=\"outline\">\r\n        Save Line\r\n      </ion-button>\r\n\r\n      <ion-button *ngIf=\"line.No\" color=\"primary\" (click)=\"updateLine()\" expand=\"block\" fill=\"outline\">\r\n        Update Line\r\n      </ion-button>\r\n\r\n    </ion-col>\r\n  </ion-row>\r\n</ion-content>");

/***/ }),

/***/ "./src/app/items/item.service.ts":
/*!***************************************!*\
  !*** ./src/app/items/item.service.ts ***!
  \***************************************/
/*! exports provided: ItemService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ItemService", function() { return ItemService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");






let ItemService = class ItemService {
    constructor(http, toastCtrl) {
        this.http = http;
        this.toastCtrl = toastCtrl;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
    }
    get items() {
        return this.http.get(`${this.url}site/items`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    itemcard(id) {
        return this.http.get(`${this.url}site/itemcard/?id=${id}`);
    }
    itemBalance(No) {
        return this.http.get(`${this.url}site/itemavailabilitybylocation/?No=${No}`);
    }
    itemBalanceByLocation(No, LocationCode) {
        return this.http.get(`${this.url}site/itemavailabilitybylocation/?No=${No}&Location=${LocationCode}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    getTotals(elements, subjectColumn) {
        let sum = 0;
        elements.forEach(obj => {
            // console.log(obj);
            for (const property in obj) {
                if (property === subjectColumn && !isNaN(+obj[property])) {
                    // console.log(+obj[property]);
                    sum += +obj[property];
                }
            }
        });
        return sum;
    }
    // Get Locations List
    getLocations() {
        return this.http.get(`${this.url}site/locationlist`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    showToast(text) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return yield this.toastCtrl.create({
                message: text,
                duration: 4000,
                position: 'top'
            }).then(toastEl => {
                toastEl.present();
            });
        });
    }
};
ItemService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"] }
];
ItemService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], ItemService);



/***/ }),

/***/ "./src/app/models/return.model.ts":
/*!****************************************!*\
  !*** ./src/app/models/return.model.ts ***!
  \****************************************/
/*! exports provided: Return */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Return", function() { return Return; });
class Return {
    constructor(Key, No, Return_Date, Customer_No, Customer_Name, Applies_to_Invoice_No, Created_By, Created_On, POS_Return_Lines) {
        this.Key = Key;
        this.No = No;
        this.Return_Date = Return_Date;
        this.Customer_No = Customer_No;
        this.Customer_Name = Customer_Name;
        this.Applies_to_Invoice_No = Applies_to_Invoice_No;
        this.Created_By = Created_By;
        this.Created_On = Created_On;
        this.POS_Return_Lines = POS_Return_Lines;
    }
}


/***/ }),

/***/ "./src/app/models/returnline.model.ts":
/*!********************************************!*\
  !*** ./src/app/models/returnline.model.ts ***!
  \********************************************/
/*! exports provided: Returnline */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Returnline", function() { return Returnline; });
class Returnline {
    constructor(Key, No, Item_No, Description, Store_Code, Store_Name, Quantity, Price, Amount) {
        this.Key = Key;
        this.No = No;
        this.Item_No = Item_No;
        this.Description = Description;
        this.Store_Code = Store_Code;
        this.Store_Name = Store_Name;
        this.Quantity = Quantity;
        this.Price = Price;
        this.Amount = Amount;
    }
}


/***/ }),

/***/ "./src/app/orders/order.service.ts":
/*!*****************************************!*\
  !*** ./src/app/orders/order.service.ts ***!
  \*****************************************/
/*! exports provided: OrderService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "OrderService", function() { return OrderService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");





let OrderService = class OrderService {
    // private items  = new BehaviorSubject<[]>([]) ;
    constructor(http) {
        this.http = http;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
    }
    get orders() {
        return this.http.get(`${this.url}site/saleinvoices`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    // Create New Sales Invoice
    createInvoice() {
        return this.http.get(`${this.url}site/create-invoice`);
    }
    // Retrieve Sales Invoice Card / Details
    ordercard(id) {
        return this.http.get(`${this.url}site/saleinvoice/?id=${id}`);
    }
    // Post Lines Data
    postLine(line) {
        return this.http.post(`${this.url}site/addsalesinvoiceline`, JSON.stringify(line));
    }
    // Update Line
    updateInvoiceLine(line) {
        return this.http.post(`${this.url}site/updatesalesinvoiceline`, JSON.stringify(line));
    }
    // Fetch Line to Update
    getLine(docId, LineNo) {
        return this.http.get(`${this.url}site/getsalesinvoiceline?Document_No=${docId}&Line_No=${LineNo}`);
    }
    // Post Invoice Header
    postInvoice(invoice) {
        invoice.Posting_Date = this.formatDate(invoice.Posting_Date);
        invoice.Due_Date = this.formatDate(invoice.Due_Date);
        return this.http.post(`${this.url}site/update-invoice`, JSON.stringify(invoice));
    }
    // Get Customers
    get Customers() {
        return this.http.get(`${this.url}site/receipting-customers`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    postSalesInvoice(No) {
        return this.http.get(`${this.url}site/postsaleinvoice?No=${No}`);
    }
    // Format date utility
    formatDate(datestring) {
        // Format Date to YYYY-MM-DD
        const recDate = new Date(datestring);
        const month = (recDate.getMonth() + 1) > 9 ? recDate.getMonth() + 1 : `0` + (recDate.getMonth() + 1);
        const day = (recDate.getDate()) > 9 ? recDate.getDate() : `0` + recDate.getDate();
        return `${recDate.getFullYear()}-${month}-${day}`;
    }
};
OrderService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
OrderService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], OrderService);



/***/ }),

/***/ "./src/app/payments/payments.service.ts":
/*!**********************************************!*\
  !*** ./src/app/payments/payments.service.ts ***!
  \**********************************************/
/*! exports provided: PaymentsService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PaymentsService", function() { return PaymentsService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _orders_order_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../orders/order.service */ "./src/app/orders/order.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");








let PaymentsService = class PaymentsService {
    constructor(http, orderService, toastCtrl) {
        this.http = http;
        this.orderService = orderService;
        this.toastCtrl = toastCtrl;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].url;
        this._refresh$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__["Subject"]();
    }
    // Define a synthetic getter for the subject
    get refresh$() {
        return this._refresh$;
    }
    newPayment(receipt) {
        return this.http.post(`${this.url}site/cash-sale`, JSON.stringify(receipt));
    }
    updateReceipt(receipt) {
        return this.http.post(`${this.url}site/cash-sale`, JSON.stringify(receipt));
    }
    getPayments(userID) {
        return this.http.get(`${this.url}site/get?service=POSReceiptList&userid=${userID}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    getPayment(id) {
        return this.http.get(`${this.url}site/receipt/?id=${id}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    get Banks() {
        return this.http.get(`${this.url}site/get?service=BankAccounts`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    getLine(Key) {
        return this.http.get(`${this.url}site/cash-sale-line?Key=${Key}`);
    }
    suggestlines(receiptNo, customerNo) {
        return this.http.get(`${this.url}site/suggestlines?receiptNo=${receiptNo}&customerNo=${customerNo}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    // Post Lines Data
    postLine(line) {
        return this.http.post(`${this.url}site/cash-sale-line`, JSON.stringify(line))
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(() => {
            this._refresh$.next();
        }));
    }
    // Update Line
    updateLine(line) {
        return this.http.post(`${this.url}site/cash-sale-line`, JSON.stringify(line))
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(() => {
            this._refresh$.next();
        }));
    }
    get Customers() {
        return this.http.get(`${this.url}site/receipting-customers`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    /*
     * Get Customer By Search Name
     */
    Customer(searchName) {
        return this.http.get(`${this.url}site/receipting-customers?searchName=${searchName}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    /*
     * Get Customer By Sales Person Code
     */
    CustomerBySalesPerson(salesPersonCode) {
        return this.http.get(`${this.url}site/receipting-customers?Salesperson_Code=${salesPersonCode}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    // Get CustomerPriceGroups
    CustomerPriceGroups() {
        return this.http.get(`${this.url}site/get?service=CustomerPriceGroups`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    Mpesa() {
        return this.http.get(`${this.url}site/get?service=MPESATransactions`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    selectLine(CustomerNo, Line, ReceiptNo) {
        const payload = { Customer_No: CustomerNo, Line_No: Line, Receipt_No: ReceiptNo };
        return this.http.post(`${this.url}site/updatecashreceiptline`, JSON.stringify(payload));
    }
    setAmountToReceipt(CustomerNo, Line, ReceiptNo, AmountToReceipt) {
        const payload = { Customer_No: CustomerNo, Line_No: Line, Receipt_No: ReceiptNo, Amount_To_Receipt: AmountToReceipt };
        // console.log(payload); return;
        return this.http.post(`${this.url}site/updateamounttoreceipt`, JSON.stringify(payload));
    }
    postReceipt(No) {
        return this.http.get(`${this.url}site/postreceipt?No=${No}`);
    }
    getTotals(elements, subjectColumn) {
        let sum = 0;
        elements.forEach(obj => {
            // console.log(obj);
            for (const property in obj) {
                if (property === subjectColumn && !isNaN(+obj[property])) {
                    // console.log(+obj[property]);
                    sum += +obj[property];
                }
            }
        });
        return sum;
    }
    showToast(text) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return yield this.toastCtrl.create({
                message: text,
                duration: 4000,
                position: 'top'
            }).then(toastEl => {
                toastEl.present();
            });
        });
    }
    formatDate(date) {
        return this.orderService.formatDate(date);
    }
    FilterReceipts(startDate, userID) {
        return this.http.get(`${this.url}site/filterpayments?startdate=${startDate}&userid=${userID}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    FilterReceiptsbyRange(startDate, endDate, userID) {
        return this.http.get(`${this.url}site/filterpayments?startdate=${startDate}&enddate=${endDate}&userid=${userID}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
};
PaymentsService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"] },
    { type: _orders_order_service__WEBPACK_IMPORTED_MODULE_5__["OrderService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] }
];
PaymentsService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], PaymentsService);



/***/ }),

/***/ "./src/app/postedsalesinvoices/sales.service.ts":
/*!******************************************************!*\
  !*** ./src/app/postedsalesinvoices/sales.service.ts ***!
  \******************************************************/
/*! exports provided: SalesService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SalesService", function() { return SalesService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _orders_order_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../orders/order.service */ "./src/app/orders/order.service.ts");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");







let SalesService = class SalesService {
    constructor(http, orderService, toastCtrl) {
        this.http = http;
        this.orderService = orderService;
        this.toastCtrl = toastCtrl;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].url;
    }
    get Sales() {
        return this.http.get(`${this.url}site/get?service=PostedSalesInvoices`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    getSale(id) {
        return this.http.get(`${this.url}site/sale/?Key=${id}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    formatDate(date) {
        return this.orderService.formatDate(date);
    }
    FilterSales(startDate, userID) {
        return this.http.get(`${this.url}site/filtersales?startdate=${startDate}&userid=${userID}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    FilterSalesbyRange(startDate, endDate, userID) {
        return this.http.get(`${this.url}site/filtersales?startdate=${startDate}&enddate=${endDate}&userid=${userID}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    showToast(text) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return yield this.toastCtrl.create({
                message: text,
                duration: 4000,
                position: 'top'
            }).then(toastEl => {
                toastEl.present();
            });
        });
    }
};
SalesService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] },
    { type: _orders_order_service__WEBPACK_IMPORTED_MODULE_5__["OrderService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"] }
];
SalesService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], SalesService);



/***/ }),

/***/ "./src/app/requisitions/requisition.service.ts":
/*!*****************************************************!*\
  !*** ./src/app/requisitions/requisition.service.ts ***!
  \*****************************************************/
/*! exports provided: RequisitionService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "RequisitionService", function() { return RequisitionService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var rxjs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs */ "./node_modules/rxjs/_esm2015/index.js");






let RequisitionService = class RequisitionService {
    constructor(http) {
        this.http = http;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
        this._refresh$ = new rxjs__WEBPACK_IMPORTED_MODULE_5__["Subject"]();
    }
    // Synthetic Getter for our refresh observerble
    get refresh$() {
        return this._refresh$;
    }
    getRequisitions(userID) {
        return this.http.get(`${this.url}site/requisitions?userid=${userID}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    get releasedrequisitions() {
        return this.http.get(`${this.url}site/releasedrequisitions`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    // Retrieve Requisition Card / Details
    requisitioncard(id) {
        return this.http.get(`${this.url}site/requisitioncard/?id=${id}`);
    }
    // Create New Requisition
    createRequisition(userID) {
        console.log('creator is:' + userID);
        return this.http.get(`${this.url}site/create-requisition?userid=${userID}`);
    }
    // get Units of Measure
    getunits(itemNo) {
        return this.http.get(`${this.url}site/unitmeasure?itemNo=${itemNo}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    // Get Locations List
    getLocations() {
        return this.http.get(`${this.url}site/locationlist`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    // Get any items from generic service getter function
    get Dimensions() {
        return this.http.get(`${this.url}site/get?service=Dimensions`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    get Departments() {
        return this.http.get(`${this.url}site/departments`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    get Projects() {
        return this.http.get(`${this.url}site/projects`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    // Post Lines Data
    postLine(line) {
        return this.http.post(`${this.url}site/requisition-lines`, JSON.stringify(line))
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(() => {
            this._refresh$.next();
        }));
    }
    // Update Line
    updateRequisitionLine(line) {
        return this.http.post(`${this.url}site/updaterequisitionline`, JSON.stringify(line))
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["tap"])(() => {
            this._refresh$.next();
        }));
    }
    // Fetch Line to Update
    getLine(Key) {
        return this.http.get(`${this.url}site/requisition-lines?Key=${Key}`);
    }
    // Post Requisition Header
    postRequisition(requisition) {
        return this.http.post(`${this.url}site/update-requisition`, JSON.stringify(requisition));
    }
    // Format date utility
    formatDate(datestring) {
        // Format Date to YYYY-MM-DD
        const recDate = new Date(datestring);
        const month = (recDate.getMonth() + 1) > 9 ? recDate.getMonth() + 1 : `0` + (recDate.getMonth() + 1);
        const day = (recDate.getDate()) > 9 ? recDate.getDate() : `0` + recDate.getDate();
        return `${recDate.getFullYear()}-${month}-${day}`;
    }
};
RequisitionService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"] }
];
RequisitionService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], RequisitionService);



/***/ }),

/***/ "./src/app/return/return-line/return-line.component.scss":
/*!***************************************************************!*\
  !*** ./src/app/return/return-line/return-line.component.scss ***!
  \***************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3JldHVybi9yZXR1cm4tbGluZS9yZXR1cm4tbGluZS5jb21wb25lbnQuc2NzcyJ9 */");

/***/ }),

/***/ "./src/app/return/return-line/return-line.component.ts":
/*!*************************************************************!*\
  !*** ./src/app/return/return-line/return-line.component.ts ***!
  \*************************************************************/
/*! exports provided: ReturnLineComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReturnLineComponent", function() { return ReturnLineComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var src_app_items_item_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/app/items/item.service */ "./src/app/items/item.service.ts");
/* harmony import */ var src_app_models_returnline_model__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! src/app/models/returnline.model */ "./src/app/models/returnline.model.ts");
/* harmony import */ var src_app_requisitions_requisition_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! src/app/requisitions/requisition.service */ "./src/app/requisitions/requisition.service.ts");
/* harmony import */ var src_app_utility_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/utility.service */ "./src/app/utility.service.ts");
/* harmony import */ var _return_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../return.service */ "./src/app/return/return.service.ts");









let ReturnLineComponent = class ReturnLineComponent {
    constructor(returnSvc, utilitySvc, modalCtrl, itemSvc, requisitionSvc) {
        this.returnSvc = returnSvc;
        this.utilitySvc = utilitySvc;
        this.modalCtrl = modalCtrl;
        this.itemSvc = itemSvc;
        this.requisitionSvc = requisitionSvc;
        this.line = new src_app_models_returnline_model__WEBPACK_IMPORTED_MODULE_5__["Returnline"]();
        this.items = [];
    }
    ngOnInit() {
        this.fetchLocations();
        this.fetchItems();
    }
    fetchItems() {
        this.utilitySvc.presentLoading(`Loading Items...`);
        this.itemSub = this.itemSvc.items
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["finalize"])(() => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.utilitySvc.loadingCtrl.dismiss();
        })))
            .subscribe(items => {
            this.items = items;
        });
    }
    fetchLocations() {
        this.locationSub = this.requisitionSvc.getLocations().subscribe(res => {
            console.log('Locations');
            console.log(res);
            this.locations = res;
        });
    }
    addLine() {
        this.utilitySvc.presentLoading('Saving ....');
        this.line.No = this.docId;
        this.lineSub = this.returnSvc.returnLine(this.line)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["finalize"])(() => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.utilitySvc.loadingCtrl.dismiss();
        })))
            .subscribe(res => {
            if (typeof res === 'string') {
                this.utilitySvc.showAlert(res);
                return;
            }
            this.utilitySvc.showToast('Line Added Successfully.');
            setTimeout(() => {
                this.modalCtrl.dismiss();
            }, 2500);
        }, err => {
            this.utilitySvc.showAlert(err.message);
        });
    }
    updateLine() {
        this.lineSub = this.returnSvc.returnLine(this.line).subscribe(res => {
            if (typeof res === 'string') {
                this.utilitySvc.showAlert(res);
            }
            this.utilitySvc.showToast('Line Updated Successfully.');
            setTimeout(() => {
                this.modalCtrl.dismiss();
            }, 2500);
        }, err => {
            this.utilitySvc.showAlert(err.message);
        });
    }
    onCancel() {
        this.modalCtrl.dismiss();
    }
};
ReturnLineComponent.ctorParameters = () => [
    { type: _return_service__WEBPACK_IMPORTED_MODULE_8__["ReturnService"] },
    { type: src_app_utility_service__WEBPACK_IMPORTED_MODULE_7__["UtilityService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
    { type: src_app_items_item_service__WEBPACK_IMPORTED_MODULE_4__["ItemService"] },
    { type: src_app_requisitions_requisition_service__WEBPACK_IMPORTED_MODULE_6__["RequisitionService"] }
];
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], ReturnLineComponent.prototype, "docId", void 0);
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], ReturnLineComponent.prototype, "key", void 0);
ReturnLineComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-return-line',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./return-line.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/return/return-line/return-line.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./return-line.component.scss */ "./src/app/return/return-line/return-line.component.scss")).default]
    })
], ReturnLineComponent);



/***/ }),

/***/ "./src/app/return/return.service.ts":
/*!******************************************!*\
  !*** ./src/app/return/return.service.ts ***!
  \******************************************/
/*! exports provided: ReturnService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ReturnService", function() { return ReturnService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var _utility_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../utility.service */ "./src/app/utility.service.ts");






let ReturnService = class ReturnService {
    constructor(http, utilitySvc) {
        this.http = http;
        this.utilitySvc = utilitySvc;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
    }
    formatDate(date) {
        return this.utilitySvc.formatDate(date);
    }
    // Can create or Update
    ReturnTransaction(returnData) {
        return this.http.post(`${this.url}site/return`, JSON.stringify(returnData)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    // Read a single Return
    getReturnTransaction(Key) {
        return this.http.get(`${this.url}site/view-return/?Key=${Key}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    // Get a list of returns for a particular user
    getReturnTransactions(userID) {
        return this.http.get(`${this.url}site/get?service=POSReturnList&userid=${userID}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
    }
    // Add Update Return Line
    returnLine(lineData) {
        return this.http.post(`${this.url}site/return-line`, JSON.stringify(lineData));
    }
    // Fetch return Line By Key
    fetchLine(Key) {
        return this.http.get(`${this.url}site/fetch-return-line?Key=${Key}`);
    }
};
ReturnService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] },
    { type: _utility_service__WEBPACK_IMPORTED_MODULE_5__["UtilityService"] }
];
ReturnService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
        providedIn: 'root'
    })
], ReturnService);



/***/ }),

/***/ "./src/app/utility.service.ts":
/*!************************************!*\
  !*** ./src/app/utility.service.ts ***!
  \************************************/
/*! exports provided: UtilityService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "UtilityService", function() { return UtilityService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");



let UtilityService = class UtilityService {
    constructor(toastCtrl, alertCtrl, loadingCtrl) {
        this.toastCtrl = toastCtrl;
        this.alertCtrl = alertCtrl;
        this.loadingCtrl = loadingCtrl;
    }
    formatDate(datestring) {
        // Format Date to YYYY-MM-DD
        const recDate = new Date(datestring);
        const month = (recDate.getMonth() + 1) > 9 ? recDate.getMonth() + 1 : `0` + (recDate.getMonth() + 1);
        const day = (recDate.getDate()) > 9 ? recDate.getDate() : `0` + recDate.getDate();
        return `${recDate.getFullYear()}-${month}-${day}`;
    }
    showToast(text) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            let toastEl = this.toastCtrl.create({
                message: text,
                duration: 4000,
                position: 'top'
            });
            (yield toastEl).present();
        });
    }
    showAlert(text) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const alertEl = yield this.alertCtrl.create({
                header: 'Operation Error',
                message: 'Message : ' + text,
                buttons: [{ text: 'Okay' }]
            });
            yield alertEl.present();
        });
    }
    presentLoading(message) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            const loading = yield this.loadingCtrl.create({
                spinner: 'dots',
                animated: true,
                message: (message) ? message : 'Loading Data...'
            });
            yield loading.present();
        });
    }
};
UtilityService.ctorParameters = () => [
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"] }
];
UtilityService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
        providedIn: 'root'
    })
], UtilityService);



/***/ })

}]);
//# sourceMappingURL=default~return-return-card-return-card-module~return-return-module-es2015.js.map