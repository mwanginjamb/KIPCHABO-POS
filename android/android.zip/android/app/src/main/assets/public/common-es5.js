function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function asyncGeneratorStep(gen, resolve, reject, _next, _throw, key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(_next, _throw); } }

function _asyncToGenerator(fn) { return function () { var self = this, args = arguments; return new Promise(function (resolve, reject) { var gen = fn.apply(self, args); function _next(value) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "next", value); } function _throw(err) { asyncGeneratorStep(gen, resolve, reject, _next, _throw, "throw", err); } _next(undefined); }); }; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["common"], {
  /***/
  "./node_modules/@ionic/core/dist/esm/button-active-a6787d69.js":
  /*!*********************************************************************!*\
    !*** ./node_modules/@ionic/core/dist/esm/button-active-a6787d69.js ***!
    \*********************************************************************/

  /*! exports provided: c */

  /***/
  function node_modulesIonicCoreDistEsmButtonActiveA6787d69Js(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "c", function () {
      return createButtonActiveGesture;
    });
    /* harmony import */


    var _index_e806d1f6_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! ./index-e806d1f6.js */
    "./node_modules/@ionic/core/dist/esm/index-e806d1f6.js");
    /* harmony import */


    var _index_f49d994d_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! ./index-f49d994d.js */
    "./node_modules/@ionic/core/dist/esm/index-f49d994d.js");
    /* harmony import */


    var _haptic_27b3f981_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./haptic-27b3f981.js */
    "./node_modules/@ionic/core/dist/esm/haptic-27b3f981.js");

    var createButtonActiveGesture = function createButtonActiveGesture(el, isButton) {
      var currentTouchedButton;
      var initialTouchedButton;

      var activateButtonAtPoint = function activateButtonAtPoint(x, y, hapticFeedbackFn) {
        if (typeof document === 'undefined') {
          return;
        }

        var target = document.elementFromPoint(x, y);

        if (!target || !isButton(target)) {
          clearActiveButton();
          return;
        }

        if (target !== currentTouchedButton) {
          clearActiveButton();
          setActiveButton(target, hapticFeedbackFn);
        }
      };

      var setActiveButton = function setActiveButton(button, hapticFeedbackFn) {
        currentTouchedButton = button;

        if (!initialTouchedButton) {
          initialTouchedButton = currentTouchedButton;
        }

        var buttonToModify = currentTouchedButton;
        Object(_index_e806d1f6_js__WEBPACK_IMPORTED_MODULE_0__["c"])(function () {
          return buttonToModify.classList.add('ion-activated');
        });
        hapticFeedbackFn();
      };

      var clearActiveButton = function clearActiveButton() {
        var dispatchClick = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : false;

        if (!currentTouchedButton) {
          return;
        }

        var buttonToModify = currentTouchedButton;
        Object(_index_e806d1f6_js__WEBPACK_IMPORTED_MODULE_0__["c"])(function () {
          return buttonToModify.classList.remove('ion-activated');
        });
        /**
         * Clicking on one button, but releasing on another button
         * does not dispatch a click event in browsers, so we
         * need to do it manually here. Some browsers will
         * dispatch a click if clicking on one button, dragging over
         * another button, and releasing on the original button. In that
         * case, we need to make sure we do not cause a double click there.
         */

        if (dispatchClick && initialTouchedButton !== currentTouchedButton) {
          currentTouchedButton.click();
        }

        currentTouchedButton = undefined;
      };

      return Object(_index_f49d994d_js__WEBPACK_IMPORTED_MODULE_1__["createGesture"])({
        el: el,
        gestureName: 'buttonActiveDrag',
        threshold: 0,
        onStart: function onStart(ev) {
          return activateButtonAtPoint(ev.currentX, ev.currentY, _haptic_27b3f981_js__WEBPACK_IMPORTED_MODULE_2__["a"]);
        },
        onMove: function onMove(ev) {
          return activateButtonAtPoint(ev.currentX, ev.currentY, _haptic_27b3f981_js__WEBPACK_IMPORTED_MODULE_2__["b"]);
        },
        onEnd: function onEnd() {
          clearActiveButton(true);
          Object(_haptic_27b3f981_js__WEBPACK_IMPORTED_MODULE_2__["h"])();
          initialTouchedButton = undefined;
        }
      });
    };
    /***/

  },

  /***/
  "./node_modules/@ionic/core/dist/esm/framework-delegate-4584ab5a.js":
  /*!**************************************************************************!*\
    !*** ./node_modules/@ionic/core/dist/esm/framework-delegate-4584ab5a.js ***!
    \**************************************************************************/

  /*! exports provided: a, d */

  /***/
  function node_modulesIonicCoreDistEsmFrameworkDelegate4584ab5aJs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "a", function () {
      return attachComponent;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "d", function () {
      return detachComponent;
    });

    var attachComponent = /*#__PURE__*/function () {
      var _ref = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee(delegate, container, component, cssClasses, componentProps) {
        var el;
        return regeneratorRuntime.wrap(function _callee$(_context) {
          while (1) {
            switch (_context.prev = _context.next) {
              case 0:
                if (!delegate) {
                  _context.next = 2;
                  break;
                }

                return _context.abrupt("return", delegate.attachViewToDom(container, component, componentProps, cssClasses));

              case 2:
                if (!(typeof component !== 'string' && !(component instanceof HTMLElement))) {
                  _context.next = 4;
                  break;
                }

                throw new Error('framework delegate is missing');

              case 4:
                el = typeof component === 'string' ? container.ownerDocument && container.ownerDocument.createElement(component) : component;

                if (cssClasses) {
                  cssClasses.forEach(function (c) {
                    return el.classList.add(c);
                  });
                }

                if (componentProps) {
                  Object.assign(el, componentProps);
                }

                container.appendChild(el);

                if (!el.componentOnReady) {
                  _context.next = 11;
                  break;
                }

                _context.next = 11;
                return el.componentOnReady();

              case 11:
                return _context.abrupt("return", el);

              case 12:
              case "end":
                return _context.stop();
            }
          }
        }, _callee);
      }));

      return function attachComponent(_x, _x2, _x3, _x4, _x5) {
        return _ref.apply(this, arguments);
      };
    }();

    var detachComponent = function detachComponent(delegate, element) {
      if (element) {
        if (delegate) {
          var container = element.parentElement;
          return delegate.removeViewFromDom(container, element);
        }

        element.remove();
      }

      return Promise.resolve();
    };
    /***/

  },

  /***/
  "./node_modules/@ionic/core/dist/esm/haptic-27b3f981.js":
  /*!**************************************************************!*\
    !*** ./node_modules/@ionic/core/dist/esm/haptic-27b3f981.js ***!
    \**************************************************************/

  /*! exports provided: a, b, c, d, h */

  /***/
  function node_modulesIonicCoreDistEsmHaptic27b3f981Js(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "a", function () {
      return hapticSelectionStart;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "b", function () {
      return hapticSelectionChanged;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "c", function () {
      return hapticSelection;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "d", function () {
      return hapticImpact;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "h", function () {
      return hapticSelectionEnd;
    });

    var HapticEngine = {
      getEngine: function getEngine() {
        var win = window;
        return win.TapticEngine || win.Capacitor && win.Capacitor.isPluginAvailable('Haptics') && win.Capacitor.Plugins.Haptics;
      },
      available: function available() {
        return !!this.getEngine();
      },
      isCordova: function isCordova() {
        return !!window.TapticEngine;
      },
      isCapacitor: function isCapacitor() {
        var win = window;
        return !!win.Capacitor;
      },
      impact: function impact(options) {
        var engine = this.getEngine();

        if (!engine) {
          return;
        }

        var style = this.isCapacitor() ? options.style.toUpperCase() : options.style;
        engine.impact({
          style: style
        });
      },
      notification: function notification(options) {
        var engine = this.getEngine();

        if (!engine) {
          return;
        }

        var style = this.isCapacitor() ? options.style.toUpperCase() : options.style;
        engine.notification({
          style: style
        });
      },
      selection: function selection() {
        this.impact({
          style: 'light'
        });
      },
      selectionStart: function selectionStart() {
        var engine = this.getEngine();

        if (!engine) {
          return;
        }

        if (this.isCapacitor()) {
          engine.selectionStart();
        } else {
          engine.gestureSelectionStart();
        }
      },
      selectionChanged: function selectionChanged() {
        var engine = this.getEngine();

        if (!engine) {
          return;
        }

        if (this.isCapacitor()) {
          engine.selectionChanged();
        } else {
          engine.gestureSelectionChanged();
        }
      },
      selectionEnd: function selectionEnd() {
        var engine = this.getEngine();

        if (!engine) {
          return;
        }

        if (this.isCapacitor()) {
          engine.selectionEnd();
        } else {
          engine.gestureSelectionEnd();
        }
      }
    };
    /**
     * Trigger a selection changed haptic event. Good for one-time events
     * (not for gestures)
     */

    var hapticSelection = function hapticSelection() {
      HapticEngine.selection();
    };
    /**
     * Tell the haptic engine that a gesture for a selection change is starting.
     */


    var hapticSelectionStart = function hapticSelectionStart() {
      HapticEngine.selectionStart();
    };
    /**
     * Tell the haptic engine that a selection changed during a gesture.
     */


    var hapticSelectionChanged = function hapticSelectionChanged() {
      HapticEngine.selectionChanged();
    };
    /**
     * Tell the haptic engine we are done with a gesture. This needs to be
     * called lest resources are not properly recycled.
     */


    var hapticSelectionEnd = function hapticSelectionEnd() {
      HapticEngine.selectionEnd();
    };
    /**
     * Use this to indicate success/failure/warning to the user.
     * options should be of the type `{ style: 'light' }` (or `medium`/`heavy`)
     */


    var hapticImpact = function hapticImpact(options) {
      HapticEngine.impact(options);
    };
    /***/

  },

  /***/
  "./node_modules/@ionic/core/dist/esm/spinner-configs-cd7845af.js":
  /*!***********************************************************************!*\
    !*** ./node_modules/@ionic/core/dist/esm/spinner-configs-cd7845af.js ***!
    \***********************************************************************/

  /*! exports provided: S */

  /***/
  function node_modulesIonicCoreDistEsmSpinnerConfigsCd7845afJs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "S", function () {
      return SPINNERS;
    });

    var spinners = {
      'bubbles': {
        dur: 1000,
        circles: 9,
        fn: function fn(dur, index, total) {
          var animationDelay = "".concat(dur * index / total - dur, "ms");
          var angle = 2 * Math.PI * index / total;
          return {
            r: 5,
            style: {
              'top': "".concat(9 * Math.sin(angle), "px"),
              'left': "".concat(9 * Math.cos(angle), "px"),
              'animation-delay': animationDelay
            }
          };
        }
      },
      'circles': {
        dur: 1000,
        circles: 8,
        fn: function fn(dur, index, total) {
          var step = index / total;
          var animationDelay = "".concat(dur * step - dur, "ms");
          var angle = 2 * Math.PI * step;
          return {
            r: 5,
            style: {
              'top': "".concat(9 * Math.sin(angle), "px"),
              'left': "".concat(9 * Math.cos(angle), "px"),
              'animation-delay': animationDelay
            }
          };
        }
      },
      'circular': {
        dur: 1400,
        elmDuration: true,
        circles: 1,
        fn: function fn() {
          return {
            r: 20,
            cx: 48,
            cy: 48,
            fill: 'none',
            viewBox: '24 24 48 48',
            transform: 'translate(0,0)',
            style: {}
          };
        }
      },
      'crescent': {
        dur: 750,
        circles: 1,
        fn: function fn() {
          return {
            r: 26,
            style: {}
          };
        }
      },
      'dots': {
        dur: 750,
        circles: 3,
        fn: function fn(_, index) {
          var animationDelay = -(110 * index) + 'ms';
          return {
            r: 6,
            style: {
              'left': "".concat(9 - 9 * index, "px"),
              'animation-delay': animationDelay
            }
          };
        }
      },
      'lines': {
        dur: 1000,
        lines: 12,
        fn: function fn(dur, index, total) {
          var transform = "rotate(".concat(30 * index + (index < 6 ? 180 : -180), "deg)");
          var animationDelay = "".concat(dur * index / total - dur, "ms");
          return {
            y1: 17,
            y2: 29,
            style: {
              'transform': transform,
              'animation-delay': animationDelay
            }
          };
        }
      },
      'lines-small': {
        dur: 1000,
        lines: 12,
        fn: function fn(dur, index, total) {
          var transform = "rotate(".concat(30 * index + (index < 6 ? 180 : -180), "deg)");
          var animationDelay = "".concat(dur * index / total - dur, "ms");
          return {
            y1: 12,
            y2: 20,
            style: {
              'transform': transform,
              'animation-delay': animationDelay
            }
          };
        }
      }
    };
    var SPINNERS = spinners;
    /***/
  },

  /***/
  "./node_modules/@ionic/core/dist/esm/theme-ff3fc52f.js":
  /*!*************************************************************!*\
    !*** ./node_modules/@ionic/core/dist/esm/theme-ff3fc52f.js ***!
    \*************************************************************/

  /*! exports provided: c, g, h, o */

  /***/
  function node_modulesIonicCoreDistEsmThemeFf3fc52fJs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "c", function () {
      return createColorClasses;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "g", function () {
      return getClassMap;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "h", function () {
      return hostContext;
    });
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "o", function () {
      return openURL;
    });

    var hostContext = function hostContext(selector, el) {
      return el.closest(selector) !== null;
    };
    /**
     * Create the mode and color classes for the component based on the classes passed in
     */


    var createColorClasses = function createColorClasses(color, cssClassMap) {
      return typeof color === 'string' && color.length > 0 ? Object.assign(_defineProperty({
        'ion-color': true
      }, "ion-color-".concat(color), true), cssClassMap) : cssClassMap;
    };

    var getClassList = function getClassList(classes) {
      if (classes !== undefined) {
        var array = Array.isArray(classes) ? classes : classes.split(' ');
        return array.filter(function (c) {
          return c != null;
        }).map(function (c) {
          return c.trim();
        }).filter(function (c) {
          return c !== '';
        });
      }

      return [];
    };

    var getClassMap = function getClassMap(classes) {
      var map = {};
      getClassList(classes).forEach(function (c) {
        return map[c] = true;
      });
      return map;
    };

    var SCHEME = /^[a-z][a-z0-9+\-.]*:/;

    var openURL = /*#__PURE__*/function () {
      var _ref2 = _asyncToGenerator( /*#__PURE__*/regeneratorRuntime.mark(function _callee2(url, ev, direction, animation) {
        var router;
        return regeneratorRuntime.wrap(function _callee2$(_context2) {
          while (1) {
            switch (_context2.prev = _context2.next) {
              case 0:
                if (!(url != null && url[0] !== '#' && !SCHEME.test(url))) {
                  _context2.next = 5;
                  break;
                }

                router = document.querySelector('ion-router');

                if (!router) {
                  _context2.next = 5;
                  break;
                }

                if (ev != null) {
                  ev.preventDefault();
                }

                return _context2.abrupt("return", router.push(url, direction, animation));

              case 5:
                return _context2.abrupt("return", false);

              case 6:
              case "end":
                return _context2.stop();
            }
          }
        }, _callee2);
      }));

      return function openURL(_x6, _x7, _x8, _x9) {
        return _ref2.apply(this, arguments);
      };
    }();
    /***/

  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/cash-deposit/cash-deposit-detail/cash-deposit-detail.page.html":
  /*!**********************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/cash-deposit/cash-deposit-detail/cash-deposit-detail.page.html ***!
    \**********************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppCashDepositCashDepositDetailCashDepositDetailPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n  \r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button defaultHref=\"cashdeposit\"></ion-back-button>\r\n    </ion-buttons>\r\n  \r\n    <ion-title>Cash Deposit Card</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content *ngIf=\"cashDeposit?.Key\">\r\n  <ion-grid>\r\n    <ion-row>\r\n      <ion-col>\r\n        <ion-card>\r\n          <ion-card-header>\r\n            <ion-card-title>\r\n              Cash Deposit Card\r\n            </ion-card-title>\r\n          </ion-card-header>\r\n\r\n          <ion-card-content>\r\n\r\n            <!--<ion-fab vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\">\r\n              <ion-fab-button color=\"warning\" (click)=\"post(card.POS_Receipt_No)\">\r\n                <ion-icon name=\"send\"></ion-icon>\r\n              </ion-fab-button>\r\n            </ion-fab>-->\r\n\r\n            <ion-row>\r\n              <ion-col>\r\n                <ion-item>\r\n                  <ion-label position=\"floating\">No.</ion-label>\r\n                  <ion-input [(ngModel)]=\"cashDeposit.No\" readonly></ion-input>\r\n                </ion-item>\r\n              </ion-col>\r\n\r\n              <ion-col>\r\n                <ion-item>\r\n                  <ion-label position=\"floating\">Reference</ion-label>\r\n                  <ion-input [(ngModel)]=\"cashDeposit.Reference\" readonly></ion-input>\r\n                </ion-item>\r\n              </ion-col>\r\n            </ion-row>\r\n\r\n\r\n\r\n\r\n            <ion-row>\r\n              <ion-col>\r\n                <ion-item>\r\n                  <ion-label position=\"floating\">Posting Date: </ion-label>\r\n                  <ion-input [(ngModel)]=\"cashDeposit.Posting_Date\" readonly></ion-input>\r\n                </ion-item>\r\n              </ion-col>\r\n\r\n              <ion-col>\r\n                <ion-item>\r\n                  <ion-label position=\"floating\">Amount:</ion-label>\r\n                  <ion-input [(ngModel)]=\"cashDeposit.Amount\" readonly></ion-input>\r\n                </ion-item>\r\n              </ion-col>\r\n            </ion-row>\r\n\r\n\r\n            <ion-row>\r\n              <ion-col>\r\n                <ion-item>\r\n                  <ion-label position=\"floating\">Created By</ion-label>\r\n                  <ion-input [(ngModel)]=\"cashDeposit.Created_By\" readonly></ion-input>\r\n                </ion-item>\r\n              </ion-col>\r\n\r\n              <ion-col>\r\n\r\n              </ion-col>\r\n\r\n            </ion-row>\r\n\r\n\r\n\r\n          </ion-card-content>\r\n\r\n        </ion-card>\r\n\r\n\r\n        <!--Start Lines Card-->\r\n        <ion-card>\r\n          <ion-card-header>\r\n            <ion-card-title>Invoice Lines</ion-card-title>\r\n          </ion-card-header>\r\n          <ion-card-content>\r\n            <ion-grid>\r\n\r\n\r\n\r\n              <ion-row scrollX=\"true\">\r\n                <ion-col>\r\n                  <ion-label>Customer</ion-label>\r\n                </ion-col>\r\n\r\n                <ion-col>\r\n                  <ion-label>Amount</ion-label>\r\n                </ion-col>\r\n\r\n                <ion-col>\r\n                  <ion-label>Select</ion-label>\r\n                </ion-col>\r\n\r\n              </ion-row>\r\n\r\n\r\n\r\n              <ion-list *ngFor=\"let ln of cashDeposit?.Cash_Deposit_Lines?.Cash_Deposit_Lines\">\r\n                <ion-row>\r\n\r\n                  <ion-col>\r\n                    <ion-item>\r\n                      <ion-label>{{ln.Customer}}</ion-label>\r\n                    </ion-item>\r\n                  </ion-col>\r\n\r\n                  <ion-col>\r\n                    <ion-item>\r\n                      <ion-label>{{ln.Amount | currency: 'Ksh.'}}</ion-label>\r\n                    </ion-item>\r\n                  </ion-col>\r\n\r\n                  <ion-col>\r\n                    <ion-item>\r\n                      <input type=\"checkbox\" [value]=\"ln.Select\" />\r\n                    </ion-item>\r\n                  </ion-col>\r\n\r\n\r\n                </ion-row>\r\n              </ion-list>\r\n\r\n\r\n            </ion-grid>\r\n          </ion-card-content>\r\n        </ion-card>\r\n        <!--End Lines Card-->\r\n\r\n      </ion-col>\r\n      </ion-row>\r\n      </ion-grid>\r\n</ion-content>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/items/availability-by-location/availability-by-location.page.html":
  /*!*************************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/items/availability-by-location/availability-by-location.page.html ***!
    \*************************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppItemsAvailabilityByLocationAvailabilityByLocationPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"primary\">\r\n\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button menu=\"m1\"></ion-menu-button>\r\n    </ion-buttons>\r\n\r\n    <ion-title>Items Availability By Location</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <div *ngIf=\"isLoading\" class=\"ion-text-center\">\r\n    <ion-spinner  name=\"crescent\"></ion-spinner>\r\n  </div>\r\n\r\n  <ion-searchbar [(ngModel)]=\"searchTerm\" debounce=\"2000\" (ionChange)=\"searchItem($event)\"></ion-searchbar>\r\n\r\n  <ion-grid fixed>\r\n    <ion-row>\r\n      <ion-col >Description</ion-col>\r\n      <ion-col >Inventory</ion-col>\r\n      \r\n    </ion-row>\r\n  </ion-grid>\r\n  \r\n  \r\n  \r\n    <ion-virtual-scroll [items]=\"Items\" approxItemHeight=\"47.2px\">\r\n               \r\n              <ion-item \r\n                [routerLink] = \"['/','items','availability-card',item.No]\"\r\n               detail\r\n               *virtualItem=\"let item\" > \r\n  \r\n               <ion-grid fixed>\r\n                  <ion-row>\r\n  \r\n                    <ion-col>\r\n                      <ion-label>\r\n                        <h3>{{ item.Description }}</h3>\r\n                      </ion-label>\r\n                    </ion-col>\r\n  \r\n                    <ion-col>\r\n                      <ion-label>\r\n                        <h3>{{ item.Inventory }}</h3>\r\n                      </ion-label>\r\n                    </ion-col>\r\n\r\n  \r\n                  </ion-row>\r\n                </ion-grid>\r\n                      \r\n          </ion-item>\r\n        \r\n    </ion-virtual-scroll>\r\n  \r\n\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/items/availability-card/availability-card.page.html":
  /*!***********************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/items/availability-card/availability-card.page.html ***!
    \***********************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppItemsAvailabilityCardAvailabilityCardPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button defaultHref=\"/items/availability\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>Item Balance Card - {{ItemCard?.Description}} </ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <ion-row>\r\n    <ion-col >\r\n      <ion-item>\r\n        <ion-label position=\"floating\">Search Balance By Location</ion-label>\r\n  \r\n        <ion-select (ionChange)=\"searchByLocation($event)\" name=\"locationCode\" placeholder=\"Select Location\">\r\n          <ion-select-option *ngFor=\"let loc of locations\" [value]=\"loc.Code\">{{loc.Name}}</ion-select-option>\r\n        </ion-select>\r\n      </ion-item>\r\n    </ion-col>\r\n  </ion-row>\r\n\r\n  <ion-card>\r\n    <ion-grid>\r\n     <ion-col>\r\n       <h3>Balance for: <b> {{ItemCard?.Description}}</b></h3>\r\n       <p>Remaining Quantity: {{TotalRemainingQuantity}}</p>\r\n     </ion-col>\r\n    </ion-grid>\r\n  </ion-card>\r\n\r\n  \r\n    \r\n  \r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/items/item-detail/item-detail.page.html":
  /*!***********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/items/item-detail/item-detail.page.html ***!
    \***********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppItemsItemDetailItemDetailPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button defaultHref=\"/\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title> {{ card?.Description }} Item Card </ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <ion-card *ngIf=\"card\" color=\"light\" >\r\n\r\n    <ion-card-header color=\"success\">\r\n      <ion-card-title>\r\n        <ion-card-title style=\"color:white\"> {{ card?.Description }} Details</ion-card-title>\r\n      </ion-card-title>\r\n    </ion-card-header>\r\n\r\n    <ion-card-content>\r\n\r\n      <ion-grid>\r\n\r\n        <ion-row>\r\n          <ion-col center text-center size=\"6\">\r\n            <ion-item>\r\n              <ion-label class=\"ion-text-wrap\">\r\n                Type Of Grade\r\n              </ion-label>\r\n              \r\n            </ion-item>\r\n          </ion-col>\r\n          <ion-col size=\"6\">\r\n            <ion-item lines=\"none\">\r\n              <ion-text>\r\n                <h4>{{ card?.Type_Of_Grade?card?.Type_Of_Grade: 'Not Set' }}</h4>\r\n              </ion-text>\r\n            </ion-item>\r\n          </ion-col>\r\n        </ion-row>\r\n\r\n        <ion-row>\r\n          <ion-col size=\"6\">\r\n            <ion-item>\r\n              <ion-label class=\"ion-text-wrap\">\r\n                Base Unit of Measure\r\n              </ion-label>              \r\n            </ion-item>\r\n          </ion-col>\r\n          <ion-col size=\"6\">\r\n            <ion-item lines=\"none\">\r\n              <ion-text>\r\n                <h4> {{ card?.Base_Unit_of_Measure?card?.Base_Unit_of_Measure: 'Not Set' }}</h4>\r\n              </ion-text>             \r\n            </ion-item>\r\n          </ion-col>\r\n        </ion-row>\r\n\r\n        <ion-row>\r\n          <ion-col size=\"6\">\r\n            <ion-item>\r\n              <ion-label class=\"ion-text-wrap\">\r\n                Inventory\r\n              </ion-label>\r\n            </ion-item>\r\n          </ion-col>\r\n          <ion-col size=\"6\">\r\n            <ion-item lines=\"none\">\r\n              <ion-text>\r\n                <h4>{{ card?.Inventory?card?.Inventory: 'Not Set' }}</h4>\r\n              </ion-text>              \r\n            </ion-item>\r\n          </ion-col>\r\n        </ion-row>\r\n\r\n        <ion-row>\r\n          <ion-col size=\"6\">\r\n            <ion-item>\r\n              <ion-label class=\"ion-text-wrap\">\r\n                Qty on Purchase Order\r\n              </ion-label>\r\n            </ion-item>\r\n          </ion-col>\r\n          <ion-col size=\"6\">\r\n            <ion-item lines=\"none\">\r\n              <ion-text>\r\n                <h4>{{ card?.Qty_on_Purch_Order?card?.Qty_on_Purch_Order: 'Not Set' }}</h4>\r\n              </ion-text>              \r\n            </ion-item>\r\n          </ion-col>\r\n        </ion-row>\r\n\r\n        <ion-row>\r\n          <ion-col size=\"6\">\r\n            <ion-item>\r\n              <ion-label class=\"ion-text-wrap\">\r\n                Qty on Production Order\r\n              </ion-label>\r\n            </ion-item>\r\n          </ion-col>\r\n          <ion-col size=\"6\">\r\n            <ion-item lines=\"none\">\r\n              <ion-text>\r\n                <h4>{{ card?.Qty_on_Prod_Order?card?.Qty_on_Prod_Order: 'Not Set' }}</h4>\r\n              </ion-text>              \r\n            </ion-item>\r\n          </ion-col>\r\n        </ion-row>\r\n\r\n\r\n        <ion-row>\r\n          <ion-col size=\"6\">\r\n            <ion-item>\r\n              <ion-label class=\"ion-text-wrap\">\r\n                Costing Method\r\n              </ion-label>\r\n            </ion-item>\r\n          </ion-col>\r\n          <ion-col size=\"6\">\r\n            <ion-item lines=\"none\">\r\n              <ion-text>\r\n                <h4>{{ card?.Costing_Method?card?.Costing_Method: 'Not Set' }}</h4>\r\n              </ion-text>              \r\n            </ion-item>\r\n          </ion-col>\r\n        </ion-row>\r\n\r\n\r\n        <ion-row>\r\n          <ion-col size=\"6\">\r\n            <ion-item>\r\n              <ion-label class=\"ion-text-wrap\">\r\n                Manufacturing Policy\r\n              </ion-label>\r\n            </ion-item>\r\n          </ion-col>\r\n          <ion-col size=\"6\">\r\n            <ion-item lines=\"none\">\r\n              <ion-text>\r\n                <h4>{{ card?.Manufacturing_Policy?card?.Manufacturing_Policy: 'Not Set' }}</h4>\r\n              </ion-text>              \r\n            </ion-item>\r\n          </ion-col>\r\n        </ion-row>\r\n\r\n        <ion-row>\r\n          <ion-col size=\"6\">\r\n            <ion-item>\r\n              <ion-label class=\"ion-text-wrap\">\r\n                Inventory Posting Group\r\n              </ion-label>\r\n            </ion-item>\r\n          </ion-col>\r\n          <ion-col size=\"6\">\r\n            <ion-item lines=\"none\">\r\n              <ion-text>\r\n                <h4>{{ card?.Inventory_Posting_Group?card?.Inventory_Posting_Group: 'Not Set' }}</h4>\r\n              </ion-text>              \r\n            </ion-item>\r\n          </ion-col>\r\n        </ion-row>\r\n\r\n\r\n        <ion-row>\r\n          <ion-col size=\"6\">\r\n            <ion-item>\r\n              <ion-label class=\"ion-text-wrap\">\r\n                Sales Unit of Measure\r\n              </ion-label>\r\n            </ion-item>\r\n          </ion-col>\r\n          <ion-col size=\"6\">\r\n            <ion-item lines=\"none\">\r\n              <ion-text>\r\n                <h4>{{ card?.Sales_Unit_of_Measure?card?.Sales_Unit_of_Measure: 'Not Set' }}</h4>\r\n              </ion-text>              \r\n            </ion-item>\r\n          </ion-col>\r\n        </ion-row>\r\n\r\n        <ion-row>\r\n          <ion-col size=\"6\">\r\n            <ion-item>\r\n              <ion-label class=\"ion-text-wrap\">\r\n                Replenishment_System\r\n              </ion-label>\r\n            </ion-item>\r\n          </ion-col>\r\n          <ion-col size=\"6\">\r\n            <ion-item lines=\"none\">\r\n              <ion-text>\r\n                <h4>{{ card?.Replenishment_System?card?.Replenishment_System: 'Not Set' }}</h4>\r\n              </ion-text>              \r\n            </ion-item>\r\n          </ion-col>\r\n        </ion-row>\r\n\r\n\r\n\r\n      </ion-grid>\r\n\r\n    </ion-card-content>\r\n\r\n  </ion-card>\r\n\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/payments/daily-report/daily-report.page.html":
  /*!****************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/payments/daily-report/daily-report.page.html ***!
    \****************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPaymentsDailyReportDailyReportPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <ion-title class=\"ion-text-center\">Daily Sales Receipts </ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <ion-grid>\r\n    <ion-row>\r\n      <ion-col>\r\n        <ion-item>\r\n          <ion-label position=\"floating\">Start Date</ion-label>\r\n          <ion-datetime type=\"date\" required (ionChange)=\"FilterReceiptsbyDate($event)\"></ion-datetime>\r\n        </ion-item>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n\r\n  <ion-card *ngIf=\"success\">\r\n    <ion-card-header color=\"success\">\r\n      <ion-card-title>Daily Receipts Summary</ion-card-title>\r\n    </ion-card-header>\r\n    <ion-item>\r\n      <ion-label>Totals: {{ Total | currency:'Ksh.' }}</ion-label>\r\n    </ion-item>\r\n  </ion-card>\r\n\r\n  <ion-grid fixed *ngIf=\"success\">\r\n\r\n    <ion-row>\r\n      <ion-col col-auto col-sm>Customer</ion-col>\r\n      <ion-col col-auto col-sm>Amount </ion-col>\r\n      <ion-col col-auto col-sm> Type</ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n  <ion-virtual-scroll [items]=\"receipts\" approxItemHeight=\"47.2px\" *ngIf=\"success\">\r\n               \r\n    <ion-item \r\n      [routerLink] = \"['/','payments',receipt.Receipt_No]\"\r\n     detail\r\n     *virtualItem=\"let receipt\" > \r\n  \r\n     <ion-grid >\r\n        <ion-row>\r\n  \r\n        <ion-col col-4 col-sm>\r\n            <ion-label>\r\n              <h3>{{ receipt?.Customer_Name }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n  \r\n          <ion-col col-4 col-sm>\r\n            <ion-label>\r\n              <h3>{{ receipt?.Total_Amount }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n\r\n          <ion-col col-4 col-sm>\r\n            <ion-label>\r\n              <h3>{{ receipt?.Type_Of_Sale }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n      \r\n        </ion-row>\r\n      </ion-grid>\r\n            \r\n  </ion-item>\r\n  \r\n  </ion-virtual-scroll>\r\n\r\n\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/payments/monthly-report/monthly-report.page.html":
  /*!********************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/payments/monthly-report/monthly-report.page.html ***!
    \********************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPaymentsMonthlyReportMonthlyReportPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <ion-title class=\"ion-text-center\">Monthly Sales Receipts Report </ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <ion-grid>\r\n    <form #f=\"ngForm\" (ngSubmit)=\"f.form.valid\">\r\n      <ion-row>\r\n        <ion-col col-5 >\r\n          <ion-item >\r\n            <ion-label position=\"floating\">Start Date</ion-label>\r\n            <ion-datetime type=\"date\" [(ngModel)]=\"FilterRange.startDate\" name=\"startDate\" required ></ion-datetime>\r\n          </ion-item>\r\n        </ion-col>\r\n  \r\n        <ion-col col-5 >\r\n          <ion-item >\r\n            <ion-label position=\"floating\">End Date</ion-label>\r\n            <ion-datetime type=\"date\" [(ngModel)]=\"FilterRange.endDate\" name=\"endDate\" required ></ion-datetime>\r\n          </ion-item>\r\n        </ion-col>\r\n  \r\n        <ion-col col-2 push=\"1\">\r\n          <ion-item lines=\"none\">\r\n            <ion-label position=\"floating\"></ion-label>\r\n            <ion-button color=\"primary\" (click)=\"FilterSalebyRange()\">\r\n              <ion-icon slot=\"icon-only\" name=\"search\"></ion-icon>\r\n            </ion-button>\r\n          </ion-item>\r\n            \r\n          \r\n        </ion-col>\r\n  \r\n      </ion-row>\r\n      </form>\r\n  </ion-grid>\r\n\r\n\r\n  <ion-card *ngIf=\"success\">\r\n    <ion-card-header color=\"success\">\r\n      <ion-card-title>Monthly Receipts Summary</ion-card-title>\r\n    </ion-card-header>\r\n    <ion-item>\r\n      <ion-label>From: {{ FilterRange.startDate | date }} To {{FilterRange.endDate | date}}</ion-label>\r\n    </ion-item>\r\n    <ion-item>\r\n      <ion-label>Totals: {{ Total | currency:'Ksh.' }}</ion-label>\r\n    </ion-item>\r\n  </ion-card>\r\n\r\n  <ion-grid fixed *ngIf=\"success\">\r\n\r\n    <ion-row>\r\n      <ion-col col-auto col-sm>Receipt No.</ion-col>\r\n      <ion-col col-auto col-sm>Customer Name</ion-col>\r\n      <ion-col col-auto col-sm>Amount </ion-col>\r\n      \r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n  <ion-virtual-scroll [items]=\"receipts\" approxItemHeight=\"47.2px\" *ngIf=\"success\">\r\n               \r\n    <ion-item \r\n      [routerLink] = \"['/','payments',receipt.Receipt_No]\"\r\n     detail\r\n     *virtualItem=\"let receipt\" > \r\n  \r\n     <ion-grid >\r\n        <ion-row>\r\n  \r\n          <ion-col col-12 col-sm>\r\n            <ion-label>\r\n              <h3>{{ receipt?.Receipt_No }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n  \r\n          <ion-col col-12 col-sm>\r\n            <ion-label>\r\n              <h3>{{ receipt?.Customer_Name }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n  \r\n          <ion-col col-12 col-sm>\r\n            <ion-label>\r\n              <h3>{{ receipt?.Total_Amount }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n  \r\n          \r\n  \r\n        </ion-row>\r\n      </ion-grid>\r\n            \r\n  </ion-item>\r\n  \r\n  </ion-virtual-scroll>\r\n\r\n\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/payments/mpesa/mpesa.page.html":
  /*!**************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/payments/mpesa/mpesa.page.html ***!
    \**************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPaymentsMpesaMpesaPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <ion-title>Mpesa Transactions</ion-title>\r\n\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<div *ngIf=\"isLoading\" class=\"ion-text-center\">\r\n  <ion-spinner name=\"crescent\"></ion-spinner>\r\n</div>\r\n\r\n<ion-content *ngIf=\"!isLoading\">\r\n\r\n\r\n\r\n  <ion-searchbar [(ngModel)]=\"searchTerm\" debounce=\"2000\" (ionChange)=\"searchPayment($event)\"></ion-searchbar>\r\n\r\n\r\n  <ion-grid fixed>\r\n    <ion-row>\r\n      <ion-col col-4 col-sm>Ref.</ion-col>\r\n      <ion-col col-4 col-sm>Phone</ion-col>\r\n      <ion-col col-4 col-sm>Name</ion-col>\r\n\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n  <ion-virtual-scroll [items]=\"transactions\" approxItemHeight=\"47.2px\">\r\n\r\n    <ion-item *virtualItem=\"let transaction\">\r\n\r\n      <ion-grid>\r\n        <ion-row>\r\n\r\n          <ion-col col-4 col-sm>\r\n            <ion-label>\r\n              <h3>{{ transaction?.Receipt_No }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n\r\n          <ion-col col-4 col-sm>\r\n            <ion-label>\r\n              <h3>{{ transaction?.Phone }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n\r\n          <ion-col col-4 col-sm>\r\n            <ion-label>\r\n              <h3>{{ transaction?.Name }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n\r\n\r\n\r\n\r\n        </ion-row>\r\n      </ion-grid>\r\n\r\n    </ion-item>\r\n\r\n  </ion-virtual-scroll>\r\n\r\n\r\n\r\n\r\n</ion-content>";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/postedsalesinvoices/dailyreport/dailyreport.page.html":
  /*!*************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/postedsalesinvoices/dailyreport/dailyreport.page.html ***!
    \*************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPostedsalesinvoicesDailyreportDailyreportPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <ion-title class=\"ion-text-center\">Daily Sales Report </ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <ion-grid>\r\n    <ion-row>\r\n      <ion-col>\r\n        <ion-item>\r\n          <ion-label position=\"floating\">Start Date</ion-label>\r\n          <ion-datetime type=\"date\" required (ionChange)=\"FilterSalebyDate($event)\"></ion-datetime>\r\n        </ion-item>\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n\r\n  <ion-card *ngIf=\"success\">\r\n    <ion-card-header color=\"success\">\r\n      <ion-card-title>Daily Sales Summary</ion-card-title>\r\n    </ion-card-header>\r\n    <ion-item>\r\n      <ion-label>Totals: {{ Total | currency:'Ksh.' }}</ion-label>\r\n    </ion-item>\r\n  </ion-card>\r\n\r\n  <ion-grid fixed *ngIf=\"success\">\r\n\r\n    <ion-row>\r\n      <!--<ion-col col-12 col-sm>No.</ion-col>\r\n                                                      <ion-col col-12 col-sm>Customer No.</ion-col>-->\r\n      <ion-col col-12 col-sm>Posting Date</ion-col>\r\n      <ion-col col-12 col-sm>Customer Name</ion-col>\r\n      <ion-col col-12 col-sm>Amount</ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n  <ion-virtual-scroll [items]=\"sales\" approxItemHeight=\"47.2px\" *ngIf=\"success\">\r\n               \r\n    <ion-item \r\n      [routerLink] = \"['/','postedsales',sale.Key]\"\r\n     detail\r\n     *virtualItem=\"let sale\" > \r\n  \r\n     <ion-grid >\r\n        <ion-row>\r\n  \r\n        <!-- <ion-col col-12 col-sm>\r\n            <ion-label>\r\n              <h3>{{ sale?.No }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n  \r\n          <ion-col col-12 col-sm>\r\n            <ion-label>\r\n              <h3>{{ sale?.Customer_No }}</h3>\r\n            </ion-label>\r\n          </ion-col>-->\r\n          <ion-col col-4 col-sm>\r\n            <ion-label>\r\n              <h3>{{ sale?.Posting_Date}}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n  \r\n          <ion-col col-4 col-sm>\r\n            <ion-label>\r\n              <h3>{{ sale?.Customer_Name }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n  \r\n\r\n          <ion-col col-4 col-sm>\r\n            <ion-label>\r\n              <h3>{{ sale?.Amount | currency:'Ksh.' }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n  \r\n        </ion-row>\r\n      </ion-grid>\r\n            \r\n  </ion-item>\r\n  \r\n  </ion-virtual-scroll>\r\n\r\n\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/postedsalesinvoices/monthlyreport/monthlyreport.page.html":
  /*!*****************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/postedsalesinvoices/monthlyreport/monthlyreport.page.html ***!
    \*****************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPostedsalesinvoicesMonthlyreportMonthlyreportPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n    <ion-title class=\"ion-text-center\">Monthly Sales Report </ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <ion-grid>\r\n    \r\n    <form #f=\"ngForm\" (ngSubmit)=\"f.form.valid\">\r\n      <ion-row>\r\n        <ion-col col-5 >\r\n          <ion-item >\r\n            <ion-label position=\"floating\">Start Date</ion-label>\r\n            <ion-datetime type=\"date\" [(ngModel)]=\"FilterRange.startDate\" name=\"startDate\" required ></ion-datetime>\r\n          </ion-item>\r\n        </ion-col>\r\n  \r\n        <ion-col col-5 >\r\n          <ion-item >\r\n            <ion-label position=\"floating\">End Date</ion-label>\r\n            <ion-datetime type=\"date\" [(ngModel)]=\"FilterRange.endDate\" name=\"endDate\" required ></ion-datetime>\r\n          </ion-item>\r\n        </ion-col>\r\n  \r\n        <ion-col col-2 push=\"1\">\r\n          <ion-item lines=\"none\">\r\n            <ion-label position=\"floating\"></ion-label>\r\n            <ion-button color=\"primary\" (click)=\"FilterSalebyRange()\">\r\n              <ion-icon slot=\"icon-only\" name=\"search\"></ion-icon>\r\n            </ion-button>\r\n          </ion-item>\r\n            \r\n          \r\n        </ion-col>\r\n  \r\n      </ion-row>\r\n      </form>\r\n  </ion-grid>\r\n\r\n\r\n  <ion-card *ngIf=\"success\">\r\n    <ion-card-header color=\"success\">\r\n      <ion-card-title>Monthly Sales Summary</ion-card-title>\r\n    </ion-card-header>\r\n    <ion-item>\r\n      <ion-label>Totals: {{ Total | currency:'Ksh.' }}</ion-label>\r\n    </ion-item>\r\n  </ion-card>\r\n\r\n  <ion-grid fixed *ngIf=\"success\">\r\n\r\n    <ion-row>\r\n      <!--<ion-col col-12 col-sm>No.</ion-col>-->\r\n      <!--<ion-col col-12 col-sm>Customer No.</ion-col>-->\r\n      <ion-col col-12 col-sm>Posting Date</ion-col>\r\n      <ion-col col-12 col-sm>Customer Name </ion-col>\r\n      <ion-col col-12 col-sm>Amount</ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n  <ion-virtual-scroll [items]=\"sales\" approxItemHeight=\"47.2px\" *ngIf=\"success\">\r\n               \r\n    <ion-item \r\n      [routerLink] = \"['/','postedsales',sale.No]\"\r\n     detail\r\n     *virtualItem=\"let sale\" > \r\n  \r\n     <ion-grid >\r\n        <ion-row>\r\n  \r\n        <!-- <ion-col col-12 col-sm>\r\n            <ion-label>\r\n              <h3>{{ sale?.No }}</h3>\r\n            </ion-label>\r\n          </ion-col>-->\r\n  \r\n        <!-- <ion-col col-12 col-sm>\r\n            <ion-label>\r\n              <h3>{{ sale?.Customer_No }}</h3>\r\n            </ion-label>\r\n          </ion-col>-->\r\n\r\n          <ion-col col-4 col-sm-4>\r\n            <ion-label>\r\n              <h3>{{ sale?.Posting_Date}}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n  \r\n          <ion-col col-4 col-sm-4>\r\n            <ion-label>\r\n              <h3>{{ sale?.Customer_Name }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n  \r\n\r\n          <ion-col col-4 col-sm-4>\r\n            <ion-label>\r\n              <h3>{{ sale?.Amount | currency:'Ksh.'}}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n  \r\n        </ion-row>\r\n      </ion-grid>\r\n            \r\n  </ion-item>\r\n  \r\n  </ion-virtual-scroll>\r\n\r\n\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/return/return-list/return-list.page.html":
  /*!************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/return/return-list/return-list.page.html ***!
    \************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppReturnReturnListReturnListPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button></ion-menu-button>\r\n    </ion-buttons>\r\n\r\n    <ion-title>Returns List</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <div *ngIf=\"isLoading\" class=\"ion-text-center\">\r\n    <ion-spinner name=\"crescent\"></ion-spinner>\r\n  </div>\r\n\r\n\r\n  <ion-searchbar [(ngModel)]=\"searchTerm\" debounce=\"2000\" (ionChange)=\"search($event)\" placeholder=\"Search Returns\">\r\n  </ion-searchbar>\r\n\r\n  <ion-grid>\r\n    <ion-row>\r\n      <ion-col size=\"4\">No.</ion-col>\r\n      <ion-col size=\"4\">Return Date</ion-col>\r\n      <ion-col size=\"4\">Customer</ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n  <ion-virtual-scroll [items]=\"list\" approxItemHeight=\"47.2px\">\r\n\r\n    <ion-item [routerLink]=\"['/','return','card',ret.Key]\" detail *virtualItem=\"let ret\">\r\n\r\n      <ion-grid>\r\n        <ion-row>\r\n\r\n          <ion-col size=\"4\">\r\n            <ion-label>\r\n              <h3>{{ ret.No }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n\r\n          <ion-col size=\"4\">\r\n            <ion-label>\r\n              <h3>{{ ret.Return_Date }}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n\r\n\r\n\r\n          <ion-col size=\"4\">\r\n            <ion-label>\r\n              <h3>{{ ret.Customer_Name}}</h3>\r\n            </ion-label>\r\n          </ion-col>\r\n\r\n        </ion-row>\r\n      </ion-grid>\r\n\r\n    </ion-item>\r\n\r\n  </ion-virtual-scroll>\r\n\r\n\r\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/cash-deposit/cash-deposit-detail/cash-deposit-detail-routing.module.ts":
  /*!****************************************************************************************!*\
    !*** ./src/app/cash-deposit/cash-deposit-detail/cash-deposit-detail-routing.module.ts ***!
    \****************************************************************************************/

  /*! exports provided: CashDepositDetailPageRoutingModule */

  /***/
  function srcAppCashDepositCashDepositDetailCashDepositDetailRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CashDepositDetailPageRoutingModule", function () {
      return CashDepositDetailPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _cash_deposit_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./cash-deposit-detail.page */
    "./src/app/cash-deposit/cash-deposit-detail/cash-deposit-detail.page.ts");

    var routes = [{
      path: '',
      component: _cash_deposit_detail_page__WEBPACK_IMPORTED_MODULE_3__["CashDepositDetailPage"]
    }];

    var CashDepositDetailPageRoutingModule = function CashDepositDetailPageRoutingModule() {
      _classCallCheck(this, CashDepositDetailPageRoutingModule);
    };

    CashDepositDetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], CashDepositDetailPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/cash-deposit/cash-deposit-detail/cash-deposit-detail.module.ts":
  /*!********************************************************************************!*\
    !*** ./src/app/cash-deposit/cash-deposit-detail/cash-deposit-detail.module.ts ***!
    \********************************************************************************/

  /*! exports provided: CashDepositDetailPageModule */

  /***/
  function srcAppCashDepositCashDepositDetailCashDepositDetailModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CashDepositDetailPageModule", function () {
      return CashDepositDetailPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _cash_deposit_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./cash-deposit-detail-routing.module */
    "./src/app/cash-deposit/cash-deposit-detail/cash-deposit-detail-routing.module.ts");
    /* harmony import */


    var _cash_deposit_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./cash-deposit-detail.page */
    "./src/app/cash-deposit/cash-deposit-detail/cash-deposit-detail.page.ts");

    var CashDepositDetailPageModule = function CashDepositDetailPageModule() {
      _classCallCheck(this, CashDepositDetailPageModule);
    };

    CashDepositDetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _cash_deposit_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__["CashDepositDetailPageRoutingModule"]],
      declarations: [_cash_deposit_detail_page__WEBPACK_IMPORTED_MODULE_6__["CashDepositDetailPage"]]
    })], CashDepositDetailPageModule);
    /***/
  },

  /***/
  "./src/app/cash-deposit/cash-deposit-detail/cash-deposit-detail.page.scss":
  /*!********************************************************************************!*\
    !*** ./src/app/cash-deposit/cash-deposit-detail/cash-deposit-detail.page.scss ***!
    \********************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppCashDepositCashDepositDetailCashDepositDetailPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2Nhc2gtZGVwb3NpdC9jYXNoLWRlcG9zaXQtZGV0YWlsL2Nhc2gtZGVwb3NpdC1kZXRhaWwucGFnZS5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/cash-deposit/cash-deposit-detail/cash-deposit-detail.page.ts":
  /*!******************************************************************************!*\
    !*** ./src/app/cash-deposit/cash-deposit-detail/cash-deposit-detail.page.ts ***!
    \******************************************************************************/

  /*! exports provided: CashDepositDetailPage */

  /***/
  function srcAppCashDepositCashDepositDetailCashDepositDetailPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CashDepositDetailPage", function () {
      return CashDepositDetailPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var src_app_utility_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/utility.service */
    "./src/app/utility.service.ts");
    /* harmony import */


    var _cash_deposit_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../cash-deposit.service */
    "./src/app/cash-deposit/cash-deposit.service.ts");

    var CashDepositDetailPage = /*#__PURE__*/function () {
      function CashDepositDetailPage(depositSvc, activatedRoute, utilitySvc) {
        _classCallCheck(this, CashDepositDetailPage);

        this.depositSvc = depositSvc;
        this.activatedRoute = activatedRoute;
        this.utilitySvc = utilitySvc;
      }

      _createClass(CashDepositDetailPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.Key = this.activatedRoute.snapshot.paramMap.get('Key');

          if (this.Key) {
            this.FetchCard();
          }
        }
      }, {
        key: "FetchCard",
        value: function FetchCard() {
          var _this = this;

          this.depositSub = this.depositSvc.getCard(this.Key).subscribe(function (result) {
            _this.cashDeposit = result;
          }, function (error) {
            console.log(error.error);

            _this.utilitySvc.showAlert(error.error.message);
          });
        }
      }]);

      return CashDepositDetailPage;
    }();

    CashDepositDetailPage.ctorParameters = function () {
      return [{
        type: _cash_deposit_service__WEBPACK_IMPORTED_MODULE_4__["CashDepositService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
      }, {
        type: src_app_utility_service__WEBPACK_IMPORTED_MODULE_3__["UtilityService"]
      }];
    };

    CashDepositDetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-cash-deposit-detail',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./cash-deposit-detail.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/cash-deposit/cash-deposit-detail/cash-deposit-detail.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./cash-deposit-detail.page.scss */
      "./src/app/cash-deposit/cash-deposit-detail/cash-deposit-detail.page.scss"))["default"]]
    })], CashDepositDetailPage);
    /***/
  },

  /***/
  "./src/app/cash-deposit/cash-deposit.service.ts":
  /*!******************************************************!*\
    !*** ./src/app/cash-deposit/cash-deposit.service.ts ***!
    \******************************************************/

  /*! exports provided: CashDepositService */

  /***/
  function srcAppCashDepositCashDepositServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CashDepositService", function () {
      return CashDepositService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");

    var CashDepositService = /*#__PURE__*/function () {
      function CashDepositService(http) {
        _classCallCheck(this, CashDepositService);

        this.http = http;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_5__["environment"].url;
        this._cashRefresh$ = new rxjs__WEBPACK_IMPORTED_MODULE_3__["Subject"]();
        this._lineRefresh$ = new rxjs__WEBPACK_IMPORTED_MODULE_3__["Subject"]();
      } // Synthetic getter for peeping into subject


      _createClass(CashDepositService, [{
        key: "cashrefresh$",
        get: function get() {
          return this._cashRefresh$;
        }
      }, {
        key: "lineRefresh$",
        get: function get() {
          return this._lineRefresh$;
        } // Retrieve all records in list

      }, {
        key: "getCashdeposits",
        value: function getCashdeposits(userID) {
          return this.http.get("".concat(this.url, "site/get?service=CashDepositList&userid=").concat(userID)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "newDeposit",
        value: function newDeposit(userID) {
          // console.table(deposit); return;
          return this.http.get("".concat(this.url, "site/create-cash-deposit?UserID=").concat(userID));
        }
      }, {
        key: "updateDeposit",
        value: function updateDeposit(deposit) {
          return this.http.post("".concat(this.url, "site/cashdeposit"), JSON.stringify(deposit));
        } // View the card

      }, {
        key: "getCard",
        value: function getCard(Key) {
          return this.http.get("".concat(this.url, "site/view-cashdeposit/?Key=").concat(Key)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "getCardByNo",
        value: function getCardByNo(No) {
          return this.http.get("".concat(this.url, "site/cash-deposit-card/?No=").concat(No)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "postDocument",
        value: function postDocument(No) {
          // post-cashdeposit
          return this.http.get("".concat(this.url, "site/post-cashdeposit/?No=").concat(No)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
        /**Process Lines */
        // Get Line

      }, {
        key: "getLine",
        value: function getLine(Key) {
          return this.http.get("".concat(this.url, "site/fetch-cashdeposit-line?Key=").concat(Key));
        } // Post Lines Data

      }, {
        key: "postLine",
        value: function postLine(line) {
          var _this2 = this;

          return this.http.post("".concat(this.url, "site/cashdeposit-line"), JSON.stringify(line)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function () {
            _this2._lineRefresh$.next(line);
          }));
        } // Update Line

      }, {
        key: "updateLine",
        value: function updateLine(line) {
          var _this3 = this;

          return this.http.post("".concat(this.url, "site/cashdeposit-line"), JSON.stringify(line)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function () {
            _this3._lineRefresh$.next(line);
          }));
        }
      }]);

      return CashDepositService;
    }();

    CashDepositService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"]
      }];
    };

    CashDepositService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
      providedIn: 'root'
    })], CashDepositService);
    /***/
  },

  /***/
  "./src/app/items/availability-by-location/availability-by-location-routing.module.ts":
  /*!*******************************************************************************************!*\
    !*** ./src/app/items/availability-by-location/availability-by-location-routing.module.ts ***!
    \*******************************************************************************************/

  /*! exports provided: AvailabilityByLocationPageRoutingModule */

  /***/
  function srcAppItemsAvailabilityByLocationAvailabilityByLocationRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AvailabilityByLocationPageRoutingModule", function () {
      return AvailabilityByLocationPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _availability_by_location_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./availability-by-location.page */
    "./src/app/items/availability-by-location/availability-by-location.page.ts");

    var routes = [{
      path: '',
      component: _availability_by_location_page__WEBPACK_IMPORTED_MODULE_3__["AvailabilityByLocationPage"]
    }];

    var AvailabilityByLocationPageRoutingModule = function AvailabilityByLocationPageRoutingModule() {
      _classCallCheck(this, AvailabilityByLocationPageRoutingModule);
    };

    AvailabilityByLocationPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], AvailabilityByLocationPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/items/availability-by-location/availability-by-location.module.ts":
  /*!***********************************************************************************!*\
    !*** ./src/app/items/availability-by-location/availability-by-location.module.ts ***!
    \***********************************************************************************/

  /*! exports provided: AvailabilityByLocationPageModule */

  /***/
  function srcAppItemsAvailabilityByLocationAvailabilityByLocationModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AvailabilityByLocationPageModule", function () {
      return AvailabilityByLocationPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _availability_by_location_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./availability-by-location-routing.module */
    "./src/app/items/availability-by-location/availability-by-location-routing.module.ts");
    /* harmony import */


    var _availability_by_location_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./availability-by-location.page */
    "./src/app/items/availability-by-location/availability-by-location.page.ts");

    var AvailabilityByLocationPageModule = function AvailabilityByLocationPageModule() {
      _classCallCheck(this, AvailabilityByLocationPageModule);
    };

    AvailabilityByLocationPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _availability_by_location_routing_module__WEBPACK_IMPORTED_MODULE_5__["AvailabilityByLocationPageRoutingModule"]],
      declarations: [_availability_by_location_page__WEBPACK_IMPORTED_MODULE_6__["AvailabilityByLocationPage"]]
    })], AvailabilityByLocationPageModule);
    /***/
  },

  /***/
  "./src/app/items/availability-by-location/availability-by-location.page.scss":
  /*!***********************************************************************************!*\
    !*** ./src/app/items/availability-by-location/availability-by-location.page.scss ***!
    \***********************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppItemsAvailabilityByLocationAvailabilityByLocationPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2l0ZW1zL2F2YWlsYWJpbGl0eS1ieS1sb2NhdGlvbi9hdmFpbGFiaWxpdHktYnktbG9jYXRpb24ucGFnZS5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/items/availability-by-location/availability-by-location.page.ts":
  /*!*********************************************************************************!*\
    !*** ./src/app/items/availability-by-location/availability-by-location.page.ts ***!
    \*********************************************************************************/

  /*! exports provided: AvailabilityByLocationPage */

  /***/
  function srcAppItemsAvailabilityByLocationAvailabilityByLocationPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AvailabilityByLocationPage", function () {
      return AvailabilityByLocationPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _item_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ../item.service */
    "./src/app/items/item.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var AvailabilityByLocationPage = /*#__PURE__*/function () {
      function AvailabilityByLocationPage(itemService, alertCtrl) {
        _classCallCheck(this, AvailabilityByLocationPage);

        this.itemService = itemService;
        this.alertCtrl = alertCtrl;
        this.isLoading = true;
        this.searchTerm = null;
        this.searched = null;
      }

      _createClass(AvailabilityByLocationPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this4 = this;

          this.isLoading = true;
          this.itemSub = this.itemService.items.subscribe(function (result) {
            // console.log(result);
            _this4.Items = _toConsumableArray(result);
            _this4.isLoading = false;
          }, function (error) {
            _this4.isLoading = false;
            console.log(error.error);

            _this4.alertCtrl.create({
              header: 'Service Error!',
              message: 'Connection problem: ' + error.error.message,
              buttons: [{
                text: 'Okay'
              }]
            }).then(function (alertEl) {
              alertEl.present();
            });
          });
        }
      }, {
        key: "searchItem",
        value: function searchItem($event) {
          var _this5 = this;

          var searchItems = _toConsumableArray(this.Items); // Begin search only if searchTerm is provided


          if (this.searchTerm.trim().length && this.searchTerm !== '') {
            this.Items = searchItems.filter(function (prod) {
              if (prod.Description && prod.Description.length > 1) {
                return prod.Description.toLowerCase().indexOf(_this5.searchTerm.toLowerCase()) > -1;
              }
            });
            return;
          } else {
            // Search Term not provide display all items
            this.initializeItems();
          }
        }
      }, {
        key: "initializeItems",
        value: function initializeItems() {
          var _this6 = this;

          this.itemSub = this.itemService.items.subscribe(function (result) {
            console.log(result);
            _this6.Items = _toConsumableArray(result);
          });
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          if (this.itemSub) {
            this.itemSub.unsubscribe();
          }
        }
      }]);

      return AvailabilityByLocationPage;
    }();

    AvailabilityByLocationPage.ctorParameters = function () {
      return [{
        type: _item_service__WEBPACK_IMPORTED_MODULE_2__["ItemService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"]
      }];
    };

    AvailabilityByLocationPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-availability-by-location',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./availability-by-location.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/items/availability-by-location/availability-by-location.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./availability-by-location.page.scss */
      "./src/app/items/availability-by-location/availability-by-location.page.scss"))["default"]]
    })], AvailabilityByLocationPage);
    /***/
  },

  /***/
  "./src/app/items/availability-card/availability-card-routing.module.ts":
  /*!*****************************************************************************!*\
    !*** ./src/app/items/availability-card/availability-card-routing.module.ts ***!
    \*****************************************************************************/

  /*! exports provided: AvailabilityCardPageRoutingModule */

  /***/
  function srcAppItemsAvailabilityCardAvailabilityCardRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AvailabilityCardPageRoutingModule", function () {
      return AvailabilityCardPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _availability_card_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./availability-card.page */
    "./src/app/items/availability-card/availability-card.page.ts");

    var routes = [{
      path: '',
      component: _availability_card_page__WEBPACK_IMPORTED_MODULE_3__["AvailabilityCardPage"]
    }];

    var AvailabilityCardPageRoutingModule = function AvailabilityCardPageRoutingModule() {
      _classCallCheck(this, AvailabilityCardPageRoutingModule);
    };

    AvailabilityCardPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], AvailabilityCardPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/items/availability-card/availability-card.module.ts":
  /*!*********************************************************************!*\
    !*** ./src/app/items/availability-card/availability-card.module.ts ***!
    \*********************************************************************/

  /*! exports provided: AvailabilityCardPageModule */

  /***/
  function srcAppItemsAvailabilityCardAvailabilityCardModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AvailabilityCardPageModule", function () {
      return AvailabilityCardPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _availability_card_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./availability-card-routing.module */
    "./src/app/items/availability-card/availability-card-routing.module.ts");
    /* harmony import */


    var _availability_card_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./availability-card.page */
    "./src/app/items/availability-card/availability-card.page.ts");

    var AvailabilityCardPageModule = function AvailabilityCardPageModule() {
      _classCallCheck(this, AvailabilityCardPageModule);
    };

    AvailabilityCardPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _availability_card_routing_module__WEBPACK_IMPORTED_MODULE_5__["AvailabilityCardPageRoutingModule"]],
      declarations: [_availability_card_page__WEBPACK_IMPORTED_MODULE_6__["AvailabilityCardPage"]]
    })], AvailabilityCardPageModule);
    /***/
  },

  /***/
  "./src/app/items/availability-card/availability-card.page.scss":
  /*!*********************************************************************!*\
    !*** ./src/app/items/availability-card/availability-card.page.scss ***!
    \*********************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppItemsAvailabilityCardAvailabilityCardPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2l0ZW1zL2F2YWlsYWJpbGl0eS1jYXJkL2F2YWlsYWJpbGl0eS1jYXJkLnBhZ2Uuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/items/availability-card/availability-card.page.ts":
  /*!*******************************************************************!*\
    !*** ./src/app/items/availability-card/availability-card.page.ts ***!
    \*******************************************************************/

  /*! exports provided: AvailabilityCardPage */

  /***/
  function srcAppItemsAvailabilityCardAvailabilityCardPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AvailabilityCardPage", function () {
      return AvailabilityCardPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _item_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ../item.service */
    "./src/app/items/item.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");

    var AvailabilityCardPage = /*#__PURE__*/function () {
      function AvailabilityCardPage(itemService, activatedRoute, alertCtrl, loadingCtrl) {
        _classCallCheck(this, AvailabilityCardPage);

        this.itemService = itemService;
        this.activatedRoute = activatedRoute;
        this.alertCtrl = alertCtrl;
        this.loadingCtrl = loadingCtrl;
        this.TotalRemainingQuantity = 0;
      }

      _createClass(AvailabilityCardPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this7 = this;

          this.ItemNo = this.activatedRoute.snapshot.paramMap.get('No'); // Get Item Balance Card

          this.ledgerSub = this.itemService.itemBalance(this.ItemNo).subscribe(function (res) {
            // console.log(typeof res[Symbol.iterator]);
            _this7.itemList = res; // Check if response of an object and if that object is iterable

            if (typeof res === 'object' && typeof res[Symbol.iterator] === 'function') {
              _this7.TotalRemainingQuantity = _this7.itemService.getTotals(res, 'Remaining_Quantity');
              console.log("Remaining Quantities are : ".concat(_this7.TotalRemainingQuantity));
            } else {
              _this7.itemService.showToast('Selected Store has no inventory record for such an item . ');
            }
          }, function (error) {
            console.log(error.error);

            _this7.alertCtrl.create({
              header: 'Service Error!',
              message: 'Connection problem: ' + error.error.message,
              buttons: [{
                text: 'Okay'
              }]
            }).then(function (alertEl) {
              alertEl.present();
            });
          }); // Get Item Description

          this.cardSub = this.itemService.itemcard(this.ItemNo).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["finalize"])(function () {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this7, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
              return regeneratorRuntime.wrap(function _callee3$(_context3) {
                while (1) {
                  switch (_context3.prev = _context3.next) {
                    case 0:
                      _context3.next = 2;
                      return this.loading.dismiss();

                    case 2:
                    case "end":
                      return _context3.stop();
                  }
                }
              }, _callee3, this);
            }));
          })).subscribe(function (result) {
            _this7.ItemCard = _toConsumableArray(result)[0];
          }); // Get Locations

          this.locationSub = this.itemService.getLocations().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_5__["finalize"])(function () {
            return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(_this7, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee4() {
              return regeneratorRuntime.wrap(function _callee4$(_context4) {
                while (1) {
                  switch (_context4.prev = _context4.next) {
                    case 0:
                      _context4.next = 2;
                      return this.loading.dismiss();

                    case 2:
                    case "end":
                      return _context4.stop();
                  }
                }
              }, _callee4, this);
            }));
          })).subscribe(function (locs) {
            _this7.locations = locs;
          });
        }
      }, {
        key: "searchByLocation",
        value: function searchByLocation($event) {
          var _this8 = this;

          if ($event.target.value.length) {
            // Get Item Balance Card
            this.ledgerSub = this.itemService.itemBalanceByLocation(this.ItemNo, $event.target.value).subscribe(function (res) {
              console.log(typeof res[Symbol.iterator]);
              _this8.itemList = res;

              if (typeof res === 'object' && typeof res[Symbol.iterator] === 'function') {
                _this8.TotalRemainingQuantity = _this8.itemService.getTotals(res, 'Remaining_Quantity');
                console.log("Remaining Quantities By Loc are : ".concat(_this8.TotalRemainingQuantity));
              } else {
                _this8.itemService.showToast('Selected Store has no inventory record for such an item . ');
              }
            }, function (error) {
              console.log(error.error);

              _this8.alertCtrl.create({
                header: 'Service Error!',
                message: 'Connection problem: ' + error.error.message,
                buttons: [{
                  text: 'Okay'
                }]
              }).then(function (alertEl) {
                alertEl.present();
              });
            });
          }
        }
      }, {
        key: "presentLoading",
        value: function presentLoading() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee5() {
            return regeneratorRuntime.wrap(function _callee5$(_context5) {
              while (1) {
                switch (_context5.prev = _context5.next) {
                  case 0:
                    _context5.next = 2;
                    return this.loadingCtrl.create({
                      spinner: 'dots',
                      animated: true,
                      message: 'Loading..'
                    });

                  case 2:
                    this.loading = _context5.sent;
                    _context5.next = 5;
                    return this.loading.present();

                  case 5:
                  case "end":
                    return _context5.stop();
                }
              }
            }, _callee5, this);
          }));
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          if (this.cardSub) {
            this.cardSub.unsubscribe();
          }

          if (this.cardSub) {
            this.cardSub.unsubscribe();
          }

          if (this.locationSub) {
            this.locationSub.unsubscribe();
          }
        }
      }]);

      return AvailabilityCardPage;
    }();

    AvailabilityCardPage.ctorParameters = function () {
      return [{
        type: _item_service__WEBPACK_IMPORTED_MODULE_2__["ItemService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"]
      }];
    };

    AvailabilityCardPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-availability-card',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./availability-card.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/items/availability-card/availability-card.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./availability-card.page.scss */
      "./src/app/items/availability-card/availability-card.page.scss"))["default"]]
    })], AvailabilityCardPage);
    /***/
  },

  /***/
  "./src/app/items/item-detail/item-detail-routing.module.ts":
  /*!*****************************************************************!*\
    !*** ./src/app/items/item-detail/item-detail-routing.module.ts ***!
    \*****************************************************************/

  /*! exports provided: ItemDetailPageRoutingModule */

  /***/
  function srcAppItemsItemDetailItemDetailRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ItemDetailPageRoutingModule", function () {
      return ItemDetailPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _item_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./item-detail.page */
    "./src/app/items/item-detail/item-detail.page.ts");

    var routes = [{
      path: '',
      component: _item_detail_page__WEBPACK_IMPORTED_MODULE_3__["ItemDetailPage"]
    }];

    var ItemDetailPageRoutingModule = function ItemDetailPageRoutingModule() {
      _classCallCheck(this, ItemDetailPageRoutingModule);
    };

    ItemDetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], ItemDetailPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/items/item-detail/item-detail.module.ts":
  /*!*********************************************************!*\
    !*** ./src/app/items/item-detail/item-detail.module.ts ***!
    \*********************************************************/

  /*! exports provided: ItemDetailPageModule */

  /***/
  function srcAppItemsItemDetailItemDetailModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ItemDetailPageModule", function () {
      return ItemDetailPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _item_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./item-detail-routing.module */
    "./src/app/items/item-detail/item-detail-routing.module.ts");
    /* harmony import */


    var _item_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./item-detail.page */
    "./src/app/items/item-detail/item-detail.page.ts");

    var ItemDetailPageModule = function ItemDetailPageModule() {
      _classCallCheck(this, ItemDetailPageModule);
    };

    ItemDetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _item_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__["ItemDetailPageRoutingModule"]],
      declarations: [_item_detail_page__WEBPACK_IMPORTED_MODULE_6__["ItemDetailPage"]]
    })], ItemDetailPageModule);
    /***/
  },

  /***/
  "./src/app/items/item-detail/item-detail.page.scss":
  /*!*********************************************************!*\
    !*** ./src/app/items/item-detail/item-detail.page.scss ***!
    \*********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppItemsItemDetailItemDetailPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2l0ZW1zL2l0ZW0tZGV0YWlsL2l0ZW0tZGV0YWlsLnBhZ2Uuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/items/item-detail/item-detail.page.ts":
  /*!*******************************************************!*\
    !*** ./src/app/items/item-detail/item-detail.page.ts ***!
    \*******************************************************/

  /*! exports provided: ItemDetailPage */

  /***/
  function srcAppItemsItemDetailItemDetailPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ItemDetailPage", function () {
      return ItemDetailPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _item_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./../item.service */
    "./src/app/items/item.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");

    var ItemDetailPage = /*#__PURE__*/function () {
      function ItemDetailPage(itemService, activatedRoute) {
        _classCallCheck(this, ItemDetailPage);

        this.itemService = itemService;
        this.activatedRoute = activatedRoute;
      }

      _createClass(ItemDetailPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this9 = this;

          // Get Item No. from Url Parameters
          var id = this.activatedRoute.snapshot.paramMap.get('id');
          console.log(id); // Get Item Card

          this.itemService.itemcard(id).subscribe(function (cardInfo) {
            _this9.card = _toConsumableArray(cardInfo)[0]; // Reference the resulting array and access first element, which an obj

            console.log(_this9.card);
          });
        }
      }]);

      return ItemDetailPage;
    }();

    ItemDetailPage.ctorParameters = function () {
      return [{
        type: _item_service__WEBPACK_IMPORTED_MODULE_2__["ItemService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["ActivatedRoute"]
      }];
    };

    ItemDetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-item-detail',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./item-detail.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/items/item-detail/item-detail.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./item-detail.page.scss */
      "./src/app/items/item-detail/item-detail.page.scss"))["default"]]
    })], ItemDetailPage);
    /***/
  },

  /***/
  "./src/app/payments/daily-report/daily-report-routing.module.ts":
  /*!**********************************************************************!*\
    !*** ./src/app/payments/daily-report/daily-report-routing.module.ts ***!
    \**********************************************************************/

  /*! exports provided: DailyReportPageRoutingModule */

  /***/
  function srcAppPaymentsDailyReportDailyReportRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DailyReportPageRoutingModule", function () {
      return DailyReportPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _daily_report_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./daily-report.page */
    "./src/app/payments/daily-report/daily-report.page.ts");

    var routes = [{
      path: '',
      component: _daily_report_page__WEBPACK_IMPORTED_MODULE_3__["DailyReportPage"]
    }];

    var DailyReportPageRoutingModule = function DailyReportPageRoutingModule() {
      _classCallCheck(this, DailyReportPageRoutingModule);
    };

    DailyReportPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], DailyReportPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/payments/daily-report/daily-report.module.ts":
  /*!**************************************************************!*\
    !*** ./src/app/payments/daily-report/daily-report.module.ts ***!
    \**************************************************************/

  /*! exports provided: DailyReportPageModule */

  /***/
  function srcAppPaymentsDailyReportDailyReportModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DailyReportPageModule", function () {
      return DailyReportPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _daily_report_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./daily-report-routing.module */
    "./src/app/payments/daily-report/daily-report-routing.module.ts");
    /* harmony import */


    var _daily_report_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./daily-report.page */
    "./src/app/payments/daily-report/daily-report.page.ts");

    var DailyReportPageModule = function DailyReportPageModule() {
      _classCallCheck(this, DailyReportPageModule);
    };

    DailyReportPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _daily_report_routing_module__WEBPACK_IMPORTED_MODULE_5__["DailyReportPageRoutingModule"]],
      declarations: [_daily_report_page__WEBPACK_IMPORTED_MODULE_6__["DailyReportPage"]]
    })], DailyReportPageModule);
    /***/
  },

  /***/
  "./src/app/payments/daily-report/daily-report.page.scss":
  /*!**************************************************************!*\
    !*** ./src/app/payments/daily-report/daily-report.page.scss ***!
    \**************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPaymentsDailyReportDailyReportPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BheW1lbnRzL2RhaWx5LXJlcG9ydC9kYWlseS1yZXBvcnQucGFnZS5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/payments/daily-report/daily-report.page.ts":
  /*!************************************************************!*\
    !*** ./src/app/payments/daily-report/daily-report.page.ts ***!
    \************************************************************/

  /*! exports provided: DailyReportPage */

  /***/
  function srcAppPaymentsDailyReportDailyReportPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DailyReportPage", function () {
      return DailyReportPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/auth/auth-service */
    "./src/app/auth/auth-service.ts");
    /* harmony import */


    var _payments_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../payments.service */
    "./src/app/payments/payments.service.ts");

    var DailyReportPage = /*#__PURE__*/function () {
      function DailyReportPage(paymentService, authService) {
        _classCallCheck(this, DailyReportPage);

        this.paymentService = paymentService;
        this.authService = authService;
        this.success = false;
        this.Total = 0;
      }

      _createClass(DailyReportPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.setUser();
        }
      }, {
        key: "ionViewDidEnter",
        value: function ionViewDidEnter() {
          this.setUser();
        }
      }, {
        key: "setUser",
        value: function setUser() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee6() {
            return regeneratorRuntime.wrap(function _callee6$(_context6) {
              while (1) {
                switch (_context6.prev = _context6.next) {
                  case 0:
                    _context6.next = 2;
                    return this.authService.getUser();

                  case 2:
                    this.user = _context6.sent;

                  case 3:
                  case "end":
                    return _context6.stop();
                }
              }
            }, _callee6, this);
          }));
        }
      }, {
        key: "FilterReceiptsbyDate",
        value: function FilterReceiptsbyDate($event) {
          var _this10 = this;

          var _a;

          var startDate = this.paymentService.formatDate($event.target.value);

          if (Date.parse(startDate)) {
            this.receiptSub = this.paymentService.FilterReceipts(startDate, (_a = this.user) === null || _a === void 0 ? void 0 : _a.User_ID).subscribe(function (res) {
              // alert(res);
              if (typeof res === 'string') {
                _this10.paymentService.showToast(res);

                _this10.receipts = [];
                _this10.Total = 0;
                _this10.success = false;
                return;
              }

              _this10.receipts = res;
              _this10.Total = _this10.getTotals(_this10.receipts, 'Total_Amount');
              _this10.success = typeof res === 'object' ? true : false;
            });
          } else {
            this.receipts = [];
            this.success = false; // return 'No Date Supplied';
          }
        }
      }, {
        key: "getTotals",
        value: function getTotals(elements, SubjectCol) {
          if (typeof elements === 'object') {
            return this.paymentService.getTotals(elements, SubjectCol);
          } else {
            return 0;
          }
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          if (this.receiptSub) {
            this.receiptSub.unsubscribe();
          }
        }
      }]);

      return DailyReportPage;
    }();

    DailyReportPage.ctorParameters = function () {
      return [{
        type: _payments_service__WEBPACK_IMPORTED_MODULE_3__["PaymentsService"]
      }, {
        type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"]
      }];
    };

    DailyReportPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-daily-report',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./daily-report.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/payments/daily-report/daily-report.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./daily-report.page.scss */
      "./src/app/payments/daily-report/daily-report.page.scss"))["default"]]
    })], DailyReportPage);
    /***/
  },

  /***/
  "./src/app/payments/monthly-report/monthly-report-routing.module.ts":
  /*!**************************************************************************!*\
    !*** ./src/app/payments/monthly-report/monthly-report-routing.module.ts ***!
    \**************************************************************************/

  /*! exports provided: MonthlyReportPageRoutingModule */

  /***/
  function srcAppPaymentsMonthlyReportMonthlyReportRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MonthlyReportPageRoutingModule", function () {
      return MonthlyReportPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _monthly_report_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./monthly-report.page */
    "./src/app/payments/monthly-report/monthly-report.page.ts");

    var routes = [{
      path: '',
      component: _monthly_report_page__WEBPACK_IMPORTED_MODULE_3__["MonthlyReportPage"]
    }];

    var MonthlyReportPageRoutingModule = function MonthlyReportPageRoutingModule() {
      _classCallCheck(this, MonthlyReportPageRoutingModule);
    };

    MonthlyReportPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], MonthlyReportPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/payments/monthly-report/monthly-report.module.ts":
  /*!******************************************************************!*\
    !*** ./src/app/payments/monthly-report/monthly-report.module.ts ***!
    \******************************************************************/

  /*! exports provided: MonthlyReportPageModule */

  /***/
  function srcAppPaymentsMonthlyReportMonthlyReportModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MonthlyReportPageModule", function () {
      return MonthlyReportPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _monthly_report_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./monthly-report-routing.module */
    "./src/app/payments/monthly-report/monthly-report-routing.module.ts");
    /* harmony import */


    var _monthly_report_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./monthly-report.page */
    "./src/app/payments/monthly-report/monthly-report.page.ts");

    var MonthlyReportPageModule = function MonthlyReportPageModule() {
      _classCallCheck(this, MonthlyReportPageModule);
    };

    MonthlyReportPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _monthly_report_routing_module__WEBPACK_IMPORTED_MODULE_5__["MonthlyReportPageRoutingModule"]],
      declarations: [_monthly_report_page__WEBPACK_IMPORTED_MODULE_6__["MonthlyReportPage"]]
    })], MonthlyReportPageModule);
    /***/
  },

  /***/
  "./src/app/payments/monthly-report/monthly-report.page.scss":
  /*!******************************************************************!*\
    !*** ./src/app/payments/monthly-report/monthly-report.page.scss ***!
    \******************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPaymentsMonthlyReportMonthlyReportPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BheW1lbnRzL21vbnRobHktcmVwb3J0L21vbnRobHktcmVwb3J0LnBhZ2Uuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/payments/monthly-report/monthly-report.page.ts":
  /*!****************************************************************!*\
    !*** ./src/app/payments/monthly-report/monthly-report.page.ts ***!
    \****************************************************************/

  /*! exports provided: MonthlyReportPage */

  /***/
  function srcAppPaymentsMonthlyReportMonthlyReportPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MonthlyReportPage", function () {
      return MonthlyReportPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _payments_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ../payments.service */
    "./src/app/payments/payments.service.ts");
    /* harmony import */


    var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/auth/auth-service */
    "./src/app/auth/auth-service.ts");

    var MonthlyReportPage = /*#__PURE__*/function () {
      function MonthlyReportPage(paymentService, authService) {
        _classCallCheck(this, MonthlyReportPage);

        this.paymentService = paymentService;
        this.authService = authService;
        this.FilterRange = {
          startDate: new Date(),
          endDate: new Date()
        };
        this.success = false;
        this.Total = 0;
      }

      _createClass(MonthlyReportPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.setUser();
        }
      }, {
        key: "ionViewDidEnter",
        value: function ionViewDidEnter() {
          this.setUser();
        }
      }, {
        key: "setUser",
        value: function setUser() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee7() {
            return regeneratorRuntime.wrap(function _callee7$(_context7) {
              while (1) {
                switch (_context7.prev = _context7.next) {
                  case 0:
                    _context7.next = 2;
                    return this.authService.getUser();

                  case 2:
                    this.user = _context7.sent;

                  case 3:
                  case "end":
                    return _context7.stop();
                }
              }
            }, _callee7, this);
          }));
        }
      }, {
        key: "FilterSalebyRange",
        value: function FilterSalebyRange() {
          var _this11 = this;

          var _a;

          var startDate = this.paymentService.formatDate(this.FilterRange.startDate);
          var endDate = this.paymentService.formatDate(this.FilterRange.endDate);

          if (Date.parse(startDate) && Date.parse(endDate)) {
            this.receiptSub = this.paymentService.FilterReceiptsbyRange(startDate, endDate, (_a = this.user) === null || _a === void 0 ? void 0 : _a.User_ID).subscribe(function (res) {
              // alert(res);
              if (typeof res === 'string') {
                _this11.paymentService.showToast(res);

                _this11.receipts = [];
                _this11.Total = 0;
                _this11.success = false;
                return;
              }

              _this11.receipts = res;
              _this11.Total = _this11.getTotals(_this11.receipts, 'Total_Amount');
              _this11.success = typeof res === 'object' ? true : false;
            });
          } else {
            return 'No Date Supplied';
          }
        }
      }, {
        key: "getTotals",
        value: function getTotals(elements, SubjectCol) {
          if (typeof elements === 'object') {
            return this.paymentService.getTotals(elements, SubjectCol);
          } else {
            return 0;
          }
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          if (this.receiptSub) {
            this.receiptSub.unsubscribe();
          }
        }
      }]);

      return MonthlyReportPage;
    }();

    MonthlyReportPage.ctorParameters = function () {
      return [{
        type: _payments_service__WEBPACK_IMPORTED_MODULE_2__["PaymentsService"]
      }, {
        type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_3__["AuthService"]
      }];
    };

    MonthlyReportPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-monthly-report',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./monthly-report.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/payments/monthly-report/monthly-report.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./monthly-report.page.scss */
      "./src/app/payments/monthly-report/monthly-report.page.scss"))["default"]]
    })], MonthlyReportPage);
    /***/
  },

  /***/
  "./src/app/payments/mpesa/mpesa-routing.module.ts":
  /*!********************************************************!*\
    !*** ./src/app/payments/mpesa/mpesa-routing.module.ts ***!
    \********************************************************/

  /*! exports provided: MpesaPageRoutingModule */

  /***/
  function srcAppPaymentsMpesaMpesaRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MpesaPageRoutingModule", function () {
      return MpesaPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _mpesa_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./mpesa.page */
    "./src/app/payments/mpesa/mpesa.page.ts");

    var routes = [{
      path: '',
      component: _mpesa_page__WEBPACK_IMPORTED_MODULE_3__["MpesaPage"]
    }];

    var MpesaPageRoutingModule = function MpesaPageRoutingModule() {
      _classCallCheck(this, MpesaPageRoutingModule);
    };

    MpesaPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], MpesaPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/payments/mpesa/mpesa.module.ts":
  /*!************************************************!*\
    !*** ./src/app/payments/mpesa/mpesa.module.ts ***!
    \************************************************/

  /*! exports provided: MpesaPageModule */

  /***/
  function srcAppPaymentsMpesaMpesaModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MpesaPageModule", function () {
      return MpesaPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _mpesa_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./mpesa-routing.module */
    "./src/app/payments/mpesa/mpesa-routing.module.ts");
    /* harmony import */


    var _mpesa_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./mpesa.page */
    "./src/app/payments/mpesa/mpesa.page.ts");

    var MpesaPageModule = function MpesaPageModule() {
      _classCallCheck(this, MpesaPageModule);
    };

    MpesaPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _mpesa_routing_module__WEBPACK_IMPORTED_MODULE_5__["MpesaPageRoutingModule"]],
      declarations: [_mpesa_page__WEBPACK_IMPORTED_MODULE_6__["MpesaPage"]]
    })], MpesaPageModule);
    /***/
  },

  /***/
  "./src/app/payments/mpesa/mpesa.page.scss":
  /*!************************************************!*\
    !*** ./src/app/payments/mpesa/mpesa.page.scss ***!
    \************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPaymentsMpesaMpesaPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3BheW1lbnRzL21wZXNhL21wZXNhLnBhZ2Uuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/payments/mpesa/mpesa.page.ts":
  /*!**********************************************!*\
    !*** ./src/app/payments/mpesa/mpesa.page.ts ***!
    \**********************************************/

  /*! exports provided: MpesaPage */

  /***/
  function srcAppPaymentsMpesaMpesaPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MpesaPage", function () {
      return MpesaPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var src_app_utility_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/utility.service */
    "./src/app/utility.service.ts");
    /* harmony import */


    var _payments_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../payments.service */
    "./src/app/payments/payments.service.ts");

    var MpesaPage = /*#__PURE__*/function () {
      function MpesaPage(paymentSvc, utilitySvc) {
        _classCallCheck(this, MpesaPage);

        this.paymentSvc = paymentSvc;
        this.utilitySvc = utilitySvc;
      }

      _createClass(MpesaPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.FetchTransactions();
        }
      }, {
        key: "FetchTransactions",
        value: function FetchTransactions() {
          var _this12 = this;

          this.mpesaSub = this.paymentSvc.Mpesa().pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_2__["finalize"])(function () {
            _this12.isLoading = false;
          })).subscribe(function (result) {
            _this12.transactions = _this12.sort(_toConsumableArray(result));
          }, function (error) {
            _this12.utilitySvc.showAlert(error.error.message);
          });
        }
      }, {
        key: "sort",
        value: function sort(transactionArray) {
          return transactionArray.sort(function (a, b) {
            return b.Receipt_No > a.Receipt_No ? 1 : -1;
          });
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          if (this.mpesaSub) {
            this.mpesaSub.unsubscribe();
          }
        }
      }, {
        key: "searchPayment",
        value: function searchPayment($event) {
          var _this13 = this;

          var searchItems = _toConsumableArray(this.transactions); // Begin search only if searchTerm is provided


          if (this.searchTerm.trim().length && this.searchTerm !== '') {
            this.transactions = searchItems.filter(function (transaction) {
              if (transaction.Phone && transaction.Phone.length > 1) {
                return transaction.Phone.toLowerCase().indexOf(_this13.searchTerm.toLowerCase()) > -1;
              }
            });
            return;
          } else {
            // Search Term not provide display all items
            this.FetchTransactions();
          }
        }
      }]);

      return MpesaPage;
    }();

    MpesaPage.ctorParameters = function () {
      return [{
        type: _payments_service__WEBPACK_IMPORTED_MODULE_4__["PaymentsService"]
      }, {
        type: src_app_utility_service__WEBPACK_IMPORTED_MODULE_3__["UtilityService"]
      }];
    };

    MpesaPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-mpesa',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./mpesa.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/payments/mpesa/mpesa.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./mpesa.page.scss */
      "./src/app/payments/mpesa/mpesa.page.scss"))["default"]]
    })], MpesaPage);
    /***/
  },

  /***/
  "./src/app/postedsalesinvoices/dailyreport/dailyreport-routing.module.ts":
  /*!*******************************************************************************!*\
    !*** ./src/app/postedsalesinvoices/dailyreport/dailyreport-routing.module.ts ***!
    \*******************************************************************************/

  /*! exports provided: DailyreportPageRoutingModule */

  /***/
  function srcAppPostedsalesinvoicesDailyreportDailyreportRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DailyreportPageRoutingModule", function () {
      return DailyreportPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _dailyreport_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./dailyreport.page */
    "./src/app/postedsalesinvoices/dailyreport/dailyreport.page.ts");

    var routes = [{
      path: '',
      component: _dailyreport_page__WEBPACK_IMPORTED_MODULE_3__["DailyreportPage"]
    }];

    var DailyreportPageRoutingModule = function DailyreportPageRoutingModule() {
      _classCallCheck(this, DailyreportPageRoutingModule);
    };

    DailyreportPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], DailyreportPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/postedsalesinvoices/dailyreport/dailyreport.module.ts":
  /*!***********************************************************************!*\
    !*** ./src/app/postedsalesinvoices/dailyreport/dailyreport.module.ts ***!
    \***********************************************************************/

  /*! exports provided: DailyreportPageModule */

  /***/
  function srcAppPostedsalesinvoicesDailyreportDailyreportModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DailyreportPageModule", function () {
      return DailyreportPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _dailyreport_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./dailyreport-routing.module */
    "./src/app/postedsalesinvoices/dailyreport/dailyreport-routing.module.ts");
    /* harmony import */


    var _dailyreport_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./dailyreport.page */
    "./src/app/postedsalesinvoices/dailyreport/dailyreport.page.ts");

    var DailyreportPageModule = function DailyreportPageModule() {
      _classCallCheck(this, DailyreportPageModule);
    };

    DailyreportPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _dailyreport_routing_module__WEBPACK_IMPORTED_MODULE_5__["DailyreportPageRoutingModule"]],
      declarations: [_dailyreport_page__WEBPACK_IMPORTED_MODULE_6__["DailyreportPage"]]
    })], DailyreportPageModule);
    /***/
  },

  /***/
  "./src/app/postedsalesinvoices/dailyreport/dailyreport.page.scss":
  /*!***********************************************************************!*\
    !*** ./src/app/postedsalesinvoices/dailyreport/dailyreport.page.scss ***!
    \***********************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPostedsalesinvoicesDailyreportDailyreportPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3Bvc3RlZHNhbGVzaW52b2ljZXMvZGFpbHlyZXBvcnQvZGFpbHlyZXBvcnQucGFnZS5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/postedsalesinvoices/dailyreport/dailyreport.page.ts":
  /*!*********************************************************************!*\
    !*** ./src/app/postedsalesinvoices/dailyreport/dailyreport.page.ts ***!
    \*********************************************************************/

  /*! exports provided: DailyreportPage */

  /***/
  function srcAppPostedsalesinvoicesDailyreportDailyreportPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "DailyreportPage", function () {
      return DailyreportPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _sales_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ../sales.service */
    "./src/app/postedsalesinvoices/sales.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/auth/auth-service */
    "./src/app/auth/auth-service.ts");

    var DailyreportPage = /*#__PURE__*/function () {
      function DailyreportPage(salesService, popOver, authService) {
        _classCallCheck(this, DailyreportPage);

        this.salesService = salesService;
        this.popOver = popOver;
        this.authService = authService;
        this.Total = 0;
        this.success = false;
      }

      _createClass(DailyreportPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.popOver.dismiss();
        }
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.setUser();
        }
      }, {
        key: "ionViewDidEnter",
        value: function ionViewDidEnter() {
          this.setUser();
        }
      }, {
        key: "setUser",
        value: function setUser() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee8() {
            return regeneratorRuntime.wrap(function _callee8$(_context8) {
              while (1) {
                switch (_context8.prev = _context8.next) {
                  case 0:
                    _context8.next = 2;
                    return this.authService.getUser();

                  case 2:
                    this.user = _context8.sent;

                  case 3:
                  case "end":
                    return _context8.stop();
                }
              }
            }, _callee8, this);
          }));
        }
      }, {
        key: "FilterSalebyDate",
        value: function FilterSalebyDate($event) {
          var _this14 = this;

          var _a;

          var startDate = this.salesService.formatDate($event.target.value);

          if (Date.parse(startDate)) {
            this.salesSub = this.salesService.FilterSales(startDate, (_a = this.user) === null || _a === void 0 ? void 0 : _a.User_ID).subscribe(function (res) {
              if (typeof res === 'string') {
                // alert(res);
                _this14.salesService.showToast(res);

                _this14.sales = [];
                _this14.Total = 0;
                _this14.success = false;
                return;
              }

              _this14.sales = res;
              _this14.Total = _this14.getTotals(_this14.sales);
              _this14.success = typeof res === 'object' ? true : false;
            });
          } else {
            this.sales = [];
            this.success = false; // return 'No Date Supplied';
          }
        }
      }, {
        key: "getTotals",
        value: function getTotals(elements) {
          var sum = 0;
          elements.forEach(function (obj) {
            // console.log(obj);
            for (var property in obj) {
              if (property === 'Amount' && !isNaN(+obj[property])) {
                console.log(+obj[property]);
                sum += +obj[property];
              }
            }
          });
          return sum;
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          if (this.salesSub) {
            this.salesSub.unsubscribe();
          }
        }
      }]);

      return DailyreportPage;
    }();

    DailyreportPage.ctorParameters = function () {
      return [{
        type: _sales_service__WEBPACK_IMPORTED_MODULE_2__["SalesService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["PopoverController"]
      }, {
        type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"]
      }];
    };

    DailyreportPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-dailyreport',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./dailyreport.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/postedsalesinvoices/dailyreport/dailyreport.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./dailyreport.page.scss */
      "./src/app/postedsalesinvoices/dailyreport/dailyreport.page.scss"))["default"]]
    })], DailyreportPage);
    /***/
  },

  /***/
  "./src/app/postedsalesinvoices/monthlyreport/monthlyreport-routing.module.ts":
  /*!***********************************************************************************!*\
    !*** ./src/app/postedsalesinvoices/monthlyreport/monthlyreport-routing.module.ts ***!
    \***********************************************************************************/

  /*! exports provided: MonthlyreportPageRoutingModule */

  /***/
  function srcAppPostedsalesinvoicesMonthlyreportMonthlyreportRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MonthlyreportPageRoutingModule", function () {
      return MonthlyreportPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _monthlyreport_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./monthlyreport.page */
    "./src/app/postedsalesinvoices/monthlyreport/monthlyreport.page.ts");

    var routes = [{
      path: '',
      component: _monthlyreport_page__WEBPACK_IMPORTED_MODULE_3__["MonthlyreportPage"]
    }];

    var MonthlyreportPageRoutingModule = function MonthlyreportPageRoutingModule() {
      _classCallCheck(this, MonthlyreportPageRoutingModule);
    };

    MonthlyreportPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], MonthlyreportPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/postedsalesinvoices/monthlyreport/monthlyreport.module.ts":
  /*!***************************************************************************!*\
    !*** ./src/app/postedsalesinvoices/monthlyreport/monthlyreport.module.ts ***!
    \***************************************************************************/

  /*! exports provided: MonthlyreportPageModule */

  /***/
  function srcAppPostedsalesinvoicesMonthlyreportMonthlyreportModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MonthlyreportPageModule", function () {
      return MonthlyreportPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _monthlyreport_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./monthlyreport-routing.module */
    "./src/app/postedsalesinvoices/monthlyreport/monthlyreport-routing.module.ts");
    /* harmony import */


    var _monthlyreport_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./monthlyreport.page */
    "./src/app/postedsalesinvoices/monthlyreport/monthlyreport.page.ts");

    var MonthlyreportPageModule = function MonthlyreportPageModule() {
      _classCallCheck(this, MonthlyreportPageModule);
    };

    MonthlyreportPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _monthlyreport_routing_module__WEBPACK_IMPORTED_MODULE_5__["MonthlyreportPageRoutingModule"]],
      declarations: [_monthlyreport_page__WEBPACK_IMPORTED_MODULE_6__["MonthlyreportPage"]]
    })], MonthlyreportPageModule);
    /***/
  },

  /***/
  "./src/app/postedsalesinvoices/monthlyreport/monthlyreport.page.scss":
  /*!***************************************************************************!*\
    !*** ./src/app/postedsalesinvoices/monthlyreport/monthlyreport.page.scss ***!
    \***************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPostedsalesinvoicesMonthlyreportMonthlyreportPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3Bvc3RlZHNhbGVzaW52b2ljZXMvbW9udGhseXJlcG9ydC9tb250aGx5cmVwb3J0LnBhZ2Uuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/postedsalesinvoices/monthlyreport/monthlyreport.page.ts":
  /*!*************************************************************************!*\
    !*** ./src/app/postedsalesinvoices/monthlyreport/monthlyreport.page.ts ***!
    \*************************************************************************/

  /*! exports provided: MonthlyreportPage */

  /***/
  function srcAppPostedsalesinvoicesMonthlyreportMonthlyreportPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "MonthlyreportPage", function () {
      return MonthlyreportPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _sales_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ../sales.service */
    "./src/app/postedsalesinvoices/sales.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/auth/auth-service */
    "./src/app/auth/auth-service.ts");

    var MonthlyreportPage = /*#__PURE__*/function () {
      function MonthlyreportPage(salesService, popOver, authService) {
        _classCallCheck(this, MonthlyreportPage);

        this.salesService = salesService;
        this.popOver = popOver;
        this.authService = authService;
        this.FilterRange = {
          startDate: new Date(),
          endDate: new Date()
        };
        this.Total = 0;
        this.success = false;
      }

      _createClass(MonthlyreportPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.popOver.dismiss();
        }
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.setUser();
        }
      }, {
        key: "ionViewDidEnter",
        value: function ionViewDidEnter() {
          this.setUser();
        }
      }, {
        key: "setUser",
        value: function setUser() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee9() {
            return regeneratorRuntime.wrap(function _callee9$(_context9) {
              while (1) {
                switch (_context9.prev = _context9.next) {
                  case 0:
                    _context9.next = 2;
                    return this.authService.getUser();

                  case 2:
                    this.user = _context9.sent;

                  case 3:
                  case "end":
                    return _context9.stop();
                }
              }
            }, _callee9, this);
          }));
        }
      }, {
        key: "FilterSalebyRange",
        value: function FilterSalebyRange() {
          var _this15 = this;

          var _a;

          var startDate = this.salesService.formatDate(this.FilterRange.startDate);
          var endDate = this.salesService.formatDate(this.FilterRange.endDate);

          if (Date.parse(startDate) && Date.parse(endDate)) {
            this.SalesSub = this.salesService.FilterSalesbyRange(startDate, endDate, (_a = this.user) === null || _a === void 0 ? void 0 : _a.User_ID).subscribe(function (res) {
              if (typeof res === 'string') {
                _this15.salesService.showToast(res);

                _this15.sales = [];
                _this15.Total = 0;
                _this15.success = false;
                return;
              }

              _this15.sales = res;
              _this15.Total = _this15.getTotals(_this15.sales);
              _this15.success = typeof res === 'object' ? true : false;
            });
          } else {
            return 'No Date Supplied';
          }
        }
      }, {
        key: "getTotals",
        value: function getTotals(elements) {
          var sum = 0;
          elements.forEach(function (obj) {
            console.log(obj);

            for (var property in obj) {
              if (property === 'Amount' && !isNaN(+obj[property])) {
                console.log(+obj[property]);
                sum += +obj[property];
              }
            }
          });
          return sum;
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          if (this.SalesSub) {
            this.SalesSub.unsubscribe();
          }
        }
      }]);

      return MonthlyreportPage;
    }();

    MonthlyreportPage.ctorParameters = function () {
      return [{
        type: _sales_service__WEBPACK_IMPORTED_MODULE_2__["SalesService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["PopoverController"]
      }, {
        type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_4__["AuthService"]
      }];
    };

    MonthlyreportPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-monthlyreport',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./monthlyreport.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/postedsalesinvoices/monthlyreport/monthlyreport.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./monthlyreport.page.scss */
      "./src/app/postedsalesinvoices/monthlyreport/monthlyreport.page.scss"))["default"]]
    })], MonthlyreportPage);
    /***/
  },

  /***/
  "./src/app/return/return-list/return-list-routing.module.ts":
  /*!******************************************************************!*\
    !*** ./src/app/return/return-list/return-list-routing.module.ts ***!
    \******************************************************************/

  /*! exports provided: ReturnListPageRoutingModule */

  /***/
  function srcAppReturnReturnListReturnListRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ReturnListPageRoutingModule", function () {
      return ReturnListPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _return_list_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./return-list.page */
    "./src/app/return/return-list/return-list.page.ts");

    var routes = [{
      path: '',
      component: _return_list_page__WEBPACK_IMPORTED_MODULE_3__["ReturnListPage"]
    }];

    var ReturnListPageRoutingModule = function ReturnListPageRoutingModule() {
      _classCallCheck(this, ReturnListPageRoutingModule);
    };

    ReturnListPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], ReturnListPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/return/return-list/return-list.module.ts":
  /*!**********************************************************!*\
    !*** ./src/app/return/return-list/return-list.module.ts ***!
    \**********************************************************/

  /*! exports provided: ReturnListPageModule */

  /***/
  function srcAppReturnReturnListReturnListModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ReturnListPageModule", function () {
      return ReturnListPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _return_list_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./return-list-routing.module */
    "./src/app/return/return-list/return-list-routing.module.ts");
    /* harmony import */


    var _return_list_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./return-list.page */
    "./src/app/return/return-list/return-list.page.ts");

    var ReturnListPageModule = function ReturnListPageModule() {
      _classCallCheck(this, ReturnListPageModule);
    };

    ReturnListPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _return_list_routing_module__WEBPACK_IMPORTED_MODULE_5__["ReturnListPageRoutingModule"]],
      declarations: [_return_list_page__WEBPACK_IMPORTED_MODULE_6__["ReturnListPage"]]
    })], ReturnListPageModule);
    /***/
  },

  /***/
  "./src/app/return/return-list/return-list.page.scss":
  /*!**********************************************************!*\
    !*** ./src/app/return/return-list/return-list.page.scss ***!
    \**********************************************************/

  /*! exports provided: default */

  /***/
  function srcAppReturnReturnListReturnListPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3JldHVybi9yZXR1cm4tbGlzdC9yZXR1cm4tbGlzdC5wYWdlLnNjc3MifQ== */";
    /***/
  },

  /***/
  "./src/app/return/return-list/return-list.page.ts":
  /*!********************************************************!*\
    !*** ./src/app/return/return-list/return-list.page.ts ***!
    \********************************************************/

  /*! exports provided: ReturnListPage */

  /***/
  function srcAppReturnReturnListReturnListPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ReturnListPage", function () {
      return ReturnListPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/auth/auth-service */
    "./src/app/auth/auth-service.ts");
    /* harmony import */


    var src_app_utility_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! src/app/utility.service */
    "./src/app/utility.service.ts");
    /* harmony import */


    var _return_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../return.service */
    "./src/app/return/return.service.ts");

    var ReturnListPage = /*#__PURE__*/function () {
      function ReturnListPage(utilitySvc, returnSvc, authSvc) {
        _classCallCheck(this, ReturnListPage);

        this.utilitySvc = utilitySvc;
        this.returnSvc = returnSvc;
        this.authSvc = authSvc;
        this.isLoading = false;
      }

      _createClass(ReturnListPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.setUser();
        }
      }, {
        key: "ionViewWillEnter",
        value: function ionViewWillEnter() {
          this.setUser();
        }
      }, {
        key: "ionViewDidEnter",
        value: function ionViewDidEnter() {
          this.setUser();
          this.FetchReturns();
        }
      }, {
        key: "setUser",
        value: function setUser() {
          var _a;

          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee10() {
            return regeneratorRuntime.wrap(function _callee10$(_context10) {
              while (1) {
                switch (_context10.prev = _context10.next) {
                  case 0:
                    _context10.next = 2;
                    return this.authSvc.getUser();

                  case 2:
                    this.user = _context10.sent;
                    this.userID = (_a = this.user) === null || _a === void 0 ? void 0 : _a.User_ID;
                    console.table(this.userID);

                  case 5:
                  case "end":
                    return _context10.stop();
                }
              }
            }, _callee10, this);
          }));
        }
      }, {
        key: "FetchReturns",
        value: function FetchReturns() {
          var _this16 = this;

          this.returnSub = this.returnSvc.getReturnTransactions(this.userID).subscribe(function (result) {
            if (typeof result === 'string') {
              _this16.isLoading = false;

              _this16.utilitySvc.showAlert(result);

              return;
            }

            _this16.list = _this16.sort(_toConsumableArray(result));
            _this16.isLoading = false;
          }, function (error) {
            _this16.isLoading = false;

            _this16.utilitySvc.showAlert('Error: ' + error.erro.message);
          });
        }
      }, {
        key: "sort",
        value: function sort(dataArray) {
          return dataArray.sort(function (a, b) {
            return b.No > a.No ? 1 : -1;
          });
        }
      }, {
        key: "search",
        value: function search($event) {
          var _this17 = this;

          // get a copy of requisitions
          var searchItems = _toConsumableArray(this.list); // Begin search, only if searchTerm is provided


          if (this.searchTerm.trim().length && this.searchTerm !== '') {
            this.list = searchItems.filter(function (req) {
              if (req.Customer_Name && req.Customer_Name.length > 1) {
                return req.Customer_Name.toLowerCase().indexOf(_this17.searchTerm.toLowerCase()) > -1;
              }
            });
            return;
          } else {
            // Search Term not provided display all requisitions
            this.initializeItems();
          }
        }
      }, {
        key: "initializeItems",
        value: function initializeItems() {
          this.FetchReturns();
        }
      }]);

      return ReturnListPage;
    }();

    ReturnListPage.ctorParameters = function () {
      return [{
        type: src_app_utility_service__WEBPACK_IMPORTED_MODULE_3__["UtilityService"]
      }, {
        type: _return_service__WEBPACK_IMPORTED_MODULE_4__["ReturnService"]
      }, {
        type: src_app_auth_auth_service__WEBPACK_IMPORTED_MODULE_2__["AuthService"]
      }];
    };

    ReturnListPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-return-list',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./return-list.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/return/return-list/return-list.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./return-list.page.scss */
      "./src/app/return/return-list/return-list.page.scss"))["default"]]
    })], ReturnListPage);
    /***/
  }
}]);
//# sourceMappingURL=common-es5.js.map