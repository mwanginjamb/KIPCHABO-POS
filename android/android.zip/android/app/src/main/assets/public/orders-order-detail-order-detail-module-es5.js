function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["orders-order-detail-order-detail-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/orders/order-detail/order-detail.page.html":
  /*!**************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/orders/order-detail/order-detail.page.html ***!
    \**************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppOrdersOrderDetailOrderDetailPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button defaultHref=\"/orders\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>Sales Invoice - {{card?.No}} Details </ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n  <ion-fab vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\">\r\n    <ion-fab-button color=\"success\" (click)=\"post(card.No)\">\r\n      <ion-icon name=\"send\"></ion-icon>\r\n    </ion-fab-button>\r\n  </ion-fab>\r\n  <ion-grid>\r\n    <ion-row>\r\n      <ion-col >\r\n         <ion-card>\r\n           <ion-card-header>\r\n             <ion-card-title>\r\n               General Card Details\r\n             </ion-card-title>\r\n           </ion-card-header>\r\n\r\n           <ion-card-content>\r\n\r\n             <ion-row>\r\n               <ion-col >\r\n                 <ion-item>\r\n                   <ion-label position=\"floating\">Customer</ion-label>\r\n                   <ion-input [(ngModel)]=\"card.Sell_to_Customer_Name\" readonly></ion-input>\r\n                 </ion-item>\r\n               </ion-col>\r\n\r\n               <ion-col >\r\n                 <ion-item>\r\n                   <ion-label position=\"floating\">Due Date</ion-label>\r\n                   <ion-input [(ngModel)]=\"card.Due_Date\" readonly></ion-input>\r\n                 </ion-item>\r\n               </ion-col>\r\n             </ion-row>\r\n\r\n             \r\n\r\n\r\n             <ion-row>\r\n               <ion-col >\r\n                 <ion-item>\r\n                   <ion-label position=\"floating\">Posting Date: </ion-label>\r\n                   <ion-input [(ngModel)]=\"card.Posting_Date\" readonly></ion-input>\r\n                 </ion-item>\r\n               </ion-col>\r\n\r\n               <ion-col >\r\n                 <ion-item>\r\n                   <ion-label position=\"floating\">Status:</ion-label>\r\n                   <ion-input [(ngModel)]=\"card.Status\" readonly></ion-input>\r\n                 </ion-item>\r\n               </ion-col>\r\n             </ion-row>\r\n\r\n            \r\n\r\n           </ion-card-content>\r\n\r\n         </ion-card>\r\n\r\n\r\n          <!--Start Lines Card-->\r\n          <ion-card>\r\n            <ion-card-header>\r\n              <ion-card-title>Lines</ion-card-title>\r\n            </ion-card-header>\r\n            <ion-card-content>\r\n              <ion-grid>\r\n                <ion-row *ngIf=\"card?.Status === 'Open' \">\r\n                  <ion-col>\r\n                    <ion-list>\r\n                      <ion-item>\r\n                        <ion-button type=\"button\" outline color=\"primary\" (click)=\"onAddLine()\" >New</ion-button>\r\n                      </ion-item>\r\n                    </ion-list>\r\n                    \r\n                  </ion-col>\r\n                </ion-row>\r\n\r\n                <ion-row scrollX=\"true\">\r\n                  <ion-col>\r\n                    <ion-label>Description</ion-label>\r\n                  </ion-col>\r\n\r\n                  <ion-col>\r\n                    <ion-label>Location Code</ion-label>\r\n                  </ion-col>\r\n\r\n                  <ion-col>\r\n                    <ion-label>Quantity</ion-label>\r\n                  </ion-col>\r\n\r\n                  <ion-col>\r\n                    <ion-label>Unit </ion-label>\r\n                  </ion-col>\r\n\r\n                  <ion-col>\r\n                    <ion-label>Line Amount (Exl. VAT)</ion-label>\r\n                  </ion-col>\r\n\r\n                </ion-row>\r\n              \r\n                 \r\n               \r\n                <ion-list *ngFor=\"let item of card?.SalesLines?.Sales_Invoice_Line\">\r\n                    <ion-row >\r\n                      <ion-col> \r\n                        <ion-item (click)=\"onUpdateLine(item?.Line_No)\" color=\"primary\">                         \r\n                            <ion-label>{{item.Description}}</ion-label>\r\n                        </ion-item>\r\n                      </ion-col>\r\n  \r\n                      <ion-col> \r\n                        <ion-item>                         \r\n                            <ion-label>{{item.Location_Code}}</ion-label>\r\n                        </ion-item>\r\n                      </ion-col>\r\n  \r\n                      <ion-col> \r\n                        <ion-item>                         \r\n                            <ion-label>{{item.Quantity}}</ion-label>\r\n                        </ion-item>\r\n                      </ion-col>\r\n  \r\n                      <ion-col> \r\n                        <ion-item>                         \r\n                            <ion-label>{{item.Unit_of_Measure}}</ion-label>\r\n                        </ion-item>\r\n                      </ion-col>\r\n  \r\n                      <ion-col> \r\n                        <ion-item>                         \r\n                            <ion-label>{{item.Line_Amount}}</ion-label>\r\n                        </ion-item>\r\n                      </ion-col>\r\n  \r\n                     \r\n  \r\n                    </ion-row>   \r\n                </ion-list>\r\n                 \r\n                \r\n              </ion-grid>\r\n            </ion-card-content>\r\n          </ion-card>\r\n          <!--End Lines Card-->\r\n\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./src/app/models/invoice.model.ts":
  /*!*****************************************!*\
    !*** ./src/app/models/invoice.model.ts ***!
    \*****************************************/

  /*! exports provided: Invoice */

  /***/
  function srcAppModelsInvoiceModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Invoice", function () {
      return Invoice;
    });

    var Invoice = function Invoice(Key, No, Sell_to_Customer_Name, Sell_to_Address, Sell_to_Address_2, Sell_to_Post_Code, Sell_to_City, Sell_to_Contact_No, Sell_to_Contact, Your_Reference, Document_Date, Posting_Date, Due_Date, Incoming_Document_Entry_No, External_Document_No, Salesperson_Code, Campaign_No, Responsibility_Center, Assigned_User_ID, Status, Job_Queue_Status, WorkDescription, Currency_Code, Shipment_Date, Quote_No, Prices_Including_VAT, VAT_Bus_Posting_Group, Payment_Terms_Code, Payment_Method_Code, SelectedPayments, Transaction_Type, Shortcut_Dimension_1_Code, Shortcut_Dimension_2_Code, Payment_Discount_Percent, Pmt_Discount_Date, Direct_Debit_Mandate_ID, Location_Code, ShippingOptions, Ship_to_Code, Ship_to_Name, Ship_to_Address, Ship_to_Address_2, Ship_to_Post_Code, Ship_to_City, Ship_to_Country_Region_Code, Ship_to_Contact, Shipment_Method_Code, Shipping_Agent_Code, Shipping_Agent_Service_Code, Package_Tracking_No, BillToOptions, Bill_to_Name, Bill_to_Address, Bill_to_Address_2, Bill_to_Post_Code, Bill_to_City, Bill_to_Contact_No, Bill_to_Contact, EU_3_Party_Trade, Transaction_Specification, Transport_Method, Exit_Point, Area, SalesLines) {
      _classCallCheck(this, Invoice);

      this.Key = Key;
      this.No = No;
      this.Sell_to_Customer_Name = Sell_to_Customer_Name;
      this.Sell_to_Address = Sell_to_Address;
      this.Sell_to_Address_2 = Sell_to_Address_2;
      this.Sell_to_Post_Code = Sell_to_Post_Code;
      this.Sell_to_City = Sell_to_City;
      this.Sell_to_Contact_No = Sell_to_Contact_No;
      this.Sell_to_Contact = Sell_to_Contact;
      this.Your_Reference = Your_Reference;
      this.Document_Date = Document_Date;
      this.Posting_Date = Posting_Date;
      this.Due_Date = Due_Date;
      this.Incoming_Document_Entry_No = Incoming_Document_Entry_No;
      this.External_Document_No = External_Document_No;
      this.Salesperson_Code = Salesperson_Code;
      this.Campaign_No = Campaign_No;
      this.Responsibility_Center = Responsibility_Center;
      this.Assigned_User_ID = Assigned_User_ID;
      this.Status = Status;
      this.Job_Queue_Status = Job_Queue_Status;
      this.WorkDescription = WorkDescription;
      this.Currency_Code = Currency_Code;
      this.Shipment_Date = Shipment_Date;
      this.Quote_No = Quote_No;
      this.Prices_Including_VAT = Prices_Including_VAT;
      this.VAT_Bus_Posting_Group = VAT_Bus_Posting_Group;
      this.Payment_Terms_Code = Payment_Terms_Code;
      this.Payment_Method_Code = Payment_Method_Code;
      this.SelectedPayments = SelectedPayments;
      this.Transaction_Type = Transaction_Type;
      this.Shortcut_Dimension_1_Code = Shortcut_Dimension_1_Code;
      this.Shortcut_Dimension_2_Code = Shortcut_Dimension_2_Code;
      this.Payment_Discount_Percent = Payment_Discount_Percent;
      this.Pmt_Discount_Date = Pmt_Discount_Date;
      this.Direct_Debit_Mandate_ID = Direct_Debit_Mandate_ID;
      this.Location_Code = Location_Code;
      this.ShippingOptions = ShippingOptions;
      this.Ship_to_Code = Ship_to_Code;
      this.Ship_to_Name = Ship_to_Name;
      this.Ship_to_Address = Ship_to_Address;
      this.Ship_to_Address_2 = Ship_to_Address_2;
      this.Ship_to_Post_Code = Ship_to_Post_Code;
      this.Ship_to_City = Ship_to_City;
      this.Ship_to_Country_Region_Code = Ship_to_Country_Region_Code;
      this.Ship_to_Contact = Ship_to_Contact;
      this.Shipment_Method_Code = Shipment_Method_Code;
      this.Shipping_Agent_Code = Shipping_Agent_Code;
      this.Shipping_Agent_Service_Code = Shipping_Agent_Service_Code;
      this.Package_Tracking_No = Package_Tracking_No;
      this.BillToOptions = BillToOptions;
      this.Bill_to_Name = Bill_to_Name;
      this.Bill_to_Address = Bill_to_Address;
      this.Bill_to_Address_2 = Bill_to_Address_2;
      this.Bill_to_Post_Code = Bill_to_Post_Code;
      this.Bill_to_City = Bill_to_City;
      this.Bill_to_Contact_No = Bill_to_Contact_No;
      this.Bill_to_Contact = Bill_to_Contact;
      this.EU_3_Party_Trade = EU_3_Party_Trade;
      this.Transaction_Specification = Transaction_Specification;
      this.Transport_Method = Transport_Method;
      this.Exit_Point = Exit_Point;
      this.Area = Area;
      this.SalesLines = SalesLines;
    };
    /***/

  },

  /***/
  "./src/app/orders/order-detail/order-detail-routing.module.ts":
  /*!********************************************************************!*\
    !*** ./src/app/orders/order-detail/order-detail-routing.module.ts ***!
    \********************************************************************/

  /*! exports provided: OrderDetailPageRoutingModule */

  /***/
  function srcAppOrdersOrderDetailOrderDetailRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "OrderDetailPageRoutingModule", function () {
      return OrderDetailPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _order_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./order-detail.page */
    "./src/app/orders/order-detail/order-detail.page.ts");

    var routes = [{
      path: '',
      component: _order_detail_page__WEBPACK_IMPORTED_MODULE_3__["OrderDetailPage"]
    }];

    var OrderDetailPageRoutingModule = function OrderDetailPageRoutingModule() {
      _classCallCheck(this, OrderDetailPageRoutingModule);
    };

    OrderDetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], OrderDetailPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/orders/order-detail/order-detail.module.ts":
  /*!************************************************************!*\
    !*** ./src/app/orders/order-detail/order-detail.module.ts ***!
    \************************************************************/

  /*! exports provided: OrderDetailPageModule */

  /***/
  function srcAppOrdersOrderDetailOrderDetailModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "OrderDetailPageModule", function () {
      return OrderDetailPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _order_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./order-detail-routing.module */
    "./src/app/orders/order-detail/order-detail-routing.module.ts");
    /* harmony import */


    var _order_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./order-detail.page */
    "./src/app/orders/order-detail/order-detail.page.ts");
    /* harmony import */


    var src_app_requisitions_lines_lines_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! src/app/requisitions/lines/lines.component */
    "./src/app/requisitions/lines/lines.component.ts");

    var OrderDetailPageModule = function OrderDetailPageModule() {
      _classCallCheck(this, OrderDetailPageModule);
    };

    OrderDetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _order_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__["OrderDetailPageRoutingModule"]],
      entryComponents: [src_app_requisitions_lines_lines_component__WEBPACK_IMPORTED_MODULE_7__["LinesComponent"]],
      declarations: [_order_detail_page__WEBPACK_IMPORTED_MODULE_6__["OrderDetailPage"], src_app_requisitions_lines_lines_component__WEBPACK_IMPORTED_MODULE_7__["LinesComponent"]]
    })], OrderDetailPageModule);
    /***/
  },

  /***/
  "./src/app/orders/order-detail/order-detail.page.scss":
  /*!************************************************************!*\
    !*** ./src/app/orders/order-detail/order-detail.page.scss ***!
    \************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppOrdersOrderDetailOrderDetailPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL29yZGVycy9vcmRlci1kZXRhaWwvb3JkZXItZGV0YWlsLnBhZ2Uuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/orders/order-detail/order-detail.page.ts":
  /*!**********************************************************!*\
    !*** ./src/app/orders/order-detail/order-detail.page.ts ***!
    \**********************************************************/

  /*! exports provided: OrderDetailPage */

  /***/
  function srcAppOrdersOrderDetailOrderDetailPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "OrderDetailPage", function () {
      return OrderDetailPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _order_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../order.service */
    "./src/app/orders/order.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _lines_lines_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../lines/lines.component */
    "./src/app/orders/lines/lines.component.ts");
    /* harmony import */


    var src_app_models_invoice_model__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! src/app/models/invoice.model */
    "./src/app/models/invoice.model.ts");
    /* harmony import */


    var src_app_payments_payments_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! src/app/payments/payments.service */
    "./src/app/payments/payments.service.ts");

    var OrderDetailPage = /*#__PURE__*/function () {
      function OrderDetailPage(activatedRoute, orderService, modalCtrl, paymentservice, alertCtrl) {
        _classCallCheck(this, OrderDetailPage);

        this.activatedRoute = activatedRoute;
        this.orderService = orderService;
        this.modalCtrl = modalCtrl;
        this.paymentservice = paymentservice;
        this.alertCtrl = alertCtrl;
        this.No = null;
        this.card = new src_app_models_invoice_model__WEBPACK_IMPORTED_MODULE_6__["Invoice"]();
      }

      _createClass(OrderDetailPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this = this;

          this.No = this.activatedRoute.snapshot.paramMap.get('No');
          this.cardSub = this.orderService.ordercard(this.No).subscribe(function (result) {
            _this.card = result;
            console.log(result);
          });
        }
      }, {
        key: "onAddLine",
        value: function onAddLine() {
          this.modalCtrl.create({
            component: _lines_lines_component__WEBPACK_IMPORTED_MODULE_5__["LinesComponent"],
            componentProps: {
              docID: this.No
            }
          }).then(function (modalEl) {
            modalEl.present();
          });
        }
      }, {
        key: "post",
        value: function post(No) {
          var _this2 = this;

          console.log(No);
          this.orderService.postSalesInvoice(No).subscribe(function (res) {
            if (typeof res === 'string') {
              // a string response represents a Nav Error, so we display it.
              _this2.alertCtrl.create({
                header: 'Service Warning!',
                message: res,
                buttons: [{
                  text: 'Okay'
                }]
              }).then(function (alertEl) {
                alertEl.present();
              });
            } else {
              // An object - Normal success response from nav
              _this2.paymentservice.showToast("Sales Invoice Posted Successfully.");
            }
          }, function (error) {
            alert(error);
          });
        }
      }, {
        key: "onUpdateLine",
        value: function onUpdateLine(LineNo) {
          this.modalCtrl.create({
            component: _lines_lines_component__WEBPACK_IMPORTED_MODULE_5__["LinesComponent"],
            componentProps: {
              docID: this.No,
              LineNo: LineNo
            }
          }).then(function (modalEl) {
            modalEl.present();
          });
        }
      }]);

      return OrderDetailPage;
    }();

    OrderDetailPage.ctorParameters = function () {
      return [{
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"]
      }, {
        type: _order_service__WEBPACK_IMPORTED_MODULE_3__["OrderService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"]
      }, {
        type: src_app_payments_payments_service__WEBPACK_IMPORTED_MODULE_7__["PaymentsService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["AlertController"]
      }];
    };

    OrderDetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-order-detail',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./order-detail.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/orders/order-detail/order-detail.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./order-detail.page.scss */
      "./src/app/orders/order-detail/order-detail.page.scss"))["default"]]
    })], OrderDetailPage);
    /***/
  },

  /***/
  "./src/app/payments/payments.service.ts":
  /*!**********************************************!*\
    !*** ./src/app/payments/payments.service.ts ***!
    \**********************************************/

  /*! exports provided: PaymentsService */

  /***/
  function srcAppPaymentsPaymentsServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "PaymentsService", function () {
      return PaymentsService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var _orders_order_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../orders/order.service */
    "./src/app/orders/order.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var rxjs__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! rxjs */
    "./node_modules/rxjs/_esm2015/index.js");

    var PaymentsService = /*#__PURE__*/function () {
      function PaymentsService(http, orderService, toastCtrl) {
        _classCallCheck(this, PaymentsService);

        this.http = http;
        this.orderService = orderService;
        this.toastCtrl = toastCtrl;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_2__["environment"].url;
        this._refresh$ = new rxjs__WEBPACK_IMPORTED_MODULE_7__["Subject"]();
      } // Define a synthetic getter for the subject


      _createClass(PaymentsService, [{
        key: "refresh$",
        get: function get() {
          return this._refresh$;
        }
      }, {
        key: "newPayment",
        value: function newPayment(receipt) {
          return this.http.post("".concat(this.url, "site/cash-sale"), JSON.stringify(receipt));
        }
      }, {
        key: "updateReceipt",
        value: function updateReceipt(receipt) {
          return this.http.post("".concat(this.url, "site/cash-sale"), JSON.stringify(receipt));
        }
      }, {
        key: "getPayments",
        value: function getPayments(userID) {
          return this.http.get("".concat(this.url, "site/get?service=POSReceiptList&userid=").concat(userID)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "getPayment",
        value: function getPayment(id) {
          return this.http.get("".concat(this.url, "site/receipt/?id=").concat(id)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "Banks",
        get: function get() {
          return this.http.get("".concat(this.url, "site/get?service=BankAccounts")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "getLine",
        value: function getLine(Key) {
          return this.http.get("".concat(this.url, "site/cash-sale-line?Key=").concat(Key));
        }
      }, {
        key: "suggestlines",
        value: function suggestlines(receiptNo, customerNo) {
          return this.http.get("".concat(this.url, "site/suggestlines?receiptNo=").concat(receiptNo, "&customerNo=").concat(customerNo)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        } // Post Lines Data

      }, {
        key: "postLine",
        value: function postLine(line) {
          var _this3 = this;

          return this.http.post("".concat(this.url, "site/cash-sale-line"), JSON.stringify(line)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function () {
            _this3._refresh$.next();
          }));
        } // Update Line

      }, {
        key: "updateLine",
        value: function updateLine(line) {
          var _this4 = this;

          return this.http.post("".concat(this.url, "site/cash-sale-line"), JSON.stringify(line)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["tap"])(function () {
            _this4._refresh$.next();
          }));
        }
      }, {
        key: "Customers",
        get: function get() {
          return this.http.get("".concat(this.url, "site/receipting-customers")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
        /*
         * Get Customer By Search Name
         */

      }, {
        key: "Customer",
        value: function Customer(searchName) {
          return this.http.get("".concat(this.url, "site/receipting-customers?searchName=").concat(searchName)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
        /*
         * Get Customer By Sales Person Code
         */

      }, {
        key: "CustomerBySalesPerson",
        value: function CustomerBySalesPerson(salesPersonCode) {
          return this.http.get("".concat(this.url, "site/receipting-customers?Salesperson_Code=").concat(salesPersonCode)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        } // Get CustomerPriceGroups

      }, {
        key: "CustomerPriceGroups",
        value: function CustomerPriceGroups() {
          return this.http.get("".concat(this.url, "site/get?service=CustomerPriceGroups")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "Mpesa",
        value: function Mpesa() {
          return this.http.get("".concat(this.url, "site/get?service=MPESATransactions")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "selectLine",
        value: function selectLine(CustomerNo, Line, ReceiptNo) {
          var payload = {
            Customer_No: CustomerNo,
            Line_No: Line,
            Receipt_No: ReceiptNo
          };
          return this.http.post("".concat(this.url, "site/updatecashreceiptline"), JSON.stringify(payload));
        }
      }, {
        key: "setAmountToReceipt",
        value: function setAmountToReceipt(CustomerNo, Line, ReceiptNo, AmountToReceipt) {
          var payload = {
            Customer_No: CustomerNo,
            Line_No: Line,
            Receipt_No: ReceiptNo,
            Amount_To_Receipt: AmountToReceipt
          }; // console.log(payload); return;

          return this.http.post("".concat(this.url, "site/updateamounttoreceipt"), JSON.stringify(payload));
        }
      }, {
        key: "postReceipt",
        value: function postReceipt(No) {
          return this.http.get("".concat(this.url, "site/postreceipt?No=").concat(No));
        }
      }, {
        key: "getTotals",
        value: function getTotals(elements, subjectColumn) {
          var sum = 0;
          elements.forEach(function (obj) {
            // console.log(obj);
            for (var property in obj) {
              if (property === subjectColumn && !isNaN(+obj[property])) {
                // console.log(+obj[property]);
                sum += +obj[property];
              }
            }
          });
          return sum;
        }
      }, {
        key: "showToast",
        value: function showToast(text) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.toastCtrl.create({
                      message: text,
                      duration: 4000,
                      position: 'top'
                    }).then(function (toastEl) {
                      toastEl.present();
                    });

                  case 2:
                    return _context.abrupt("return", _context.sent);

                  case 3:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "formatDate",
        value: function formatDate(date) {
          return this.orderService.formatDate(date);
        }
      }, {
        key: "FilterReceipts",
        value: function FilterReceipts(startDate, userID) {
          return this.http.get("".concat(this.url, "site/filterpayments?startdate=").concat(startDate, "&userid=").concat(userID)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }, {
        key: "FilterReceiptsbyRange",
        value: function FilterReceiptsbyRange(startDate, endDate, userID) {
          return this.http.get("".concat(this.url, "site/filterpayments?startdate=").concat(startDate, "&enddate=").concat(endDate, "&userid=").concat(userID)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
        }
      }]);

      return PaymentsService;
    }();

    PaymentsService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_3__["HttpClient"]
      }, {
        type: _orders_order_service__WEBPACK_IMPORTED_MODULE_5__["OrderService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_6__["ToastController"]
      }];
    };

    PaymentsService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], PaymentsService);
    /***/
  }
}]);
//# sourceMappingURL=orders-order-detail-order-detail-module-es5.js.map