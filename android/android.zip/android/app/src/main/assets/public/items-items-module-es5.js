function _toConsumableArray(arr) { return _arrayWithoutHoles(arr) || _iterableToArray(arr) || _unsupportedIterableToArray(arr) || _nonIterableSpread(); }

function _nonIterableSpread() { throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method."); }

function _unsupportedIterableToArray(o, minLen) { if (!o) return; if (typeof o === "string") return _arrayLikeToArray(o, minLen); var n = Object.prototype.toString.call(o).slice(8, -1); if (n === "Object" && o.constructor) n = o.constructor.name; if (n === "Map" || n === "Set") return Array.from(o); if (n === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _arrayLikeToArray(o, minLen); }

function _iterableToArray(iter) { if (typeof Symbol !== "undefined" && Symbol.iterator in Object(iter)) return Array.from(iter); }

function _arrayWithoutHoles(arr) { if (Array.isArray(arr)) return _arrayLikeToArray(arr); }

function _arrayLikeToArray(arr, len) { if (len == null || len > arr.length) len = arr.length; for (var i = 0, arr2 = new Array(len); i < len; i++) { arr2[i] = arr[i]; } return arr2; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["items-items-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/items/items.page.html":
  /*!*****************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/items/items.page.html ***!
    \*****************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppItemsItemsPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n\r\n    <ion-buttons slot=\"start\">\r\n      <ion-menu-button menu=\"m1\"></ion-menu-button>\r\n    </ion-buttons>\r\n\r\n    <ion-title>Items</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <div *ngIf=\"isLoading\" class=\"ion-text-center\">\r\n    <ion-spinner  name=\"crescent\"></ion-spinner>\r\n  </div>\r\n\r\n  <ion-searchbar [(ngModel)]=\"searchTerm\" debounce=\"2000\" (ionChange)=\"searchItem($event)\"></ion-searchbar>\r\n\r\n  <ion-grid fixed>\r\n    <ion-row>\r\n      <ion-col >Description</ion-col>\r\n      <ion-col >Inventory</ion-col>\r\n      <ion-col > Replenishment Sys.</ion-col>\r\n      <ion-col >Costing Method</ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n  \r\n  \r\n  \r\n    <ion-virtual-scroll [items]=\"Items\" approxItemHeight=\"47.2px\">\r\n               \r\n              <ion-item \r\n                [routerLink] = \"['/','items',item.No]\"\r\n               detail\r\n               *virtualItem=\"let item\" > \r\n  \r\n               <ion-grid fixed>\r\n                  <ion-row>\r\n  \r\n                    <ion-col>\r\n                      <ion-label>\r\n                        <h3>{{ item.Description }}</h3>\r\n                      </ion-label>\r\n                    </ion-col>\r\n  \r\n                    <ion-col>\r\n                      <ion-label>\r\n                        <h3>{{ item.Inventory }}</h3>\r\n                      </ion-label>\r\n                    </ion-col>\r\n  \r\n                    <ion-col>\r\n                      <ion-label>\r\n                        <h3>{{ item.Replenishment_System }}</h3>\r\n                      </ion-label>\r\n                    </ion-col>\r\n  \r\n                    <ion-col>\r\n                      <ion-label>\r\n                        <h3>{{ item.Costing_Method}}</h3>\r\n                      </ion-label>\r\n                    </ion-col>\r\n  \r\n                  </ion-row>\r\n                </ion-grid>\r\n                      \r\n          </ion-item>\r\n        \r\n    </ion-virtual-scroll>\r\n  \r\n\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./src/app/items/item.service.ts":
  /*!***************************************!*\
    !*** ./src/app/items/item.service.ts ***!
    \***************************************/

  /*! exports provided: ItemService */

  /***/
  function srcAppItemsItemServiceTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ItemService", function () {
      return ItemService;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common_http__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common/http */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
    /* harmony import */


    var rxjs_operators__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! rxjs/operators */
    "./node_modules/rxjs/_esm2015/operators/index.js");
    /* harmony import */


    var src_environments_environment__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/environments/environment */
    "./src/environments/environment.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var ItemService = /*#__PURE__*/function () {
      function ItemService(http, toastCtrl) {
        _classCallCheck(this, ItemService);

        this.http = http;
        this.toastCtrl = toastCtrl;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_4__["environment"].url;
      }

      _createClass(ItemService, [{
        key: "items",
        get: function get() {
          return this.http.get("".concat(this.url, "site/items")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "itemcard",
        value: function itemcard(id) {
          return this.http.get("".concat(this.url, "site/itemcard/?id=").concat(id));
        }
      }, {
        key: "itemBalance",
        value: function itemBalance(No) {
          return this.http.get("".concat(this.url, "site/itemavailabilitybylocation/?No=").concat(No));
        }
      }, {
        key: "itemBalanceByLocation",
        value: function itemBalanceByLocation(No, LocationCode) {
          return this.http.get("".concat(this.url, "site/itemavailabilitybylocation/?No=").concat(No, "&Location=").concat(LocationCode)).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "getTotals",
        value: function getTotals(elements, subjectColumn) {
          var sum = 0;
          elements.forEach(function (obj) {
            // console.log(obj);
            for (var property in obj) {
              if (property === subjectColumn && !isNaN(+obj[property])) {
                // console.log(+obj[property]);
                sum += +obj[property];
              }
            }
          });
          return sum;
        } // Get Locations List

      }, {
        key: "getLocations",
        value: function getLocations() {
          return this.http.get("".concat(this.url, "site/locationlist")).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_3__["take"])(1));
        }
      }, {
        key: "showToast",
        value: function showToast(text) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.toastCtrl.create({
                      message: text,
                      duration: 4000,
                      position: 'top'
                    }).then(function (toastEl) {
                      toastEl.present();
                    });

                  case 2:
                    return _context.abrupt("return", _context.sent);

                  case 3:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }]);

      return ItemService;
    }();

    ItemService.ctorParameters = function () {
      return [{
        type: _angular_common_http__WEBPACK_IMPORTED_MODULE_2__["HttpClient"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"]
      }];
    };

    ItemService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Injectable"])({
      providedIn: 'root'
    })], ItemService);
    /***/
  },

  /***/
  "./src/app/items/items-routing.module.ts":
  /*!***********************************************!*\
    !*** ./src/app/items/items-routing.module.ts ***!
    \***********************************************/

  /*! exports provided: ItemsPageRoutingModule */

  /***/
  function srcAppItemsItemsRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ItemsPageRoutingModule", function () {
      return ItemsPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _items_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./items.page */
    "./src/app/items/items.page.ts");

    var routes = [{
      path: '',
      component: _items_page__WEBPACK_IMPORTED_MODULE_3__["ItemsPage"]
    }, {
      path: 'item-detail',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | item-detail-item-detail-module */
        "common").then(__webpack_require__.bind(null,
        /*! ./item-detail/item-detail.module */
        "./src/app/items/item-detail/item-detail.module.ts")).then(function (m) {
          return m.ItemDetailPageModule;
        });
      }
    }, {
      path: 'availability',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | availability-by-location-availability-by-location-module */
        "common").then(__webpack_require__.bind(null,
        /*! ./availability-by-location/availability-by-location.module */
        "./src/app/items/availability-by-location/availability-by-location.module.ts")).then(function (m) {
          return m.AvailabilityByLocationPageModule;
        });
      }
    }, {
      path: 'availability-card',
      loadChildren: function loadChildren() {
        return __webpack_require__.e(
        /*! import() | availability-card-availability-card-module */
        "common").then(__webpack_require__.bind(null,
        /*! ./availability-card/availability-card.module */
        "./src/app/items/availability-card/availability-card.module.ts")).then(function (m) {
          return m.AvailabilityCardPageModule;
        });
      }
    }];

    var ItemsPageRoutingModule = function ItemsPageRoutingModule() {
      _classCallCheck(this, ItemsPageRoutingModule);
    };

    ItemsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], ItemsPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/items/items.module.ts":
  /*!***************************************!*\
    !*** ./src/app/items/items.module.ts ***!
    \***************************************/

  /*! exports provided: ItemsPageModule */

  /***/
  function srcAppItemsItemsModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ItemsPageModule", function () {
      return ItemsPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _items_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./items-routing.module */
    "./src/app/items/items-routing.module.ts");
    /* harmony import */


    var _items_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./items.page */
    "./src/app/items/items.page.ts");

    var ItemsPageModule = function ItemsPageModule() {
      _classCallCheck(this, ItemsPageModule);
    };

    ItemsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _items_routing_module__WEBPACK_IMPORTED_MODULE_5__["ItemsPageRoutingModule"]],
      declarations: [_items_page__WEBPACK_IMPORTED_MODULE_6__["ItemsPage"]]
    })], ItemsPageModule);
    /***/
  },

  /***/
  "./src/app/items/items.page.scss":
  /*!***************************************!*\
    !*** ./src/app/items/items.page.scss ***!
    \***************************************/

  /*! exports provided: default */

  /***/
  function srcAppItemsItemsPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL2l0ZW1zL2l0ZW1zLnBhZ2Uuc2NzcyJ9 */";
    /***/
  },

  /***/
  "./src/app/items/items.page.ts":
  /*!*************************************!*\
    !*** ./src/app/items/items.page.ts ***!
    \*************************************/

  /*! exports provided: ItemsPage */

  /***/
  function srcAppItemsItemsPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "ItemsPage", function () {
      return ItemsPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _item_service__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! ./item.service */
    "./src/app/items/item.service.ts");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");

    var ItemsPage = /*#__PURE__*/function () {
      function ItemsPage(itemService, platform, alertCtrl) {
        _classCallCheck(this, ItemsPage);

        /* this.appSub = this.platform.backButton.subscribeWithPriority(666666, () => {
          if ( this.constructor.name === 'ItemsPage' ) {
              if (window.confirm(`Do you want to exit the app?`)) {
                navigator['app'].exitApp();
              }
          }
        });*/
        this.itemService = itemService;
        this.platform = platform;
        this.alertCtrl = alertCtrl;
        this.isLoading = true;
        this.searchTerm = null;
        this.searched = null;
        var routerEl = document.querySelector('ion-router');
        document.addEventListener('ionBackButton', function (ev) {
          ev.detail.register(-1, function () {
            var path = window.location.pathname;

            if (path === routerEl.root) {
              if (window.confirm("Do you want to exit the app?")) {
                navigator['app'].exitApp();
              }
            }
          });
        });
      }

      _createClass(ItemsPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this = this;

          this.isLoading = true;
          this.itemSub = this.itemService.items.subscribe(function (result) {
            console.log(result);
            _this.Items = _toConsumableArray(result);
            _this.isLoading = false;
          }, function (error) {
            _this.isLoading = false;
            console.log(error.error);

            _this.alertCtrl.create({
              header: 'Service Error!',
              message: 'Connection problem: ' + error.error.message,
              buttons: [{
                text: 'Okay'
              }]
            }).then(function (alertEl) {
              alertEl.present();
            });
          });
        }
      }, {
        key: "searchItem",
        value: function searchItem($event) {
          var _this2 = this;

          var searchItems = _toConsumableArray(this.Items); // Begin search only if searchTerm is provided


          if (this.searchTerm.trim().length && this.searchTerm !== '') {
            this.Items = searchItems.filter(function (prod) {
              if (prod.Description && prod.Description.length > 1) {
                return prod.Description.toLowerCase().indexOf(_this2.searchTerm.toLowerCase()) > -1;
              }
            });
            return;
          } else {
            // Search Term not provide display all items
            this.initializeItems();
          }
        }
      }, {
        key: "initializeItems",
        value: function initializeItems() {
          var _this3 = this;

          this.itemSub = this.itemService.items.subscribe(function (result) {
            console.log(result);
            _this3.Items = _toConsumableArray(result);
          });
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          if (this.itemSub) {
            this.itemSub.unsubscribe();
          }

          if (this.appSub) {
            this.appSub.unsubscribe();
          }
        }
      }]);

      return ItemsPage;
    }();

    ItemsPage.ctorParameters = function () {
      return [{
        type: _item_service__WEBPACK_IMPORTED_MODULE_2__["ItemService"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"]
      }];
    };

    ItemsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-items',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./items.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/items/items.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./items.page.scss */
      "./src/app/items/items.page.scss"))["default"]]
    })], ItemsPage);
    /***/
  }
}]);
//# sourceMappingURL=items-items-module-es5.js.map