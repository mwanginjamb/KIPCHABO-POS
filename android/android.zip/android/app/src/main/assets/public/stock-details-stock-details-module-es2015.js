(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["stock-details-stock-details-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/stock-details/lines/lines.component.html":
/*!************************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/stock-details/lines/lines.component.html ***!
  \************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar>\r\n    <ion-title>Stock Issue Line</ion-title>\r\n\r\n    <ion-buttons slot=\"primary\">\r\n      <ion-button (click)=\"onCancel()\">\r\n        <ion-icon name=\"close\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <ion-row>\r\n    <ion-col size-sm=\"6\" offset-sm=\"3\">\r\n      <ion-list>\r\n\r\n      \r\n\r\n        <ion-item>\r\n          <ion-label position=\"floating\">Description</ion-label>\r\n          <ion-input [(ngModel)]=\"line.Description\" type=\"text\" readonly></ion-input>\r\n        </ion-item>\r\n\r\n        <ion-item>\r\n          <ion-label  position=\"floating\">Qty. Requested</ion-label>\r\n          <ion-input [(ngModel)]=\"line.Requested_Pieces\" type=\"number\" readonly></ion-input>\r\n        </ion-item>\r\n\r\n        <ion-item>\r\n          <ion-label  position=\"floating\">Qty. Issues</ion-label>\r\n          <ion-input [(ngModel)]=\"line.Issued_Pieces\" type=\"number\" readonly></ion-input>\r\n        </ion-item>\r\n\r\n        <ion-item>\r\n          <ion-label position=\"floating\">Pieces Received</ion-label>\r\n          <ion-input [(ngModel)]=\"line.Pieces_Received\" type=\"number\"></ion-input>\r\n        </ion-item>\r\n      \r\n\r\n        \r\n\r\n\r\n      </ion-list>\r\n\r\n\r\n\r\n      <ion-button  color=\"primary\" (click)=\"updateLine()\" expand=\"block\" fill=\"outline\" >\r\n        Update Line\r\n      </ion-button>\r\n\r\n    </ion-col>\r\n  </ion-row>\r\n\r\n</ion-content>\r\n");

/***/ }),

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/stock-details/stock-details.page.html":
/*!*********************************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/stock-details/stock-details.page.html ***!
  \*********************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button defaultHref=\"requisitions/released-requisitions\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>Shipped Stock Details</ion-title>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content *ngIf=\"card?.Stock_Issue_No\">\r\n\r\n  <ion-refresher slot=\"fixed\" (ionRefresh)=\"refresh($event)\" pullMin=\"100\" pullMax=\"200\">\r\n    <ion-refresher-content pullingIcon=\"arrow-down-outline\" pullingText=\"Pull to Refresh\" refreshingSpinner=\"crescent\"\r\n      refreshingText=\"Refreshing...\">\r\n    </ion-refresher-content>\r\n  </ion-refresher>\r\n\r\n<ion-fab vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\">\r\n  <ion-fab-button color=\"warning\" (click)=\"post(card.Stock_Issue_No)\">\r\n    <ion-icon name=\"send\"></ion-icon>\r\n  </ion-fab-button>\r\n</ion-fab>\r\n\r\n  <ion-grid>\r\n    <ion-row>\r\n      <ion-col >\r\n         <ion-card>\r\n           <ion-card-header>\r\n             <ion-card-title>\r\n               General Card Details\r\n             </ion-card-title>\r\n           </ion-card-header>\r\n\r\n           <ion-card-content>\r\n\r\n             <ion-row>\r\n               <ion-col >\r\n                 <ion-item>\r\n                   <ion-label position=\"fixed\">Issue. No</ion-label>\r\n                   <ion-text>{{ card?.Stock_Issue_No }}</ion-text>\r\n                 </ion-item>\r\n               </ion-col>\r\n\r\n               <ion-col >\r\n                 <ion-item>\r\n                   <ion-label position=\"fixed\">Receiving Store</ion-label>\r\n                   <ion-text>{{ card?.Receiving_Store_Name }}</ion-text>\r\n                 </ion-item>\r\n               </ion-col>\r\n             </ion-row>\r\n\r\n             <ion-row>\r\n               <ion-col >\r\n                 <ion-item>\r\n                   <ion-label position=\"fixed\">Receipt Date</ion-label>\r\n                  <!-- <ion-text>{{ card?.Receipt_Date }}</ion-text>-->\r\n                  <ion-datetime type=\"date\" [(ngModel)]=\"card.Receipt_Date\" (ionChange)=\"onUpdateCard($event)\" name=\"Receipt_Date\">\r\n                  </ion-datetime>\r\n                 </ion-item>\r\n               </ion-col>\r\n\r\n               <ion-col >\r\n                 <ion-item>\r\n                   <ion-label position=\"fixed\">Order No.</ion-label>\r\n                   <ion-text>{{ card?.Order_No }}</ion-text>\r\n                 </ion-item>\r\n               </ion-col>\r\n             </ion-row>\r\n\r\n            \r\n\r\n             \r\n\r\n            \r\n           </ion-card-content>\r\n\r\n         </ion-card> \r\n\r\n         <!--Start Lines Card-->\r\n         <ion-card>\r\n           <ion-card-header>\r\n             <ion-card-title>Lines</ion-card-title>\r\n           </ion-card-header>\r\n           <ion-card-content>\r\n             <ion-grid>\r\n               \r\n\r\n               <ion-row scrollX=\"true\">\r\n                 <ion-col>\r\n                   <ion-label>Description</ion-label>\r\n                 </ion-col>\r\n\r\n                 \r\n                 <ion-col>\r\n                   <ion-label>Requested</ion-label>\r\n                 </ion-col>\r\n\r\n                 \r\n                 <ion-col>\r\n                   <ion-label>Issued</ion-label>\r\n                 </ion-col>\r\n\r\n                 <ion-col>\r\n                  <ion-label>Received</ion-label>\r\n                </ion-col>\r\n\r\n                \r\n\r\n               </ion-row>\r\n             \r\n                \r\n              \r\n               <ion-list *ngFor=\"let item of card ?.Point_Of_Sale_Issue_Line_Ship ?.Point_Of_Sale_Issue_Line_Ship\">\r\n                   <ion-row >\r\n                     <ion-col> \r\n                      <ion-item (click)=\"onUpdateLine(item?.Key)\" color=\"primary\">\r\n                           <ion-label>{{item.Description}}</ion-label>\r\n                       </ion-item>\r\n                     </ion-col>\r\n \r\n                    \r\n \r\n                     \r\n \r\n                     <ion-col> \r\n                       <ion-item>                         \r\n                           <ion-label>{{item.Requested_Pieces}}</ion-label>\r\n                       </ion-item>\r\n                     </ion-col>\r\n \r\n                     \r\n \r\n                     <ion-col> \r\n                       <ion-item>                         \r\n                           <ion-label>{{item.Issued_Pieces}}</ion-label>\r\n                       </ion-item>\r\n                     </ion-col>\r\n\r\n                     <ion-col> \r\n                      <ion-item>                         \r\n                          <ion-label>{{item.Pieces_Received}}</ion-label>\r\n                      </ion-item>\r\n                    </ion-col>\r\n \r\n                     \r\n \r\n                   </ion-row>   \r\n               </ion-list>\r\n                \r\n               \r\n             </ion-grid>\r\n           </ion-card-content>\r\n         </ion-card>\r\n         <!--End Lines Card-->\r\n      </ion-col>\r\n    </ion-row>\r\n </ion-grid>\r\n\r\n</ion-content>\r\n");

/***/ }),

/***/ "./src/app/models/stockissueline.model.ts":
/*!************************************************!*\
  !*** ./src/app/models/stockissueline.model.ts ***!
  \************************************************/
/*! exports provided: Stockissueline */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Stockissueline", function() { return Stockissueline; });
class Stockissueline {
    constructor(Key, Item_No, Description, Requested_Pieces, Issued_Pieces, Pieces_Received, Stock_Issue_No) {
        this.Key = Key;
        this.Item_No = Item_No;
        this.Description = Description;
        this.Requested_Pieces = Requested_Pieces;
        this.Issued_Pieces = Issued_Pieces;
        this.Pieces_Received = Pieces_Received;
        this.Stock_Issue_No = Stock_Issue_No;
    }
}


/***/ }),

/***/ "./src/app/stock-details/lines/lines.component.scss":
/*!**********************************************************!*\
  !*** ./src/app/stock-details/lines/lines.component.scss ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3N0b2NrLWRldGFpbHMvbGluZXMvbGluZXMuY29tcG9uZW50LnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/stock-details/lines/lines.component.ts":
/*!********************************************************!*\
  !*** ./src/app/stock-details/lines/lines.component.ts ***!
  \********************************************************/
/*! exports provided: LinesComponent */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "LinesComponent", function() { return LinesComponent; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var src_app_models_stockissueline_model__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/app/models/stockissueline.model */ "./src/app/models/stockissueline.model.ts");
/* harmony import */ var _stockdetail_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../stockdetail.service */ "./src/app/stock-details/stockdetail.service.ts");





let LinesComponent = class LinesComponent {
    constructor(stockService, modalCtrl, toastCtrl, alertCtrl) {
        this.stockService = stockService;
        this.modalCtrl = modalCtrl;
        this.toastCtrl = toastCtrl;
        this.alertCtrl = alertCtrl;
        this.line = new src_app_models_stockissueline_model__WEBPACK_IMPORTED_MODULE_3__["Stockissueline"]();
    }
    ngOnInit() {
        console.log(this.Key);
        if (this.Key) {
            this.FetchLinetoUpdate();
        }
    }
    updateLine() {
        this.stockService.updateRequisitionLine(this.line).subscribe(line => {
            if (typeof line !== 'string') {
                console.log(`Updated Line.......`);
                console.table(line);
                this.toastCtrl.create({
                    message: `${line.Description} Requisition Line Updated Successfully.`,
                    duration: 3000,
                    position: 'top'
                }).then((toastData) => {
                    toastData.present();
                });
                this.modalCtrl.dismiss();
                // this.router.navigate(['/requisitions/' + line.Document_No]);
            }
            else {
                // Alert the error
                this.alertCtrl.create({
                    header: 'Operation Error',
                    message: 'Message : ' + line,
                    buttons: [{ text: 'Okay', handler: () => this.modalCtrl.dismiss() }]
                }).then(alertEl => {
                    alertEl.present();
                });
            }
        }, error => {
            console.log(error.error);
            this.alertCtrl.create({
                header: 'Service Error!',
                message: 'Connection problem: ' + error.error,
                buttons: [{ text: 'Okay', handler: () => this.modalCtrl.dismiss() }]
            })
                .then(alertEl => {
                alertEl.present();
            });
        });
    }
    FetchLinetoUpdate() {
        this.updateLineSub = this.stockService.getLine(this.Key)
            .subscribe(res => {
            Object.assign(this.line, res);
        }, error => {
            console.log(error.error);
            this.alertCtrl.create({
                header: 'Service Error!',
                message: 'Connection problem: ' + error.error.message,
                buttons: [{ text: 'Okay', handler: () => this.modalCtrl.dismiss() }]
            })
                .then(alertEl => {
                alertEl.present();
            });
        });
    }
    // Closing component modal
    onCancel() {
        this.modalCtrl.dismiss();
    }
};
LinesComponent.ctorParameters = () => [
    { type: _stockdetail_service__WEBPACK_IMPORTED_MODULE_4__["StockdetailService"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["AlertController"] }
];
Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()
], LinesComponent.prototype, "Key", void 0);
LinesComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-lines',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./lines.component.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/stock-details/lines/lines.component.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./lines.component.scss */ "./src/app/stock-details/lines/lines.component.scss")).default]
    })
], LinesComponent);



/***/ }),

/***/ "./src/app/stock-details/stock-details-routing.module.ts":
/*!***************************************************************!*\
  !*** ./src/app/stock-details/stock-details-routing.module.ts ***!
  \***************************************************************/
/*! exports provided: StockDetailsPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StockDetailsPageRoutingModule", function() { return StockDetailsPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _stock_details_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./stock-details.page */ "./src/app/stock-details/stock-details.page.ts");




const routes = [
    {
        path: ':id',
        component: _stock_details_page__WEBPACK_IMPORTED_MODULE_3__["StockDetailsPage"]
    }
];
let StockDetailsPageRoutingModule = class StockDetailsPageRoutingModule {
};
StockDetailsPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], StockDetailsPageRoutingModule);



/***/ }),

/***/ "./src/app/stock-details/stock-details.module.ts":
/*!*******************************************************!*\
  !*** ./src/app/stock-details/stock-details.module.ts ***!
  \*******************************************************/
/*! exports provided: StockDetailsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StockDetailsPageModule", function() { return StockDetailsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var _stock_details_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./stock-details-routing.module */ "./src/app/stock-details/stock-details-routing.module.ts");
/* harmony import */ var _stock_details_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./stock-details.page */ "./src/app/stock-details/stock-details.page.ts");
/* harmony import */ var _lines_lines_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./lines/lines.component */ "./src/app/stock-details/lines/lines.component.ts");








let StockDetailsPageModule = class StockDetailsPageModule {
};
StockDetailsPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _stock_details_routing_module__WEBPACK_IMPORTED_MODULE_5__["StockDetailsPageRoutingModule"]
        ],
        declarations: [_stock_details_page__WEBPACK_IMPORTED_MODULE_6__["StockDetailsPage"], _lines_lines_component__WEBPACK_IMPORTED_MODULE_7__["LinesComponent"]],
        entryComponents: [_lines_lines_component__WEBPACK_IMPORTED_MODULE_7__["LinesComponent"]],
    })
], StockDetailsPageModule);



/***/ }),

/***/ "./src/app/stock-details/stock-details.page.scss":
/*!*******************************************************!*\
  !*** ./src/app/stock-details/stock-details.page.scss ***!
  \*******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3N0b2NrLWRldGFpbHMvc3RvY2stZGV0YWlscy5wYWdlLnNjc3MifQ== */");

/***/ }),

/***/ "./src/app/stock-details/stock-details.page.ts":
/*!*****************************************************!*\
  !*** ./src/app/stock-details/stock-details.page.ts ***!
  \*****************************************************/
/*! exports provided: StockDetailsPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StockDetailsPage", function() { return StockDetailsPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _lines_lines_component__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./lines/lines.component */ "./src/app/stock-details/lines/lines.component.ts");
/* harmony import */ var _stockdetail_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./stockdetail.service */ "./src/app/stock-details/stockdetail.service.ts");







let StockDetailsPage = class StockDetailsPage {
    constructor(stockService, activatedRoute, modalCtrl, loadingCtrl, alertCtrl, toastCtrl) {
        this.stockService = stockService;
        this.activatedRoute = activatedRoute;
        this.modalCtrl = modalCtrl;
        this.loadingCtrl = loadingCtrl;
        this.alertCtrl = alertCtrl;
        this.toastCtrl = toastCtrl;
    }
    ngOnInit() {
        // this.presentLoading();
        this.id = this.activatedRoute.snapshot.paramMap.get('id');
        // console.log(this.id);
        this.cardSub = this.stockService.requisitioncard(this.id)
            .pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["finalize"])(() => Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            yield this.loading.dismiss();
        })))
            .subscribe(cardInfo => {
            this.card = cardInfo;
            console.log(this.card);
        });
    }
    refresh(event) {
        this.cardSub = this.stockService.requisitioncard(this.id).subscribe(result => {
            this.card = result;
            if (event) {
                event.target.complete();
            }
        });
    }
    onUpdateLine(Key) {
        this.modalCtrl.create({
            component: _lines_lines_component__WEBPACK_IMPORTED_MODULE_5__["LinesComponent"],
            componentProps: { Key }
        })
            .then(modalEl => {
            modalEl.present();
        });
    }
    onUpdateCard(event) {
        let issue_date = event.target.value;
        this.card.Receipt_Date = this.stockService.formatDate(issue_date);
        this.stockService.updateStockIssue(this.card).subscribe(line => {
            if (typeof line !== 'string') {
                this.toastCtrl.create({
                    message: `Document ${line.Stock_Issue_No}  Updated Successfully.`,
                    duration: 3000,
                    position: 'top'
                }).then((toastData) => {
                    toastData.present();
                });
                this.modalCtrl.dismiss();
                // this.router.navigate(['/requisitions/' + line.Document_No]);
            }
            else {
                // Alert the error
                this.alertCtrl.create({
                    header: 'Operation Error',
                    message: 'Error : ' + line,
                    buttons: [{ text: 'Okay', handler: () => this.modalCtrl.dismiss() }]
                }).then(alertEl => {
                    alertEl.present();
                });
            }
        }, error => {
            console.log(error.error);
            this.alertCtrl.create({
                header: 'Service Error!',
                message: 'Connection problem: ' + error.message,
                buttons: [{ text: 'Okay', handler: () => this.modalCtrl.dismiss() }]
            })
                .then(alertEl => {
                alertEl.present();
            });
        });
    }
    presentLoading(message) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            this.loading = yield this.loadingCtrl.create({
                spinner: 'dots',
                animated: true,
                message: (message) ? message : 'Loading Data...'
            });
            yield this.loading.present();
        });
    }
    post(ReceiptNo) {
        console.log(ReceiptNo);
        this.stockService.acknowledgeStockIssue(ReceiptNo).subscribe(res => {
            if (typeof res === 'string') { // a string response represents a Nav Error, so we display it.
                this.alertCtrl.create({
                    header: 'Service Warning!',
                    message: res,
                    buttons: [{ text: 'Okay' }]
                }).then(alertEl => {
                    alertEl.present();
                });
            }
            else {
                // alert(res);
                this.stockService.showToast(`Document Posted Successfully.`);
            }
        }, error => {
            alert(error);
        });
    }
};
StockDetailsPage.ctorParameters = () => [
    { type: _stockdetail_service__WEBPACK_IMPORTED_MODULE_6__["StockdetailService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["ActivatedRoute"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["AlertController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"] }
];
StockDetailsPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-stock-details',
        template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! raw-loader!./stock-details.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/stock-details/stock-details.page.html")).default,
        styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(/*! ./stock-details.page.scss */ "./src/app/stock-details/stock-details.page.scss")).default]
    })
], StockDetailsPage);



/***/ }),

/***/ "./src/app/stock-details/stockdetail.service.ts":
/*!******************************************************!*\
  !*** ./src/app/stock-details/stockdetail.service.ts ***!
  \******************************************************/
/*! exports provided: StockdetailService */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "StockdetailService", function() { return StockdetailService; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_common_http__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/common/http */ "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/http.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
/* harmony import */ var src_environments_environment__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! src/environments/environment */ "./src/environments/environment.ts");
/* harmony import */ var rxjs_operators__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/operators */ "./node_modules/rxjs/_esm2015/operators/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");






let StockdetailService = class StockdetailService {
    constructor(http, toastCtrl) {
        this.http = http;
        this.toastCtrl = toastCtrl;
        this.url = src_environments_environment__WEBPACK_IMPORTED_MODULE_3__["environment"].url;
    }
    get releasedrequisitions() {
        return this.http.get(`${this.url}site/releasedrequisitions`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    // Retrieve Stock Issue Card / Details
    requisitioncard(id) {
        return this.http.get(`${this.url}site/stockissue/?id=${id}`);
    }
    // Create New Requisition
    createRequisition() {
        return this.http.get(`${this.url}site/create-requisition`);
    }
    //Update Stock Issue
    updateStockIssue(Card) {
        return this.http.post(`${this.url}site/stock-issue-card`, JSON.stringify(Card));
    }
    // get Units of Measure
    getunits(itemNo) {
        return this.http.get(`${this.url}site/unitmeasure?itemNo=${itemNo}`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    // Get Locations List
    getLocations() {
        return this.http.get(`${this.url}site/locationlist`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    // Get any items from generic service getter function
    get Dimensions() {
        return this.http.get(`${this.url}site/get?service=Dimensions`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    get Departments() {
        return this.http.get(`${this.url}site/departments`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    get Projects() {
        return this.http.get(`${this.url}site/projects`).pipe(Object(rxjs_operators__WEBPACK_IMPORTED_MODULE_4__["take"])(1));
    }
    // Post Lines Data
    postLine(line) {
        return this.http.post(`${this.url}site/addline`, JSON.stringify(line));
    }
    // Update Line
    updateRequisitionLine(line) {
        return this.http.post(`${this.url}site/updateissueline`, JSON.stringify(line));
    }
    // Fetch Line to Update
    getLine(Key) {
        return this.http.get(`${this.url}site/stock-issue-line?Key=${Key}`);
    }
    // Post Requisition Header
    postRequisition(requisition) {
        return this.http.post(`${this.url}site/update-requisition`, JSON.stringify(requisition));
    }
    // Format date utility
    formatDate(datestring) {
        // Format Date to YYYY-MM-DD
        const recDate = new Date(datestring);
        const month = (recDate.getMonth() + 1) > 9 ? recDate.getMonth() + 1 : `0` + (recDate.getMonth() + 1);
        const day = (recDate.getDate()) > 9 ? recDate.getDate() : `0` + recDate.getDate();
        return `${recDate.getFullYear()}-${month}-${day}`;
    }
    acknowledgeStockIssue(No) {
        return this.http.get(`${this.url}site/acknowledge-stock-issue?No=${No}`);
    }
    postDocument(No) {
        return this.http.get(`${this.url}site/acknowledge-stock-issue?No=${No}`);
    }
    showToast(text) {
        return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, function* () {
            return yield this.toastCtrl.create({
                message: text,
                duration: 4000,
                position: 'top'
            }).then(toastEl => {
                toastEl.present();
            });
        });
    }
};
StockdetailService.ctorParameters = () => [
    { type: _angular_common_http__WEBPACK_IMPORTED_MODULE_1__["HttpClient"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ToastController"] }
];
StockdetailService = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Injectable"])({
        providedIn: 'root'
    })
], StockdetailService);



/***/ })

}]);
//# sourceMappingURL=stock-details-stock-details-module-es2015.js.map