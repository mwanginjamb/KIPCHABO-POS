function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["default~postedsalesinvoices-sale-detail-sale-detail-module~sale-detail-sale-detail-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/postedsalesinvoices/sale-detail/sale-detail.page.html":
  /*!*************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/postedsalesinvoices/sale-detail/sale-detail.page.html ***!
    \*************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPostedsalesinvoicesSaleDetailSaleDetailPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header>\r\n  <ion-toolbar color=\"warning\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-back-button defaultHref=\"postedsales\"></ion-back-button>\r\n    </ion-buttons>\r\n    <ion-title>Posted Sales Invoice - {{ card.No}}</ion-title>\r\n    <ion-buttons slot=\"end\">\r\n      <ion-button slot=\"icon-only\" fill=\"clear\" (click)=\"presentPopover($event)\">\r\n        <ion-icon  name=\"ellipsis-vertical-outline\"></ion-icon>\r\n      </ion-button>      \r\n    </ion-buttons>\r\n  </ion-toolbar>\r\n</ion-header>\r\n\r\n<ion-content>\r\n\r\n  <ion-grid>\r\n    <ion-row>\r\n      <ion-col >\r\n         <ion-card>\r\n           <ion-card-header>\r\n             <ion-card-title>\r\n               General Card Details\r\n             </ion-card-title>\r\n           </ion-card-header>\r\n\r\n           <ion-card-content>\r\n\r\n             <ion-row>\r\n               <ion-col >\r\n                 <ion-item>\r\n                   <ion-label position=\"floating\">Customer.</ion-label>\r\n                   <ion-input [(ngModel)]=\"card.Sell_to_Customer_Name\"></ion-input>\r\n                 </ion-item>\r\n               </ion-col>\r\n\r\n               <ion-col >\r\n                 <ion-item>\r\n                   <ion-label position=\"floating\">Due Date</ion-label>\r\n                   <ion-input [value]=\"card.Due_Date | date\"></ion-input>\r\n                 </ion-item>\r\n               </ion-col>\r\n             </ion-row>\r\n\r\n             \r\n\r\n\r\n             <ion-row>\r\n               <ion-col >\r\n                 <ion-item>\r\n                   <ion-label position=\"floating\">Posting Date: </ion-label>\r\n                   <ion-input [value]=\"card.Posting_Date | date\"></ion-input>\r\n                 </ion-item>\r\n               </ion-col>\r\n\r\n               <ion-col >\r\n                 <ion-item>\r\n                   <ion-label position=\"floating\">Closed:</ion-label>\r\n                   <ion-input [value]=\"card.Closed?'Yes':'No'\"></ion-input>\r\n                 </ion-item>\r\n               </ion-col>\r\n             </ion-row>\r\n\r\n            \r\n\r\n           </ion-card-content>\r\n\r\n         </ion-card>\r\n\r\n\r\n          <!--Start Lines Card-->\r\n          <ion-card>\r\n            <ion-card-header>\r\n              <ion-card-title>Lines</ion-card-title>\r\n            </ion-card-header>\r\n            <ion-card-content>\r\n              <ion-grid>\r\n                \r\n\r\n                <ion-row scrollX=\"true\">\r\n                  <ion-col>\r\n                    <ion-label>Description</ion-label>\r\n                  </ion-col>\r\n\r\n                  <ion-col>\r\n                    <ion-label>Quantity</ion-label>\r\n                  </ion-col>\r\n\r\n                  <!--<ion-col>\r\n                    <ion-label>Unit </ion-label>\r\n                  </ion-col>-->\r\n\r\n                  <ion-col>\r\n                    <ion-label>Unit Price</ion-label>\r\n                  </ion-col>\r\n\r\n                <ion-col>\r\n                    <ion-label>Line Amt. Incl. VAT </ion-label>\r\n                  </ion-col>\r\n\r\n                  <!--<ion-col>\r\n                    <ion-label>Discount %</ion-label>\r\n                  </ion-col>-->\r\n\r\n                </ion-row>\r\n              \r\n                 \r\n               \r\n                <ion-list *ngFor=\"let line of card?.SalesInvLines?.Posted_Sales_Invoice_Line\">\r\n                    <ion-row >\r\n                        \r\n                      <ion-col> \r\n                        <ion-item>                         \r\n                            <ion-label>{{line.Description}}</ion-label>\r\n                        </ion-item>\r\n                      </ion-col>\r\n  \r\n                      <ion-col> \r\n                        <ion-item>                         \r\n                            <ion-label>{{line.Quantity}}</ion-label>\r\n                        </ion-item>\r\n                      </ion-col>\r\n  \r\n                      <!--<ion-col> \r\n                        <ion-item>                         \r\n                            <ion-label>{{line.Unit_of_Measure_Code}}</ion-label>\r\n                        </ion-item>\r\n                      </ion-col>-->\r\n\r\n                      <ion-col> \r\n                        <ion-item>                         \r\n                          <ion-label>{{line.Unit_Price}}</ion-label>\r\n                        </ion-item>\r\n                      </ion-col>\r\n  \r\n                      <ion-col > \r\n                        <ion-item>                         \r\n                            <ion-label>{{ line.Line_Amount }}</ion-label>\r\n                        </ion-item>\r\n                      </ion-col>\r\n\r\n                      <!---<ion-col > \r\n                        <ion-item>                         \r\n                          <ion-label>{{ line.Line_Discount_Percent}}</ion-label>\r\n                        </ion-item>\r\n                      </ion-col>-->\r\n\r\n                      \r\n  \r\n                     \r\n  \r\n                    </ion-row>   \r\n                </ion-list>\r\n                 \r\n                \r\n              </ion-grid>\r\n            </ion-card-content>\r\n          </ion-card>\r\n          <!--End Lines Card-->\r\n\r\n      </ion-col>\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/postedsalesinvoices/sales-popover/sales-popover.component.html":
  /*!**********************************************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/postedsalesinvoices/sales-popover/sales-popover.component.html ***!
    \**********************************************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppPostedsalesinvoicesSalesPopoverSalesPopoverComponentHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-list>\r\n  <ion-item lines=\"none\">\r\n    <ion-icon slot=\"start\" name=\"print\"></ion-icon>\r\n    <ion-label (click)=\"showBluetoothDevices()\">Print Invoice</ion-label>\r\n  </ion-item>\r\n\r\n  <ion-item lines=\"none\">\r\n    <ion-icon slot=\"start\" name=\"copy\"></ion-icon>\r\n    <ion-label (click)=\"showDaily()\">Daily Sales Report</ion-label>\r\n  </ion-item>\r\n\r\n  <ion-item lines=\"none\">\r\n    <ion-icon slot=\"start\" name=\"copy\"></ion-icon>\r\n    <ion-label (click)=\"showMonthly()\">Monthly Sales Report</ion-label>\r\n  </ion-item>\r\n  \r\n</ion-list>";
    /***/
  },

  /***/
  "./src/app/models/postedsalesinvoice.model.ts":
  /*!****************************************************!*\
    !*** ./src/app/models/postedsalesinvoice.model.ts ***!
    \****************************************************/

  /*! exports provided: Postedsalesinvoice */

  /***/
  function srcAppModelsPostedsalesinvoiceModelTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "Postedsalesinvoice", function () {
      return Postedsalesinvoice;
    });

    var Postedsalesinvoice = function Postedsalesinvoice(Key, No, Customer_No, Customer_Name, Posting_Date, Amount, Sell_to_Customer_Name, Sell_to_Address, Sell_to_Address_2, Sell_to_Post_Code, Sell_to_City, Sell_to_Contact_No, Sell_to_Contact, Document_Date, Due_Date, Document_Exchange_Status, Quote_No, Order_No, Pre_Assigned_No, External_Document_No, Salesperson_Code, Responsibility_Center, No_Printed, Cancelled, Corrective, Closed, GetWorkDescription, Currency_Code, Shipment_Date, Payment_Terms_Code, Payment_Method_Code, SelectedPayments, Shortcut_Dimension_1_Code, Shortcut_Dimension_2_Code, Payment_Discount_Percent, Pmt_Discount_Date, Direct_Debit_Mandate_ID, Location_Code, Shipment_Method_Code, Shipping_Agent_Code, Package_Tracking_No, Ship_to_Code, Ship_to_Name, Ship_to_Address, Ship_to_Address_2, Ship_to_Post_Code, Ship_to_City, Ship_to_Contact, Bill_to_Name, Bill_to_Address, Bill_to_Address_2, Bill_to_Post_Code, Bill_to_City, Bill_to_Contact_No, Bill_to_Contact, EU_3_Party_Trade, Transaction_Specification, Transport_Method, Exit_Point, Area, SalesInvLines) {
      _classCallCheck(this, Postedsalesinvoice);

      this.Key = Key;
      this.No = No;
      this.Customer_No = Customer_No;
      this.Customer_Name = Customer_Name;
      this.Posting_Date = Posting_Date;
      this.Amount = Amount;
      this.Sell_to_Customer_Name = Sell_to_Customer_Name;
      this.Sell_to_Address = Sell_to_Address;
      this.Sell_to_Address_2 = Sell_to_Address_2;
      this.Sell_to_Post_Code = Sell_to_Post_Code;
      this.Sell_to_City = Sell_to_City;
      this.Sell_to_Contact_No = Sell_to_Contact_No;
      this.Sell_to_Contact = Sell_to_Contact;
      this.Document_Date = Document_Date;
      this.Due_Date = Due_Date;
      this.Document_Exchange_Status = Document_Exchange_Status;
      this.Quote_No = Quote_No;
      this.Order_No = Order_No;
      this.Pre_Assigned_No = Pre_Assigned_No;
      this.External_Document_No = External_Document_No;
      this.Salesperson_Code = Salesperson_Code;
      this.Responsibility_Center = Responsibility_Center;
      this.No_Printed = No_Printed;
      this.Cancelled = Cancelled;
      this.Corrective = Corrective;
      this.Closed = Closed;
      this.GetWorkDescription = GetWorkDescription;
      this.Currency_Code = Currency_Code;
      this.Shipment_Date = Shipment_Date;
      this.Payment_Terms_Code = Payment_Terms_Code;
      this.Payment_Method_Code = Payment_Method_Code;
      this.SelectedPayments = SelectedPayments;
      this.Shortcut_Dimension_1_Code = Shortcut_Dimension_1_Code;
      this.Shortcut_Dimension_2_Code = Shortcut_Dimension_2_Code;
      this.Payment_Discount_Percent = Payment_Discount_Percent;
      this.Pmt_Discount_Date = Pmt_Discount_Date;
      this.Direct_Debit_Mandate_ID = Direct_Debit_Mandate_ID;
      this.Location_Code = Location_Code;
      this.Shipment_Method_Code = Shipment_Method_Code;
      this.Shipping_Agent_Code = Shipping_Agent_Code;
      this.Package_Tracking_No = Package_Tracking_No;
      this.Ship_to_Code = Ship_to_Code;
      this.Ship_to_Name = Ship_to_Name;
      this.Ship_to_Address = Ship_to_Address;
      this.Ship_to_Address_2 = Ship_to_Address_2;
      this.Ship_to_Post_Code = Ship_to_Post_Code;
      this.Ship_to_City = Ship_to_City;
      this.Ship_to_Contact = Ship_to_Contact;
      this.Bill_to_Name = Bill_to_Name;
      this.Bill_to_Address = Bill_to_Address;
      this.Bill_to_Address_2 = Bill_to_Address_2;
      this.Bill_to_Post_Code = Bill_to_Post_Code;
      this.Bill_to_City = Bill_to_City;
      this.Bill_to_Contact_No = Bill_to_Contact_No;
      this.Bill_to_Contact = Bill_to_Contact;
      this.EU_3_Party_Trade = EU_3_Party_Trade;
      this.Transaction_Specification = Transaction_Specification;
      this.Transport_Method = Transport_Method;
      this.Exit_Point = Exit_Point;
      this.Area = Area;
      this.SalesInvLines = SalesInvLines;
    };
    /***/

  },

  /***/
  "./src/app/postedsalesinvoices/sale-detail/sale-detail-routing.module.ts":
  /*!*******************************************************************************!*\
    !*** ./src/app/postedsalesinvoices/sale-detail/sale-detail-routing.module.ts ***!
    \*******************************************************************************/

  /*! exports provided: SaleDetailPageRoutingModule */

  /***/
  function srcAppPostedsalesinvoicesSaleDetailSaleDetailRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SaleDetailPageRoutingModule", function () {
      return SaleDetailPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _sale_detail_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./sale-detail.page */
    "./src/app/postedsalesinvoices/sale-detail/sale-detail.page.ts");

    var routes = [{
      path: '',
      component: _sale_detail_page__WEBPACK_IMPORTED_MODULE_3__["SaleDetailPage"]
    }];

    var SaleDetailPageRoutingModule = function SaleDetailPageRoutingModule() {
      _classCallCheck(this, SaleDetailPageRoutingModule);
    };

    SaleDetailPageRoutingModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], SaleDetailPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/postedsalesinvoices/sale-detail/sale-detail.module.ts":
  /*!***********************************************************************!*\
    !*** ./src/app/postedsalesinvoices/sale-detail/sale-detail.module.ts ***!
    \***********************************************************************/

  /*! exports provided: SaleDetailPageModule */

  /***/
  function srcAppPostedsalesinvoicesSaleDetailSaleDetailModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SaleDetailPageModule", function () {
      return SaleDetailPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/__ivy_ngcc__/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/__ivy_ngcc__/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _sale_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./sale-detail-routing.module */
    "./src/app/postedsalesinvoices/sale-detail/sale-detail-routing.module.ts");
    /* harmony import */


    var _sale_detail_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./sale-detail.page */
    "./src/app/postedsalesinvoices/sale-detail/sale-detail.page.ts");
    /* harmony import */


    var _sales_popover_sales_popover_component__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! ../sales-popover/sales-popover.component */
    "./src/app/postedsalesinvoices/sales-popover/sales-popover.component.ts");

    var SaleDetailPageModule = function SaleDetailPageModule() {
      _classCallCheck(this, SaleDetailPageModule);
    };

    SaleDetailPageModule = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _sale_detail_routing_module__WEBPACK_IMPORTED_MODULE_5__["SaleDetailPageRoutingModule"]],
      entryComponents: [_sales_popover_sales_popover_component__WEBPACK_IMPORTED_MODULE_7__["SalesPopoverComponent"]],
      declarations: [_sale_detail_page__WEBPACK_IMPORTED_MODULE_6__["SaleDetailPage"], _sales_popover_sales_popover_component__WEBPACK_IMPORTED_MODULE_7__["SalesPopoverComponent"]]
    })], SaleDetailPageModule);
    /***/
  },

  /***/
  "./src/app/postedsalesinvoices/sale-detail/sale-detail.page.scss":
  /*!***********************************************************************!*\
    !*** ./src/app/postedsalesinvoices/sale-detail/sale-detail.page.scss ***!
    \***********************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPostedsalesinvoicesSaleDetailSaleDetailPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3Bvc3RlZHNhbGVzaW52b2ljZXMvc2FsZS1kZXRhaWwvc2FsZS1kZXRhaWwucGFnZS5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/postedsalesinvoices/sale-detail/sale-detail.page.ts":
  /*!*********************************************************************!*\
    !*** ./src/app/postedsalesinvoices/sale-detail/sale-detail.page.ts ***!
    \*********************************************************************/

  /*! exports provided: SaleDetailPage */

  /***/
  function srcAppPostedsalesinvoicesSaleDetailSaleDetailPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SaleDetailPage", function () {
      return SaleDetailPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var src_app_models_postedsalesinvoice_model__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! src/app/models/postedsalesinvoice.model */
    "./src/app/models/postedsalesinvoice.model.ts");
    /* harmony import */


    var _sales_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../sales.service */
    "./src/app/postedsalesinvoices/sales.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _sales_popover_sales_popover_component__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ../sales-popover/sales-popover.component */
    "./src/app/postedsalesinvoices/sales-popover/sales-popover.component.ts");

    var SaleDetailPage = /*#__PURE__*/function () {
      function SaleDetailPage(salesService, activatedRoute, popoverCtrl, modalCtrl) {
        _classCallCheck(this, SaleDetailPage);

        this.salesService = salesService;
        this.activatedRoute = activatedRoute;
        this.popoverCtrl = popoverCtrl;
        this.modalCtrl = modalCtrl;
        this.No = null;
        this.card = new src_app_models_postedsalesinvoice_model__WEBPACK_IMPORTED_MODULE_2__["Postedsalesinvoice"]();
      }

      _createClass(SaleDetailPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.No = this.activatedRoute.snapshot.paramMap.get('id');
          console.log(this.No);
          this.FetchCard();
        }
      }, {
        key: "ionViewWillLoad",
        value: function ionViewWillLoad() {
          this.FetchCard();
        }
      }, {
        key: "ionViewDidLoad",
        value: function ionViewDidLoad() {
          this.FetchCard();
        }
      }, {
        key: "FetchCard",
        value: function FetchCard() {
          var _this = this;

          this.cardSub = this.salesService.getSale(this.No).subscribe(function (result) {
            _this.card = result;
            console.log(_this.card);
          });
        }
      }, {
        key: "presentPopover",
        value: function presentPopover(event) {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.popoverCtrl.create({
                      component: _sales_popover_sales_popover_component__WEBPACK_IMPORTED_MODULE_6__["SalesPopoverComponent"],
                      componentProps: {
                        No: this.No,
                        Card: this.card
                      },
                      event: event
                    }).then(function (pop) {
                      pop.present();
                    });

                  case 2:
                    return _context.abrupt("return", _context.sent);

                  case 3:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "ngOnDestroy",
        value: function ngOnDestroy() {
          if (this.cardSub) {
            this.cardSub.unsubscribe();
          }
        }
      }]);

      return SaleDetailPage;
    }();

    SaleDetailPage.ctorParameters = function () {
      return [{
        type: _sales_service__WEBPACK_IMPORTED_MODULE_3__["SalesService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["ActivatedRoute"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["PopoverController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_5__["ModalController"]
      }];
    };

    SaleDetailPage = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-sale-detail',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./sale-detail.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/postedsalesinvoices/sale-detail/sale-detail.page.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./sale-detail.page.scss */
      "./src/app/postedsalesinvoices/sale-detail/sale-detail.page.scss"))["default"]]
    })], SaleDetailPage);
    /***/
  },

  /***/
  "./src/app/postedsalesinvoices/sales-popover/sales-popover.component.scss":
  /*!********************************************************************************!*\
    !*** ./src/app/postedsalesinvoices/sales-popover/sales-popover.component.scss ***!
    \********************************************************************************/

  /*! exports provided: default */

  /***/
  function srcAppPostedsalesinvoicesSalesPopoverSalesPopoverComponentScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IiIsImZpbGUiOiJzcmMvYXBwL3Bvc3RlZHNhbGVzaW52b2ljZXMvc2FsZXMtcG9wb3Zlci9zYWxlcy1wb3BvdmVyLmNvbXBvbmVudC5zY3NzIn0= */";
    /***/
  },

  /***/
  "./src/app/postedsalesinvoices/sales-popover/sales-popover.component.ts":
  /*!******************************************************************************!*\
    !*** ./src/app/postedsalesinvoices/sales-popover/sales-popover.component.ts ***!
    \******************************************************************************/

  /*! exports provided: SalesPopoverComponent */

  /***/
  function srcAppPostedsalesinvoicesSalesPopoverSalesPopoverComponentTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "SalesPopoverComponent", function () {
      return SalesPopoverComponent;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/__ivy_ngcc__/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/__ivy_ngcc__/fesm2015/ionic-angular.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/__ivy_ngcc__/fesm2015/router.js");

    var SalesPopoverComponent = /*#__PURE__*/function () {
      function SalesPopoverComponent(modalCtrl, router) {
        _classCallCheck(this, SalesPopoverComponent);

        this.modalCtrl = modalCtrl;
        this.router = router;
      }

      _createClass(SalesPopoverComponent, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "showBluetoothDevices",
        value: function showBluetoothDevices() {
          return Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"])(this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2);
          }));
        }
      }, {
        key: "showDaily",
        value: function showDaily() {
          return this.router.navigate(['./postedsales/dailyreport']);
        }
      }, {
        key: "showMonthly",
        value: function showMonthly() {
          return this.router.navigate(['./postedsales/monthlyreport']);
        }
      }]);

      return SalesPopoverComponent;
    }();

    SalesPopoverComponent.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["ModalController"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_3__["Router"]
      }];
    };

    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], SalesPopoverComponent.prototype, "No", void 0);
    Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Input"])()], SalesPopoverComponent.prototype, "Card", void 0);
    SalesPopoverComponent = Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"])([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-sales-popover',
      template: Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! raw-loader!./sales-popover.component.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/postedsalesinvoices/sales-popover/sales-popover.component.html"))["default"],
      styles: [Object(tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"])(__webpack_require__(
      /*! ./sales-popover.component.scss */
      "./src/app/postedsalesinvoices/sales-popover/sales-popover.component.scss"))["default"]]
    })], SalesPopoverComponent);
    /***/
  }
}]);
//# sourceMappingURL=default~postedsalesinvoices-sale-detail-sale-detail-module~sale-detail-sale-detail-module-es5.js.map